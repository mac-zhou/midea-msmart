var mdSmartios = mdSmartios || {};
window.mdSmartios=mdSmartios;
(function(mdSmartios) {
    if (mdSmartios.bridge) {
        return;
    }
    mdSmartios.bridge = mdSmartios.bridge || {};
    mdSmartios.bridge.callbackFunctions = {};
    mdSmartios.bridge.callbackFailFunctions = {};
    mdSmartios.bridge.setCardTitleCBF = undefined;
    
    /*
      operation 接口名
      params 传参
    */
    mdSmartios.bridge.commandInterface = function(operation, params, callback, callbackFail) {
        var param = {};
        param.operation = operation;
        param.params = params;
        param.cammandId = Math.floor(Math.random() * 10000);
        var commandIds = param.cammandId;
        var p = JSON.stringify(param);
        if (typeof callback == "function") {
            mdSmartios.bridge.callbackFunctions[commandIds] = callback;
        }
        var commandId = mdSmartios.bridge.po._execObjcMethod('commandInterface', p);
        return commandId;
    };

    mdSmartios.bridge.getDeviceSN = function(callback, callbackFail) {
        var param={};
        param.cammandId = Math.floor(Math.random() * 1000);
        var commandIds = param.cammandId;
        var p = JSON.stringify(param);
        console.log(p);

        if ( typeof callback == "function") {
            mdSmartios.bridge.callbackFunctions[commandIds] = callback;
        }

        if ( typeof callbackFail == "function") {
            mdSmartios.bridge.callbackFailFunctions[commandIds] = callbackFail;
        }

        var commandId = mdSmartios.bridge.po._execObjcMethod('getDeviceSN', p);

        return commandId;
    };

    mdSmartios.bridge.getCardTitle = function(callback) {
        var param = {};
        var p = JSON.stringify(param);
        if ( typeof callback == "function") {
            mdSmartios.bridge.setCardTitleCBF = callback;
        }
        var commandId = mdSmartios.bridge.po._execObjcMethod('getCardTitle', p);
        return commandId;
    };

    //卡片的标题(IOS调用：回复getCardTitle)
    mdSmartios.bridge.setCardTitle = function(message) {
        var jsonResult = JSON.parse(message);
        if ( typeof mdSmartios.bridge.setCardTitleCBF == "function") {
            mdSmartios.bridge.setCardTitleCBF(jsonResult.messageBody);
        }
    };

    mdSmartios.bridge.showControlPanelPage = function(pageParamers) {
        var p = JSON.stringify({
            pageParameters : pageParamers
        });
        return mdSmartios.bridge.po._execObjcMethod('showControlPanelPage', p);
    };

    mdSmartios.bridge.recieveMessage = function(message) {
        var jsonResult = JSON.parse(message);
        $.event.trigger("recieveMessage", [jsonResult.messageBody]);
    };
    
    mdSmartios.bridge.callbackFunction = function(retObjcValue, result) {
        var jsonResult = JSON.parse(result);
        var cbf = mdSmartios.bridge.callbackFunctions[retObjcValue];
        var cbff = mdSmartios.bridge.callbackFailFunctions[retObjcValue];
        if (jsonResult.errCode !== undefined && jsonResult.errMessage == 'TimeOut') {
            if(jsonResult.errCode!=-1){
                //keane 指令失败函数自定义 Mod S
                if (typeof cbff == "function") {
                    cbff(-1);//表示指令超时 －1
                }
            }
        } else {
            if ( typeof cbf == "function") {
                cbf(jsonResult.messageBody);
            }
        }
        delete mdSmartios.bridge.callbackFunctions[retObjcValue];
        delete mdSmartios.bridge.callbackFailFunctions[retObjcValue];
    };

    mdSmartios.bridge.po = {
        _execObjcMethod : function(method, data) {
            try {
                var tmp = method;

                if (data != undefined && data != '') {
                    tmp = tmp + '?' + data;
                }
                console.log('Exec ' + tmp);
                var iframe = document.createElement("IFRAME");
                iframe.setAttribute("src", "iosbridge://" + tmp);
                document.documentElement.appendChild(iframe);
                iframe.parentNode.removeChild(iframe);
                iframe = null;
            } catch(e) {
                console.log(method + ' exception');
            }
            return mdSmartios.bridge.retObjcValue;
        }
    };
    window.bridge = mdSmartios.bridge;
})(mdSmartios);