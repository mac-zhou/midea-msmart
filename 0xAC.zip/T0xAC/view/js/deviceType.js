//根据家电SN获取机型，返回机型名称
	function getDeviceName() {
		var subQA100List = "11005/10977/11007/10979/10563/10567/10711/11415/11417/11423/11425/11467/11469/11471/11473/11475/11477";
		var subSA100List = "11175/11177/11419/11421/11437/11439/11441/Z1140";
		var subSA200List = "11285/11287/11351/11353/11355/11357"; //SA200  SA201
		var subSA300List = "11179/11181/11183/11313/11315/11317/11537/11539/11541/Z1139/Z1149/Z2155/Z1166/Z2185";
		var subYAList = "11381/11387/11383/11385/11389/11393/11391/11395/11463/11465/11571/11573/11575/Z2165/Z2168/Z1151/Z1152/Z1153/Z1154/Z1158/Z2165/Z2166/Z2167/Z1167/Z2169/Z2170/Z2172/Z2186";
		var sub26YAList = "11835";
		var subYAB3List = "11397/11399/11401/11403/11405/11407/Z2170/Z1155/Z1156";
		var subWJABCList = "11295/11301/11297/11303/11299/11305"; //WJA、WJB、WJC
		//		var subWJAList = "11295/11301";
		//		var subWJBList = "11297/11303";
		//		var subWJCList = "11299/11305";
		var subYA100List = "50491/50493/50271/50273/50603/50607/50663/50665";
		var subCJ200List = "50601/50509/50507/50605/Z1138";
		var subWYAList = "50585/50583";
		var subWPAList = "50559/50557";
		var subLBB2List = "50095/50163/50077/50167"; // LB(B2)
		var subLBB3List = "50119/50213/50397/50081/50285/50403/50661/50695"; // LB(B3)
		var subPA400List = "50387/50401";
		var subWEAList = "11373/11375/11377/11379/11309/11311/10983/10985/F0283/F0285/F0287/F0289/F0291/F0293 /F0295/F0297/F0299/F0301/F0303/F0305/Z1172/Z1211/Z1212/Z1173";
		var subCAList = "11447/11451/11453/11455/11457/11459/11525/11527";
		var subTAB3List = "11489/11491/11493/11505/11507/11509/Z1161/Z1162/Z2182/Z2183/11551/11553/11557/11561/11565";
		var subTAB12List = "11495/11497/11499/11501/11503/11511/11513/11515/Z1165/Z1164/Z1163/Z2180/Z2181/Z2184/11543/11545/11547/11549/11555/11559/11563/11585/11587/11833/11837/11931/11929/Z2240/Z1217";
		var subKHB1List = "50637/50639/50655/50653/50723";
		var subCACPList = "11533/11535"; //CA定速机
		var subZA300List = "50199/50201/50265/50269/50307/50373/50317/50375/50431/50433"; //ZA300(B2)
		var subZA300B3List = "50251/50253/50281/50289/50309/50315/50383/50385/50427/50429/50669/50701"; //ZA300(B3)
		var subZB300List = "50657/50659"; //ZB300
		var subZB300YJList = "Z1170/Z2191";					//ZB300YJ
		var subYA300List = "50205/50207/50393/50451";
		var subYA301List = "50531/50533/50677/50687/G0041/G0043/G0047/G0049/G0045/G0051/50777/50779/Z2231/Z1207"; //YA301
		var subYA302List = "50577/50579/50679/50693";
		var subYA201List = "50609/50681/50689/50611/50675/50685/50775/50773";//YA201 20170527将773 775从YA200转到YA201 By lyf
		var subYA200List = "50771/50769";//YA200
		var subPC400B23List = "11367/11369/11371/11323/11325/11327/11445/11449/11461/11757/11759/11761/11323/11325/11327/11445/11449/11461/F0473/Z2217"; //PC400(B2)、PC400(B3)
		var subWXAList = "11695/11697/Z1209/Z2234";
		var subWJ7List = "10167/10169/10171";
		var subWYBList = "50725/50727";
		var subPCB50List = "11719";
		var subYB200List = "50731/50733/Z1184/Z2208";
		var subYB200TestList = "55555";
		var subDA100List = "11717/11711";
		var subWXDList = "11713/11715/Z1208/Z2233";
		var subYB300List = "50753/50755/Z1187/Z2212/50841/50839/50835/50837/Z1204/Z2229/50903/Z2254/Z1231/50905";
		var subWDAA3List = "11763/11765/Z2214/11879/11885/Z1210/Z2235";//WDBA3
		var subWDAD3List = "11735/11737/11883/11881/11799/11803/11801/11805";//WDBD3
		var subWYAD2D3List = "50763/50599/50761/50589/50597/Z1216/Z2239";
		var subWPAD3List = "50749/50751/50737/50739/50741/50743";
		var subDA400B3List = "11605/11613/11641/11729/11731/11733/Z3063/Z3065/Z2187/Z2215/11843/11231";
		var subPC400B1List = "11775/11777/11829/11831/11937/11933";//PE200、PC200
		var subDA200300List = "11589/11591/11593/11597/11599/11649/Z1168/Z2188/Z2164/11739/11741/11743/11745/11747/11749/11661/11663/11667/Z1169/Z2189/11751/11753/11755/11821/11823/11825/11827/Z1191/Z2218/Z1192/Z2219/11891/11889/11925/11927/Z1206/11941/11943";//WCC，WDB
	    var subDA400D3List = "11779/11781/11783/11785/11787/11789/11791/11793";
		var subDA400BP = "50853/50847/Z2241/Z1218";//DA400带不吹人功能，变频
		var subDA400DP = "50843/50845/50849/50851";//DA400带不吹人功能，定频
	    var subPA400B3List = "50745/50747";
	    var subJ9List = "19003/19001/Z2900/Z1900/Z1902/19013/19014/19011/19012/Z2902/19017/19015";
	    var subYA400D2D3List = "50569/50571/50587/50593/50757/50759/50647/50648/50649";
	    var subQA301B1List = "11795/11797/11796/11798/Z2213/Z1188";
	    var subWCBA3List = "F0275/F0277/F0279/F0281/F0307/F0309/F0311/F0313/F0315/F0317/11701/11699";
	    var subIQ100List = "Z1194/11819/11813/Z2221/Z1198";
	    var subDA100ZList = "11809/11811/Z1193/Z2220/11907/11905/11911/11909/11895/11893/11923/11921/Z1201/Z2232";
	    var subIQ300List = "Z1195/Z2222/11815/11817";
	    var subJ7List = "Z2901/Z1008/Z1901/50103/50101/50079/50081/50781/50783/50109/50107/Z1205/Z2230";
	    var subYA400B2List = "50565/50567/50613/50621/50683/50691";
	    var subWPBCList = "50789/50791/50785/50787/Z2237/Z1214";//WPB、WPC
	    var subWPCDList = "50797/50799";
	    var subYB400List = "50823/50825/Z2227/Z1199/50891/50893/50907/50909";//WYE、WYG"
	    var subPE400B3List = "11723/11727";
	    var subJ8List = "Z2903/Z1903/50113/50111";
		var subYB301List = "50861/50863/Z1215/Z2238/Z1223/Z2246/50875/50873/50877/50879/Z1224/Z2247/50917/50919/Z1241/50921/50923/Z1242/50933/50935";
		var subWYSList = "50895/50897/Z1244";
		var sub1TO1List = "96901/96902/96903/96904";//一拖一
		var subYB201List = "50869/50871/Z1226/Z2249/Z1227/Z2250/50889/50887/50925/50927/Z1243";
		var subPF200List = "11963/11961/Z2245/Z1222/11981/11983";
		var subGM100List = "11967/11965/Z1229/Z2252";
		var subWOWList = "11979/11977/Z1235/Z2259/Z2266";
		var subS10List = "20003/20001/Z1904/Z2904";
		var subFA100List = "12037/12035";
		var subW10List = "60001/60003";
	

		var deviceSN = bridge.getCurrentDevSN();
		if(deviceSN == 0) {
			return "";
		}

		var deviceBarCode = undefined;
		var deviceName = undefined;
		if (deviceSN != "") {
			if (deviceSN.length == '32') {
				deviceBarCode = deviceSN.substring(12, 17);
			} else if (deviceSN.length == '22') {
				deviceBarCode = deviceSN.substring(6, 11);
			} else {
				deviceBarCode = "";
			}
			//alert(deviceBarCode);
		} else {
			deviceBarCode = "";
		}

		if (subQA100List.indexOf(deviceBarCode) != '-1') {
			deviceName = "QA100";
		} else if (subSA100List.indexOf(deviceBarCode) != '-1') {
			deviceName = "SA100";
		} else if (subSA200List.indexOf(deviceBarCode) != '-1') {
			deviceName = "SA200";
		} else if (subSA300List.indexOf(deviceBarCode) != '-1') {
			deviceName = "SA300";
		} else if (subYAList.indexOf(deviceBarCode) != '-1') {
			deviceName = "YA";
		} else if (sub26YAList.indexOf(deviceBarCode) != '-1') {
			deviceName = "26YA";
		} else if (subYAB3List.indexOf(deviceBarCode) != '-1') {
			deviceName = "YAB3";
		}else if (subWJABCList.indexOf(deviceBarCode) != '-1') {
			deviceName = "WJABC";
		} else if (subYA100List.indexOf(deviceBarCode) != '-1') {
			deviceName = "YA100";
		} else if (subCJ200List.indexOf(deviceBarCode) != '-1') {
			deviceName = "CJ200";
		} else if (subWYAList.indexOf(deviceBarCode) != '-1') {
			deviceName = "WYA";
		} else if (subWPAList.indexOf(deviceBarCode) != '-1') {
			deviceName = "WPA";
		} else if (subLBB2List.indexOf(deviceBarCode) != '-1') {
			deviceName = "LBB2";
		} else if (subLBB3List.indexOf(deviceBarCode) != '-1') {
			deviceName = "LBB3";
		} else if (subPA400List.indexOf(deviceBarCode) != '-1') {
			deviceName = "PA400";
		} else if (subWEAList.indexOf(deviceBarCode) != '-1') {
			deviceName = "WEA";
		} else if (subCAList.indexOf(deviceBarCode) != '-1') {
			deviceName = "CA";
		} else if (subTAB3List.indexOf(deviceBarCode) != '-1') {
			deviceName = "TAB3";
		} else if (subTAB12List.indexOf(deviceBarCode) != '-1') {
			deviceName = "TAB12";
		} else if (subKHB1List.indexOf(deviceBarCode) != '-1') {
			deviceName = "KHB1";
		} else if (subCACPList.indexOf(deviceBarCode) != '-1') {
			deviceName = "CACP";
		} else if (subZA300List.indexOf(deviceBarCode) != '-1') {
			deviceName = "ZA300";
		} else if (subZA300B3List.indexOf(deviceBarCode) != '-1') {
			deviceName = "ZA300B3";
		} else if (subZB300List.indexOf(deviceBarCode) != '-1') {
			deviceName = "ZB300";
		} else if (subZB300YJList.indexOf(deviceBarCode) != '-1') {
			deviceName = "ZB300YJ";
		} else if (subYA300List.indexOf(deviceBarCode) != '-1') {
			deviceName = "YA300";
		} else if (subYA201List.indexOf(deviceBarCode) != '-1') {
			deviceName = "YA201";
		} else if (subYA200List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YA200";
		} else if (subYA301List.indexOf(deviceBarCode) != '-1') {
			deviceName = "YA301";
		} else if (subYA302List.indexOf(deviceBarCode) != '-1') {
			deviceName = "YA302";
		} else if (subPC400B23List.indexOf(deviceBarCode) != '-1') {
			deviceName = "PC400B23";
		} else if (subWXAList.indexOf(deviceBarCode) != '-1') {
			deviceName = "WXA";
		} else if (subWJ7List.indexOf(deviceBarCode) != '-1') {
			deviceName = "WJ7";
		} else if (subWYBList.indexOf(deviceBarCode) != '-1') {
			deviceName = "WYB";
		} else if (subPCB50List.indexOf(deviceBarCode) != '-1') {
			deviceName = "PCB50";
		} else if (subYB200List.indexOf(deviceBarCode) != '-1') {
			deviceName = "YB200";
		} else if (subDA100List.indexOf(deviceBarCode) != '-1') {
			deviceName = "DA100";
		} else if (subYB200TestList.indexOf(deviceBarCode) != '-1') {
			deviceName = "YB200Test";
		} else if (subWXDList.indexOf(deviceBarCode) != '-1') {
			deviceName = "WXD";
		} else if (subYB300List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YB300";
		}  else if (subWDAA3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "WDAA3";
		} else if (subWDAD3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "WDAD3";
		}else if (subWYAD2D3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "WYAD2D3";
		}else if (subWPAD3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "WPAD3";
		}else if (subDA400B3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "DA400B3";
		}else if (subPC400B1List.indexOf(deviceBarCode) != '-1') {
			deviceType = "PC400B1";
		}else if (subDA200300List.indexOf(deviceBarCode) != '-1') {
			deviceType = "DA200300";
		}else if (subDA400D3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "DA400D3";
		}else if (subDA400BP.indexOf(deviceBarCode) != '-1') {
			deviceType = "DA400BP";
		}else if (subDA400DP.indexOf(deviceBarCode) != '-1') {
			deviceType = "DA400DP";
		}else if (subPA400B3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "PA400B3";
		}else if (subJ9List.indexOf(deviceBarCode) != '-1') {
			deviceType = "J9";
		}else if (subYA400D2D3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YA400D2D3";
		} else if (subQA301B1List.indexOf(deviceBarCode) != '-1') {
			deviceType = "QA301B1";
		}else if (subWCBA3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "WCBA3";
		}else if (subIQ100List.indexOf(deviceBarCode) != '-1') {
			deviceType = "IQ100";
		}else if (subDA100ZList.indexOf(deviceBarCode) != '-1') {
			deviceType = "DA100Z";
		}else if (subIQ300List.indexOf(deviceBarCode) != '-1') {
			deviceType = "IQ300";
		}else if (subJ7List.indexOf(deviceBarCode) != '-1') {
			deviceType = "J7";
		}else if (subWPBCList.indexOf(deviceBarCode) != '-1') {
			deviceType = "WPBC";
		}else if (subWPCDList.indexOf(deviceBarCode) != '-1') {
			deviceType = "WPCD";
		}else if (subYB400List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YB400";
		}else if (subPE400B3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "PE400B3";
		}else if (subJ8List.indexOf(deviceBarCode) != '-1') {
			deviceType = "J8";
		}else if (subYA400B2List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YA400";
		}else if (sub1TO1List.indexOf(deviceBarCode) != '-1') {
			deviceType = "1TO1";
		}else if (subPF200List.indexOf(deviceBarCode) != '-1') {
			deviceType = "PF200";
		}else if (subGM100List.indexOf(deviceBarCode) != '-1') {
			deviceType = "GM100";
		}else if (subWOWList.indexOf(deviceBarCode) != '-1') {
			deviceType = "WOW";
		}else if(subS10List.indexOf(deviceBarCode) != '-1') {
			deviceType = "S10";
		}else if(subFA100List.indexOf(deviceBarCode) != '-1') {
			deviceType = "FA100";
		}else if(subW10List.indexOf(deviceBarCode) != '-1') {
			deviceType = "W10";
		}
		else {
			deviceName = "OTHER";
		}
		

//		alert(deviceSN);
		return deviceName;

	}
	
	//根据家电条码，返回家电类型  	1:挂机	2:柜机  3：挂机iq 4:一拖多
	function getDeviceType() {
		var subQA100List = "11005/10977/11007/10979/10563/10567/10711/11415/11417/11423/11425/11467/11469/11471/11473/11475/11477";
		var subSA100List = "11175/11177/11419/11421/11437/11439/11441/Z1140";
		var subSA200List = "11285/11287/11351/11353/11355/11357"; //SA200  SA201
		var subSA300List = "11179/11181/11183/11313/11315/11317/11537/11539/11541/Z1139/Z1149/Z2155/Z1166/Z2185";
		var subYAList = "11381/11387/11383/11385/11389/11393/11391/11395/11463/11465/11571/11573/11575/Z2165/Z2168/Z1151/Z1152/Z1153/Z1154/Z1158/Z2165/Z2166/Z2167/Z1167/Z2169/Z2170/Z2172/Z2186/11839/11835/11919/11917/11915/11913";
		var sub26YAList = "11835";
		var subYAB3List = "11397/11399/11401/11403/11405/11407/Z2170/Z1155/Z1156";
		var subWJABCList = "11295/11301/11297/11303/11299/11305"; //WJA、WJB、WJC
		//		var subWJAList = "11295/11301";
		//		var subWJBList = "11297/11303";
		//		var subWJCList = "11299/11305";
		var subYA100List = "50491/50493/50271/50273/50603/50607/50663/50665";
		var subCJ200List = "50601/50509/50507/50605/Z1138";
		var subWYAList = "50585/50583";
		var subWPAList = "50559/50557";
		var subLBB2List = "50095/50163/50077/50167"; // LB(B2)
		var subLBB3List = "50119/50213/50397/50081/50285/50403/50661/50695"; // LB(B3)
		var subPA400List = "50387/50401";
		var subWEAList = "11373/11375/11377/11379/11309/11311/10983/10985/F0283/F0285/F0287/F0289/F0291/F0293 /F0295/F0297/F0299 /F0301/F0303/F0305/Z1172/Z1211/Z1212/Z1173";
		var subCAList = "11447/11451/11453/11455/11457/11459/11525/11527";
		var subTAB3List = "11489/11491/11493/11505/11507/11509/Z1161/Z1162/Z2182/Z2183/11551/11553/11557/11561/11565";
		var subTAB12List = "11495/11497/11499/11501/11503/11511/11513/11515/Z1165/Z1164/Z1163/Z2180/Z2181/Z2184/11543/11545/11547/11549/11555/11559/11563/11585/11587/11833/11837/11931/11929/Z2240/Z1217";
		var subKHB1List = "50637/50639/50655/50653/50723";
		var subCACPList = "11533/11535"; //CA定速机
		var subZA300List = "50199/50201/50265/50269/50307/50373/50317/50375/50431/50433"; //ZA300(B2)
		var subZA300B3List = "50251/50253/50281/50289/50309/50315/50383/50385/50427/50429/50669/50701"; //ZA300(B3)
		var subZB300List = "50657/50659"; //ZB300
		var subZB300YJList = "Z1170/Z2191";					//ZB300YJ
		var subYA300List = "50205/50207/50393/50451";
		var subYA301List = "50531/50533/50677/50687/G0041/G0043/G0047/G0049/G0045/G0051/50777/50779/Z2231/Z1207"; //YA301
		var subYA302List = "50577/50579/50679/50693";
		var subYA201List = "50609/50681/50689/50611/50675/50685/50775/50773";//YA201 20170527将773 775从YA200转到YA201 By lyf
		var subYA200List = "50771/50769";//YA200
		var subPC400B23List = "11367/11369/11371/11323/11325/11327/11445/11449/11461/11757/11759/11761/11323/11325/11327/11445/11449/11461/F0473/Z2217"; //PC400(B2)、PC400(B3)
		var subWXAList = "11695/11697/Z1209/Z2234";
		var subWJ7List = "10167/10169/10171";
		var subWYBList = "50725/50727";
		var subPCB50List = "11719";
		var subYB200List = "50731/50733/Z1184/Z2208";
		var subYB200TestList = "55555";
		var subDA100List = "11717/11711";
		var subWXDList = "11713/11715/Z1208/Z2233";
		var subYB300List = "50753/50755/Z1187/Z2212/50841/50839/50835/50837/Z1204/Z2229/50903/Z2254/Z1231/50905";
		var subWDAA3List = "11763/11765/Z2214/11879/11885/Z1210/Z2235";//WDBA3
		var subWDAD3List = "11735/11737/11883/11881/11799/11803/11801/11805";//WDBD3
		var subWYAD2D3List = "50763/50599/50761/50589/50597/Z1216/Z2239";
		var subWPAD3List = "50749/50751/50737/50739/50741/50743";
		var subDA400B3List = "11605/11613/11641/11729/11731/11733/Z3063/Z3065/Z2187/Z2215/11843/11231";
		var subPC400B1List = "11775/11777/11829/11831/11937/11933";//PE200、PC200
		var subDA200300List = "11589/11591/11593/11597/11599/11649/Z1168/Z2188/Z2164/11739/11741/11743/11745/11747/11749/11661/11663/11667/Z1169/Z2189/11751/11753/11755/11821/11823/11825/11827/Z1191/Z2218/Z1192/Z2219/11891/11889/11925/11927/Z1206/11941/11943";//WCC，WDB
	    var subDA400D3List = "11779/11781/11783/11785/11787/11789/11791/11793";
		var subDA400BP = "50853/50847/Z2241/Z1218";//DA400带不吹人功能，变频
		var subDA400DP = "50843/50845/50849/50851";//DA400带不吹人功能，定频
	    var subPA400B3List = "50745/50747";
	    var subJ9List = "19003/19001/Z2900/Z1900/Z1902/19013/19014/19011/19012/Z2902/19017/19015";
	    var subYA400D2D3List = "50569/50571/50587/50593/50757/50759/50647/50648/50649";
	    var subQA301B1List = "11795/11797/11796/11798/Z2213/Z1188";
	    var subWCBA3List = "F0275/F0277/F0279/F0281/F0307/F0309/F0311/F0313/F0315/F0317/11701/11699";
	    var subIQ100List = "Z1194/11819/11813/Z2221/Z1198";
	    var subDA100ZList = "11809/11811/Z1193/Z2220/11907/11905/11911/11909/11895/11893/11923/11921/Z1201/Z2232";
	    var subIQ300List = "Z1195/Z2222/11815/11817";
	    var subJ7List = "Z2901/Z1008/Z1901/50103/50101/50079/50081/50781/50783/50109/50107/Z1205/Z2230";
	    var subYA400B2List = "50565/50567/50613/50621/50683/50691";
	    var subWPBCList = "50789/50791/50785/50787/Z2237/Z1214";//WPB、WPC
	    var subWPCDList = "50797/50799";
	    var subYB400List = "50823/50825/Z2227/Z1199/50891/50893/50907/50909";//WYE、WYG
	    var subPE400B3List = "11723/11727";
	    var subJ8List = "Z2903/Z1903/50113/50111";
		var sub1TOnList = "PD004";//一拖多
		var subYB301List = "50861/50863/Z1215/Z2238/Z1223/Z2246/50875/50873/50877/50879/Z1224/Z2247/50933/50935";
		var subWYSList = "50895/50897/Z1244";
		var sub1TO1List = "96901/96902/96903/96904";//一拖一
		var subYB201List = "50869/50871/Z1226/Z2249/Z1227/Z2250/50889/50887";
		var subPF200List = "11963/11961/Z2245/Z1222";
		var subGM100List = "11967/11965/Z1229/Z2252";
		var subWOWList = "11979/11977/Z1235/Z2259/Z2266";
		var subS10List = "20003/20001/Z1904/Z2904";
        var subFA100List = "12037/12035";
		var subW10List = "60001/60003";
		
		var deviceSN = bridge.getCurrentDevSN();
		if(deviceSN == 0) {
			return "";
		}
		var deviceBarCode = undefined;
		var deviceFirstTypeCode = undefined;
		var deviceType = 1;
		if (deviceSN != "") {
			if (deviceSN.length == '32') {
				deviceBarCode = deviceSN.substring(12, 17);
				deviceFirstTypeCode = deviceSN.substring(12, 13);
			} else if (deviceSN.length == '22') {
				deviceBarCode = deviceSN.substring(6, 11);
				deviceFirstTypeCode = deviceSN.substring(6, 7);
			} else {
				deviceBarCode = "";
				deviceFirstTypeCode = 0;
			}
		} else {
			deviceBarCode = "";
			deviceFirstTypeCode = 0;
		}

		if (deviceFirstTypeCode == 'Z') {
			deviceType = 1;
		} else{
			if (deviceFirstTypeCode >= 5 && deviceFirstTypeCode <= 9&&
				subIQ100List.indexOf(deviceBarCode) == -1 &&
				subIQ300List.indexOf(deviceBarCode) == -1
			){
				deviceType = 2;
			} 
			else if(subIQ100List.indexOf(deviceBarCode) != -1||
			subIQ300List.indexOf(deviceBarCode) != -1){
				deviceType = 3;
			}
			else {
				deviceType = 1;
			}
		}

		if (subQA100List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subSA100List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subSA200List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subSA300List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subYAList.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (sub26YAList.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subYAB3List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subWJABCList.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subYA100List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subCJ200List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subWYAList.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subWPAList.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subLBB2List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subLBB3List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subPA400List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subWEAList.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subCAList.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subTAB3List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subTAB12List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subKHB1List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subCACPList.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subZA300List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subZA300B3List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subZB300List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subZB300YJList.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subYA300List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subYA201List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subYA200List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subYA301List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subYA302List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subPC400B23List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subWXAList.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subWJ7List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subWYBList.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subPCB50List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subYB200List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subDA100List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subYB200TestList.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subWXDList.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subYB300List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		}  else if (subWDAA3List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subWDAD3List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subWYAD2D3List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subWPAD3List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subDA400B3List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subPC400B1List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subDA200300List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		} else if (subDA400D3List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		}else if (subDA400BP.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		}else if (subDA400DP.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		} else if (subPA400B3List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		}else if (subJ9List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		}else if (subYA400D2D3List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		}else if (subQA301B1List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		}else if (subWCBA3List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		}else if (subIQ100List.indexOf(deviceBarCode) != '-1') {
			deviceType = 3;
		}else if (subDA100ZList.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		}else if (subIQ300List.indexOf(deviceBarCode) != '-1') {
			deviceType = 3;
		}else if (subJ7List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		}else if (subWPBCList.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		}else if (subWPCDList.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		}else if (subYB400List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		}else if (subPE400B3List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		}else if (subJ8List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		}else if (subYA400B2List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		}else if (sub1TO1List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		}else if (sub1TOnList.indexOf(deviceBarCode) != '-1') {
			deviceType = 4;
		}else if (subYB201List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		}else if (subPF200List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		}else if (subGM100List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		}else if (subYB301List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		}else if (subWYSList.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		}else if (subWOWList.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		}else if (subS10List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		}else if (subFA100List.indexOf(deviceBarCode) != '-1') {
			deviceType = 1;
		}else if (subW10List.indexOf(deviceBarCode) != '-1') {
			deviceType = 2;
		}
		return deviceType;
	}
		
		
		
		