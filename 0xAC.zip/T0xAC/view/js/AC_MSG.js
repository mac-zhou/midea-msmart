var mdSmart = mdSmart || {};
/*
 * 空调定长通信协议
 * @doc 空调--美的家电物联网应用通信协议V1.0.5(20140512).doc
 * 20150320 wjl:协议长度由22个字节，扩展为24个字节
 * 第19字节 bit7用于控制下左右摆风 bit0-bit6为设定湿度。 默认填0
 * 第20字节 bit7用于控制下左右摇摆 bit0-bit6为净化器设定风速。 默认填0
 * 第21字节 双温度控制指定温度。 默认填0
 * 第22字节 特殊功能 bit0:预冷预热；bit1:手环与舒睡联动开关；bit2:手环离家回家模式开关；bit3：无风感功能开关
 * 第23字节 帧序号
 * 第24字节 crc8
 * 增函数说明：
 * setreadyColdOrHor:function(p1) 预冷预热功能
 * setbraceLetSleep:function(p1) 手环与舒睡联动功能 
 * setbraceLetSleep:function(p1) 手环与舒睡联动功能
 * setsmartWind:function(p1) 无风感开关
 *  *  *2015-04-08:增加支持新控制协议，新控制协议支持：
 * 喇叭声音种类选择:loudspeeaerType;以数组表示，长度1位
 * pm2.5数值显示开关:pm25showSwitch;以数组表示，长度1位
 * 负离子间歇控制:anionStart;以数组表示，1位
 * 负离子控制开启关闭时间:anionTimeCount;以数组表示，长度4位
 * 
 * 无级风速选择开关:smartWindSwitch;以数组表示，长度1位
 * 离家模式开关:braceLetContralAwaySwitch;以数组表示，长度1位
 * 回家模式开关:braceLetContralComeSwitch;以数组表示，长度1位
 * 预冷预热开关:readyColdOrHotSwitch;以数组表示，长度1位
 * 手环与舒睡联动:braceLetSleepSwitch;以数组表示，长度1位
 * 
 * setHumidity  对应智能除湿模式的设定湿度
 */
/**
 * 通信数据
 * @param {String} pStr16Message 空调通信数据
 */

var currentTimeValue = 0; //当前时间戳
var tmpTimeValue = 0; //临时时间戳
var currentOrder; //当前帧序号
var tmptOrder; //临时帧序号

mdSmart.msg0xAC = function() {
	var _messageBodyControl = undefined,
		_messageBodyRequestStatus = undefined;
	_messageBodyCheckStatus = undefined;
	var _equipmentReturnCommandBack = undefined,
		_x05Xa0Back = undefined,
		_x04Xa1Back, frameCumulative = 1;
	var currentTimeValue = tmpTimeValue = Date.parse(new Date()) / 1000; //时间戳
	var currentOrder = tmptOrder = 11; //帧序号
	(function init() {
		//		_messageBodyControl = mdSmart.message.createMessageBody(22);
		//		_messageBodyRequestStatus = mdSmart.message.createMessageBody(22);

		//20150320 wjl
		_messageBodyControl = mdSmart.message.createMessageBody(25);
		_messageBodyRequestStatus = mdSmart.message.createMessageBody(25);

		_messageBodyCheckStatus = mdSmart.message.createMessageBody(7); //查询设备状态组包数组
	}());
	var _status = {
		faultFlag: {
			name: "故障标志",
			value: 0x00,
			view: {
				0: "无故障",
				1: "有故障"
			}
		},
		fastCheckStatus: {
			name: "快检状态",
			value: 0x00,
			view: {
				0: "关闭",
				1: "开启"
			}
		},
		timeingMode: {
			name: "定时方式",
			value: 0x00,
			view: {
				0: "相对定时",
				1: "绝对定时"
			}
		},
		iModeRecovery: {
			name: "I模式恢复",
			value: 0x00,
			view: {
				0: "关闭",
				1: "开启"
			}
		},
		runningState: {
			name: "运行状态",
			value: 0x00,
			view: {
				0: "关机",
				1: "开机"
			}
		},
		settingMode: {
			name: "设定模式",
			value: 0x00,
			view: {
				0: "无效",
				1: "自动",
				2: "制冷",
				3: "抽湿",
				4: "制热",
				5: "送风"
			}
		},
		settingTemperature: {
			name: "设定温度",
			value: 0x00,
			view: {
				0: "无效",
				1: "17℃",
				2: "18℃",
				3: "19℃",
				4: "20℃",
				5: "21℃",
				6: "22℃",
				7: "23℃",
				8: "24℃",
				9: "25℃",
				10: "26℃",
				11: "27℃",
				12: "28℃",
				13: "29℃",
				14: "30℃"
			}
		},
		settingTemperatureDot5: {
			name: "+0.5",
			value: 0x00,
			view: {
				0: "+0.0",
				1: "+0.5"
			}
		},
		noPolarWindSpeedValue: {
			name: "无极风速值",
			value: 0x00,
			view: {
				0: "无效",
				101: "固定风",
				102: "自动风",
				80: "高风",
				60: "中风",
				40: "低风",
				20: "静音风",
				60: "中风"
			}
		},
		timingOpen: {
			name: "定时开",
			value: 0x00,
			view: {
				0: "关",
				1: "开"
			}
		},
		timingOpenAbsoluteHours: {
			name: "定时开－绝对小时",
			value: 0x00
		},
		timingOpenAbsoluteMinutes: {
			name: "定时开－绝对分",
			value: 0x00
		},
		timingClose: {
			name: "定时关",
			value: 0x00,
			view: {
				0: "关",
				1: "开"
			}
		},
		timingCloseAbsoluteHours: {
			name: "定时关－绝对小时",
			value: 0x00
		},
		timingCloseAbsoluteMinutes: {
			name: "定时关－绝对分",
			value: 0x00
		},
		shushiFeng: {
			name: "舒适风",
			value: 0x00,
			view: {
				0x11: "广角",
				0x12: "左广角",
				0x13: "右广角",
				0x14: "左定点",
				0x15: "右定点",
				0x16: "正面定点",
				0x17: "环绕立体风",
				0x18: "跟随-迎风",
				0x19: "避开-避风",
				0x20: "正出风上下摆",
				0x21: "正出风左右摆",
				0x22: "侧出风左右摆"
			}
		},
		downWind: {
			name: "下摆风",
			value: 0x00,
			view: {
				0: "关闭",
				1: "开启"
			}
		},
		downWindControl: {
			name: "下摆风单独控制",
			value: 0x00
		},
		downWindControlLR: {
			name: "下左右摇摆",
			value: 0x00
		},
		personalFeeling: {
			name: "随身感",
			value: 0x00,
			view: {
				0: "关闭",
				1: "开启"
			}
		},
		zhihuiyan: {
			name: "智慧眼",
			value: 0x00,
			view: {
				0: "关闭",
				1: "开启"
			}
		},
		energySaving: {
			name: "节能",
			value: 0x00,
			view: {
				0: "关",
				1: "开"
			}
		},
		strong: {
			name: "强劲",
			value: 0x00,
			view: {
				0: "关闭",
				1: "开启"
			}
		},
		ruiFeng: {
			name: "睿风",
			value: 0x00,
			view: {
				0: "关闭",
				1: "开启"
			}
		},
		shengDian: {
			name: "省电",
			value: 0x00,
			view: {
				0: "关闭",
				1: "开启"
			}
		},
		sleepMode: {
			name: "舒睡模式",
			value: 0x00,
			view: {
				0: "无舒睡",
				1: "舒睡1",
				10: "舒睡2",
				11: "舒睡3"
			}
		},
		selfPersonalFeeling: {
			name: "本机随身感",
			value: 0x00,
			view: {
				0: "关",
				1: "开"
			}
		},
		selfSleep: {
			name: "本机舒睡",
			value: 0x00,
			view: {
				0: "关",
				1: "开"
			}
		},
		purifyingFunction: {
			name: "净化功能",
			value: 0x00,
			view: {
				0: "关",
				1: "开"
			}
		},
		ecoFunction: {
			name: "ECO功能",
			value: 0x00,
			view: {
				0: "关",
				1: "开"
			}
		},
		keepWarm: {
			name: "保温功能",
			value: 0x00,
			view: {
				0: "关闭",
				1: "开启"
			}
		},
		shabbat: {
			name: "以色列功能",
			value: 0x00,
			view: {
				0: "关闭",
				1: "开启"
			}
		},			
		windBlowing:{
			name: "旧协议防直吹",
			value: 0x00,
			view: {
				0: "关闭",
				1: "开启"
			}
		},
		electricHeat: {
			name: "电辅热",
			value: 0x00,
			view: {
				0: "关",
				1: "开"
			}
		},
		dry: {
			name: "干燥",
			value: 0x00,
			view: {
				0: "关",
				1: "开"
			}
		},
		naturalWindFunction: {
			name: "自然风功能",
			value: 0x00,
			view: {
				0: "关",
				1: "开"
			}
		},
		childrenSleepMode: {
			name: "儿童舒睡模式",
			value: 0x00,
			view: {
				0: "关",
				1: "开"
			}
		},
		coolWindMode: {
			name: "凉风模式",
			value: 0x00,
			view: {
				0: "关",
				1: "开"
			}
		},
		peakValleyElectricity: {
			name: "峰谷节电",
			value: 0x00,
			view: {
				0: "关",
				1: "开"
			}
		},
		catchCold: {
			name: "防着凉",
			value: 0x00,
			view: {
				0: "关",
				1: "开"
			}
		},
		nightLight: {
			name: "小夜灯",
			value: 0x00,
			view: {
				0: "关",
				1: "开"
			}
		},
		ventilation: {
			name: "换气",
			value: 0x00,
			view: {
				0: "关",
				1: "开"
			}
		},
		celsiusFahrenheit: {
			name: "摄氏/华氏",
			value: 0x00,
			view: {
				0: "关",
				1: "华氏"
			}
		},
		tubro: {
			name: "TUBRO",
			value: 0x00,
			view: {
				0: "关",
				1: "开"
			}
		},
		sleepFunctionStatus: {
			name: "Sleep功能状态",
			value: 0x00,
			view: {
				0: "关",
				1: "开"
			}
		},
		indoorTemperature: {
			name: "室内温度(整数),表示方法：温度值 x 2 + 50",
			value: 0x00
		},
		outdoorTemperature: {
			name: "室外温度(整数)),表示方法：温度值 x 2 + 50",
			value: 0x00
		},
		dustFullMark: {
			name: "尘满标识",
			value: 0x00,
			view: {
				0: "尘满未到",
				1: "尘满时间到"
			}
		},
		filterReplace:{
		   name: "滤网替换时间标识",
			value: 0x00,
			view: {
				0: "滤网替换时间未到",
				1: "滤网替换时间到"
			}	
		},
		settingTemperature2: {
			name: "设定温度2",
			value: 0x00,
			view: {
				0: "无效",
				1: "13℃",
				2: "14℃",
				3: "15℃",
				17: "30℃",
				18: "31℃",
				19: "32℃",
				20: "33℃",
				21: "34℃",
				22: "35℃"
			}
		},
		pmvMode: {
			name: "PMV模式",
			value: 0x00,
			view: {
				0: "PMV关闭",
				1: "PMV=-3",
				2: "PMV=-2.5",
				3: "PMV=-2",
				4: "PMV功能-1.5",
				5: "PMV功能-1",
				6: "PMV功能-0.5",
				7: "PMV功能0",
				8: "PMV功能0.5",
				9: "PMV功能1",
				10: "PMV功能1.5",
				11: "PMV功能2",
				12: "PMV功能2.5"
			}
		},
		faultNo: {
			name: "故障代号",
			value: 0x00,
			view: {
				0: "",
				1: "室内板与显示板通信故障 fg_ERROR_EB",
				2: "室内主控板E方故障",
				3: "室内板与室外板通信故障",
				4: "过零检测故障",
				5: "室内板风机失速故障",
				6: "室外冷凝器传感器故障",
				7: "室外环境温度传感器故障",
				8: "室外压缩机排气温度传感器故障",
				9: "室外E方故障",
				10: "室内温度传感器故障",
				11: "室内蒸发器温度传感器故障",
				12: "室外风速失速故障",
				13: "IPM模块保护",
				14: "电压保护",
				15: "室外压缩机顶部温度保护",
				16: "室外温度过低保护",
				17: "压缩机位置保护",
				18: "显示板E方故障",
				21: "外管温保护",
				23: "排气高温保护",
				25: "制热防冷风",
				26: "电流保护",
				29: "蒸发器高低温保护",
				30: "冷凝器高低温保护限频",
				31: "排气高低温保护",
				32: "室内外通信配错协议",
				33: "冷媒泄漏保护"
			}
		},
		ecoSleepRunningMinus: {
			name: "ECO/舒睡已运行时间 － 秒（范围：0～59）",
			value: 0x00
		},
		ecoSleepRunningSecond: {
			name: "ECO/舒睡已运行时间－ 分（低二位）（范围：0～59）",
			value: 0x00
		},
		ecoSleepRunningHour: {
			name: "ECO/舒睡已运行时间－ 小时（范围：0～10）",
			value: 0x00
		},
		//20150320 wjl
		//		readyColdOrHot:{
		//			name:"预冷预热",value:0x00,view:{0:"关闭",1:"开启"}
		//		},
		braceLetSleep: {
			name: "手环与舒睡联动",
			value: 0x00,
			view: {
				0: "关闭",
				1: "开启"
			}
		},
		braceLetContral: {
			name: "手环离家回家模式",
			value: 0x00,
			view: {
				0: "关闭",
				1: "开启"
			}
		},
		smartWind: {
			name: "无风感功能",
			value: 0x00,
			view: {
				0: "关闭",
				1: "开启"
			}
		},
		downleftandrightMove: {
			name: "下左右摇摆",
			value: 0x00,
			view: {
				0: "关闭",
				1: "开启"
			}
		},
		childKick: {
			name: "踢被子",
			value: 0x00,
			view: {
				0: "关闭",
				1: "开启"
			}
		},
		lightClass: {
			name: "屏显",
			value: 0x00,
			view: {
				0: "最亮",
				1: "二档",
				2: "三档",
				3: "四档",
				4: "五档",
				5: "六档",
				6: "七档",
				7: "关闭"
			}
		},
		eightHot: {
			name: "8度制热",
			value: 0x00,
			view: {
				0: "关闭",
				1: "开启"
			}
		},
		doubleContral: {
			name: "双温控制",
			value: 0x00,
			view: {
				0: "关闭",
				1: "开启"
			}
		},
		doubleContralTemp: {
			name: "双温控制设定温度 000表示无效 1-13度",
			value: 0x05
		},
		doubleContralDot: {
			name: "双温控制小数位",
			value: 0x00,
			view: {
				0: "0",
				1: "0.5度"
			}
		},
		indoorTemperatureDot: {
			name: "室内温度(小数)",
			value: 0x00
		},
		outdoorTemperatureDot: {
			name: "室外温度(小数)",
			value: 0x00
		},
		setHumidity: {
			name: "设定湿度",
			value: 0x00
		},
		//2017-05-04
		order: {
			name: "帧序号",
			value: 0x01
		}
	};

	function _parseMessage(pReceiveMessage) {
		var receiveMessageBody = pReceiveMessage.slice(10, pReceiveMessage.length - 1);
		var messageType = mdSmart.message.getByte(pReceiveMessage, 9);
		var isEquipmentReturnCommandBack = false,
			isX05Xa0Back = false,
			isX04Xa1Back = false;
		bridge.logToIOS("_parseMessage=" + pReceiveMessage);
		_equipmentReturnCommandBack = pReceiveMessage;
		//		alert(pReceiveMessage);
		//2015-04-08
		var isNEWVerBack = false;

		//2015-04-08 新协议命令回复处理
		if((receiveMessageBody[0] == 0xB0) || (receiveMessageBody[0] == 0xB1)) {
			isNEWVerBack = true;
			return;
		}
		//查询空调各组参数
		//		if((receiveMessageBody[0] ==  0xC1) && (receiveMessageBody[1] ==  0x21))
		//		{
		//			//alert(receiveMessageBody);
		//			//alert(123);
		//			return 0;
		//		}

		if(receiveMessageBody[0] == 0xC0) {
			//设备返回命令(设备当前状态返回)
			isEquipmentReturnCommandBack = true;
		}
		if(receiveMessageBody[0] == 0xA0) {
			bridge.logToIOS("A0parseMessage=" + pReceiveMessage);
		}
		if(receiveMessageBody[0] == 0xA1) {
			bridge.logToIOS("A1parseMessage=" + pReceiveMessage);
		}

		if(messageType == 0x05) {
			if(receiveMessageBody[0] == 0xA0) {
				//空调自动上传命令(0x05)
				bridge.logToIOS("05 receivemessage");
				isX05Xa0Back = true;
			}
		}
		if(messageType == 0x04) {
			if(receiveMessageBody[0] == 0xA1) {
				//空调自动上传命令(0x04)
				//isX04Xa1Back = true;
				return null;
			}
		}
		//设备返回命令(设备当前状态返回)
		if(isEquipmentReturnCommandBack == true) {
			//			_equipmentReturnCommandBack = pReceiveMessage;
			_parseEquipmentReturnCommandBackToStatus(receiveMessageBody);
			_doSynchronousEquipmentReturnCommandBackToCmd(receiveMessageBody);
		}
		//空调自动上传命令(0x05)
		if(isX05Xa0Back == true) {
			_x05Xa0Back = pReceiveMessage;
			_parseX05Xa0BackToStatus(receiveMessageBody);
			_doSynchronousX05Xa0BackToCmd(receiveMessageBody);
		}
		//空调自动上传命令(0x04)
		if(isX04Xa1Back == true) {
			_x04Xa1Back = pReceiveMessage;
			_parseX04Xa1BackToStatus(receiveMessageBody);
			_doSynchronousX04Xa1BackToCmd(receiveMessageBody);
		}
		var result = {
			messageType: messageType,
			status: _status
		};
		return result;
	}

	//2015-04-08 新协议返回解析	
	function _refreshNewVer(p1, p2) {
		alert(p1 + ' ' + p2);

		if((p1[0] == 0x02) && (p1[1] == 0x09)) {
			return;
		}
		if((p1[0] == 0x02) && (p1[1] == 0x09)) {

			return;
		}
		if((p1[0] == 0x02) && (p1[1] == 0x09)) {

			return;
		}
		if((p1[0] == 0x02) && (p1[1] == 0x09)) {

			return;
		}
		if((p1[0] == 0x02) && (p1[1] == 0x09)) {

			return;
		}
		if((p1[0] == 0x02) && (p1[1] == 0x09)) {

			return;
		}
		if((p1[0] == 0x02) && (p1[1] == 0x09)) {

			return;
		}
	}

	//2015-04-08 新协议返回解析
	function _parseEquipmentReturnCommandBackForNewVer(pReceiveMessageBody) {
		var dealCount = pReceiveMessageBody[1]; //属性个数
		var si = 0;
		var sj = 0;
		var NewCmdType = []; //属性命令
		var NewCmdLength = 0; //属性长度
		var NewValue = []; //属性值
		var sk = 2;
		for(si = 0; si < dealCount; si++) {
			NewCmdType[0] = pReceiveMessageBody[sk];
			NewCmdType[1] = pReceiveMessageBody[sk + 1]; //高位

			NewCmdLength = pReceiveMessageBody[sk + 3];
			if(pReceiveMessageBody[sk + 2] == 0x00) {
				for(sj = 0; sj < NewCmdLength; sj++) {
					NewValue[sj] = pReceiveMessageBody[sk + 4 + sj];
				}
				_refreshNewVer(NewCmdType, NewValue);
			} else {
				alert('设置失败！');
			}
			sk = sk + 3 + NewCmdLength + 1;
		}
	}

	// 设备返回命令==>_status
	function _parseEquipmentReturnCommandBackToStatus(pReceiveMessageBody) {
		_status.faultFlag.value = mdSmart.message.getBit(pReceiveMessageBody, 1, 7);
		_status.fastCheckStatus.value = mdSmart.message.getBit(pReceiveMessageBody, 1, 5);
		_status.timeingMode.value = mdSmart.message.getBit(pReceiveMessageBody, 1, 4);
		_status.iModeRecovery.value = mdSmart.message.getBit(pReceiveMessageBody, 1, 2);
		_status.runningState.value = mdSmart.message.getBit(pReceiveMessageBody, 1, 0);
		_status.settingMode.value = mdSmart.message.getBits(pReceiveMessageBody, 2, 5, 7);
		_status.settingTemperature.value = mdSmart.message.getBits(pReceiveMessageBody, 2, 0, 3);
		_status.settingTemperatureDot5.value = mdSmart.message.getBit(pReceiveMessageBody, 2, 4);
		_status.noPolarWindSpeedValue.value = mdSmart.message.getBits(pReceiveMessageBody, 3, 0, 6);
		_status.timingOpen.value = mdSmart.message.getBit(pReceiveMessageBody, 4, 7);
		_status.timingOpenAbsoluteHours.value = mdSmart.message.getBits(pReceiveMessageBody, 4, 0, 6);
		_status.timingOpenAbsoluteMinutes.value = mdSmart.message.getBits(pReceiveMessageBody, 6, 4, 7);
		_status.timingClose.value = mdSmart.message.getBit(pReceiveMessageBody, 5, 7);
		_status.timingCloseAbsoluteHours.value = mdSmart.message.getBits(pReceiveMessageBody, 5, 0, 6);
		_status.timingCloseAbsoluteMinutes.value = mdSmart.message.getBits(pReceiveMessageBody, 6, 0, 3);
		_status.shushiFeng.value = mdSmart.message.getByte(pReceiveMessageBody, 7);
		_status.downWind.value = mdSmart.message.getBit(pReceiveMessageBody, 20, 7);
		_status.personalFeeling.value = mdSmart.message.getBit(pReceiveMessageBody, 8, 7);
		_status.zhihuiyan.value = mdSmart.message.getBit(pReceiveMessageBody, 8, 6);
		_status.strong.value = mdSmart.message.getBit(pReceiveMessageBody, 8, 5);
		_status.ruiFeng.value = mdSmart.message.getBit(pReceiveMessageBody, 8, 4);
		_status.shengDian.value = mdSmart.message.getBit(pReceiveMessageBody, 8, 3);
		_status.sleepMode.value = mdSmart.message.getBits(pReceiveMessageBody, 8, 0, 1);
		_status.selfPersonalFeeling.value = mdSmart.message.getBit(pReceiveMessageBody, 9, 7);
		_status.selfSleep.value = mdSmart.message.getBit(pReceiveMessageBody, 9, 6);
		_status.purifyingFunction.value = mdSmart.message.getBit(pReceiveMessageBody, 9, 5);
		_status.ecoFunction.value = mdSmart.message.getBit(pReceiveMessageBody, 9, 4);
		_status.electricHeat.value = mdSmart.message.getBit(pReceiveMessageBody, 9, 3);
		_status.dry.value = mdSmart.message.getBit(pReceiveMessageBody, 9, 2);
		_status.naturalWindFunction.value = mdSmart.message.getBit(pReceiveMessageBody, 9, 1);
		_status.childrenSleepMode.value = mdSmart.message.getBit(pReceiveMessageBody, 9, 0);
		_status.coolWindMode.value = mdSmart.message.getBit(pReceiveMessageBody, 10, 7);
		_status.peakValleyElectricity.value = mdSmart.message.getBit(pReceiveMessageBody, 10, 6);
		_status.catchCold.value = mdSmart.message.getBit(pReceiveMessageBody, 10, 5);
		_status.nightLight.value = mdSmart.message.getBit(pReceiveMessageBody, 10, 4);
		_status.ventilation.value = mdSmart.message.getBit(pReceiveMessageBody, 10, 3);
		_status.celsiusFahrenheit.value = mdSmart.message.getBit(pReceiveMessageBody, 10, 2);
		_status.tubro.value = mdSmart.message.getBit(pReceiveMessageBody, 10, 1);
		_status.sleepFunctionStatus.value = mdSmart.message.getBit(pReceiveMessageBody, 10, 0);
		_status.indoorTemperature.value = mdSmart.message.getByte(pReceiveMessageBody, 11);
		_status.outdoorTemperature.value = mdSmart.message.getByte(pReceiveMessageBody, 12);
		_status.dustFullMark.value = mdSmart.message.getBit(pReceiveMessageBody, 13, 5);
		_status.filterReplace.value = mdSmart.message.getBit(pReceiveMessageBody, 13, 6);
		_status.settingTemperature2.value = mdSmart.message.getBits(pReceiveMessageBody, 13, 0, 4);
		_status.pmvMode.value = mdSmart.message.getBits(pReceiveMessageBody, 14, 0, 3);
		_status.faultNo.value = mdSmart.message.getByte(pReceiveMessageBody, 16);
		_status.ecoSleepRunningMinus.value = mdSmart.message.getBits(pReceiveMessageBody, 17, 2, 7);
		_status.ecoSleepRunningSecond.value = mdSmart.message.getBits(pReceiveMessageBody, 18, 4, 7) << 2 | mdSmart.message.getBits(pReceiveMessageBody, 17, 0, 1);
		_status.ecoSleepRunningHour.value = mdSmart.message.getBits(pReceiveMessageBody, 18, 0, 3);

		_status.indoorTemperatureDot.value = mdSmart.message.getBits(pReceiveMessageBody, 15, 0, 3);
		_status.outdoorTemperatureDot.value = mdSmart.message.getBits(pReceiveMessageBody, 15, 4, 7);

		_status.lightClass.value = mdSmart.message.getBits(pReceiveMessageBody, 14, 4, 6);
		//2015-04-14 设定湿度值
		_status.setHumidity.value = mdSmart.message.getBits(pReceiveMessageBody, 19, 0, 6);
		//	    frameCumulative=mdSmart.message.getByte(pReceiveMessageBody,20);

		_status.downWindControl = mdSmart.message.getBit(pReceiveMessageBody, 19, 7); //2017-05-05 for yb301
		_status.downWindControlLR = mdSmart.message.getBit(pReceiveMessageBody, 20, 7); //2017-05-05	 for yb301	

		//升级协议前长度为22，超过22按新协议解释   2015-04-03
		if(pReceiveMessageBody.length > 24) {
			//20150320 wjl
			bridge.logToIOS("AC_P04 smartWind=" + mdSmart.message.getBit(pReceiveMessageBody, 22, 3));
			_status.keepWarm.value = mdSmart.message.getBit(pReceiveMessageBody, 22, 0);
			_status.shabbat.value = mdSmart.message.getBit(pReceiveMessageBody, 22, 5);
			_status.windBlowing.value = mdSmart.message.getBit(pReceiveMessageBody, 22, 4);
			//	        _status.readyColdOrHot.value = mdSmart.message.getBit(pReceiveMessageBody,22,0);
			_status.braceLetSleep.value = mdSmart.message.getBit(pReceiveMessageBody, 22, 1);
			_status.braceLetContral.value = mdSmart.message.getBit(pReceiveMessageBody, 22, 2);
			_status.smartWind.value = mdSmart.message.getBit(pReceiveMessageBody, 22, 3);
			//	        frameCumulative=mdSmart.message.getByte(pReceiveMessageBody,23);

		}
		//2017-05-04 
		_status.order = mdSmart.message.getByte(pReceiveMessageBody, pReceiveMessageBody.length - 2);
	}
	// 空调自动上传命令(0x05)==>_status
	function _parseX05Xa0BackToStatus(pReceiveMessageBody) {
		_status.faultFlag.value = mdSmart.message.getBit(pReceiveMessageBody, 1, 7);
		//		_status.settingTemperature.value = mdSmart.message.getBits(pReceiveMessageBody,1,2,6) - 4;
		//		_status.settingTemperature.value = mdSmart.message.getBits(pReceiveMessageBody,1,2,6);
		//		_status.settingTemperatureDot5.value = mdSmart.message.getBit(pReceiveMessageBody,1,1);
		_status.settingTemperature.value = mdSmart.message.getBits(pReceiveMessageBody, 1, 1, 5) - 4;
		_status.settingTemperatureDot5.value = mdSmart.message.getBit(pReceiveMessageBody, 1, 6);
		_status.runningState.value = mdSmart.message.getBit(pReceiveMessageBody, 1, 0);

		_status.settingMode.value = mdSmart.message.getBits(pReceiveMessageBody, 2, 5, 7);

		_status.noPolarWindSpeedValue.value = mdSmart.message.getBits(pReceiveMessageBody, 3, 0, 6);

		_status.timingOpen.value = mdSmart.message.getBit(pReceiveMessageBody, 4, 7);
		_status.timingClose.value = mdSmart.message.getBit(pReceiveMessageBody, 5, 7);

		_status.timingOpenAbsoluteHours.value = mdSmart.message.getBits(pReceiveMessageBody, 4, 0, 6);
		_status.timingOpenAbsoluteMinutes.value = mdSmart.message.getBits(pReceiveMessageBody, 6, 4, 7);

		_status.timingCloseAbsoluteHours.value = mdSmart.message.getBits(pReceiveMessageBody, 5, 0, 6);
		_status.timingCloseAbsoluteMinutes.value = mdSmart.message.getBits(pReceiveMessageBody, 6, 0, 3);

		_status.shushiFeng.value = mdSmart.message.getByte(pReceiveMessageBody, 7);

		_status.downWind.value = mdSmart.message.getBit(pReceiveMessageBody, 9, 6);

		_status.personalFeeling.value = mdSmart.message.getBit(pReceiveMessageBody, 8, 7);

		//TODO:20140604物联网产品电控规格书-家用空调(网络).doc P21 节能有两个，是不是其中一个是误记
		_status.energySaving.value = mdSmart.message.getBit(pReceiveMessageBody, 8, 6);

		_status.strong.value = mdSmart.message.getBit(pReceiveMessageBody, 8, 5);

		_status.ruiFeng.value = mdSmart.message.getBit(pReceiveMessageBody, 8, 4);

		_status.shengDian.value = mdSmart.message.getBit(pReceiveMessageBody, 8, 3);

		_status.sleepMode.value = mdSmart.message.getBits(pReceiveMessageBody, 8, 0, 1);

		//TODO:20140604物联网产品电控规格书-家用空调(网络).doc P21 EOC功能有两个，是不是其中一个是误记
		_status.ecoFunction.value = mdSmart.message.getBit(pReceiveMessageBody, 9, 4);

		_status.purifyingFunction.value = mdSmart.message.getBit(pReceiveMessageBody, 9, 5);
		_status.electricHeat.value = mdSmart.message.getBit(pReceiveMessageBody, 9, 3);
		_status.dry.value = mdSmart.message.getBit(pReceiveMessageBody, 9, 2);
		_status.ventilation.value = mdSmart.message.getBit(pReceiveMessageBody, 9, 1);
		_status.zhihuiyan.value = mdSmart.message.getBit(pReceiveMessageBody, 9, 0);

		_status.downleftandrightMove.value = mdSmart.message.getBit(pReceiveMessageBody, 9, 6); //2015-03-25 wjl 

		_status.naturalWindFunction.value = mdSmart.message.getBit(pReceiveMessageBody, 10, 6);
		_status.peakValleyElectricity.value = mdSmart.message.getBit(pReceiveMessageBody, 10, 5);
		_status.nightLight.value = mdSmart.message.getBit(pReceiveMessageBody, 10, 4);
		_status.catchCold.value = mdSmart.message.getBit(pReceiveMessageBody, 10, 3);
		_status.childKick.value = mdSmart.message.getBit(pReceiveMessageBody, 10, 2); //2015-03-25 wjl
		_status.tubro.value = mdSmart.message.getBit(pReceiveMessageBody, 10, 1);
		_status.sleepFunctionStatus.value = mdSmart.message.getBit(pReceiveMessageBody, 10, 0);

		_status.pmvMode.value = mdSmart.message.getBits(pReceiveMessageBody, 11, 4, 7);

		//2015-03-25 wjl
		_status.lightClass.value = mdSmart.message.getBits(pReceiveMessageBody, 11, 0, 2);
		_status.eightHot.value = mdSmart.message.getBit(pReceiveMessageBody, 12, 7);
		_status.doubleContral.value = mdSmart.message.getBits(pReceiveMessageBody, 12, 6);
		_status.doubleContralTemp.value = mdSmart.message.getBits(pReceiveMessageBody, 12, 1, 5);
		_status.doubleContralDot.value = mdSmart.message.getBit(pReceiveMessageBody, 12, 0);

		//2015-04-14 设定湿度值
		_status.setHumidity.value = mdSmart.message.getBits(pReceiveMessageBody, 13, 0, 6);
		//无风感上报处理
		_status.smartWind.value = mdSmart.message.getBit(pReceiveMessageBody, 14, 3);

		//保温功能
		_status.keepWarm.value = mdSmart.message.getBit(pReceiveMessageBody, 14, 0);
		//健康降温
//		_status.ladderCool.value = mdSmart.message.getBit(pReceiveMessageBody, 14, 2);
		//以色列功能
		_status.shabbat.value = mdSmart.message.getBit(pReceiveMessageBody, 14, 5);		
		//旧协议防直吹功能
		_status.windBlowing.value = mdSmart.message.getBit(pReceiveMessageBody, 14, 4);
		
		//2017-05-05 同步下摆风状态
		_status.downWindControl = mdSmart.message.getBit(pReceiveMessageBody, 19, 7); //2017-05-05 for yb301
		_status.downWindControlLR = mdSmart.message.getBit(pReceiveMessageBody, 20, 7); //2017-05-05	 for yb301	

		//2017-05-04
		_status.order = mdSmart.message.getByte(pReceiveMessageBody, pReceiveMessageBody.length - 2);

	}
	// 空调自动上传命令(0x04)==>_status
	function _parseX04Xa1BackToStatus(pReceiveMessageBody) {
		//TODO:
	}

	function _doSynchronousEquipmentReturnCommandBackToCmd(pReceiveMessageBody) {
		var deviceName = _returnDeviceType();
		mdSmart.message.setBit(_messageBodyControl, 1, 5, mdSmart.message.getBit(pReceiveMessageBody, 1, 5));
		mdSmart.message.setBit(_messageBodyControl, 1, 4, mdSmart.message.getBit(pReceiveMessageBody, 1, 4));
		mdSmart.message.setBit(_messageBodyControl, 1, 2, mdSmart.message.getBit(pReceiveMessageBody, 1, 2));
		mdSmart.message.setBit(_messageBodyControl, 1, 0, mdSmart.message.getBit(pReceiveMessageBody, 1, 0));
		mdSmart.message.setBits(_messageBodyControl, 2, 5, 7, mdSmart.message.getBits(pReceiveMessageBody, 2, 5, 7));

		// 判断设定温度值
		if(mdSmart.message.getBits(pReceiveMessageBody, 2, 0, 3) == 0) {
			mdSmart.message.setBits(_messageBodyControl, 2, 0, 3, 1);
		} else if(mdSmart.message.getBits(pReceiveMessageBody, 2, 0, 3) >= 15) {
			mdSmart.message.setBits(_messageBodyControl, 2, 0, 3, 14);
		} else {
			mdSmart.message.setBits(_messageBodyControl, 2, 0, 4, mdSmart.message.getBits(pReceiveMessageBody, 2, 0, 4));
		}
		mdSmart.message.setBits(_messageBodyControl, 3, 7, 7, mdSmart.message.getBits(pReceiveMessageBody, 3, 7, 7));
		mdSmart.message.setBits(_messageBodyControl, 3, 0, 6, mdSmart.message.getBits(pReceiveMessageBody, 3, 0, 6));
		mdSmart.message.setByte(_messageBodyControl, 4, mdSmart.message.getByte(pReceiveMessageBody, 4));
		mdSmart.message.setByte(_messageBodyControl, 5, mdSmart.message.getByte(pReceiveMessageBody, 5));
		mdSmart.message.setByte(_messageBodyControl, 6, mdSmart.message.getByte(pReceiveMessageBody, 6));
		mdSmart.message.setByte(_messageBodyControl, 7, mdSmart.message.getByte(pReceiveMessageBody, 7));
		mdSmart.message.setBit(_messageBodyControl, 8, 7, mdSmart.message.getBit(pReceiveMessageBody, 8, 7));
		mdSmart.message.setBit(_messageBodyControl, 9, 0, mdSmart.message.getBit(pReceiveMessageBody, 8, 6));
		mdSmart.message.setBit(_messageBodyControl, 8, 5, mdSmart.message.getBit(pReceiveMessageBody, 8, 5));
		mdSmart.message.setBit(_messageBodyControl, 8, 4, mdSmart.message.getBit(pReceiveMessageBody, 8, 4));
		//		mdSmart.message.setBit(_messageBodyControl,8,3,mdSmart.message.getBit(pReceiveMessageBody,8,3));
		if(deviceName == "ZB300YJ") {
			mdSmart.message.setBit(_messageBodyControl, 8, 3, mdSmart.message.getBit(pReceiveMessageBody, 9, 4));
		} else {
			mdSmart.message.setBit(_messageBodyControl, 8, 3, mdSmart.message.getBit(pReceiveMessageBody, 8, 3));
		}
		mdSmart.message.setBits(_messageBodyControl, 8, 0, 1, mdSmart.message.getBits(pReceiveMessageBody, 8, 0, 1));
		//err第9字节，bit6位的切换舒睡开关没有？？？？
		mdSmart.message.setBit(_messageBodyControl, 9, 5, mdSmart.message.getBit(pReceiveMessageBody, 9, 5));
		mdSmart.message.setBit(_messageBodyControl, 9, 7, mdSmart.message.getBit(pReceiveMessageBody, 9, 4));
		mdSmart.message.setBit(_messageBodyControl, 9, 3, mdSmart.message.getBit(pReceiveMessageBody, 9, 3));
		mdSmart.message.setBit(_messageBodyControl, 9, 2, mdSmart.message.getBit(pReceiveMessageBody, 9, 2));
		//err第9字节，bit0 位的切换舒睡开关没有？？？？
		mdSmart.message.setBit(_messageBodyControl, 17, 6, mdSmart.message.getBit(pReceiveMessageBody, 9, 1));
		mdSmart.message.setBit(_messageBodyControl, 1, 3, mdSmart.message.getBit(pReceiveMessageBody, 9, 0));
		mdSmart.message.setBit(_messageBodyControl, 10, 5, mdSmart.message.getBit(pReceiveMessageBody, 10, 6));
		mdSmart.message.setBit(_messageBodyControl, 10, 3, mdSmart.message.getBit(pReceiveMessageBody, 10, 5));
		mdSmart.message.setBit(_messageBodyControl, 10, 4, mdSmart.message.getBit(pReceiveMessageBody, 10, 4));
		mdSmart.message.setBit(_messageBodyControl, 9, 1, mdSmart.message.getBit(pReceiveMessageBody, 10, 3));
		mdSmart.message.setBit(_messageBodyControl, 10, 2, mdSmart.message.getBit(pReceiveMessageBody, 10, 2));
		mdSmart.message.setBit(_messageBodyControl, 10, 1, mdSmart.message.getBit(pReceiveMessageBody, 10, 1));
		mdSmart.message.setBit(_messageBodyControl, 10, 0, mdSmart.message.getBit(pReceiveMessageBody, 10, 0));
		mdSmart.message.setBit(_messageBodyControl, 10, 6, mdSmart.message.getBit(pReceiveMessageBody, 13, 5));
		//mdSmart.message.setBits(_messageBodyControl,18,0,4,mdSmart.message.getBits(pReceiveMessageBody,13,0,4));
		// 屏蔽第二温度显示  2015-03-25
		mdSmart.message.setBits(_messageBodyControl, 18, 0, 4, 0);
		//mdSmart.message.setBits(_messageBodyControl,17,7,7,mdSmart.message.getBits(pReceiveMessageBody,13,0,0));//err
		//mdSmart.message.setBits(_messageBodyControl,18,5,7,mdSmart.message.getBits(pReceiveMessageBody,13,1,3));//err
		// 2015-03-18
		mdSmart.message.setBit(_messageBodyControl, 17, 7, mdSmart.message.getBit(pReceiveMessageBody, 14, 3));
		mdSmart.message.setBits(_messageBodyControl, 18, 5, 7, mdSmart.message.getBits(pReceiveMessageBody, 14, 0, 2));
		mdSmart.message.setBits(_messageBodyControl, 19, 0, 6, mdSmart.message.getBits(pReceiveMessageBody, 19, 0, 6));

		if(deviceName == "WYA") {
			mdSmart.message.setBit(_messageBodyControl, 19, 7, 0x00);
		} else {
			mdSmart.message.setBit(_messageBodyControl, 19, 7, 0x01);
		}

		mdSmart.message.setBit(_messageBodyControl, 20, 7, mdSmart.message.getBit(pReceiveMessageBody, 20, 7));
		bridge.logToIOS("messagebodycontrol=" + _messageBodyControl);
		//20150302 wjl 升级协议前长度为22，保留22位协议解释  2015-04-03
		if(pReceiveMessageBody.length > 24) {
			mdSmart.message.setBit(_messageBodyControl, 22, 0, mdSmart.message.getBit(pReceiveMessageBody, 22, 0));
			mdSmart.message.setBit(_messageBodyControl, 22, 1, mdSmart.message.getBit(pReceiveMessageBody, 22, 4));
			mdSmart.message.setBit(_messageBodyControl, 22, 2, mdSmart.message.getBit(pReceiveMessageBody, 22, 2));
			mdSmart.message.setBit(_messageBodyControl, 22, 3, mdSmart.message.getBit(pReceiveMessageBody, 22, 3));
		}
	}

	function _doSynchronousX05Xa0BackToCmd(pReceiveMessageBody) {
		var deviceName = _returnDeviceType();
		//mdSmart.message.setBits(_messageBodyControl,2,0,3,mdSmart.message.getBits(pReceiveMessageBody,1,2,6));

		//mdSmart.message.setBits(_messageBodyControl,2,0,3,mdSmart.message.getBits(pReceiveMessageBody,1,2,6));  //2015-04-15 wjl
		//mdSmart.message.setBit(_messageBodyControl,2,4,mdSmart.message.getBit(pReceiveMessageBody,1,1));

		mdSmart.message.setBit(_messageBodyControl, 1, 0, mdSmart.message.getBit(pReceiveMessageBody, 1, 0));
		//		mdSmart.message.setBits(_messageBodyControl,2,0,3,(mdSmart.message.getBits(pReceiveMessageBody,1,2,6) - 4));
		//		mdSmart.message.setBits(_messageBodyControl,2,0,3,(mdSmart.message.getBits(pReceiveMessageBody,1,2,6)));
		mdSmart.message.setBits(_messageBodyControl, 2, 0, 3, (mdSmart.message.getBits(pReceiveMessageBody, 1, 1, 5) - 4));
		mdSmart.message.setBit(_messageBodyControl, 2, 4, mdSmart.message.getBit(pReceiveMessageBody, 1, 6));
		mdSmart.message.setBits(_messageBodyControl, 2, 5, 7, mdSmart.message.getBits(pReceiveMessageBody, 2, 5, 7));
		mdSmart.message.setBits(_messageBodyControl, 3, 7, 7, mdSmart.message.getBits(pReceiveMessageBody, 3, 7, 7));
		mdSmart.message.setBits(_messageBodyControl, 3, 0, 6, mdSmart.message.getBits(pReceiveMessageBody, 3, 0, 6));
		mdSmart.message.setByte(_messageBodyControl, 4, mdSmart.message.getByte(pReceiveMessageBody, 4));
		mdSmart.message.setByte(_messageBodyControl, 5, mdSmart.message.getByte(pReceiveMessageBody, 5));
		mdSmart.message.setByte(_messageBodyControl, 6, mdSmart.message.getByte(pReceiveMessageBody, 6));
		mdSmart.message.setByte(_messageBodyControl, 7, mdSmart.message.getByte(pReceiveMessageBody, 7));
		mdSmart.message.setBit(_messageBodyControl, 8, 7, mdSmart.message.getBit(pReceiveMessageBody, 8, 7));
		mdSmart.message.setBit(_messageBodyControl, 8, 6, mdSmart.message.getBit(pReceiveMessageBody, 8, 6));
		mdSmart.message.setBit(_messageBodyControl, 8, 5, mdSmart.message.getBit(pReceiveMessageBody, 8, 5));
		mdSmart.message.setBit(_messageBodyControl, 8, 4, mdSmart.message.getBit(pReceiveMessageBody, 8, 4));
		//		mdSmart.message.setBit(_messageBodyControl,8,3,mdSmart.message.getBit(pReceiveMessageBody,8,3));
		if(deviceName == "ZB300YJ") {
			mdSmart.message.setBit(_messageBodyControl, 8, 3, mdSmart.message.getBit(pReceiveMessageBody, 9, 4));
		} else {
			mdSmart.message.setBit(_messageBodyControl, 8, 3, mdSmart.message.getBit(pReceiveMessageBody, 8, 3));
		}
		mdSmart.message.setBits(_messageBodyControl, 8, 0, 1, mdSmart.message.getBits(pReceiveMessageBody, 8, 0, 1));
		//TODO:ECO功能
		mdSmart.message.setBit(_messageBodyControl, 9, 7, mdSmart.message.getBit(pReceiveMessageBody, 9, 4));
		mdSmart.message.setBit(_messageBodyControl, 9, 5, mdSmart.message.getBit(pReceiveMessageBody, 9, 5));
		mdSmart.message.setBit(_messageBodyControl, 9, 3, mdSmart.message.getBit(pReceiveMessageBody, 9, 3));
		mdSmart.message.setBit(_messageBodyControl, 9, 2, mdSmart.message.getBit(pReceiveMessageBody, 9, 2));
		mdSmart.message.setBit(_messageBodyControl, 9, 1, mdSmart.message.getBit(pReceiveMessageBody, 9, 1));
		mdSmart.message.setBit(_messageBodyControl, 9, 0, mdSmart.message.getBit(pReceiveMessageBody, 9, 0));
		//TODO:节能
		mdSmart.message.setBit(_messageBodyControl, 17, 6, mdSmart.message.getBit(pReceiveMessageBody, 10, 6));
		mdSmart.message.setBit(_messageBodyControl, 10, 5, mdSmart.message.getBit(pReceiveMessageBody, 10, 5));
		mdSmart.message.setBit(_messageBodyControl, 10, 4, mdSmart.message.getBit(pReceiveMessageBody, 10, 4));
		mdSmart.message.setBit(_messageBodyControl, 10, 3, mdSmart.message.getBit(pReceiveMessageBody, 10, 3));
		mdSmart.message.setBit(_messageBodyControl, 10, 1, mdSmart.message.getBit(pReceiveMessageBody, 10, 1));
		mdSmart.message.setBit(_messageBodyControl, 10, 0, mdSmart.message.getBit(pReceiveMessageBody, 10, 0));
		//		mdSmart.message.setBits(_messageBodyControl,18,7,5,mdSmart.message.getBits(pReceiveMessageBody,11,7,5));
		//		mdSmart.message.setBits(_messageBodyControl,17,7,7,mdSmart.message.getBits(pReceiveMessageBody,11,4,4));
		mdSmart.message.setBits(_messageBodyControl, 18, 7, 5, mdSmart.message.getBits(pReceiveMessageBody, 11, 6, 4));
		mdSmart.message.setBits(_messageBodyControl, 17, 7, 7, mdSmart.message.getBits(pReceiveMessageBody, 11, 7, 7));
		mdSmart.message.setBit(_messageBodyControl, 20, 7, mdSmart.message.getBit(pReceiveMessageBody, 9, 6));
		mdSmart.message.setBit(_messageBodyControl, 22, 0, mdSmart.message.getBit(pReceiveMessageBody, 14, 0));
  		mdSmart.message.setBit(_messageBodyControl, 22, 1, mdSmart.message.getBit(pReceiveMessageBody, 14, 4));
		//设定湿度
		mdSmart.message.setBits(_messageBodyControl, 19, 0, 6, mdSmart.message.getBits(pReceiveMessageBody, 13, 0, 6));
	}

	function _doSynchronousX04Xa1BackToCmd(pReceiveMessageBody) {
		//TODO:
	}

	function _CRC8(pBytes) {
		return mdSmart.message.CRC8(pBytes);
	}

	function _returnDeviceType() {
		var subWYAList = "50585/50583";
		var subZB300YJList = "Z1170/Z2191";
		var SNStr = bridge.getCurrentDevSN();
		var deviceType = "";
		var deviceName = "AC";
		if(SNStr != "") {
			if(SNStr.length == '32') {
				deviceType = SNStr.substring(12, 17);
			} else {
				deviceType = SNStr.substring(6, 11);
			}
		}
		if(subWYAList.indexOf(deviceType) != '-1') {
			deviceName = "WYA";
		} else if(subZB300YJList.indexOf(deviceType) != '-1') {
			deviceName = "ZB300YJ";
		}
		return deviceName;
	}

	return {
		getCurrentBody: function() {
			return _messageBodyControl;
		},
		/**
		 * 生成设备控制命令
		 *
		 *@return {byteArray} 设备控制命令
		 */
		cmdControl: function(p1) {

			setReceiveUploadIsUnallowed(); //设置家电上报不可用 add by yuxg 20150826
			bridge.logToIOS("setReceiveUploadIsUnallowed");
			var messageBody = _messageBodyControl;
			//			alert(mdSmart.message.getBit(_messageBodyControl,22,0));
			// 只要当前状态是制热模式或自动模式的时候，这“电辅热”和“电辅热按键按下开启条件”两个bit都置为1  2015-03-18
			//			if(mdSmart.message.getBits(messageBody,2,5,7) == 1 || mdSmart.message.getBits(messageBody,2,5,7) == 4) {
			//				// 电辅热
			//				mdSmart.message.setBit(messageBody,9,3,1);
			//				// 电辅热按键按下标识
			//				mdSmart.message.setBit(messageBody,9,4,1);
			//			} 
			//设备控制命令
			mdSmart.message.setByte(messageBody, 0, 0x40);
			//按键状态
			//			mdSmart.message.setBit(messageBody,1,6,0x01);//按键状态有用户设置 modify by yuxg
			var SNStr = bridge.getCurrentDevSN();
			var promptStr = localStorage.getItem("ACTone" + SNStr);
			bridge.logToIOS("actone=" + promptStr + " sn=" + SNStr);
			if("0" == promptStr) {
				bridge.logToIOS("actone close sn=" + SNStr);
				mdSmart.message.setBit(messageBody, 1, 6, 0x00);
			} else {
				bridge.logToIOS("actone open sn=" + SNStr);
				mdSmart.message.setBit(messageBody, 1, 6, 0x01);
			}
			//遥控码来源
			mdSmart.message.setBit(messageBody, 1, 1, 0x00);
			//遥控码来源
			mdSmart.message.setBit(messageBody, 1, 1, 0x01);

			//关闭舒睡  2015-03-19
			//			alert(p1);
			//			if((p1 == undefined)||(p1 == 0)){
			if(p1 == 0) {
				mdSmart.message.setBits(messageBody, 8, 0, 1, 0x00);
				mdSmart.message.setBit(messageBody, 9, 6, 0x00);
			} else if(p1 == 9) {
				mdSmart.message.setBits(messageBody, 8, 0, 1, 0x00);
				mdSmart.message.setBit(messageBody, 9, 6, 0x00);
				//按键状态
				mdSmart.message.setBit(messageBody, 1, 6, 0x00);
			}

			//重写帧序号	
			tmpTimeValue = Date.parse(new Date()) / 1000;
			tmptOrder = (tmpTimeValue - currentTimeValue) % 255;
			if(tmptOrder == currentOrder) {
				tmptOrder = tmptOrder + 1;
			}
			if((tmptOrder == 0) || (tmptOrder > 255) || (tmptOrder == 2)) {
				tmptOrder = 10;
			}
			currentOrder = tmptOrder;

			var pk = 0xff & tmptOrder;
			mdSmart.message.setByte(messageBody, 23, pk);

			bridge.logToIOS("send frameCumulative=" + frameCumulative);
			//设定温度BYTE18
			mdSmart.message.setBits(messageBody, 18, 0, 4, 0x00);
			//CRC8
			//mdSmart.message.setByte(messageBody,21,_CRC8(messageBody));

			//20150320 wjl
			mdSmart.message.setByte(messageBody, 24, _CRC8(messageBody));
			//			alert('messageBody:' + messageBody);

			var message = mdSmart.message.createMessage(0xAC, 0x02, messageBody);

			return message;
		},

		/**
		 * 生成设备状态查询命令
		 *
		 *@return {byteArray} 
		 */
		cmdCheckStatus: function(p1) {

			setReceiveUploadIsUnallowed(); //设置家电上报不可用 add by yuxg 20150826
			var messageBody = _messageBodyCheckStatus;

			mdSmart.message.setByte(messageBody, 0, 0x41);
			mdSmart.message.setByte(messageBody, 1, 0x21);
			mdSmart.message.setByte(messageBody, 2, 0x01);
			mdSmart.message.setByte(messageBody, 3, 0x40 + p1);
			mdSmart.message.setByte(messageBody, 4, 0x00);
			mdSmart.message.setByte(messageBody, 5, 0x01);
			mdSmart.message.setByte(messageBody, 6, _CRC8(messageBody));

			var message = mdSmart.message.createMessage(0xAC, 0x03, messageBody);
			return message;
		},
		/**
		 * 生成电量校准命令
		 *
		 *@return {byteArray} 
		 */
		cmdCheckElec: function(p1, p2, p3, p4, p5) {
			var messageBody = _messageBodyCheckStatus;

			mdSmart.message.setByte(messageBody, 0, 0x41);
			mdSmart.message.setByte(messageBody, 1, 0x21);
			mdSmart.message.setByte(messageBody, 2, 0x01);
			mdSmart.message.setByte(messageBody, 3, 0x80 + p1);
			mdSmart.message.setByte(messageBody, 4, 0x02);
			mdSmart.message.setByte(messageBody, 5, p2);
			mdSmart.message.setByte(messageBody, 6, p3);
			mdSmart.message.setByte(messageBody, 7, p4);
			mdSmart.message.setByte(messageBody, 8, p5);
			mdSmart.message.setByte(messageBody, 9, _CRC8(messageBody));

			var message = mdSmart.message.createMessage(0xAC, 0x03, messageBody);
			//alert(message);
			return message;
		},

		/*2015-04-24 设置睡眠曲线
		 * p1:0:关闭曲线;1:打开曲线
		 * p2:曲线数据
		 */
		setLocationSleepMode: function(p1, p2) {
			//alert(p1 + '  ' + p2);
			mdSmart.message.setBit(_messageBodyControl, 1, 1, 0); //app来源标志
			mdSmart.message.setBits(_messageBodyControl, 8, 0, 1, p1);
			mdSmart.message.setBit(_messageBodyControl, 9, 6, 1);

			//舒睡开启后关闭自然风、强劲、睿风、无风感、ECO、舒睡、默认自动风
			mdSmart.message.setBit(_messageBodyControl, 17, 6, 0);
			mdSmart.message.setBit(_messageBodyControl, 8, 5, 0);
			mdSmart.message.setBit(_messageBodyControl, 8, 4, 0);
			mdSmart.message.setBit(_messageBodyControl, 9, 7, 0);
			mdSmart.message.setBit(_messageBodyControl, 17, 7, 0);
			mdSmart.message.setBits(_messageBodyControl, 18, 5, 7, 0);
			mdSmart.message.setBits(_messageBodyControl, 3, 6, 0, 102);
			if(p1 == 3) {
				mdSmart.message.setBit(_messageBodyControl, 10, 3, 0);
			}

			//第1小时
			mdSmart.message.setBits(_messageBodyControl, 11, 0, 3, p2[0]);
			mdSmart.message.setBit(_messageBodyControl, 16, 0, 0);
			//第2小时
			mdSmart.message.setBits(_messageBodyControl, 11, 4, 7, p2[1]);
			mdSmart.message.setBit(_messageBodyControl, 16, 1, 0);
			//第3小时
			mdSmart.message.setBits(_messageBodyControl, 12, 0, 3, p2[2]);
			mdSmart.message.setBit(_messageBodyControl, 16, 2, 0);
			//第4小时
			mdSmart.message.setBits(_messageBodyControl, 12, 4, 7, p2[3]);
			mdSmart.message.setBit(_messageBodyControl, 16, 3, 0);
			//第5小时
			mdSmart.message.setBits(_messageBodyControl, 13, 0, 3, p2[4]);
			mdSmart.message.setBit(_messageBodyControl, 16, 4, 0);
			//第6小时
			mdSmart.message.setBits(_messageBodyControl, 13, 4, 7, p2[5]);
			mdSmart.message.setBit(_messageBodyControl, 16, 5, 0);
			//第7小时
			mdSmart.message.setBits(_messageBodyControl, 14, 0, 3, p2[6]);
			mdSmart.message.setBit(_messageBodyControl, 16, 6, 0);
			//第8小时
			mdSmart.message.setBits(_messageBodyControl, 14, 4, 7, p2[7]);
			mdSmart.message.setBit(_messageBodyControl, 16, 7, 0);
			//第9小时
			mdSmart.message.setBits(_messageBodyControl, 15, 0, 3, p2[8]);
			mdSmart.message.setBit(_messageBodyControl, 17, 4, 0);
			//第10小时
			mdSmart.message.setBits(_messageBodyControl, 15, 4, 7, p2[9]);
			mdSmart.message.setBit(_messageBodyControl, 17, 5, 0);

			//有效时间10个小时
			mdSmart.message.setBits(_messageBodyControl, 17, 0, 3, 10);
		},

		/**
		 * SET-预冷预热功能  20150320 wjl
		 *@param {Number} p1 预冷预热状态
		 *                 0-关
		 *				   1-开
		 */
		//		setreadyColdOrHor:function(p1){
		//			mdSmart.message.setBit(_messageBodyControl,22,0,p1);
		//		},
		/**
		 * SET-手环与舒睡联动功能  20150320 wjl
		 *@param {Number} p1 手环与舒睡联动状态
		 *                 0-关
		 *				   1-开
		 */
		setbraceLetSleep: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 22, 1, p1);
		},

		/**
		 * SET-手环离家与回家模式状态  20150320 wjl
		 *@param {Number} p1 手环离字与回家模式状态
		 *                 0-关
		 *				   1-开
		 */
		setbraceLetContral: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 22, 2, p1);
		},
		/**
		 * SET-无风感开关  20150320 wjl
		 *@param {Number} p1 无风感开关
		 *                 0-关
		 *				   1-开
		 */
		setsmartWind: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 22, 3, p1);
		},
		/**
		 * SET-按键状态(按键有无用于决定空调器蜂鸣器是否发出声音)
		 *@param {Number} p1 按键状态
		 *                 0-无键
		 *				   1-有键
		 */
		setKeystrokeStatus: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 1, 6, p1);
		},
		/**
		 * SET-快检状态
		 *@param {Number} p1 快检状态
		 *                 默认：0
		 */
		setFastCheckStatus: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 1, 5, p1 == undefined ? 0x00 : p1);
		},
		/**
		 * SET-定时方式
		 *@param {Number} p1 定时方式
		 *                 0-相对定时
		 *				   1-绝对定时
		 */
		setTimingMode: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 1, 4, p1);
		},
		/**
		 * SET-儿童睡眠模式
		 *@param {Number} p1 儿童睡眠模式
		 *                 1：开启
		 *				   0：关闭
		 */
		setChildrenSleepMode: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 1, 3, p1);
		},
		/**
		 * SET-I模式恢复
		 *@param {Number} p1 I模式恢复
		 *                 默认：0
		 */
		setIModeRecovery: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 1, 2, p1 == undefined ? 0x00 : p1);
		},
		/**
		 * SET-运行状态
		 *@param {Number} p1 运行状态
		 *                 0-关机
		 *                 1-开机
		 */
		setRunningState: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 1, 0, p1);
		},
		/**
		 * SET-设定模式
		 *@param {Number} p1 模式
		 *                 0-无效
		 *                 1-自动
		 *                 2-制冷
		 *                 3-抽湿
		 *                 4-制热
		 *                 5-送风
		 *                 6-自动除湿			2015-04-14
		 *                 7-手动除湿
		 */
		setSetMode: function(p1) {
			mdSmart.message.setBits(_messageBodyControl, 2, 5, 7, p1);
			//			if(p1 == 6){
			//				mdSmart.message.setBits(_messageBodyControl,19,0,6,101);
			//			}else if(p1 == 7){
			//				mdSmart.message.setBits(_messageBodyControl,19,0,6,60);
			//			}
		},
		/*设定湿度
		 */
		setHumidity: function(p1) {
			mdSmart.message.setBits(_messageBodyControl, 19, 0, 6, p1);
		},

		/**
		 * SET-设定温度
		 *@param {Number} p1 温度
		 *                 0-无效
		 *				   1-17℃-62
		 *				   2-18℃-64
		 *				   ...
		 *				   13-29℃-84
		 *				   14-30℃-86
		 *		 {Number} p2 华氏奇偶
		 *                 0-+0.0-偶数
		 *				   1-+0.5-奇数
		 */
		setSetTemperate: function(p1, p2) {
			mdSmart.message.setBits(_messageBodyControl, 2, 0, 3, p1);
			mdSmart.message.setBit(_messageBodyControl, 2, 4, p2);
		},
		/**
		 * SET-移动终端定时信息
		 *@param {Number} p1 有效/无效
		 *                 0 - 无效
		 *				   1 - 有效
		 */
		setMobileTimerInfoSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 3, 7, p1);
		},
		/**
		 * SET-无极风速值
		 *(手机端只保留5档风速
		 * 自动模式，风速不可调，固定为自动风102
		 * 抽湿模式，风速不可调，固定为固定风101，手机软件显示自风)
		 *@param {Number} p1 无极风速值
		 *                 0-无效
		 *                 高风-80
		 *				   中风-60
		 *				   低风-40
		 *				   静音风－20
		 *				   自动风/固定风-102/101
		 */
		setNoPolarWindSpeedValue: function(p1) {
			// 改变风速，强制取消强劲
			mdSmart.message.setBit(_messageBodyControl, 8, 5, 0);

			mdSmart.message.setBits(_messageBodyControl, 3, 6, 0, p1);
		},
		/**
		 * SET-定时开
		 *@param {Number} p1 开/关
		 *                 0- 关
		 *                 1- 开
		 */
		setTimerOpenSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 4, 7, p1);
		},
		/**
		 * SET-定时开－绝对小时
		 *@param {Number} p1 定时开－绝对小时
		 */
		setTimerOpenAbsoluteHour: function(p1) {
			mdSmart.message.setBits(_messageBodyControl, 4, 0, 6, p1);
		},
		/**
		 * SET-定时开－绝对分
		 *@param {Number} p1 定时开－绝对分
		 */
		setTimerOpenAbsoluteMinute: function(p1) {
			/* 协议修正，修正来源赵俊帅出差得来，没有文档记录，没有新协议文档2014/09/25 */
			/* mdSmart.message.setBits(_messageBodyControl,4,0,1,mdSmart.message._getBits(p1,0,1)); */
			/* mdSmart.message.setBits(_messageBodyControl,6,4,7,mdSmart.message._getBits(p1,2,5)); */
			mdSmart.message.setBits(_messageBodyControl, 6, 4, 7, p1);
		},
		/**
		 * SET-定时关
		 *@param {Number} p1 开/关
		 *                 0- 关
		 *                 1- 开
		 */
		setTimerCloseSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 5, 7, p1);
		},
		/**
		 * SET-定时关－绝对小时
		 *@param {Number} p1 定时关－绝对小时
		 */
		setTimerCloseAbsoluteHour: function(p1) {
			mdSmart.message.setBits(_messageBodyControl, 5, 0, 6, p1);
		},
		/**
		 * SET-定时关－绝对分
		 *@param {Number} p1 定时关－绝对分
		 */
		setTimerCloseAbsoluteMinute: function(p1) {
			/* 协议修正，修正来源赵俊帅出差得来，没有文档记录，没有新协议文档2014/09/25 */
			/* mdSmart.message.setBits(_messageBodyControl,5,0,1,mdSmart.message._getBits(p1,0,1)); */
			/* mdSmart.message.setBits(_messageBodyControl,6,0,3,mdSmart.message._getBits(p1,2,5)); */
			mdSmart.message.setBits(_messageBodyControl, 6, 0, 3, p1);
		},
		/**
		 *SET-舒适风(舒适风键)
		 *@param {Number} p1 指示
		 *                 0x11-广角
		 *				   0x12-左广角
		 *				   0x13-右广角
		 *				   0x14-左定点
		 *				   0x15-右定点
		 *				   0x16-正面定点
		 *				   0x17-环绕立体风
		 *				   0x18-跟随-迎风
		 *				   0x19-避开-避风
		 *				   0x20-正出风上下摆
		 *				   0x21-正出风左右摆
		 *				   0x22-侧出风左右摆
		 */
		setComfortWindVH: function(p1) {
			mdSmart.message.setByte(_messageBodyControl, 7, p1);
		},
		/**
		 *SET-舒适风(0x3-左侧上下风)
		 *@param {Number} p1 指示
		 *                 0-关闭
		 *				   1-开启
		 */
		setComfortWind0x3LV: function(p1) {
			mdSmart.message.setBits(_messageBodyControl, 7, 4, 7, 0x03);
			mdSmart.message.setBit(_messageBodyControl, 7, 3, p1);
		},
		/**
		 *SET-舒适风(0x3-右侧上下风)
		 *@param {Number} p1 指示
		 *                 0-关闭
		 *				   1-开启
		 */
		setComfortWind0x3RV: function(p1) {
			mdSmart.message.setBits(_messageBodyControl, 7, 4, 7, 0x03);
			mdSmart.message.setBit(_messageBodyControl, 7, 2, p1);
		},
		/**
		 *SET-舒适风(0x3-左侧左右风)
		 *@param {Number} p1 指示
		 *                 0-关闭
		 *				   1-开启
		 */
		setComfortWind0x3LH: function(p1) {
			mdSmart.message.setBits(_messageBodyControl, 7, 4, 7, 0x03);
			mdSmart.message.setBit(_messageBodyControl, 7, 1, p1);
		},
		/**
		 *SET-舒适风(0x3-右侧左右风)
		 *@param {Number} p1 指示
		 *                 0-关闭
		 *				   1-开启
		 */
		setComfortWind0x3RH: function(p1) {
			mdSmart.message.setBits(_messageBodyControl, 7, 4, 7, 0x03);
			mdSmart.message.setBit(_messageBodyControl, 7, 0, p1);
		},
		/**
		 *SET-下摆风(19字节第7位代表下摆风是否独立控制)
		 *@param {Number} p1 指示
		 *                 0-通过左右摇摆控制
		 *				   1-独立控制
		 */
		setComfortWindDownControl: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 19, 7, p1);
		},
		/**
		 *SET-下摆风(20字节第7位下摆风开启及关闭状态)
		 *@param {Number} p2 指示
		 *                 0-关闭
		 *				   1-开启
		 */
		setComfortWindDownState: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 20, 7, p1);
		},
		/**
		 *SET-随身感
		 *@param {Number} p1 指示
		 *                 0—关
		 *				   1—开
		 */
		setPersonalFeelingSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 8, 7, p1);
		},
		/**
		 *SET-节能
		 *@param {Number} p1 指示
		 *                 0—关
		 *				   1—开
		 */
		setEnergySavingSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 8, 6, p1);
		},
		/**
		 *SET-强劲
		 *@param {Number} p1 指示
		 *                 0—关
		 *				   1—开
		 */
		setStrongSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 8, 5, p1);
		},
		/**
		 *SET-睿风
		 *@param {Number} p1 指示
		 *                 0—关
		 *				   1—开
		 */
		setRuiFengSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 8, 4, p1);
		},
		/**
		 *SET-省电
		 *@param {Number} p1 指示
		 *                 0—关
		 *				   1—开
		 */
		setPowerSavingSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 8, 3, p1);
		},
		/**
		 *SET-闹铃睡眠
		 *@param {Number} p1 指示
		 *                 0—关
		 *				   1—开
		 */
		setAlarmSleepSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 8, 2, p1);
		},
		/**
		 *SET-舒睡模式
		 *@param {Number} p1 指示
		 *                 00-无舒睡
		 *				   01- 舒睡1
		 *				   02- 舒睡2
		 *				   03- 舒睡3
		 */
		setSleepModeSwitch: function(p1) {
			mdSmart.message.setBits(_messageBodyControl, 8, 0, 1, p1);
		},
		/**
		 *SET-ECO功能
		 *@param {Number} p1 指示
		 *                 0- 关
		 *				   1- 开
		 */
		setEOCFunctionSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 9, 7, p1);
		},
		/**
		 *SET-保温功能
		 *@param {Number} p1 指示
		 *                 0- 关
		 *				   1- 开
		 */
		setKeepWarmSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 22, 0, p1);
		},
		/**
		 *SET- 以色列功能
		 *@param {Number} p1 指示
		 *                 0- 关
		 *				   1- 开
		 */
		setShabbatSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 22, 1, p1);
		},
		/**
		 *SET-旧协议防直吹功能
		 *@param {Number} p1 指示
		 *                 0- 关
		 *				   1- 开
		 */
		setWindBlowingSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 22, 1, p1);
		},
		
		/**
		 *SET-切换舒睡曲线
		 *@param {Number} p1 指示
		 *                 0- 关
		 *				   1- 开
		 */
		setSwitchSleepingCurve: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 9, 6, p1);
		},
		/**
		 *SET-净化功能
		 *@param {Number} p1 
		 */
		setPurifyingFunction: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 9, 5, p1);
		},
		/**
		 *SET-电辅热按键按下标识(当按下电辅热按键时，发1)
		 *@param {Number} p1 指示
		 */
		setElectricHeatingButtonPressFlg: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 9, 4, p1);
		},
		/**
		 *SET-电辅热
		 *@param {Number} p1 
		 */
		setElectricAuxiliaryHeat: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 9, 3, p1);
		},
		/**
		 *SET-干燥
		 *@param {Number} p1 
		 */
		setDry: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 9, 2, p1);
		},
		/**
		 *SET-防着凉
		 *@param {Number} p1 
		 */
		setPreventingCold: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 10, 3, p1);
		},
		/**
		 *SET-换气
		 *@param {Number} p1 
		 */
		setChangeAir: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 9, 1, p1);
		},
		/**
		 *SET-智慧眼
		 *@param {Number} p1 
		 */
		setZhihuiyan: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 9, 0, p1);
		},
		/**
		 *SET-清除风机运行时间
		 *@param {Number} p1 指示
		 *                 0- 关
		 *				   1- 开
		 */
		setScavengingFlowerRunningTimeSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 10, 7, p1);
		},
		/**
		 *SET-尘满标识
		 *@param {Number} p1 尘满标识
		 *                 0：尘满未到
		 *				   1：尘满时间到
		 */
		setDustFullMark: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 10, 6, p1);
		},
		/**
		 *SET-峰谷节电功能
		 *@param {Number} p1 指示
		 *                 0：关闭
		 *				   1：开启
		 */
		setPeakValleyElectricitySavingFunctonSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 10, 5, p1);
		},
		/**
		 *SET-小夜灯
		 *@param {Number} p1 指示
		 *                 0：关闭
		 *				   1：开启
		 */
		setNightLightSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 10, 4, p1);
		},
		/**
		 *SET-防着凉
		 *@param {Number} p1 指示
		 *                 0：关闭
		 *				   1：开启
		 */
		setCatchColdSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 10, 3, p1);
		},
		/**
		 *SET-摄氏/华氏
		 *@param {Number} p1 指示
		 *                 0：摄氏
		 *				   1：华氏
		 */
		setCelsiusFahrenheitSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 10, 2, p1);
		},
		/**
		 *SET-TUBRO状态
		 *1、TUBRO功能只有在制冷和制热模式下，其他模式下无效的逻辑由空调主控处理；
		 *如果XML中无此项，发0x00，兼容国内空调
		 *@param {Number} p1 指示
		 *                 0：关
		 *				   1：开
		 */
		setTubroStateSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 10, 1, p1);
		},
		/**
		 *SET-Sleep功能状态
		 * 1、SLEEP后，风速改变，模式改变取消SLEEP（强制置bit0为0）由UI及上层应用处理；
		 * 2、只有在制冷、制热、自动模式，内机7小时关机,下有效的逻辑由空调主控处理；
		 *@param {Number} p1 指示
		 *                 0：关
		 *				   1：开
		 */
		setSleepFunctionSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 10, 0, p1);
		},
		/**
		 *SET-第一小时舒睡温度
		 *@param {Number} p1 温度
		 *		 {Number} p2 +0.5℃标示
		 */
		setFirstHourSleepTemperature: function(p1, p2) {
			mdSmart.message.setBits(_messageBodyControl, 11, 0, 3, p1);
			mdSmart.message.setBit(_messageBodyControl, 16, 0, p2);
		},
		/**
		 *SET-第二小时舒睡温度
		 *@param {Number} p1 温度
		 *		 {Number} p2 +0.5℃标示
		 */
		setSecondHourSleepTemperature: function(p1, p2) {
			mdSmart.message.setBits(_messageBodyControl, 11, 4, 7, p1);
			mdSmart.message.setBit(_messageBodyControl, 16, 1, p2);
		},
		/**
		 *SET-第三小时舒睡温度
		 *@param {Number} p1 温度
		 *		 {Number} p2 +0.5℃标示
		 */
		setThirdHourSleepTemperature: function(p1, p2) {
			mdSmart.message.setBits(_messageBodyControl, 12, 0, 3, p1);
			mdSmart.message.setBit(_messageBodyControl, 16, 2, p2);
		},
		/**
		 *SET-第四小时舒睡温度
		 *@param {Number} p1 温度
		 *		 {Number} p2 +0.5℃标示
		 */
		setFourthHourSleepTemperature: function(p1, p2) {
			mdSmart.message.setBits(_messageBodyControl, 12, 4, 7, p1);
			mdSmart.message.setBit(_messageBodyControl, 16, 3, p2);
		},
		/**
		 *SET-第五小时舒睡温度
		 *@param {Number} p1 温度
		 *		 {Number} p2 +0.5℃标示
		 */
		setFifthHourSleepTemperature: function(p1, p2) {
			mdSmart.message.setBits(_messageBodyControl, 13, 0, 3, p1);
			mdSmart.message.setBit(_messageBodyControl, 16, 4, p2);
		},
		/**
		 *SET-第六小时舒睡温度
		 *@param {Number} p1 温度
		 *		 {Number} p2 +0.5℃标示
		 */
		setSixthHourSleepTemperature: function(p1, p2) {
			mdSmart.message.setBits(_messageBodyControl, 13, 4, 7, p1);
			mdSmart.message.setBit(_messageBodyControl, 16, 5, p2);
		},
		/**
		 *SET-第七小时舒睡温度
		 *@param {Number} p1 温度
		 *		 {Number} p2 +0.5℃标示
		 */
		setSeventhHourSleepTemperature: function(p1, p2) {
			mdSmart.message.setBits(_messageBodyControl, 14, 0, 3, p1);
			mdSmart.message.setBit(_messageBodyControl, 16, 6, p2);
		},
		/**
		 *SET-第八小时舒睡温度
		 *@param {Number} p1 温度
		 *		 {Number} p2 +0.5℃标示
		 */
		setEighthHourSleepTemperature: function(p1, p2) {
			mdSmart.message.setBits(_messageBodyControl, 14, 4, 7, p1);
			mdSmart.message.setBit(_messageBodyControl, 16, 7, p2);
		},
		/**
		 *SET-第九小时舒睡温度
		 *@param {Number} p1 温度
		 *		 {Number} p2 +0.5℃标示
		 */
		setNinthHourSleepTemperature: function(p1, p2) {
			mdSmart.message.setBits(_messageBodyControl, 15, 0, 3, p1);
			mdSmart.message.setBit(_messageBodyControl, 17, 4, p2);
		},
		/**
		 *SET-第十小时舒睡温度
		 *@param {Number} p1 温度
		 *		 {Number} p2 +0.5℃标示
		 */
		setTenHourSleepTemperature: function(p1, p2) {
			mdSmart.message.setBits(_messageBodyControl, 15, 4, 7, p1);
			mdSmart.message.setBit(_messageBodyControl, 17, 5, p2);
		},
		/**
		 *SET-PMV功能
		 *@param {Number} p1 温度
		 *					0000：PMV功能关闭
		 *					0001：PMV功能-3
		 *					0010 ：PMV功能-2.5
		 *					0011：PMV功能-2
		 *					0100 ：PMV功能-1.5
		 *					0101：PMV功能-1
		 *					0110 ：PMV功能-0.5
		 *					0111：PMV功能0
		 *					1000 ：PMV功能0.5
		 *					1001：PMV功能1
		 *					1010 ：PMV功能1.5
		 *					1011：PMV功能2
		 *					1100 ：PMV功能2.5
		 *					1101：PMV功能3
		 */
		setPMVFunction: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 17, 7, mdSmart.message._getBit(p1, 3));
			mdSmart.message.setBits(_messageBodyControl, 18, 5, 7, mdSmart.message._getBits(p1, 0, 2));
		},
		/**
		 *SET-自然风功能
		 *@param {Number} p1 指示
		 *					0：关闭
		 *					1：开启
		 */
		setNaturalWindFunctionSwitch: function(p1) {
			mdSmart.message.setBit(_messageBodyControl, 17, 6, p1);
		},
		/**
		 *SET-舒睡时间
		 *@param {Number} p1 舒睡小时
		 *					0-10
		 */
		setSleepingTime: function(p1) {
			mdSmart.message.setBits(_messageBodyControl, 17, 0, 3, p1);
		},
		/**
		 * SET-设定温度10Byte
		 *@param {Number} p1 温度
		 *                 0-无效
		 *				   1——13℃
		 *				   2——14℃
		 *				   ...
		 *				   21——33℃
		 *				   22——34℃
		 */
		setSetTemperate18B: function(p1) {
			mdSmart.message.setBits(_messageBodyControl, 18, 0, 4, p1);
		},
		/**
		 * 生成设备参数查询命令
		 *
		 *@return {byteArray} 设备当前参数查询命令
		 */
		cmdRequestDevStatus: function(p1) {

			setReceiveUploadIsUnallowed(); //设置家电上报不可用 add by yuxg 20150826
			var messageBody = _messageBodyRequestStatus;
			messageBody[0] = 0x41;
			messageBody[1] = 0x21;
			messageBody[2] = 0x01;
			messageBody[3] = 0x40 + p1;
			messageBody[4] = 0x00;
			messageBody[5] = 0x00;
			messageBody[6] = 0x00;
			messageBody[7] = 0x00;
			messageBody[8] = 0x00;
			messageBody[9] = 0x00;
			messageBody[10] = 0x00;
			messageBody[11] = 0x00;
			messageBody[12] = 0x00;
			messageBody[13] = 0x00;
			messageBody[14] = 0x00;
			messageBody[15] = 0x00;
			messageBody[16] = 0x00;
			messageBody[17] = 0x00;
			messageBody[18] = 0x00;
			messageBody[19] = 0x00;
			messageBody[20] = 0x00;

			//20150320 wjl
			messageBody[21] = 0x00;
			messageBody[22] = 0x00;
			messageBody[23] = 0x01;

			//CRC8
			//mdSmart.message.setByte(messageBody,21,_CRC8(messageBody));

			//20150320 wjl
			mdSmart.message.setByte(messageBody, 24, _CRC8(messageBody));

			var message = mdSmart.message.createMessage(0xAC, 0x03, messageBody)

			return message;
		},
		/**
		 * 生成设备当前状态查询命令
		 *
		 *@return {byteArray} 设备当前状态查询命令
		 */
		cmdRequestStatus: function() {
			var messageBody = _messageBodyRequestStatus;
			//设备控制命令
			mdSmart.message.setByte(messageBody, 0, 0x41);
			//收到回传数据标志
			//mdSmart.message.setBit(messageBody,1,7,0x00);
			//按键状态
			// mdSmart.message.setBit(messageBody,1,6,0x01);
			//独立码类型
			//mdSmart.message.setBits(messageBody,1,0,5,0x00);
			messageBody[1] = 0x81;
			//Byte2
			mdSmart.message.setByte(messageBody, 2, 0x00);
			//Byte3
			mdSmart.message.setByte(messageBody, 3, 0xFF);
			messageBody[4] = 3;
			messageBody[5] = 0xff;
			messageBody[7] = 2;
			//发送帧累加
			frameCumulative = frameCumulative + 1;
			if(frameCumulative > 0 && frameCumulative < 254) {
				//mdSmart.message.setByte(messageBody,20,frameCumulative);

				//20150320 wjl
				mdSmart.message.setByte(messageBody, 23, frameCumulative);
			} else if(frameCumulative == 0 || frameCumulative == 254) {
				frameCumulative = 1;
				//mdSmart.message.setByte(messageBody,20,frameCumulative);

				//20150320
				mdSmart.message.setByte(messageBody, 23, frameCumulative);
			}
			//CRC8
			//mdSmart.message.setByte(messageBody,21,_CRC8(messageBody));

			//20150320 wjl
			mdSmart.message.setByte(messageBody, 24, _CRC8(messageBody));
			var message = mdSmart.message.createMessage(0xAC, 0x03, messageBody);
			return message;
		},
		/**
		 * 生成设备当前状态查询命令
		 *
		 *@return {byteArray} 设备当前状态查询命令
		 */
		cmdChangeDisplay: function() {
			var messageBody = _messageBodyRequestStatus;
			//设备控制命令
			mdSmart.message.setByte(messageBody, 0, 0x41);
			var SNStr = bridge.getCurrentDevSN();
			var promptStr = localStorage.getItem("ACTone" + SNStr);
			//收到回传数据标志
			//mdSmart.message.setBit(messageBody,1,7,0x00);
			//按键状态
			// mdSmart.message.setBit(messageBody,1,6,0x01);
			//独立码类型
			//mdSmart.message.setBits(messageBody,1,0,5,0x00);
			messageBody[1] = 0x81;
			if("0" == promptStr) {
				mdSmart.message.setBit(messageBody, 1, 6, 0x00);
			} else {
				mdSmart.message.setBit(messageBody, 1, 6, 0x01);
			}
			//Byte2
			mdSmart.message.setByte(messageBody, 2, 0x00);
			//Byte3
			mdSmart.message.setByte(messageBody, 3, 0xFF);
			messageBody[4] = 2;
			messageBody[5] = 0xff;
			messageBody[6] = 2;
			messageBody[7] = 2;
			//发送帧累加
			frameCumulative = frameCumulative + 1;
			if(frameCumulative > 0 && frameCumulative < 254) {
				//mdSmart.message.setByte(messageBody,20,frameCumulative);

				//20150320 wjl
				mdSmart.message.setByte(messageBody, 23, frameCumulative);
			} else if(frameCumulative == 0 || frameCumulative == 254) {
				frameCumulative = 1;
				//mdSmart.message.setByte(messageBody,20,frameCumulative);

				//20150320
				mdSmart.message.setByte(messageBody, 23, frameCumulative);
			}
			//CRC8
			//mdSmart.message.setByte(messageBody,21,_CRC8(messageBody));

			//20150320 wjl
			mdSmart.message.setByte(messageBody, 24, _CRC8(messageBody));

			var message = mdSmart.message.createMessage(0xAC, 0x03, messageBody);
			return message;
		},
		/**
		 * SET-Byte4
		 *@param {Number} p1 指示
		 *                 0x00 - 同步信息指令，其他字节指令值无效
		 *				   0x01 - BYTE NO.5 为有效指令（随身感温度值）
		 *				   0x02 - BYTE NO.6 为有效指令（特殊功能键值）
		 *				   0x03 - BYTE NO.7 为有效指令（查询状态）
		 *				   0x04 - BYTE NO.8 为有效指令（安装位置检测）
		 *				   0x05 –BYTE NO.9 为有效指令（工程模式）
		 *				   0x06- BYTE NO.9为有效指令(制冷制热最大频率限制bit7 1为制冷 0：为制热)
		 *				   其他 - 无效指令
		 */
		setSetByte4: function(p1) {
			mdSmart.message.setByte(_messageBodyRequestStatus, 4, p1);
		},
		/**
		 * SET-随身感温度值
		 *@param {Number} p1 指示
		 *                 0xFF - 无效指令
		 *				   其他 - 随身感温度，表示方法：实际温度 x 2 + 50 （取值范围：0℃～50.0℃）
		 */
		setSetByte5: function(p1) {
			mdSmart.message.setByte(_messageBodyRequestStatus, 5, p1);
		},
		/**
		 * SET-特殊功能键值
		 *@param {Number} p1 指示
		 *                 0x00 - 无效指令
		 *				   0x01 - i模式记忆
		 *				   0x02 - 数显长按（开启或关闭数显）
		 *				   0x03 - 查询显示板程序版本
		 */
		setSetByte6: function(p1) {
			mdSmart.message.setByte(_messageBodyRequestStatus, 6, p1);
		},
		/**
		 * SET-查询状态
		 *@param {Number} p1 指示
		 *                 0x00 - 无效指令
		 *				   0x01 - 退出查询
		 *				   0x02 - 查询室内温度
		 *				   0x03 - 查询室外温度
		 */
		setSetByte7: function(p1) {
			mdSmart.message.setByte(_messageBodyRequestStatus, 7, p1);
		},
		/**
		 * SET-安装位置检测
		 *@param {Number} p1 指示
		 *                 0x00 - 无效指令
		 *				   0xFF - 查询当前安装位置
		 *				   0x01 - 左2
		 *				   0x02 - 左1
		 *				   0x01 - 左2
		 *				   0x02 - 左1
		 *				   0x03 - 居中
		 *				   0x04 - 右1
		 *				   0x05 - 右2
		 */
		setSetByte8: function(p1) {
			mdSmart.message.setByte(_messageBodyRequestStatus, 7, p1);
		},
		/**
		 * SET-工程模式
		 *@param {Number} p1 指示
		 *                 工程模式0——20
		 *		 {Number} p2 指示
		 *				   最大频率限制 bit7为模式选择，0：为制冷模式 1：为制热模式
		 */
		setSetByte9: function(p1, p2) {
			mdSmart.message.setBits(_messageBodyRequestStatus, 9, 0, 6, p1);
			mdSmart.message.setBit(_messageBodyRequestStatus, 9, 7, p2);
		},
		/**
		 * 设定帧累加
		 */
		setFrameCumulative: function(p1) {
			frameCumulative = p1;
		},
		/**
		 * 获取帧累加
		 */
		getFrameCumulative: function(p1) {
			return frameCumulative;
		},
		/**
		 * 解析报文
		 *@param {byteArray} message 报文
		 *@return {json}
		 */
		parseMessageForView: function(message) {
			return _parseMessage(message);
		},
		//设备返回命令
		getEquipmentReturnCommandBack: function() {
			return _equipmentReturnCommandBack;
		},

		//2015-04-09
		cmdNewVerForCheck: function(p1, p2) {
			var messageBody = [];
			//当前状态查询引导码
			mdSmart.message.setByte(messageBody, 0, 0xB1);
			mdSmart.message.setByte(messageBody, 1, p1);

			var si;
			var sk = 2;
			for(si = 0; si < p1; si++) {
				mdSmart.message.setByte(messageBody, sk, p2[si * 2 + 1]);
				sk = sk + 1;
				mdSmart.message.setByte(messageBody, sk, p2[si * 2]);
				sk = sk + 1;
			}
			mdSmart.message.setByte(messageBody, sk, 0x00);

			mdSmart.message.setByte(messageBody, (2 + 2 * p1), _CRC8(messageBody));

			var message = mdSmart.message.createMessage(0xAC, 0x03, messageBody);

			return message;
		},
		/**
		 * 生成新协议控制命令   2015-04-08
		 *p1:命令标识：02－控制命令，03-查询命令
		 *p2:属性代码：2个字节，低位在前
		 *p3:属性长度
		 *p4:属性值
		 *@return {byteArray} 新协议控制命令
		 */
		cmdNewVer: function(p1, p2, p3) {
			var messageBody = [];
			//当前状态查询引导码
			mdSmart.message.setByte(messageBody, 0, 0xB0);
			mdSmart.message.setByte(messageBody, 1, 0x01);

			mdSmart.message.setByte(messageBody, 2, p1[0]);
			mdSmart.message.setByte(messageBody, 3, p1[1]);

			mdSmart.message.setByte(messageBody, 4, p2); //长度

			var si;
			for(si = 0; si < p2; si++) {
				mdSmart.message.setByte(messageBody, 5 + si, p3[si]);
			}

			mdSmart.message.setByte(messageBody, 5 + p2, 0x00);

			mdSmart.message.setByte(messageBody, 5 + p2, _CRC8(messageBody));
			//alert(messageBody);

			var message = mdSmart.message.createMessage(0xAC, 0x02, messageBody);

			return message;
		},

		/**
		 * 根据家电控制内容转换为控制指令
		 * @param {Number} itemNum 家电要控制的属性个数
		 * @param {Array} items 家电要控制的属性内容， {[家电属性代码（2字节）+ 属性值长度（1字节）+ 属性值（变长）],[...]}
		 * @return {Array} 用于发码的家电字节数组
		 */
		cmdNewProtocol4MutableItemControl: function(itemNum, items) {
			setReceiveUploadIsUnallowed();
			var itemNumWithTone = itemNum + 1; //增加声音控制 
			var messageBody = [];
			mdSmart.message.setByte(messageBody, 0, 0xB0);
			mdSmart.message.setByte(messageBody, 1, itemNumWithTone);
			var itemsContentLength = items.length;
			for(i = 0; i < itemsContentLength; i++) {
				mdSmart.message.setByte(messageBody, 2 + i, items[i]);
			}

			var toneFirstBit = 2 + itemsContentLength;
			mdSmart.message.setByte(messageBody, toneFirstBit, 0x1A);
			mdSmart.message.setByte(messageBody, toneFirstBit + 1, 0x00);
			mdSmart.message.setByte(messageBody, toneFirstBit + 2, 0x01);
			var SNStr = bridge.getCurrentDevSN();
			var promptStr = localStorage.getItem("ACTone" + SNStr);
			if("0" == promptStr) {
				mdSmart.message.setByte(messageBody, toneFirstBit + 3, 0x00);
			} else {
				mdSmart.message.setByte(messageBody, toneFirstBit + 3, 0x01);
			}

			mdSmart.message.setByte(messageBody, toneFirstBit + 4, 0x00);
			mdSmart.message.setByte(messageBody, toneFirstBit + 4, _CRC8(messageBody));
			var message = mdSmart.message.createMessage(0xAC, 0x02, messageBody);
			return message;
		},

		//空调自动上传命令(0x05)
		getX05Xa0Back: function() {
			return _x05Xa0Back;
		}
	}
}