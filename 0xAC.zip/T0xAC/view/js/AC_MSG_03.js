(function (mdSmart) {
	var co=0;//bridge.getCardOrder();
	var bDebug = false;
    mdSmart.AC_P03 = mdSmart.AC_P03 || {};

    $(document).on('pageinit', 'div[id="AC_P03"]', function (event) {
        console.log('#AC_P03 pageinit.');
		// IOSLOG
		bridge.logToIOS("AC_P03 pageinit start");
		mdSmart.AC_P03.message = mdSmart.AC_P01.message;
		//多语言初始化
		mdSmart.AC_P03.pageTextInit();
		$(document).bind('recieveMessage',{},  function(event,message){
			var isPermit = receiveUploadMsgIsPermitCard();
			bridge.logToIOS("AC_P03 recieveMessage ="+isPermit);
			if (isPermit) {
				bridge.logToIOS("AC_P03 receiveMessage=" + message);
				mdSmart.AC_P03.showStatus("", message);
			}
		});
		
//		$(document).bind('updateCard',{},  function(event,message){
//			bridge.logToIOS("AC_P03 updateCard");
//			mdSmart.AC_P03.showStatus("",message);
//		});
		
		// IOSLOG
		bridge.logToIOS("AC_P03 pageinit end");
    });
	
    $(document).on('pageshow', 'div[id="AC_P03"]', function (event) {
        console.log('#AC_P03 pageshow.');
		// IOSLOG
		bridge.logToIOS("AC_P03 pageshow start");
		bridge.logToIOS("AC_P03 getNetType="+bridge.getNetType());
        mdSmart.AC_P03.prepareAndShow();
		$("#AC_P03_BTN_Open").bind('tap', {}, mdSmart.AC_P03.eventOpen);
		$(".card_off").bind('tap', {}, mdSmart.AC_P03.gotoControlPanelPage);
		
		$('.card_off').css('backgroundImage','url(view/images/card_bg_closed'+co+'.png)');

       // IOSLOG
		bridge.logToIOS("AC_P03 pageshow end");
    });

    $(document).on('pagehide', 'div[id="AC_P03"]', function (event) {
        console.log('#AC_P03 pagehide.');
		// IOSLOG
		bridge.logToIOS("AC_P03 pagehide start");
        $("#AC_P03_BTN_Open").unbind('tap');
		$(".card_off").unbind('tap');
		
		$("#AC_P03_BTN_Open span").removeClass("cart_waiting_rotating");
		mdSmart.common.isCartBtnLockControl(false);
		
		// IOSLOG
		bridge.logToIOS("AC_P03 pagehide end");
    });

    mdSmart.AC_P03.prepareAndShow = function() {
        console.log("mdSmart.AC_P03.prepareAndShow");
		// IOSLOG
		bridge.logToIOS("AC_P03 prepareAndShow start");
//		mdSmart.AC_P03.cmdRequestStatus();
		bridge.getCardTitle(function(message){
			$("#AC_P03_title span").html(message);
		});
		// For Debug
		if(bDebug == true){
			var title = JSON.stringify({
				messageBody: mdSmart.i18n.APP_NAME
			});
			bridge.setCardTitle(title);
		}
		// IOSLOG
		bridge.logToIOS("AC_P03 prepareAndShow end");
    };
	//多语言初始化
	mdSmart.AC_P03.pageTextInit=function(){
		console.log("mdSmart.AC_P03.pageTextInit");
		// IOSLOG
		bridge.logToIOS("AC_P03 pageTextInit start");
	    $(".close").html(mdSmart.i18n.ALREADY_POWERED_OFF);
		$("#AC_P03_BTN_Open span").html(mdSmart.i18n.POWER_ON);
		// IOSLOG
		bridge.logToIOS("AC_P03 pageTextInit end");
	};
	//开机按钮事件
	mdSmart.AC_P03.eventOpen=function(){
	    console.log("function:mdSmart.AC_P03.eventOpen");
		// IOSLOG
		bridge.logToIOS("AC_P03 eventOpen start");
        $("#AC_P01_BTN_Close span").html(mdSmart.i18n.POWER_OFF);
		if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		mdSmart.AC_P03.setRunningStateOn();
		// IOSLOG
		bridge.logToIOS("AC_P03 eventOpen end");
	};
	// 控制面板
    mdSmart.AC_P03.gotoControlPanelPage = function() {
        console.log("function:mdSmart.FC_P01.gotoControlPanelPage");
		// IOSLOG
		bridge.logToIOS("AC_P03 gotoControlPanelPage start");
		if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		var pageParamers={
			frameCumulative:mdSmart.AC_P01.message.getFrameCumulative()
		};
		bridge.showControlPanelPage(pageParamers);
		// IOSLOG
		bridge.logToIOS("AC_P03 gotoControlPanelPage end");
    };
	// 空调状态参数查询
	mdSmart.AC_P03.cmdRequestStatus = function() {
        console.log("function:mdSmart.AC_P03.cmdRequestStatus");
		// IOSLOG
		bridge.logToIOS("AC_P03 cmdRequestStatus start");
		mdSmart.AC_P03.message.setSetByte4(0x03);//0x03 - BYTE NO.7 为有效指令（查询状态）
		mdSmart.AC_P03.message.setSetByte7(0x02);//0x02 - 查询室内温度
		var cmdBytes = mdSmart.AC_P03.message.cmdRequestStatus();
		var cmdId = bridge.startCmdProcess(cmdBytes,function(messageBack){
			bridge.logToIOS("AC_P03 cmdRequestStatus databack="+messageBack);
			mdSmart.AC_P03.showStatus(cmdBytes,messageBack);
		});
		mdSmart.AC_P03.afterControlProcess(cmdId,cmdBytes);
		// IOSLOG
		bridge.logToIOS("AC_P03 cmdRequestStatus end");
    };
	//运行状态(ON)
	mdSmart.AC_P03.setRunningStateOn = function(events) {
        console.log("function:mdSmart.AC_P03.setRunningStateOn");
		// IOSLOG
		bridge.logToIOS("AC_P03 setRunningStateOn start");
		if(mdSmart.common.isCartBtnLock() == true){return false;}
		
//		var jsonStatus = mdSmart.AC_P03.message.parseMessageForView(mdSmart.AC_P03.message.getEquipmentReturnCommandBack());
//		var dataBack = mdSmart.AC_P03.message.getEquipmentReturnCommandBack()
//		var receiveMessageBody = dataBack.slice(10, dataBack.length - 1);
        var jsonStatus = mdSmart.AC_P03.message.parseMessageForView(mdSmart.AC_P03.message.getEquipmentReturnCommandBack());
		
		if(jsonStatus.status.settingMode.value!=null)
		{
			switch(jsonStatus.status.settingMode.value)//$(".control span").html(mdSmart.i18n.AUTO+mdSmart.i18n.FORMATER_IN_PROCESS);
			{
				case 1:mdSmart.AC_P03.message.setNoPolarWindSpeedValue(101);
					   mdSmart.AC_P03.message.setElectricHeatingButtonPressFlg(0);
					   mdSmart.AC_P03.message.setElectricAuxiliaryHeat(1);break;
				case 3:mdSmart.AC_P03.message.setNoPolarWindSpeedValue(101);break;
				case 2:mdSmart.AC_P03.message.setNoPolarWindSpeedValue(102);break;
				case 4:mdSmart.AC_P03.message.setNoPolarWindSpeedValue(102);
					   mdSmart.AC_P03.message.setElectricHeatingButtonPressFlg(0);
					   mdSmart.AC_P03.message.setElectricAuxiliaryHeat(1);break;
				case 5:mdSmart.AC_P03.message.setNoPolarWindSpeedValue(102);break;
				default:break;
			}
		}
		
		mdSmart.AC_P03.message.setRunningState(0x01);
		
		mdSmart.AC_P03.message.setSetTemperate(mdSmart.AC_P03.settingTemperature,mdSmart.AC_P03.settingTemperatureDot5);
		
		mdSmart.AC_P03.message.setPMVFunction(0);
		var cmdBytes = mdSmart.AC_P03.message.cmdControl(0);
		setReceiveUploadIsUnallowedCard();//设置家电上报不可用 add by yuxg 20150826
		bridge.logToIOS("AC_P03 setRunningStateOn cmdBytes="+cmdBytes);
		$("#AC_P03_BTN_Open span").addClass("cart_waiting_rotating");
		var cmdId = bridge.startCmdProcess(cmdBytes,function(messageBack){
			bridge.logToIOS("AC_P03 setRunningStateOn start databack="+messageBack);
			mdSmart.AC_P03.showStatus(cmdBytes,messageBack);
		    $("#AC_P03_BTN_Open span").removeClass("cart_waiting_rotating");
			mdSmart.common.isCartBtnLockControl(false);
		},function(errCode){
			setReceiveUploadMsgIsPermitCard(); //设置家电上传可用 add by yuxg 20150826
			if(errCode == -1){
				$("#AC_P03_BTN_Open span").removeClass("cart_waiting_rotating");
				mdSmart.common.isCartBtnLockControl(false);
			} 
		});
		mdSmart.AC_P03.afterControlProcess(cmdId,cmdBytes);
		// IOSLOG
		bridge.logToIOS("AC_P03 setRunningStateOn end");
    };
	mdSmart.AC_P03.afterControlProcess = function(cmdId,cmdBytes) {
		console.log("function:mdSmart.AC_P03.afterControlProcess");
		// For Debug
		if(bDebug == true){
			var cmdMessageType = cmdBytes[9],cmdMessageBody=cmdBytes.slice(10,cmdBytes.length - 1);
			var statusMessage = mdSmart.AC_P03.message.getEquipmentReturnCommandBack();
			var messageBody = mdSmart.message.createMessageBody(22);
			if(statusMessage != undefined){
				messageBody = statusMessage.slice(10,statusMessage.length - 1);
			}
			var messageType = undefined;
			if(cmdMessageType == 0x03){
				messageType = 0x03;
				mdSmart.message.setByte(messageBody,0,0xC0);
				//设置当前设定模式为制热4、制冷2
				mdSmart.message.setBits(messageBody,2,5,7,mdSmart.message.getBits(cmdMessageBody,2,5,7));
				if(cmdMessageBody[0] == 0x41){
					//0x00 - 同步信息指令，其他字节指令值无效
					if(cmdMessageBody[4] == 0x00){
					}
					//0x01 - BYTE NO.5 为有效指令（随身感温度值）
					if(cmdMessageBody[4] == 0x01){
						mdSmart.message.setBit(messageBody,8,7,0x01);
					}
					//0x02 - BYTE NO.6 为有效指令（特殊功能键值）
					if(cmdMessageBody[4] == 0x02){
						//i模式记忆
						if(cmdMessageBody[6] == 0x01){
							mdSmart.message.setBit(messageBody,1,2,0x01);
						}
					}
					//0x03 - BYTE NO.7 为有效指令（查询状态）
					if(cmdMessageBody[4] == 0x03){
						//0x02 - 查询室内温度
						if(cmdMessageBody[7] == 0x02){
							mdSmart.message.setByte(messageBody,11,0x02);
						}
						//0x03 - 查询室外温度
						if(cmdMessageBody[7] == 0x03){
							mdSmart.message.setByte(messageBody,12,0x03);
						}
					}
					//0x04 - BYTE NO.8 为有效指令（安装位置检测）
					if(cmdMessageBody[4] == 0x04){
					}
					//0x05 –BYTE NO.9 为有效指令（工程模式）
					if(cmdMessageBody[4] == 0x05){
					}
					//0x06- BYTE NO.9为有效指令(制冷制热最大频率限制bit7 1为制冷 0：为制热)
					if(cmdMessageBody[4] == 0x06){
					}
				}				
			}
			if(cmdMessageType == 0x02){
				messageType = 0x02;
				mdSmart.message.setByte(messageBody,0,0xC0);
				if(cmdMessageBody[0] == 0x40){
					// 儿童睡眠模式
					mdSmart.message.setBit(messageBody,9,0,mdSmart.message.getBit(cmdMessageBody,1,3));
					// I模式恢复
					mdSmart.message.setBit(messageBody,1,2,mdSmart.message.getBit(cmdMessageBody,1,2));
					// 运行状态
					mdSmart.message.setBit(messageBody,1,0,mdSmart.message.getBit(cmdMessageBody,1,0));
					// 设定模式
					mdSmart.message.setBits(messageBody,2,5,7,mdSmart.message.getBits(cmdMessageBody,2,5,7));
					
					// 设定温度
					mdSmart.message.setBits(messageBody,2,0,3,mdSmart.message.getBits(cmdMessageBody,2,0,3));
					mdSmart.message.setBit(messageBody,2,4,mdSmart.message.getBits(cmdMessageBody,2,4,4));
					// 无极风速值
					mdSmart.message.setBits(messageBody,3,0,6,mdSmart.message.getBits(cmdMessageBody,3,0,6));
					// 移动终端定时信息(1 - 有效)
					if(mdSmart.message.getBit(cmdMessageBody,3,7) == 0x01){
						mdSmart.message.setByte(messageBody,4,mdSmart.message.getByte(cmdMessageBody,4));
						mdSmart.message.setByte(messageBody,5,mdSmart.message.getByte(cmdMessageBody,5));
						mdSmart.message.setByte(messageBody,6,mdSmart.message.getByte(cmdMessageBody,6));
					}
					// 舒适风，具体参照舒适风表
					mdSmart.message.setByte(messageBody,7,mdSmart.message.getByte(cmdMessageBody,7));
					// 随身感
					mdSmart.message.setBit(messageBody,8,7,mdSmart.message.getBit(cmdMessageBody,8,7));
					// 节能
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,8,6));
					// 强劲
					mdSmart.message.setBit(messageBody,8,5,mdSmart.message.getBit(cmdMessageBody,8,5));
					// 睿风
					mdSmart.message.setBit(messageBody,8,4,mdSmart.message.getBit(cmdMessageBody,8,4));
					// 省电
					mdSmart.message.setBit(messageBody,8,3,mdSmart.message.getBit(cmdMessageBody,8,3));
					// 闹铃睡眠
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,8,2));
					// 舒睡模式
					mdSmart.message.setBits(messageBody,8,0,1,mdSmart.message.getBits(cmdMessageBody,8,0,1));
					//ECO功能
					mdSmart.message.setBit(messageBody,9,4,mdSmart.message.getBit(cmdMessageBody,9,7));
					//切换舒睡曲线
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,9,6));
					//净化功能
					mdSmart.message.setBit(messageBody,9,5,mdSmart.message.getBit(cmdMessageBody,9,5));
					//电辅热按键按下标识。当按下电辅热按键时，发1
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,9,4));
					//电辅热
					mdSmart.message.setBit(messageBody,9,3,mdSmart.message.getBit(cmdMessageBody,9,3));
					//干燥
					mdSmart.message.setBit(messageBody,9,2,mdSmart.message.getBit(cmdMessageBody,9,2));
					//换气
					mdSmart.message.setBit(messageBody,10,3,mdSmart.message.getBit(cmdMessageBody,9,1));
					//智慧眼
					mdSmart.message.setBit(messageBody,8,6,mdSmart.message.getBit(cmdMessageBody,9,0));
					//清除风机运行时间
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,10,7));
					//尘满标识
					mdSmart.message.setBit(messageBody,13,5,mdSmart.message.getBit(cmdMessageBody,10,6));
					//峰谷节电功能
					mdSmart.message.setBit(messageBody,10,6,mdSmart.message.getBit(cmdMessageBody,10,5));
					//小夜灯
					mdSmart.message.setBit(messageBody,10,4,mdSmart.message.getBit(cmdMessageBody,10,4));
					//防着凉
					mdSmart.message.setBit(messageBody,10,5,mdSmart.message.getBit(cmdMessageBody,10,3));
					//摄氏/华氏
					mdSmart.message.setBit(messageBody,10,2,mdSmart.message.getBit(cmdMessageBody,10,2));
					//TUBRO状态
					mdSmart.message.setBit(messageBody,10,1,mdSmart.message.getBit(cmdMessageBody,10,1));
					//Sleep功能状态
					mdSmart.message.setBit(messageBody,10,0,mdSmart.message.getBit(cmdMessageBody,10,0));
					//第一小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,11,0,3));
					//第二小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,11,7,4));
					//第三小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,12,0,3));
					//第四小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,12,7,4));
					//第五小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,13,0,3));
					//第六小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,13,7,4));
					//第七小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,14,0,3));
					//第八小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,14,7,4));
					//第九小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,15,0,3));
					//第十小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,15,7,4));
					//第一小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,16,0));
					//第二小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,16,1));
					//第三小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,16,2));
					//第四小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,16,3));
					//第五小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,16,4));
					//第六小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,16,5));
					//第七小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,16,6));
					//第八小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,16,7));
					//第九小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,17,4));
					//第十小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,17,5));
					//PMV功能
					mdSmart.message.setBits(messageBody,14,0,3,mdSmart.message.getBits(cmdMessageBody,18,5,7) << 1 | mdSmart.message.getBit(cmdMessageBody,17,7));
					//自然风功能
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,17,6));
					//舒睡时间
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,17,0,3));
					//设定温度2
					mdSmart.message.setBit(messageBody,13,0,4,mdSmart.message.getBit(cmdMessageBody,18,0,4));
				}				
			}
			var message = mdSmart.message.createMessage(0xAC,messageType,messageBody);
			var bridgeMessage = mdSmart.message.converMessageToBridgePStr(message);
			bridge.callbackFunction(cmdId,bridgeMessage);
		}
    };
    
    // 根据机型判断是否支持无极调速
	mdSmart.AC_P03.isCACP = function() {
		// 判断SN位数，获取机型
		var subCACPList = "11533/11535";	
		var subCAList = "11447/11451/11453/11455/11457/11459/11525/11527";
		var deviceSNValue = bridge.getCurrentDevSN();
		bridge.logToIOS("isCACP deviceSNValue="+deviceSNValue);

		if (deviceSNValue != "") {
			if (deviceSNValue.length == '32') {
				deviceType = deviceSNValue.substring(12, 17);
			} else {
				deviceType = deviceSNValue.substring(6, 11);
			}
		}
		var ifSupport = "";
		if (subCACPList.indexOf(deviceType) != '-1' || subCAList.indexOf(deviceType) != '-1') {
			ifSupport = true;
		} else {
			ifSupport = false;
		}
		return ifSupport;
	};
    
    
	mdSmart.AC_P03.showStatus = function(dataRequest,dataBack){
		// IOSLOG
		bridge.logToIOS("AC_P03 showStatus start");
		bridge.logToIOS("AC_P03 showStatus databack="+dataBack);
		setReceiveUploadMsgIsPermitCard(); //设置家电上传可用 add by yuxg 20150826
		var receiveMessageBody = dataBack.slice(10, dataBack.length - 1);
		if (!(receiveMessageBody[0] == 0xC0 || receiveMessageBody[0] == 0xA0)) {
			return false;
		}
		
		mdSmart.common.setLsVar(0xAC, "receiveMessage"+bridge.getCurrentDevSN(), dataBack);
		var jsonStatus = mdSmart.AC_P03.message.parseMessageForView(dataBack);
		
		
		// CA定速主动上报温度更新		卡片界面更新温度不对
		if(mdSmart.AC_P03.isCACP() && receiveMessageBody[0] == 0xA0){
			mdSmart.AC_P03.settingTemperature = (receiveMessageBody[1]>>2) - 4;
			mdSmart.AC_P03.settingTemperatureDot5 = (receiveMessageBody[1]>>1)&0x01;
			bridge.logToIOS("settingTemperature="+mdSmart.AC_P03.settingTemperature);
			bridge.logToIOS("settingTemperatureDot5="+mdSmart.AC_P03.settingTemperatureDot5);
		}else{
			mdSmart.AC_P03.settingTemperature = jsonStatus.status.settingTemperature.value;
			mdSmart.AC_P03.settingTemperatureDot5 = jsonStatus.status.settingTemperatureDot5.value;
		}
		
		if(mdSmart.AC_P03.settingTemperature < 1) {
			mdSmart.AC_P03.settingTemperature = 1;
	 	} else if (mdSmart.AC_P03.settingTemperature > 14) {
			mdSmart.AC_P03.settingTemperature = 14;
	 	} else {
	 		
	 	}

		if(receiveMessageBody[0] == 0xA0){
			bridge.logToIOS("A0 settingTemperature="+mdSmart.AC_P01.settingTemperature);
			bridge.logToIOS("A0 settingTemperatureDot5="+mdSmart.AC_P01.settingTemperatureDot5);
		}
		
		
		
		if(receiveMessageBody[0] == 0xA0 && jsonStatus.status.faultFlag.value != 0){
			return false;
		}
		
		$("#sendMsgDiv").html("<hr>send:"+mdSmart.message.convertTo16Str(dataRequest));
		$("#receiveMsgDiv").html("<hr>receive:"+mdSmart.message.convertTo16Str(dataBack));
		
		mdSmart.AC_P03.settingMode = jsonStatus.status.settingMode.value;
		
//		var jsonStatus = mdSmart.AC_P03.message.parseMessageForView(dataBack);
		//开机状态画面跳转
		if(jsonStatus.status.runningState.value==1)
		{bridge.logToIOS("mobile.changePage AC_P01");
		    $.mobile.changePage("#AC_P01", "turn"); 
		}
		var strStatus = "messageType:"+jsonStatus.messageType+"<br>";
		strStatus = strStatus + mdSmart.AC_P03.showJSON(jsonStatus.status)
		$("#statusDiv").html("<hr>"+strStatus);
		// IOSLOG
		bridge.logToIOS("AC_P03 showStatus end");
	}
	mdSmart.AC_P03.showJSON = function(pJson){
		var strStatus = "";
		for(var o in pJson){  
			var temp = pJson[o];
			if(temp.name != undefined){
				if(temp.value != undefined && temp.value != 0){
					strStatus =  strStatus +"<BR>" + temp.name + ":"
					if(temp.view != undefined && temp.view[temp.value] != undefined){
						strStatus = strStatus + temp.view[temp.value];
					}else{
						strStatus = strStatus + temp.value;
					}
				}else if(temp.detail != undefined){
					strStatus = strStatus + mdSmart.AC_P03.showJSON(temp.detail);
				}
			}
		}
		return	strStatus;
	}
})(mdSmart);
