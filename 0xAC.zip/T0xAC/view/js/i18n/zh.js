var mdSmart_i18n_zh = {
	POWER_OFF: '关机',
	POWER_ON: '开机',
	BACK:'返回',
    SHUTTING_DOWN:'正在关机',
    CONFIRMSHUTDOWN:'确认关机',
	APP_NAME:'家用空调',
    REFRIGERATING:'制冷',
    DEHUMIDIFY:'抽湿',
    HEATING:'制热',
    BLOW:'送风',
    INVALIDMODE:'无效',
    AUTO:'自动',
    AUTODEHUMIDITY:"舒适抽湿",
    HANDDEHUMIDITY:"个性抽湿",
    CONFIRM:'确认',
    TEMP_DELETE:'温度减',
    TEMP_ADD:'温度加',
    CURRENT_TEMP:'当前室温',
    ALREADY_POWERED_OFF:'已关机',
    FORMATER_IN_PROCESS:'中',
	
	BTN_CONFIRM: '确定',

    //操作逻辑DIALOG提示
    TEMPINVLAID:'"送风"模式下温度不可调节',

    //WEEK BUTTON
    MONDAY:'一',
    TUESDAY:'二',
    WEDNESDAY:'三',
    THURSDAY:'四',
    FRIDAY:'五',
    SATURDAY:'六',
    SUNDAY:'日'

};