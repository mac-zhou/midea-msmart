var isWYA = false;			//是否WYA机型
var isZB300YJ = false;//是否ZB300演示样机

(function (mdSmart) {
	var co;//bridge.getCardOrder();
	if(typeof bridge.getCurrentDevSN=='function'){
		co = '_' + bridge.getCurrentDevSN();
	}else{
		co = '';
	}
	var deviceSNValue =  bridge.getCurrentDevSN();
//	alert(co);
	var bDebug = false;
	var logFlg = false;
    var t;
    var tmpTitle = "美的电器";//用于保存卡片页标题
    
    mdSmart.AC_P01 = mdSmart.AC_P01 || {};
    
    function changeViewBg() {
    		var deviceType = "";
        setTimeout(function(){
        		deviceType = getDeviceType();
	        if (deviceType == 1) {
	    			$("#AC_P").removeClass("card_main_guiji").removeClass("card_main_iq").removeClass("card_main_tranfer").addClass("card_main");
//	    			$("#AC_P").removeClass("card_main_guiji").removeClass("card_main_iq").removeClass("card_main").addClass("card_main_tranfer");
	        } else if (deviceType == 2) {
	    			$("#AC_P").removeClass("card_main").removeClass("card_main_iq").removeClass("card_main_tranfer").addClass("card_main_guiji");
	        } else if (deviceType == 3) {
	    			$("#AC_P").removeClass("card_main").removeClass("card_main_guiji").removeClass("card_main_tranfer").addClass("card_main_iq");
	        } else if (deviceType == 4) {
	    			$("#AC_P").removeClass("card_main_guiji").removeClass("card_main_iq").removeClass("card_main").addClass("card_main_tranfer");
	    			$(".data_info").hide();
	    			$(".card_bottom").hide();
	    			$("#AC_P03").hide();
	        } 
	        
	        else {
	    			changeViewBg();
	        }
//	         $("#AC_P").removeClass("card_main_guiji").removeClass("card_main_iq").removeClass("card_main").addClass("card_main_tranfer");
        },1000);
    }
    
    
    $(document).on('pageinit', 'div[id="AC_P"]', function (event) {
        console.log('#AC_P01 pageinit.');
		// IOSLOG
		bridge.logToIOS("AC_P01 pageinit start");
		mdSmart.AC_P01.message = new mdSmart.msg0xAC();
		$(document).unbind('recieveMessage').bind('recieveMessage',{},  function(event,message){
            var isPermit = receiveUploadMsgIsPermitCard();
            bridge.logToIOS("AC_P01 recieveMessage ="+isPermit);
            if (isPermit) {
                bridge.logToIOS("AC_P01 receiveMessage=" + message);
                mdSmart.AC_P01.showStatus("", message);
		        changeViewBg();
            }
		});
		$(document).bind('updateCard',{},  function(event,message){
			bridge.logToIOS("AC_P03 updateCard");
			
			mdSmart.AC_P01.cmdRequestStatus();
			changeViewBg();
		});
		// IOSLOG
		bridge.logToIOS("AC_P01 pageinit end");
    });
	
    $(document).on('pageshow', 'div[id="AC_P"]', function (event) {
        console.log('#AC_P01 pageshow.');
        bridge.logToIOS("pageshow");
        changeViewBg();
        
		// IOSLOG
		bridge.logToIOS("AC_P01 getNetType="+bridge.getNetType());
		//多语言初始化
		mdSmart.AC_P01.pageTextInit();
        mdSmart.AC_P01.prepareAndShow();
		$("#AC_P01_BTN_Temperature_Plus").unbind('tap').bind('tap', {}, mdSmart.AC_P01.eventTemperaturePlus);
		$("#AC_P01_BTN_Temperature_Reduction").unbind('tap').bind('tap', {}, mdSmart.AC_P01.eventTemperatureReduction);
		$("#AC_P01_BTN_Close").unbind('tap').bind('tap', {}, mdSmart.AC_P01.eventClose);
        $("#AC_P03_BTN_Open").unbind('tap').bind('tap', {}, mdSmart.AC_P01.eventOpen);
		$(".card_bg").unbind('tap').bind('tap', {}, mdSmart.AC_P01.gotoControlPanelPage);
		// IOSLOG
		bridge.logToIOS("AC_P01 pageshow end");

    });

    $(document).on('pagehide', 'div[id="AC_P"]', function (event) {
        console.log('#AC_P01 pagehide.');
		// IOSLOG
		bridge.logToIOS("AC_P01 pagehide start");
		$("#AC_P01_BTN_Temperature_Plus").unbind('tap');
		$("#AC_P01_BTN_Temperature_Reduction").unbind('tap');
        $("#AC_P01_BTN_Close").unbind('tap');
		$("#AC_P01_panel_bg_mode").unbind('tap');
		$("#AC_P01_BTN_Temperature_Reduction span").removeClass("cart_waiting_rotating");
		$("#AC_P01_BTN_Temperature_Plus span").removeClass("cart_waiting_rotating");
		$("#AC_P01_BTN_Close span").removeClass("cart_waiting_rotating");
		mdSmart.common.isCartBtnLockControl(false);
		// IOSLOG
		bridge.logToIOS("AC_P01 pagehide end");
    });


    //获取设备产码
	mdSmart.AC_P01.getDeviceSN = function() {
		var deviceType = "";
		// 判断SN位数，获取机型
		if(deviceSNValue != ""){
			if (deviceSNValue.length == '32') {
				deviceType = deviceSNValue.substring(12, 17);
			} else {
				deviceType = deviceSNValue.substring(6, 11);
			}				
		}
		return deviceType;
	};
//	 if(deviceType <= 4999){
//	 document.getElementById('AC_P03').style.backgroundImage = 'url(view/images/T0xAC.png)';
//
//}
//else if(deviceType <= 7999){
//	    	 document.getElementById('AC_P03').style.backgroundImage = 'url(view/images/card_bg_blow.png)';
// }else{
// 	document.getElementById('AC_P03').style.backgroundImage = 'url(view/images/T0xAC.png)';
//	    	
//}

    mdSmart.AC_P01.prepareAndShow = function() {

        console.log("mdSmart.AC_P01.prepareAndShow");
		// IOSLOG
		bridge.logToIOS("AC_P01 prepareAndShow start");
//		mdSmart.AC_P01.message.setFrameCumulative(mdSmart.AC_P01.message.getFrameCumulative()-1);
		mdSmart.AC_P01.cmdRequestStatus();
		bridge.getCardTitle(function(message){
			$(".title").html(message);
			tmpTitle = message;
		});
		//判断是否关机
		// For Debug
		if(bDebug == true){
			var title = JSON.stringify({
				messageBody: mdSmart.i18n.APP_NAME
			});
			bridge.setCardTitle(title);
		}
		// IOSLOG
		bridge.logToIOS("AC_P01 prepareAndShow end");
    };
	//多语言初始化
	mdSmart.AC_P01.pageTextInit=function(){
		console.log("mdSmart.AC_P01.pageTextInit");
		// IOSLOG
		bridge.logToIOS("AC_P01 pageTextInit start");
	    $("#AC_P01_BTN_Temperature_Reduction span").html(mdSmart.i18n.TEMP_DELETE);
		$("#AC_P01_BTN_Temperature_Plus span").html(mdSmart.i18n.TEMP_ADD);
		$("#AC_P01_BTN_Close span").html(mdSmart.i18n.POWER_OFF);
        $(".close").html(mdSmart.i18n.ALREADY_POWERED_OFF);
        $("#AC_P03_BTN_Open span").html(mdSmart.i18n.POWER_ON);
        $('#popup_message p').html(mdSmart.i18n.TEMPINVLAID);
        $('#popup_message a').html(mdSmart.i18n.CONFIRM);
		// IOSLOG
		bridge.logToIOS("AC_P01 pageTextInit end");
	};
	// 控制面板
    mdSmart.AC_P01.gotoControlPanelPage = function() {
        console.log("function:mdSmart.FC_P01.gotoControlPanelPage");
		// IOSLOG
		bridge.logToIOS("AC_P01 gotoControlPanelPage start");
		if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
//		mdSmart.AC_P01.message.setFrameCumulative(mdSmart.AC_P01.message.getFrameCumulative());
		var pageParamers={
			frameCumulative:mdSmart.AC_P01.message.getFrameCumulative()
		};
		
		applianceId = bridge.getCurrentApplianceID();
//		setCookie("name",tmpTitle,300);
		
		bridge.showControlPanelPage(pageParamers);
		// IOSLOG
		bridge.logToIOS("AC_P01 gotoControlPanelPage end");
    };
	//温度加按钮事件
	mdSmart.AC_P01.eventTemperaturePlus=function(){
		// IOSLOG
		bridge.logToIOS("AC_P01 eventTemperaturePlus start");
		// 送风模式下不可调节温度
		if(mdSmart.AC_P01.settingMode == 5){
			$('#popup_message').show();
			$('#popup_message').popup('open');
			return true;
		}
		if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		//获取当前空调的温度
		/*if(mdSmart.AC_P01.settingMode==null||mdSmart.AC_P01.settingMode==0x05)
		{
			$('#popup_message').popup('open');
			return false;
		}*/
		
		if(mdSmart.common.isCartBtnLock() == true){return false;}

		var settingTemperature = mdSmart.AC_P01.settingTemperature;
		if (mdSmart.AC_P01.isSupportDot5()) {
				
			var tempPlus = 14;
			var dot5Value = mdSmart.AC_P01.settingTemperatureDot5;
			if (settingTemperature >= tempPlus) {
				mdSmart.AC_P01.message.setSetTemperate(tempPlus,0x00);
			} else {
			    	if (dot5Value != 0) {
		            tempPlus = settingTemperature + 1;
			    	  	mdSmart.AC_P01.message.setSetTemperate(tempPlus,0x00);
			    	} else {
			    	  	tempPlus = settingTemperature;
			    	  	mdSmart.AC_P01.message.setSetTemperate(tempPlus,0x01);
			    	}
			}
		} else {
			var tempPlus = 14;
			if (settingTemperature < tempPlus) {
				tempPlus = settingTemperature + 1;
			}
			mdSmart.AC_P01.message.setSetTemperate(tempPlus,0x00);
		}
		
		mdSmart.AC_P01.message.setSetTemperate18B(0x00);
		mdSmart.AC_P01.message.setPMVFunction(0);
		var cmdBytes = mdSmart.AC_P01.message.cmdControl(0);
        setReceiveUploadIsUnallowedCard();//设置家电上报不可用 add by yuxg 20150826
		bridge.logToIOS("AC_P01 eventTemperaturePlus="+cmdBytes);
		$("#AC_P01_BTN_Temperature_Plus span").addClass("cart_waiting_rotating");
		var cmdId = bridge.startCmdProcess(cmdBytes,function(messageBack){
			mdSmart.AC_P01.showStatus(cmdBytes,messageBack);
			$("#AC_P01_BTN_Temperature_Plus span").removeClass("cart_waiting_rotating");
			mdSmart.common.isCartBtnLockControl(false);
		},function(errCode){
            setReceiveUploadMsgIsPermitCard(); //设置家电上传可用 add by yuxg 20150826
			if(errCode == -1){
				$("#AC_P01_BTN_Temperature_Plus span").removeClass("cart_waiting_rotating");
				mdSmart.common.isCartBtnLockControl(false);
			} 
		});
		mdSmart.AC_P01.afterControlProcess(cmdId,cmdBytes);

		// IOSLOG
		bridge.logToIOS("AC_P01 eventTemperaturePlus end");
		
	};
	//温度减按钮事件
	mdSmart.AC_P01.eventTemperatureReduction=function(){
	    console.log("function:mdSmart.AC_P01.eventTemperatureReduction");
		// IOSLOG
		bridge.logToIOS("AC_P01 eventTemperatureReduction start");
		// 送风模式下不可调节温度
		if(mdSmart.AC_P01.settingMode == 5){
			$('#popup_message').show();
			$('#popup_message').popup('open');
			return true;
		}
		if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		//获取当前空调的温度
		/*if(mdSmart.AC_P01.settingMode==null||mdSmart.AC_P01.settingMode==0x05)
		{
			$('#popup_message').popup('open');
			return false;
		}*/
		

		if(mdSmart.common.isCartBtnLock() == true){return false;}

		var settingTemperature = mdSmart.AC_P01.settingTemperature;
		if (mdSmart.AC_P01.isSupportDot5()) {
			var tempReduction = 1;
			var dot5Value = mdSmart.AC_P01.settingTemperatureDot5;
			if (settingTemperature <= tempReduction) {
				mdSmart.AC_P01.message.setSetTemperate(tempReduction,0x00);
			} else {
			    	if (dot5Value != 0) {
		            tempReduction = settingTemperature;
			    	  	mdSmart.AC_P01.message.setSetTemperate(tempReduction,0x00);
			    	} else {
			    	  	tempReduction = settingTemperature - 1;
			    	  	mdSmart.AC_P01.message.setSetTemperate(tempReduction,0x01);
			    	}
			 }
				
		} else {
			 var tempReduction = 1;
			 if (settingTemperature > 1) {
				 tempReduction = settingTemperature - 1;
			 }
			 mdSmart.AC_P01.message.setSetTemperate(tempReduction,0x00);
		}
		mdSmart.AC_P01.message.setSetTemperate18B(0x00);
		mdSmart.AC_P01.message.setPMVFunction(0);
		var cmdBytes = mdSmart.AC_P01.message.cmdControl(0);
        setReceiveUploadIsUnallowedCard();//设置家电上报不可用 add by yuxg 20150826
		bridge.logToIOS("AC_P01 eventTemperatureReduction="+cmdBytes);
		$("#AC_P01_BTN_Temperature_Reduction span").addClass("cart_waiting_rotating");
		var cmdId = bridge.startCmdProcess(cmdBytes,function(messageBack){
			mdSmart.AC_P01.showStatus(cmdBytes,messageBack);
			$("#AC_P01_BTN_Temperature_Reduction span").removeClass("cart_waiting_rotating");
			mdSmart.common.isCartBtnLockControl(false);
		},function(errCode){
            setReceiveUploadMsgIsPermitCard(); //设置家电上传可用 add by yuxg 20150826
			if(errCode == -1){
				$("#AC_P01_BTN_Temperature_Reduction span").removeClass("cart_waiting_rotating");
				mdSmart.common.isCartBtnLockControl(false);
			} 
		});
		mdSmart.AC_P01.afterControlProcess(cmdId,cmdBytes);

		// IOSLOG
		bridge.logToIOS("AC_P01 eventTemperatureReduction end");
	}
	//关机按钮事件
	mdSmart.AC_P01.eventClose=function(){
	    console.log("function:mdSmart.AC_P01.eventClose");
		// IOSLOG
		bridge.logToIOS("AC_P01 eventClose start");
		if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		mdSmart.AC_P01.setRunningStateOff();
		// IOSLOG
		bridge.logToIOS("AC_P01 eventClose end");
	}
	// 空调状态参数查询
	mdSmart.AC_P01.cmdRequestStatus = function() {
        console.log("function:mdSmart.AC_P01.cmdRequestStatus");
		// IOSLOG
		bridge.logToIOS("AC_P01 cmdRequestStatus start");
		mdSmart.AC_P01.message.setSetByte4(0x00);
		var cmdBytes = mdSmart.AC_P01.message.cmdRequestStatus();
		bridge.logToIOS("AC_P01 cmdRequestStatus cmdBytes="+cmdBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes,function(messageBack){
			mdSmart.AC_P01.showStatus(cmdBytes,messageBack);
		});
		mdSmart.AC_P01.afterControlProcess(cmdId,cmdBytes);
		// IOSLOG
		bridge.logToIOS("AC_P01 cmdRequestStatus end");
    };
	//运行状态(OFF)
	mdSmart.AC_P01.setRunningStateOff = function() {
        console.log("function:mdSmart.AC_P01.setRunningStateOff");
		// IOSLOG
		bridge.logToIOS("AC_P01 setRunningStateOff start");
        if($("#AC_P01_BTN_Close span").html() == mdSmart.i18n.POWER_OFF){
			// IOSLOG
			bridge.logToIOS("AC_P01 setRunningStateOff if start");
			if(mdSmart.common.isCartBtnLock() == true){
				bridge.logToIOS("AC_P01 setRunningStateOff isCartBtnLock = true");
				return false;
			}
			
			$("#AC_P01_BTN_Close span").html(mdSmart.i18n.CONFIRMSHUTDOWN);

			t = window.setTimeout(function() {
				$("#AC_P01_BTN_Close span").html(mdSmart.i18n.POWER_OFF);
				mdSmart.common.isCartBtnLockControl(false);
			}, 5000);
			// IOSLOG
			mdSmart.common.isCartBtnLockControl(false);
			bridge.logToIOS("AC_P01 setRunningStateOff if end");
        } else if($("#AC_P01_BTN_Close span").html() == mdSmart.i18n.CONFIRMSHUTDOWN){
			// IOSLOG
			bridge.logToIOS("AC_P01 setRunningStateOff else if start");
			if(mdSmart.common.isCartBtnLock() == true){
				bridge.logToIOS("AC_P01 setRunningStateOff isCartBtnLock = true");
				return false;
			}
			$("#AC_P01_BTN_Close span").html(mdSmart.i18n.SHUTTING_DOWN);
			mdSmart.AC_P01.message.setMobileTimerInfoSwitch(0x00);
			mdSmart.AC_P01.message.setPurifyingFunction(0x00);
			mdSmart.AC_P01.message.setRunningState(0x00);
			mdSmart.AC_P01.message.setPreventingCold(0x00);
			mdSmart.AC_P01.message.setSetTemperate(mdSmart.AC_P01.settingTemperature,mdSmart.AC_P01.settingTemperatureDot5);
			mdSmart.AC_P01.message.setComfortWindVH(0x00);
			mdSmart.AC_P01.message.setPMVFunction(0);
			var cmdBytes = mdSmart.AC_P01.message.cmdControl(0);
            setReceiveUploadIsUnallowedCard();//设置家电上报不可用 add by yuxg 20150826
			bridge.logToIOS("AC_P01 setRunningStateOff="+cmdBytes);
			$("#AC_P01_BTN_Close span").addClass("cart_waiting_rotating");
			window.clearTimeout(t);
			var cmdId = bridge.startCmdProcess(cmdBytes,function(messageBack){
					bridge.logToIOS("AC_P01 setRunningStateOff startCmdProcess start");
                mdSmart.AC_P01.showStatus(cmdBytes,messageBack);
                $("#AC_P01_BTN_Close span").removeClass("cart_waiting_rotating");
                mdSmart.common.isCartBtnLockControl(false);
                bridge.logToIOS("AC_P01 setRunningStateOff startCmdProcess end");

			},function(errCode){
				bridge.logToIOS("AC_P01 setRunningStateOff errCode");
                setReceiveUploadMsgIsPermitCard(); //设置家电上传可用 add by yuxg 20150826
				if(errCode == -1){
					$("#AC_P01_BTN_Close span").html(mdSmart.i18n.POWER_OFF);
					$("#AC_P01_BTN_Close span").removeClass("cart_waiting_rotating");
					mdSmart.common.isCartBtnLockControl(false);
				}
			});
			
			mdSmart.AC_P01.afterControlProcess(cmdId,cmdBytes);
			
			// IOSLOG
			bridge.logToIOS("AC_P01 setRunningStateOff else if end");
        } else {
			// IOSLOG
			bridge.logToIOS("AC_P01 setRunningStateOff else start");
			
			bridge.logToIOS("AC_P01_BTN_Close span:" + $("#AC_P01_BTN_Close span").html());
			 
			// IOSLOG
			bridge.logToIOS("AC_P01 setRunningStateOff else start");
		}
		// IOSLOG
		bridge.logToIOS("AC_P01 setRunningStateOff end");
    };
 
	mdSmart.AC_P01.afterControlProcess = function(cmdId,cmdBytes) {
		console.log("function:mdSmart.AC_P01.afterControlProcess");
		// For Debug
		if(bDebug == true){
			var cmdMessageType = cmdBytes[9],cmdMessageBody=cmdBytes.slice(10,cmdBytes.length - 1);;
			var statusMessage = mdSmart.AC_P01.message.getEquipmentReturnCommandBack();
			var messageBody = mdSmart.message.createMessageBody(22);
			if(statusMessage != undefined){
				messageBody = statusMessage.slice(10,statusMessage.length - 1);
			}
			var messageType = undefined;
			if(cmdMessageType == 0x03){
				messageType = 0x03;
				mdSmart.message.setByte(messageBody,0,0xC0);
				// 运行状0:"关机",1:"开机"
				mdSmart.message.setBit(messageBody,1,0,0x01);
				//设置当前设定模式为制热4、制冷2
				//mdSmart.message.setBits(messageBody,2,5,7,mdSmart.message.getBits(cmdMessageBody,2,5,7));
				mdSmart.message.setBits(messageBody,2,5,7,0x04);
                // 设定温度
                mdSmart.message.setBits(messageBody,2,0,3,0x0A);
 
				if(cmdMessageBody[0] == 0x41){
					//0x00 - 同步信息指令，其他字节指令值无效
					if(cmdMessageBody[4] == 0x00){
					}
					//0x01 - BYTE NO.5 为有效指令（随身感温度值）
					if(cmdMessageBody[4] == 0x01){
						mdSmart.message.setBit(messageBody,8,7,0x01);
					}
					//0x02 - BYTE NO.6 为有效指令（特殊功能键值）
					if(cmdMessageBody[4] == 0x02){
						//i模式记忆
						if(cmdMessageBody[6] == 0x01){
							mdSmart.message.setBit(messageBody,1,2,0x01);
						}
					}
					//0x03 - BYTE NO.7 为有效指令（查询状态）
					if(cmdMessageBody[4] == 0x03){
						//0x02 - 查询室内温度
						if(cmdMessageBody[7] == 0x02){
							mdSmart.message.setByte(messageBody,11,0x66);
						}
						//0x03 - 查询室外温度
						if(cmdMessageBody[7] == 0x03){
							mdSmart.message.setByte(messageBody,12,0x66);
						}
					}
					//0x04 - BYTE NO.8 为有效指令（安装位置检测）
					if(cmdMessageBody[4] == 0x04){
					}
					//0x05 –BYTE NO.9 为有效指令（工程模式）
					if(cmdMessageBody[4] == 0x05){
					}
					//0x06- BYTE NO.9为有效指令(制冷制热最大频率限制bit7 1为制冷 0：为制热)
					if(cmdMessageBody[4] == 0x06){
					}
				}				
			}
			if(cmdMessageType == 0x02){
				messageType = 0x02;
				mdSmart.message.setByte(messageBody,0,0xC0);
				if(cmdMessageBody[0] == 0x40){
					// 儿童睡眠模式
					mdSmart.message.setBit(messageBody,9,0,mdSmart.message.getBit(cmdMessageBody,1,3));
					// I模式恢复
					mdSmart.message.setBit(messageBody,1,2,mdSmart.message.getBit(cmdMessageBody,1,2));
					// 运行状态
					mdSmart.message.setBit(messageBody,1,0,mdSmart.message.getBit(cmdMessageBody,1,0));
					// 设定模式
					mdSmart.message.setBits(messageBody,2,5,7,mdSmart.message.getBits(cmdMessageBody,2,5,7));
					
					// 设定温度
					mdSmart.message.setBits(messageBody,2,0,3,mdSmart.message.getBits(cmdMessageBody,2,0,3));
					mdSmart.message.setBit(messageBody,2,4,mdSmart.message.getBits(cmdMessageBody,2,4,4));
					// 无极风速值
					mdSmart.message.setBits(messageBody,3,0,6,mdSmart.message.getBits(cmdMessageBody,3,0,6));
					// 移动终端定时信息(1 - 有效)
					if(mdSmart.message.getBit(cmdMessageBody,3,7) == 0x01){
						mdSmart.message.setByte(messageBody,4,mdSmart.message.getByte(cmdMessageBody,4));
						mdSmart.message.setByte(messageBody,5,mdSmart.message.getByte(cmdMessageBody,5));
						mdSmart.message.setByte(messageBody,6,mdSmart.message.getByte(cmdMessageBody,6));
					}
					// 舒适风，具体参照舒适风表
					mdSmart.message.setByte(messageBody,7,mdSmart.message.getByte(cmdMessageBody,7));
					// 随身感
					mdSmart.message.setBit(messageBody,8,7,mdSmart.message.getBit(cmdMessageBody,8,7));
					// 节能
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,8,6));
					// 强劲
					mdSmart.message.setBit(messageBody,8,5,mdSmart.message.getBit(cmdMessageBody,8,5));
					// 睿风
					mdSmart.message.setBit(messageBody,8,4,mdSmart.message.getBit(cmdMessageBody,8,4));
					// 省电
					mdSmart.message.setBit(messageBody,8,3,mdSmart.message.getBit(cmdMessageBody,8,3));
					// 闹铃睡眠
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,8,2));
					// 舒睡模式
					mdSmart.message.setBits(messageBody,8,0,1,mdSmart.message.getBits(cmdMessageBody,8,0,1));
					//ECO功能
					mdSmart.message.setBit(messageBody,9,4,mdSmart.message.getBit(cmdMessageBody,9,7));
					//切换舒睡曲线
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,9,6));
					//净化功能
					mdSmart.message.setBit(messageBody,9,5,mdSmart.message.getBit(cmdMessageBody,9,5));
					//电辅热按键按下标识。当按下电辅热按键时，发1
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,9,4));
					//电辅热
					mdSmart.message.setBit(messageBody,9,3,mdSmart.message.getBit(cmdMessageBody,9,3));
					//干燥
					mdSmart.message.setBit(messageBody,9,2,mdSmart.message.getBit(cmdMessageBody,9,2));
					//换气
					mdSmart.message.setBit(messageBody,10,3,mdSmart.message.getBit(cmdMessageBody,9,1));
					//智慧眼
					mdSmart.message.setBit(messageBody,8,6,mdSmart.message.getBit(cmdMessageBody,9,0));
					//清除风机运行时间
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,10,7));
					//尘满标识
					mdSmart.message.setBit(messageBody,13,5,mdSmart.message.getBit(cmdMessageBody,10,6));
					//峰谷节电功能
					mdSmart.message.setBit(messageBody,10,6,mdSmart.message.getBit(cmdMessageBody,10,5));
					//小夜灯
					mdSmart.message.setBit(messageBody,10,4,mdSmart.message.getBit(cmdMessageBody,10,4));
					//防着凉
					mdSmart.message.setBit(messageBody,10,5,mdSmart.message.getBit(cmdMessageBody,10,3));
					//摄氏/华氏
					mdSmart.message.setBit(messageBody,10,2,mdSmart.message.getBit(cmdMessageBody,10,2));
					//TUBRO状态
					mdSmart.message.setBit(messageBody,10,1,mdSmart.message.getBit(cmdMessageBody,10,1));
					//Sleep功能状态
					mdSmart.message.setBit(messageBody,10,0,mdSmart.message.getBit(cmdMessageBody,10,0));
					mdSmart.message.setByte(messageBody,11,0x66);
					//第一小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,11,0,3));
					//第二小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,11,7,4));
					//第三小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,12,0,3));
					//第四小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,12,7,4));
					//第五小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,13,0,3));
					//第六小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,13,7,4));
					//第七小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,14,0,3));
					//第八小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,14,7,4));
					//第九小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,15,0,3));
					//第十小时舒睡温度
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,15,7,4));
					//第一小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,16,0));
					//第二小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,16,1));
					//第三小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,16,2));
					//第四小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,16,3));
					//第五小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,16,4));
					//第六小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,16,5));
					//第七小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,16,6));
					//第八小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,16,7));
					//第九小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,17,4));
					//第十小时
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,17,5));
					//PMV功能
					mdSmart.message.setBits(messageBody,14,0,3,mdSmart.message.getBits(cmdMessageBody,18,5,7) << 1 | mdSmart.message.getBit(cmdMessageBody,17,7));
					//自然风功能
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBit(cmdMessageBody,17,6));
					//舒睡时间
					//mdSmart.message.setBit(messageBody,0,0,mdSmart.message.getBits(cmdMessageBody,17,0,3));
					//设定温度2
					mdSmart.message.setBit(messageBody,13,0,4,mdSmart.message.getBit(cmdMessageBody,18,0,4));
				}				
			}
			var message = mdSmart.message.createMessage(0xAC,messageType,messageBody);
			var bridgeMessage = mdSmart.message.converMessageToBridgePStr(message);
			bridge.callbackFunction(cmdId,bridgeMessage);
		}
    };
    
    mdSmart.AC_P01.ifWYA = function() {
		var subWYAList = "50585/50583";
		var deviceType = "";
		if (deviceSNValue != "") {
			if (deviceSNValue.length == '32') {
				deviceType = deviceSNValue.substring(12, 17);
			} else {
				deviceType = deviceSNValue.substring(6, 11);
			}
		}
		if(subWYAList.indexOf(deviceType) != '-1'){
			isWYA = true;
		}
    };
    
    mdSmart.AC_P01.ifZB300YJ = function() {
		var subZB300YJList = "Z1170/Z2191";					//ZB300YJ
		var deviceType = "";
		if (deviceSNValue != "") {
			if (deviceSNValue.length == '32') {
				deviceType = deviceSNValue.substring(12, 17);
			} else {
				deviceType = deviceSNValue.substring(6, 11);
			}
		}
		if(subZB300YJList.indexOf(deviceType) != '-1'){
			isZB300YJ = true;
		}
    };
    
    // 根据机型判断是否支持无极调速
	mdSmart.AC_P01.isCACP = function() {
		// 判断SN位数，获取机型
		var subCACPList = "11533/11535";	
		var subCAList = "11447/11451/11453/11455/11457/11459/11525/11527";
		var deviceSNValue = bridge.getCurrentDevSN();
		bridge.logToIOS("isCACP deviceSNValue="+deviceSNValue);

		if (deviceSNValue != "") {
			if (deviceSNValue.length == '32') {
				deviceType = deviceSNValue.substring(12, 17);
			} else {
				deviceType = deviceSNValue.substring(6, 11);
			}
		}
		var ifSupport = "";
		if (subCACPList.indexOf(deviceType) != '-1' || subCAList.indexOf(deviceType) != '-1') {
			ifSupport = true;
		} else {
			ifSupport = false;
		}
		return ifSupport;
	};



	mdSmart.AC_P01.showStatus = function(dataRequest,dataBack){
		// IOSLOG
//        alert("showStatus:"+dataBack.toString());
        setReceiveUploadMsgIsPermitCard();//设置家电上传可用 add by yuxg 20150826
		var receiveMessageBody = dataBack.slice(10, dataBack.length - 1);
		if(receiveMessageBody[0] == 0xA1){
			//Byte13 对应室内温度			Byte14对应室外温度	
			//Byte18高四位为室外温度小数位，低四位为室内温度小数位
			if((parseInt((receiveMessageBody[13] - 50)/2) < -19) || (parseInt((receiveMessageBody[13] - 50)/2) > 50)){
				//当前温度更新
				$("#AC_P01_IndoorTemperature").html(mdSmart.i18n.CURRENT_TEMP + "--" +"&#176");
				$(".AC_P01_IndoorTemperature").html(mdSmart.i18n.CURRENT_TEMP + "--" +"&#176");
			}else{
				//当前温度更新
				$("#AC_P01_IndoorTemperature").html(mdSmart.i18n.CURRENT_TEMP+(parseInt((receiveMessageBody[13] - 50)/2))+"&#176");
				$(".AC_P01_IndoorTemperature").html(mdSmart.i18n.CURRENT_TEMP+(parseInt((receiveMessageBody[13] - 50)/2))+"&#176");
			}
			return false;
		}
		
		if (!(receiveMessageBody[0] == 0xC0 || receiveMessageBody[0] == 0xA0)) {
			return false;
		}
		
		bridge.logToIOS("AC_P01 showStatus start");
		//保存家电返回数据
		mdSmart.common.setLsVar(0xAC, "receiveMessage"+bridge.getCurrentDevSN(), dataBack);
		
		var jsonStatus = mdSmart.AC_P01.message.parseMessageForView(dataBack);
        if(receiveMessageBody[0] == 0xA0 && jsonStatus.status.faultFlag.value != 0){
            return false;
        }
        mdSmart.AC_P01.settingMode=jsonStatus.status.settingMode.value;
		bridge.logToIOS("iscacp="+mdSmart.AC_P01.isCACP());
		bridge.logToIOS("receiveMessageBody[1]="+receiveMessageBody[1]);
		// CA定速主动上报温度更新
		if(mdSmart.AC_P01.isCACP() && receiveMessageBody[0] == 0xA0){
			mdSmart.AC_P01.settingTemperature = (receiveMessageBody[1]>>2) - 4;
			mdSmart.AC_P01.settingTemperatureDot5 = (receiveMessageBody[1]>>1)&0x01;
			bridge.logToIOS("settingTemperature="+mdSmart.AC_P01.settingTemperature);
			bridge.logToIOS("settingTemperatureDot5="+mdSmart.AC_P01.settingTemperatureDot5);
		}else{
			mdSmart.AC_P01.settingTemperature = jsonStatus.status.settingTemperature.value;
			mdSmart.AC_P01.settingTemperatureDot5 = jsonStatus.status.settingTemperatureDot5.value;
		}

		if(receiveMessageBody[0] == 0xA0){
			bridge.logToIOS("A0 settingTemperature="+mdSmart.AC_P01.settingTemperature);
			bridge.logToIOS("A0 settingTemperatureDot5="+mdSmart.AC_P01.settingTemperatureDot5);
		}

		var workModeImg;
    		bridge.logToIOS("settingmode="+jsonStatus.status.settingMode.value);
        if(jsonStatus.status.runningState.value==0){
            setTimeout(function(){
                bridge.jumpOtherPlugin("card_close");
            },0);
        }else{
            if(jsonStatus.status.settingMode.value==0x01)
            {
                bridge.logToIOS("modeset 01");
                setTimeout(function(){
                    bridge.jumpOtherPlugin("card_open");
                },0);
                //当前模式
                $("#AC_P01_workMode").html(mdSmart.i18n.AUTO+mdSmart.i18n.FORMATER_IN_PROCESS);
                bridge.logToIOS("modeset 01 end co="+co);
            }
            else if(jsonStatus.status.settingMode.value==0x02)
            {
                bridge.logToIOS("modeset 02");
                setTimeout(function(){
                    bridge.jumpOtherPlugin("card_open");
                },0);
                //当前模式
                $("#AC_P01_workMode").html(mdSmart.i18n.REFRIGERATING+mdSmart.i18n.FORMATER_IN_PROCESS);
                bridge.logToIOS("modeset 02 end co="+co);
            }
            else if(jsonStatus.status.settingMode.value==0x03)
            {
                bridge.logToIOS("modeset 03");
                setTimeout(function(){
                    bridge.jumpOtherPlugin("card_other");
                },0);
                //当前模式
                $("#AC_P01_workMode").html(mdSmart.i18n.DEHUMIDIFY+mdSmart.i18n.FORMATER_IN_PROCESS);
                bridge.logToIOS("modeset 03 end co="+co);
            }
            else if(jsonStatus.status.settingMode.value==0x04)
            {
                bridge.logToIOS("modeset 04");
                setTimeout(function(){
                    bridge.jumpOtherPlugin("card_hot");
                },0);
                //当前模式
                $("#AC_P01_workMode").html(mdSmart.i18n.HEATING+mdSmart.i18n.FORMATER_IN_PROCESS);
                bridge.logToIOS("modeset 04 end co="+co);
            }
            else if(jsonStatus.status.settingMode.value==0x05)
            {
                bridge.logToIOS("modeset 05");
                setTimeout(function(){
                    bridge.jumpOtherPlugin("card_other");
                },0);
                //当前模式
                $("#AC_P01_workMode").html(mdSmart.i18n.BLOW+mdSmart.i18n.FORMATER_IN_PROCESS);
                bridge.logToIOS("modeset 05 end co="+co);
            }
            else if (jsonStatus.status.settingMode.value == 0x06 && jsonStatus.status.setHumidity.value == 101)//自动除湿模式
            {
                setTimeout(function(){
                    bridge.jumpOtherPlugin("card_other");
                },0);
                //当前模式
                $("#AC_P01_workMode").html(mdSmart.i18n.AUTODEHUMIDITY + mdSmart.i18n.FORMATER_IN_PROCESS);
            }
            else if (jsonStatus.status.settingMode.value == 0x06 && jsonStatus.status.setHumidity.value != 101)//手动除湿模式
            {
                setTimeout(function(){
                    bridge.jumpOtherPlugin("card_other");
                },0);
                //当前模式
                $("#AC_P01_workMode").html(mdSmart.i18n.HANDDEHUMIDITY + mdSmart.i18n.FORMATER_IN_PROCESS);
            }
            else
            {
                //当前模式
                $("#AC_P01_workMode").html(mdSmart.i18n.AUTO+mdSmart.i18n.FORMATER_IN_PROCESS);
            }
        }

        if(mdSmart.AC_P01.settingTemperature < 1) {
				$("#AC_P01_TemperatureNumber>span").html("17");
				$(".AC_P01_TemperatureNumber>span").html("17");
				mdSmart.AC_P01.settingTemperature = 1;
		 	} else if (mdSmart.AC_P01.settingTemperature > 14) {
				$("#AC_P01_TemperatureNumber>span").html("30");
				$(".AC_P01_TemperatureNumber>span").html("30");
				mdSmart.AC_P01.settingTemperature = 14;
		 	} else {
				$("#AC_P01_TemperatureNumber>span").html(mdSmart.AC_P01.settingTemperature+16);
				$(".AC_P01_TemperatureNumber>span").html(mdSmart.AC_P01.settingTemperature+16);
		 	}
		 	
//		}

		// 异常测试代码
		if (logFlg == true) {
			if (jsonStatus.status.settingTemperature.value < 1 || jsonStatus.status.settingTemperature.value > 14) {
				bridge.logToIOS("设定温度返回错误,请检查设备返回值。返回值：" + jsonStatus.status.settingTemperature.value);
			}
		}

//		
//		if(jsonStatus.status.settingMode.value==0x05)
//		{
//			//当前温度更新
//			$("#AC_P01_IndoorTemperature a").html("");
//			$(".AC_P01_IndoorTemperature a").html("");
//		}
//		else
//		{
		if (receiveMessageBody[0] == 0xC0) {
			if(((parseInt((jsonStatus.status.indoorTemperature.value-50)/2)) < -19) || ((parseInt((jsonStatus.status.indoorTemperature.value-50)/2)) > 50))
			{
				//当前温度更新
				$("#AC_P01_IndoorTemperature").html(mdSmart.i18n.CURRENT_TEMP + "--" +"&#176");
				$(".AC_P01_IndoorTemperature").html(mdSmart.i18n.CURRENT_TEMP + "--" +"&#176");
			}
			else
			{
				//当前温度更新
				$("#AC_P01_IndoorTemperature").html(mdSmart.i18n.CURRENT_TEMP+(parseInt((jsonStatus.status.indoorTemperature.value-50)/2))+"&#176");
				$(".AC_P01_IndoorTemperature").html(mdSmart.i18n.CURRENT_TEMP+(parseInt((jsonStatus.status.indoorTemperature.value-50)/2))+"&#176");
			}
		}
//		}
//        alert("jsonStatus.status.runningState.value"+jsonStatus.status.runningState.value);
       deviceType = getDeviceType();
       if(deviceType==4){
       	
       }else{
		if(jsonStatus.status.runningState.value==0)
		{
//            alert("关机");
            bridge.logToIOS("mobile.changePage AC_P03");
            $.mobile.changePage("#AC_P03", "turn");
            $(".data_info").show();
            $(".card_bottom").show();
            $("#AC_P01").hide();
            $("#AC_P03").show();
		}
        else{
//            alert("开机");
            //画面显示更新
            $(".data_info").show();
            $(".card_bottom").show();
            $("#AC_P01").show();
            $("#AC_P03").hide();
			$("#AC_P01_BTN_Close span").html(mdSmart.i18n.POWER_OFF);//Reset close button status
        }
       }
		// IOSLOG
		bridge.logToIOS("AC_P01 showStatus end");
	}
	mdSmart.AC_P01.showJSON = function(pJson){
		var strStatus = "";
		for(var o in pJson){  
			var temp = pJson[o];
			if(temp.name != undefined){
				if(temp.value != undefined && temp.value != 0){
					strStatus =  strStatus +"<BR>" + temp.name + ":";
					if(temp.view != undefined && temp.view[temp.value] != undefined){
						strStatus = strStatus + temp.view[temp.value];
					}else{
						strStatus = strStatus + temp.value;
					}
				}else if(temp.detail != undefined){
					strStatus = strStatus + mdSmart.AC_P01.showJSON(temp.detail);
				}
			}
		}
		return	strStatus;
	}

    //开机按钮事件
    mdSmart.AC_P01.eventOpen=function(){
        console.log("function:mdSmart.AC_P03.eventOpen");
        // IOSLOG
        bridge.logToIOS("AC_P03 eventOpen start");
        $("#AC_P01_BTN_Close span").html(mdSmart.i18n.POWER_OFF);
        if(mdSmart.common.isOperationLock() == true){return false;}
        if(mdSmart.common.isPopupLock() == true){return false;}
        mdSmart.AC_P01.setRunningStateOn();
        // IOSLOG
        bridge.logToIOS("AC_P03 eventOpen end");
    };
    //运行状态(ON)
    mdSmart.AC_P01.setRunningStateOn = function(events) {
        console.log("function:mdSmart.AC_P03.setRunningStateOn");
        // IOSLOG
        bridge.logToIOS("AC_P03 setRunningStateOn start");
        if(mdSmart.common.isCartBtnLock() == true){return false;}

        var jsonStatus = mdSmart.AC_P01.message.parseMessageForView(mdSmart.AC_P01.message.getEquipmentReturnCommandBack());
        var dataBack = mdSmart.AC_P01.message.getEquipmentReturnCommandBack()
        var receiveMessageBody = dataBack.slice(10, dataBack.length - 1);

        if(jsonStatus.status.settingMode.value!=null)
        {
            switch(jsonStatus.status.settingMode.value)//$(".control span").html(mdSmart.i18n.AUTO+mdSmart.i18n.FORMATER_IN_PROCESS);
            {
                case 1:mdSmart.AC_P01.message.setNoPolarWindSpeedValue(101);
                    mdSmart.AC_P01.message.setElectricHeatingButtonPressFlg(0);
                    mdSmart.AC_P01.message.setElectricAuxiliaryHeat(1);break;
                case 3:mdSmart.AC_P01.message.setNoPolarWindSpeedValue(101);break;
                case 2:mdSmart.AC_P01.message.setNoPolarWindSpeedValue(102);break;
                case 4:mdSmart.AC_P01.message.setNoPolarWindSpeedValue(102);
                    mdSmart.AC_P01.message.setElectricHeatingButtonPressFlg(0);
                    mdSmart.AC_P01.message.setElectricAuxiliaryHeat(1);break;
                case 5:mdSmart.AC_P01.message.setNoPolarWindSpeedValue(102);break;
                default:break;
            }
        }

        mdSmart.AC_P01.message.setRunningState(0x01);

        mdSmart.AC_P01.message.setSetTemperate(mdSmart.AC_P01.settingTemperature,mdSmart.AC_P01.settingTemperatureDot5);

        mdSmart.AC_P01.message.setPMVFunction(0);
        var cmdBytes = mdSmart.AC_P01.message.cmdControl(0);
        bridge.logToIOS("AC_P03 setRunningStateOn cmdBytes="+cmdBytes);
        $("#AC_P03_BTN_Open span").addClass("cart_waiting_rotating");
        var cmdId = bridge.startCmdProcess(cmdBytes,function(messageBack){
            bridge.logToIOS("AC_P03 setRunningStateOn start databack="+messageBack);
            mdSmart.AC_P01.showStatus(cmdBytes,messageBack);
            $("#AC_P03_BTN_Open span").removeClass("cart_waiting_rotating");
            mdSmart.common.isCartBtnLockControl(false);
        },function(errCode){
            setReceiveUploadMsgIsPermit(); //设置家电上传可用 add by yuxg 20150826
            if(errCode == -1){
                $("#AC_P03_BTN_Open span").removeClass("cart_waiting_rotating");
                mdSmart.common.isCartBtnLockControl(false);
            }
        });
        mdSmart.AC_P01.afterControlProcess(cmdId,cmdBytes);
        // IOSLOG
        bridge.logToIOS("AC_P03 setRunningStateOn end");
    };
		// 根据机型判断是否支持0.5
	mdSmart.AC_P01.isSupportDot5 = function() {
		var deviceType = "";
		// 判断SN位数，获取机型

//		applianceId = bridge.getCurrentApplianceID();
//		if(deviceSNValue != ""){
//			if (deviceSNValue.length == '32') {
//				deviceType = deviceSNValue.substring(12, 17);
//			} else {
//				deviceType = deviceSNValue.substring(6, 11);
//			}				
//		}
//		var ifSupport = "";
//		
//		var subWEAList = "11373/11375/11377/11379/11309/11311";
//		var subCAList = "11447/11451/11453/11455/11457/11459/67890/11111";
//		var subTAList = "11489/11491/11493/11495/11497/11499/11501/11503";
//		if(subWEAList.indexOf(deviceType) != '-1' || subCAList.indexOf(deviceType) != '-1' || subTAList.indexOf(deviceType) != '-1'){
//			ifSupport = true;
//		}else{
//			ifSupport = false;
//		}
		var ifSupport = false;
		return ifSupport;
	};

})(mdSmart);

//getBits01(receiveMessageBody,1,2,6)
function getBits01(pByte,pStartIndex,pEndIndex){
	var tempVal = 0x00;
	for(var i=pStartIndex;i<=pEndIndex;i++){
		tempVal = tempVal | getBits01(pByte,i) << (i-pStartIndex);
		alert(tempVal);
	}
	return tempVal;
}

function getBit01(pByte,pIndex){
	alert("getbits="+(pByte >> pIndex) & 0x01);
	return (pByte >> pIndex) & 0x01;
}
