var mideaACApp = angular.module('mideaACApp', ['ngRoute', 'ngTouch', 'ngAnimate']);
var _dm_ = new mdSmart.ACDataManager();
 function yesno(){
 	var deviceSN = bridge.getCurrentDevSN();
 	var deviceBarCode = undefined;
 	if (deviceSN != "") {
			if (deviceSN.length == '32') {
				deviceBarCode = deviceSN.substring(12, 17);
			} else if (deviceSN.length == '22') {
				deviceBarCode = deviceSN.substring(6, 11);
			} 
			if(deviceBarCode=="PD004"){
			return	isCentralAC =true;
			}
 }
 	}
 
 	function isCentralAC(){
 	if(yesno()){
 		currentHomePage = 'view/app/partials/central-ac/device-manager.html';
 	}else{
 		if(_dm_.getDeviceType() == "YB100"){
 			currentHomePage = 'view/app/partials/themes/yb200/main.html';
 		}else if(_dm_.getDeviceType() == "MQ200"){
 			currentHomePage = 'view/app/partials/themes/disney/main.html';
 		}else{
 		currentHomePage = 'view/app/partials/main.html';
 		}
 	}
 	return currentHomePage;
      } 
//程序路由映射
mideaACApp.config(function($routeProvider) {

	$routeProvider
       .when(
			'/', {
				templateUrl: isCentralAC
			})
     	.when(
			'/main', {
				templateUrl: 'view/app/partials/main.html'
			})
         .when(
        '/main_new', {
				templateUrl: 'view/app/partials/main_new.html'
			})
         .when(
         '/yb200-main', {
				templateUrl: 'view/app/partials/themes/yb200/main.html'
			})
         .when(
         '/mq200-main', {
				templateUrl: 'view/app/partials/themes/disney/main.html'
			})
		.when(
			'/intelligence-wind', {
				templateUrl: 'view/app/partials/themes/yb200/intelligencewind.html'
			})
		.when(
			'/gesture-control', {
				templateUrl: 'view/app/partials/themes/yb200/gesturecontrol.html'
			})
		.when(
			'/yb200-setting', {
				templateUrl: 'view/app/partials/themes/yb200/setting.html'
			})
		.when(
			'/mq200-setting', {
				templateUrl: 'view/app/partials/setting.html'
			})
		.when(
			'/securityprotect-setting', {
				templateUrl: 'view/app/partials/themes/yb200/securityprotect-setting.html'
			})
		.when(
			'/comfort-sleep_new', {
				templateUrl: 'view/app/partials/comfortSleep_new.html'
			})
		.when(
			'/central-ac', {
				templateUrl: 'view/app/partials/central-ac/device-manager.html'
			})
		.when(
			'/quankong-ac', {
				templateUrl: 'view/app/partials/central-ac/quankong-ac.html'
			})
		.when(
		'/duokong-ac', {
				templateUrl: 'view/app/partials/central-ac/duokong-ac.html'
			})
		.when(
			'/air-check', {
				templateUrl: 'view/app/partials/airCheck.html'
			})
		.when(
			'/all-data', {
				templateUrl: 'view/app/partials/allData.html'
			})
		.when(
			'/auto-off', {
				templateUrl: 'view/app/partials/autoOff.html'
			})
		.when(
			'/check-result', {
				templateUrl: 'view/app/partials/checkResult.html'
			})
		.when(
			'/clean-method', {
				templateUrl: 'view/app/partials/cleanMethod.html'
			})
		.when(
			'/comfort-sleep', {
				templateUrl: 'view/app/partials/comfortSleep.html'
			})
		.when(
			'/electricity', {
				templateUrl: 'view/app/partials/electricity.html'
			})
		.when(
			'/function-btn', {
				templateUrl: 'view/app/partials/functionBtn.html'
			})
		.when(
			'/index', {
				templateUrl: 'view/app/partials/index.html'
			})
		.when(
			'/general', {
				templateUrl: 'view/app/partials/general.html'
			})
		.when(
			'/child-quilt', {
				templateUrl: 'view/app/partials/childQuilt.html'
			})
		.when(
			'/ladder-control', {
				templateUrl: 'view/app/partials/ladderControl.html'
			})
		.when(
			'/operate-intro', {
				templateUrl: 'view/app/partials/operateIntro.html'
			})
		.when(
			'/quilt', {
				templateUrl: 'view/app/partials/quilt.html'
			})
		.when(
			'/setting', {
				templateUrl: 'view/app/partials/setting.html'
			})
		.when(
			'/show', {
				templateUrl: 'view/app/partials/show.html'
			})
		.when(
			'/sound', {
				templateUrl: 'view/app/partials/sound.html'
			})
		.when(
			'/midea-fan', {
				templateUrl: 'view/app/partials/mideaFan.html'
			})
		.when(
			'/midea-store', {
				templateUrl: 'view/app/partials/mideaStore.html'
			})
		.when(
			'/after-sale', {
				templateUrl: 'view/app/partials/afterSale.html'
			})
		.when(
			'/about-air', {
				templateUrl: 'view/app/partials/aboutAir.html'
			})
		.when(
			'/mechine-info', {
				templateUrl: 'view/app/partials/mechineInfo.html'
			})
		.when(
			'/current-month-elect', {
				templateUrl: 'view/app/partials/currentMonthElect.html'
			})
		.when(
			'/electric', {
				templateUrl: 'view/app/partials/electric.html'
			})
		.when(
			'/intel-check', {
				templateUrl: 'view/app/partials/intelCheck.html'
			})
		.when(
			'/time-power', {
				templateUrl: 'view/app/partials/timePower.html'
			})
		.when(
			'/strong-prevent', {
				templateUrl: 'view/app/partials/strongPrevent.html'
			})
		.when(
			'/filter-alter', {
				templateUrl: 'view/app/partials/filterAlter.html'
			})
		.when(
			'/safe-invade', {
				templateUrl: 'view/app/partials/safeInvade.html'
			})
		.when(
			'/intel-control', {
				templateUrl: 'view/app/partials/intelControl.html'
			})
		.when(
			'/gesture-recognize', {
				templateUrl: 'view/app/partials/gestureRecognize.html'
			})
		//		添加手环
		.when(
			'/wristband', {
				templateUrl: 'view/app/partials/wristband.html'
			})
		.when(
			'/add-wristband', {
				templateUrl: 'view/app/partials/addWristband.html'
			})
		.when(
			'/my-wristband', {
				templateUrl: 'view/app/partials/myWristband.html'
			})
		.when(
			'/bluetooch-upgrade', {
				templateUrl: 'view/app/partials/blueToothUpgrade.html'
			})
		.when(
			'/iqComfort', {
				templateUrl: 'view/app/partials/iqComfort.html'
			})
		.when(
			'/iqSound', {
				templateUrl: 'view/app/partials/iqSound.html'
			})
		.when(
			'/capacityYb', {
				templateUrl: 'view/app/partials/capacityYb.html'
			})
		.when(
			'/voiceToUpgrade', {
				templateUrl: 'view/app/partials/voiceToUpgrade.html'
			})
		.when(
			'/self-study', {
				templateUrl: 'view/app/partials/selfStudy.html'
			})
		.when(
			'/user-action-analysis', {
				templateUrl: 'view/app/partials/userActionAnalysis.html'
			})
		.when(
			'/welcome', {
				templateUrl: 'view/app/partials/filter-maintenance/welcome.html'
			})
		.when(
			'/cleanpanel', {
				templateUrl: 'view/app/partials/filter-maintenance/cleanpanel.html'
			})
		.when(
			'/start', {
				templateUrl: 'view/app/partials/filter-maintenance/start.html'
			})
		.when(
			'/record', {
				templateUrl: 'view/app/partials/filter-maintenance/record.html'
			})
		.when(
			'/cleandetail', {
				templateUrl: 'view/app/partials/filter-maintenance/cleandetail.html'
			})
		.when(
			'/cleantime', {
				templateUrl: 'view/app/partials/filter-maintenance/cleantime.html'
			})
        .when(
			'/filterScreen', {
				templateUrl: 'view/app/partials/filterScreen.html'
			})
        .when(
			'/screenCalibration', {
				templateUrl: 'view/app/partials/screenCalibration.html'
			})
		.when(
			'/lvwangshuju', {
				templateUrl: 'view/app/partials/lvwangshuju.html'
			})
		.when(
			'/IsraelCustom', {
				templateUrl: 'view/app/partials/IsraelCustom.html'
			})
});