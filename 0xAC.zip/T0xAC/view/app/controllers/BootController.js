//程序的主入口控制器
mideaACApp.controller('BootController', function ($scope, $rootScope, $location, $sce, deviceCommand, deviceRequest, staticData, coreHelper, $filter) {

    /*程序初始化*/
    $scope.init = function () {
        $scope.currentModule = _dm_.getDeviceType() == "YB100" ? "yb200-" : _dm_.getDeviceType() == "MQ200" ? "mq200-" : "";
        //事件处理初始化
        $scope.handleEvents();
        //主界面控件高度
        $scope.centerHeight = 0;
        $scope.centerMoveHeight = 0;

        //变量监控
        $scope.watchVariable();
        //		小米手环
        $scope.wristhandItems = [];
        $scope.wristbandNameItems = [];
        $scope.wristbandDate = "--";
        $scope.wristbandConsumption = "--";
        $scope.wristbandSteps = "--";
        $scope.wristbandWalkTime = "--";
        $scope.wristbandRunDistance = "--";
        $scope.wristbandDayDistance = "--";

        //蓝牙版本信息
        $scope.bluetoothCurrentVersionNum = "0.0.1.0";
        $scope.bluetoothNewestVersionNum = "0.0.1.7";
        $scope.bluetoothNewestVersionProgress = 0;
        $scope.ifBluetoothNew = false;
        $scope.bluetoothUpdateBtn = false;
        $scope.newBluetoothUpdateBtn = false;
        $scope.updateBluetoothProgressAnimate = false;
        $scope.bluetoothUpgradeProgressValue = 0;
        $scope.ifToBluetoothNewestVersion = 0;
        $scope.bluetoothMac = "";
        $scope.updateBluetoothProgressAnimate = false;
        $scope.isUpdatingBluetooth = false;
        $scope.queryBluetoothUpgradeDelay = 0;
        $scope.queryProgressInterval = 3000;
        $scope.MACItems = [];
        $scope.MACItemsStatus = [];
        $scope.currentBluetoothUpgradeStatus = "搜索蓝牙";
        $scope.currentBluetoothMode = "2";
        $scope.currentUpgradeIndex = -1;

        $scope.bluetoothMode2 = false;		//当前主机模式
        $scope.bluetoothMode1 = false;		//当前从机模式

        //程序配置初始化
        $scope.appConfig = {};
        $scope.appConfig.currentPage = 'main';
        $scope.appConfig.loadMode = 'lazy';
        $scope.appConfig.supportDecimaffl = false;
        $scope.runningModeColor = '#0686FE';
        $scope.runningModeColorDisney = '#66C7FF';
        $scope.appConfig.pageInEffect = 'zj-right';
        $scope.appConfig.pageOutEffect = 'zj-animate-speed';
        $scope.appConfig.pageRenderClass = $scope.appConfig.pageInEffect;
        $scope.appConfig.isDebug = false;
        $scope.appConfig.activeColor = '#0686FE';
        $scope.appConfig.deactiveColor = '#b3b3b3';
        $scope.appConfig.version = '4.1.5';
        $scope.intelCheckBg = false;
        $scope.isOverFlowAuto = false;
        $scope.appConfig.isCentralAC = false;

        /*组件标志位控制*/
        $scope.appRuntime = {};
        $scope.appRuntime.messageCount = 0;
        $scope.appRuntime.touchEventCount = 0;
        $scope.appRuntime.countCloseModalEvent = 0;
        $scope.appConfig.firstRunBallPanel = true;
        $scope.appConfig.firstRunApp = true;
        $scope.appConfig.firstRunInteractChart = true;
        $scope.appConfig.isRunInteractChart = true;
        $scope.appRuntime.testSwitch = false;
        $scope.appRuntime.isTempChange = true;
        $scope.appRuntime.isModeChange = true;
        $scope.appRuntime.isStatusChange = true;
        $scope.appRuntime.firstRunProg = 0;
        $scope.appRuntime.isTouchOpenClose = false;
        $scope.appRuntime.touchOpenCloseStatus = false;
        $scope.appRuntime.firstLoadHomePage = true;
        $scope.appRuntime.isTouchModeChange = false;
        $scope.appRuntime.touchModeDelay = 0;

        /*驻留组件标志位控制*/
        $scope.component = {};
        $scope.component.pullMenuStatus = false;
        $scope.component.ballPanelTouch = false;
        $scope.component.ballPanelTouching = false;
        $scope.component.ballPanelValueChange = false;
        $scope.component.ballPanelToolTipsPos = {};

        /*数据缓存机制*/
        $scope.appCache = {};
        $scope.appCache.pullMenuData = [];

        /*设备状态初始化*/
        $scope.deviceStatus = {};
        $scope.deviceStatus.indoorTempInteger = "--";
        $scope.appRuntime.defaultPlaceholder = "--";
        $scope.deviceStatus.temperatureInteger = -1;
        $scope.appRuntime.currentConfigTemp = $scope.appRuntime.defaultPlaceholder;
//		$scope.deviceStatus.indoorTempInteger = 17;
        $scope.deviceStatus.windSpeedValue = $scope.appRuntime.defaultPlaceholder;
        $scope.deviceStatus.manualAdjustmentValue = $scope.appRuntime.defaultPlaceholder;
        $scope.runningModeName = '制冷运行';
        $scope.deviceStatus.currentIndoorTemp = 17;
        $scope.appRuntime.changeTempTimeOut = 0;
        //电量显示
        $scope.elecStaticTypeShow = false;
        $scope.currentWeekDataShow = false;
        $scope.currentWeekShow = false;
        $scope.currentMonthDataShow = true;
        $scope.blueRowDivisActive = false;
        $scope.layerIsActive = false;
        $scope.arrowUpDown = false;
        $scope.goto_top_type = -1;
        $scope.goto_top_itv = 0;
        $scope.monthDataPosition = "62px";

        //定时开关控制
        $scope.setTimeImgIsActive = true;
//		$scope.setTimeIconIsActive = false;
        $scope.currentElectTitle = "本月电量";

        /*初始化常量表示静态信息*/
        $scope._MSG_SYS_OUT_DEVICE = "您并不在设备中运行此程序";

        //智能体检
        $scope.intelCheckStatus = false;
        $scope.intelCheckOperation = "开始体检";
        $scope.intelCheckDiv = false;
        $scope.checkParame = "false";
        $scope.intelCheckHeight = "138px";
        $scope.checkScoreSize = "55px";
        $scope.checkFen = "20px";
        $scope.intelCheckShow = false;
        $scope.checkScore = "--";
        $scope.checkParameters = "--";
        $scope.faultNumber = "--";
        $scope.checkNum = "--";

        //睡眠曲线
        $scope.currentSleepCustomStatus = false;
        $scope.currentSleepRecommendStatus = false;
        $scope.sleepCurveCustomStatus = false;
        $scope.sleepCurveRecommendStatus = false;
        $scope.currentSleepOperation = "执行睡眠";
        $scope.ifChooseSleepCurve = false;
        $scope.currentSleepStatus = false;

        //强力防霉
        $scope.queryState = false;
        $scope.queryCount = 0;
        $scope.finishFlag = false;
        $scope.remainingTime = "20分钟";
        $scope.queryInterval = 15000;
        $scope.strongPreventOperation = "运行防霉";
        $scope.strongPreventDesc = "强力防霉可有效防止";
        $scope.strongPreventState = "未知";
        $scope.curStrongPreventState = 0;
        $scope.strongPreventQuery = 0;
        $scope.appRuntime.queryStrongPreventDelay = 0;
        $scope.appRuntime.queryCalibrationDelay = 0;
        $scope.animateTime = 1200000;

        //本机信息
        $scope.BAND = "--";
        $scope.productModel = "--";
        $scope.productDate = "--";
        $scope.productPlace = "--";
        $scope.VERSION = "--";
        $scope.productSN = "--";

        //基准校准
        $scope.calibrationOperation = "运行校准";
        $scope.curCalibrationState = 0;
        $scope.calibrationState = "未知";
        $scope.calibrationDesc = "当滤网脏检测结果与实际状态不一致时,可进行基准校准";
        $scope.calibrationAnimateTime = 1200000;
        $scope.calibrationQueryState = false;
        //模式延时发码
        $scope.appRuntime.modeMap = [{
            index: 0,
            status: "none valide"
        }, {
            index: 1,
            status: "自动运行"
        }, {
            index: 2,
            status: "制冷运行"
        }, {
            index: 3,
            status: "抽湿运行"
        }, {
            index: 4,
            status: "制热运行"
        }, {
            index: 5,
            status: "送风运行"
        }];
        $scope.appRuntime.currentModeIndex = 1;
        $scope.appRuntime.modeDelay = 0;
        $scope.appRuntime.isPageBlocking = true;

        //引入数据容器
        $scope.staticData = staticData.getIconResource();
        $scope.openCloseisActive = false;
        $scope.switchModelisActive = false;
        $scope.changeWindisActive = false;
        $scope.upDownisActive = false;
        $scope.upisActive = false;
        $scope.downisActive = false;
        $scope.leftRightisActive = false;
        $scope.windisActive = false;
        $scope.EcoisActive = false;
        $scope.keepWarmoisActive = false;
        $scope.sleepisActive = false;
        $scope.timerisActive = false;
        $scope.timerOpenisActive = false;
        $scope.noWindFeelisActive = false;
        $scope.readyColdHotisActive = false;
        $scope.electricHeatisActive = false;
        $scope.natureWindisActive = false;
        $scope.purifyisActive = false;
        $scope.childrenPreventColdisActive = false;
        $scope.dryisActive = false;
        $scope.savingElectricisActive = false;
        $scope.pmvisActive = false;
        $scope.comfortSleepisActive = false;
        $scope.strongisActive = false;
        $scope.comfortDryisActive = false;
        $scope.manualDryisActive = false;
        $scope.safeInvadeisActive = false;
        $scope.selfCleaningisActive = false;
        $scope.coldHotSwitchActive = false;
        $scope.preventStraightLineWindIsActive = false;
        $scope.upNoWindFeelIsActive = false;
        $scope.downNoWindFeelIsActive = false;
        $scope.childrenPreventWindisActive = false;
        $scope.straightBlowActive = false;
        $scope.softWindFeelSwitchActive = false;
        $scope.sleepisActive = false;

        $scope.appRuntime.checkStatusColorNormal = "#23CC20";
        $scope.appRuntime.checkStatusColorError = "#F15A24";
        $scope.checkStatusColorBg = true;
        $scope.appRuntime.checkStatusColor = $scope.appRuntime.checkStatusColorNormal;
        $scope.currenLevel = "goodState";
        $scope.testStatus = "";
        $scope.ADvalueLow = "";
        $scope.ADvalueHigh = "";
        $scope.controlADrangeLow = "";
        $scope.controlADrangeHigh = "";
        $scope.thresholdValue = "";
        $scope.dutyRatio = "";
        $scope.environmentValueLow = "";
        $scope.environmentValueHigh = "";
        $scope.percentageReadings = 100;
        $scope.fanRunTimeLow = "";
        $scope.fanRunTimeHigh = "";

        //自学习
        $scope.appRuntime.scrollSelectorStart = 0;
        $scope.appRuntime.scrollSelectorStop = 0;
        $scope.appRuntime.startTime = "--";
        $scope.appRuntime.stopTime = "--";
        $scope.appRuntime.selfLearningBtn = "应用曲线";
        $scope.appRuntime.avgTemp = "--";
        $scope.appRuntime.minTemp = "--";
        $scope.appRuntime.maxTemp = "--";
        $scope.appRuntime.avgWindspeed = "--";
        $scope.appRuntime.minWindspeed = "--";
        $scope.appRuntime.maxWindspeed = "--";
        $scope.appRuntime.selfLearningBtnShow = false;
        $scope.tempSpeedMin = new Array();
        $scope.tempSpeedMax = new Array();
        $scope.tempSpeedAvg = new Array();
        $scope.appRuntime.selfLearningCurveDate = "--";
        $scope.appRuntime.selfLearningLength = "10";

        //yuyin版本说明内容
        $scope.yuyinVersionContent = "";
        //yuyin版本信息
        $scope.ifNew = false;
        $scope.yuyinVersionCurrentVersionNum = 0;//当前版本
        $scope.yuyinUpdateVersionNum = 0;//可升级版本
        $scope.YuyinDownloadRateVersionProgress = 0;//下载进度
        $scope.ifWifiNew = false;
        $scope.yuyinUpdateBtn = false;//升级
        $scope.newYuyinUpdateBtn = false;//已最新
        $scope.updateYuyinProgressAnimate = false;//正在升级
        $scope.yuyinNewestVersionProgress = 0;
        $scope.yuyinDeviceStatus = 0;//设备状态, 0：空闲，1：下载中，2：下载成功，3：下载失败，4：升级中，5：升级成功，6：升级失败
        // 过滤网校准
        $scope.noScreenCalibration = false;//未校准
        $scope.screenCalibrationIng = false;//正在校准
        $scope.screenCalibrationStatic = false;//静态校准
        $scope.screenCalibrationFail = false;//校准失败
        $scope.noRuning = false;//空调未开机，无法校准
        $scope.screenCalibrationSuccessful = false;//校准成功

        //获得当前设备的状态
        $scope.getDeviceStatus();

        //获得外部资源
        $scope.getExtenalResource();

        //首次更新视图
        $scope.updateMainView();

        //获取设备类型
        $scope.getCurrentdevicetype();

        //初始化风速控制
        $scope.switchChangeWindSpeed();

        //初始化湿度控制
        $scope.switchChangeSetHumidity();
        //初始化音量控制
        $scope.switchChangeSetSoundValue();

        //判断设备
        $scope.appConfig.isMobile = coreHelper.detectDevice();
        $scope.appConfig.isHpDevice = coreHelper.detectHpDevice();

        //判断设备version
        $scope.appConfig.deviceVersion = coreHelper.getDeviceVersion();

        //控件初始化准备
        $scope.preLaunchComponent();
        $scope.initPhysicBack();
        $scope.isCentralAC();

        //more module
        $scope.filterMaintenance = {
            isTimerSelected: false,
            lastCleanTimeIndex: 0,
            yesterdayCleanStatus: -0.5,
            currentCleanStateValue: 100,
            currentCleanStateValueForView: 100,
            currentCleanState: "goodState",
            isFirstEnterPage: true,
            isToolDirty: false,
            runTimeData: {
                currentBgCircle: "./view/public/images/green-c.png",
                setCleanTimeError: false,
                networkTimeout: 0,
                locationTime: undefined, //安装时间
                recordList: [], //清洗记录列表
                recordListBool: false, //是否清洗记录
                setCleanTimeFlag: false, //新增滤网清洗 标志
                cleanStatusMsg: false, //当前滤网状态
                cleanStatusMsgHis: [{
                    time: "2017-04-30",
                    point: -0.0,
                    detail: {
                        acUsedTime: 8,
                        cleanStatus: -5.0,
                        windSetTime: {
                            hight: 10,
                            mid: 2,
                            low: 3,
                            auto: 1
                        },
                        modeSetTime: {
                            cool: 20,
                            hot: 10,
                            wind: 2,
                            humidity: 3,
                            auto: 10
                        },
                        weather: {
                            desc: "晴朗",
                            aqi: 10,
                            maxTemp: 30,
                            minTemp: 22,
                            humidity: 70
                        }
                    }
                }, {
                    time: "2017-04-29",
                    point: -0.0,
                    detail: {
                        acUsedTime: 20,
                        cleanStatus: 1.0,
                        windSetTime: {
                            hight: 7,
                            mid: 2,
                            low: 5,
                            auto: 10,
                        },
                        modeSetTime: {
                            cool: 16,
                            hot: 10,
                            wind: 1,
                            humidity: 5,
                            auto: 10,
                        },
                        weather: {
                            desc: "多云",
                            aqi: 10,
                            maxTemp: 20,
                            minTemp: 12,
                            humidity: 50
                        }
                    }
                }, {
                    time: "2017-04-28",
                    point: +36.0,
                    detail: {
                        acUsedTime: 18,
                        cleanStatus: -10.0,
                        windSetTime: {
                            hight: 2,
                            mid: 20,
                            low: 30,
                            auto: 19,
                        },
                        modeSetTime: {
                            cool: 5,
                            hot: 12,
                            wind: 12,
                            humidity: 18,
                            auto: 15
                        },
                        weather: {
                            desc: "大雨",
                            aqi: 20,
                            maxTemp: 10,
                            minTemp: 2,
                            humidity: 9
                        }
                    }
                }], //undefined,历史滤网状态
                currentCleanStatusPageIndex: 0,
                cleanUrl: $sce.trustAsResourceUrl("http://air-manager-source.oss-cn-hangzhou.aliyuncs.com/video/yb200/guaji.mp4")
            },
            cleanPanel: {
                goodState: {
                    bgColor: "#0F83FF",
                    bgClass: "main-color-green",
                    valueRange: [75, 100],
                    notice: "空调滤网很洁净哦,棒棒哒~",
                },
                midState: {
                    bgColor: "#ea5514",
                    bgClass: "main-color-orange",
                    valueRange: [35, 75],
                    notice: "滤网已聚集一些灰尘，建议清洗",
                },
                badState: {
                    bgColor: "#f39800",
                    bgClass: "main-color-red",
                    valueRange: [0, 35],
                    notice: "滤网严重脏堵，建议立刻清洗！",
                },
            },
            cleanTimeList: [{
                time: '从未清洗过',
                isChecked: false,
                rule: -1,
            }, {
                time: '今天',
                isChecked: false,
                rule: 0
            }, {
                time: '两周内',
                isChecked: false,
                rule: 7,
            }, {
                time: '一个月内',
                isChecked: false,
                rule: 15
            }, {
                time: '三个月内',
                isChecked: false,
                rule: 50,
            }, {
                time: '一年以内',
                isChecked: false,
                rule: 180,
            }, {
                time: '一年以上',
                isChecked: false,
                rule: 500
            }]
        };
    };
    $scope.isCentralAC = function () {
        if ($scope.currentDeviceInfo.isCentralAC) {
            $scope.appConfig.isCentralAC = true;
        } else {
            $scope.appConfig.isCentralAC = false;
        }
    }

    $scope.initPhysicBack = function () {
        bridge.setAndroidGoBack = function () {
            var url = location.href;
            var urlLength = url.length;
            if (url != '' && urlLength >= 2) {
                last2Char = url.substring(urlLength - 2, urlLength);
                if (url.indexOf("main") != -1 || last2Char === '#/') {
                    location.href = "iosbridge://goBack";
                }
                else if (url.indexOf('setting') != -1) {
                    $scope.redirectPage($scope.currentModule + 'main', 'in');
                    $scope.$apply();
                } else if ((url.indexOf("time-power") != -1) ||
                    (url.indexOf("current-month-elect") != -1)) {
                    $scope.redirectPage('electric', 'in');
                    $scope.$apply();
                } else if (url.indexOf("filter-alter") != -1) {
                    $scope.redirectPage('strong-prevent', 'in');
                    $scope.$apply();
                } else if ((url.indexOf("show") != -1) ||
                    (url.indexOf("sound") != -1)) {
                    $scope.redirectPage('general', 'in');
                    $scope.$apply();
                } else if ((url.indexOf("operate-intro") != -1) ||
                    (url.indexOf("mechine-info") != -1)) {
                    $scope.redirectPage('about-air', 'in');
                    $scope.$apply();
                } else if (url.indexOf("add-wristband") != -1) {
                    $scope.redirectPage('wristband', 'in');
                    $scope.$apply();
                }
                else {
                    $scope.redirectPage($scope.currentModule + "setting", 'in');
                    $scope.$apply();
                }
            }
        }
    }

    $scope.filterScreen = function () {
        $scope.acController.filterDirtyPluggingStatus();
        if ($scope.acController.dataManager.getFilterDirtyPlugging().testStatus == 0) {
            $scope.timeoutPopUp("请先开机!");
        }
        else if ($scope.acController.dataManager.getFilterDirtyPlugging().meshFailure1 ||
            $scope.acController.dataManager.getFilterDirtyPlugging().meshFailure2) {
            $scope.timeoutPopUp("请清洁滤网!");
        }
        else {
            $scope.redirectPage('filterScreen', 'in');
        }
    }

    //改变main.html界面元素大小
    $scope.changeMain = function () {
        var bodyWidth = $('.loadingWrapper').width();
        var bodyHeight = $('.loadingWrapper').height();

        //设置alernate-center-render-fixed为正方形
        if (bodyWidth * 0.7 > bodyHeight * 0.7 * 0.7) {
            $('.alernate-center-render-fixed').css('width', bodyHeight * 0.7 * 0.7);
            $('.alernate-center-render-fixed').css('height', bodyHeight * 0.7 * 0.7);
            $('.alernate-center-render').css('height', bodyHeight * 0.7 * 0.7);
            $scope.centerHeight = bodyHeight * 0.7 * 0.7;
        } else {
            $('.alernate-center-render-fixed').css('height', bodyWidth * 0.7);
            $('.alernate-center-render-fixed').css('width', bodyWidth * 0.7);
            $('.alernate-center-render').css('height', bodyWidth * 0.7);
            $scope.centerHeight = bodyWidth * 0.7;
        }

        var marginLeftRight = (bodyWidth - $('.alernate-center-render-fixed').width()) / 2;
        $('.alernate-center-render-fixed').css('margin-left', marginLeftRight);

        $('.main-temp-add').css('width', (bodyWidth - 30) * 0.25 * 0.65);
        $('.main-temp-add').css('height', (bodyWidth - 30) * 0.25 * 0.65);

        $('.main-temp-sub').css('width', (bodyWidth - 30) * 0.25 * 0.65);
        $('.main-temp-sub').css('height', (bodyWidth - 30) * 0.25 * 0.65);
        $scope.centerMoveHeight = $('.alernate-center-render-fixed').offset().top;
        var tempAddSubWidth = $('.main-temp-add').width();

        $('.main-temp-add').css('margin-right', -tempAddSubWidth / 2);
        $('.main-temp-sub').css('margin-left', -tempAddSubWidth / 2);
    }

    //温度加
    $scope.addTemp = function () {
        changeTempData(false);
    }

    //温度减
    $scope.subTemp = function () {
        changeTempData(true);
    }

    function changeTempData(isSubTemp) {
        if (!$scope.appConfig.supportDecimal) {
            if (isSubTemp) {
                //减
                if ($scope.appRuntime.currentConfigTemp <= 17) {
                    $scope.appRuntime.currentConfigTemp = 17;
                     $scope.timeoutPopUp("最低设置温度17度");
                } else {
                    $scope.appRuntime.currentConfigTemp--;
                }
            } else {
                //加
                if ($scope.appRuntime.currentConfigTemp >= 30) {
                    $scope.appRuntime.currentConfigTemp = 30;
                    $scope.timeoutPopUp("最高设置温度30度");
                } else {
                    $scope.appRuntime.currentConfigTemp++;
                }
            }
            $scope.$apply();
        } else {
            if (isSubTemp) {
                //减
                if ($scope.appRuntime.currentConfigTemp <= 17) {
                    $scope.appRuntime.currentConfigTemp = 17;
                    $scope.timeoutPopUp("最低设置温度17度");
                } else {
                    $scope.appRuntime.currentConfigTemp -= 0.5;
                }
            } else {
                //加
                if ($scope.appRuntime.currentConfigTemp >= 30) {
                    $scope.appRuntime.currentConfigTemp = 30;
                    $scope.timeoutPopUp("最高设置温度30度");
                } else {
                    $scope.appRuntime.currentConfigTemp += 0.5;
                }
            }
            $scope.$apply();
        }
    }

    function mainTempStartChange(event, changeFunction) {
        event.preventDefault();
        if (!$scope.deviceStatus.deviceRunningStatus) {
            $scope.timeoutPopUp("关机下温度不可调节!");
        } else {
            if ($scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind) {
                $scope.timeoutPopUp("送风模式下温度不可调节!");
            } else {
                changeFunction();
                if ($scope.appRuntime.changeTempTimeOut != 0) {
                    clearInterval($scope.appRuntime.changeTempTimeOut);
                }
                $scope.appRuntime.changeTempTimeOut = setInterval(function () {
                    changeFunction();
                }, 300);
                setReceiveUploadIsUnallowed();
                $scope.acController.dataManager.getColdHotState().coldHotSwitch = 0;
                $scope.deviceStatus.coldHotSwitch = 0;
            }
        }
        $scope.$apply();
    }

    function mainTempStopChange(event) {
        event.preventDefault();
        clearInterval($scope.appRuntime.changeTempTimeOut);
        if ($scope.deviceStatus.deviceRunningStatus &&
            $scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind) {
            if (!$scope.appConfig.supportDecimal) {
                $scope.acController.controlSetTemperature($scope.appRuntime.currentConfigTemp, 0);
            } else {
                $scope.acController.controlSetTemperature(parseInt($scope.appRuntime.currentConfigTemp), $scope.appRuntime.currentConfigTemp - parseInt($scope.appRuntime.currentConfigTemp));
            }
        }
        $scope.$apply();
    }

    $scope.tempDecimal = function (temp) {
        return (temp - parseInt(temp)) * 10;
    }

    $scope.tempInteger = function (temp) {
        return parseInt(temp);
    }
    $scope.changeTemp = function () {
        $(".main-temp-add,.slider-control-temp-disney-right,.slider-control-temp-disney-right-up").unbind("touchstart").bind("touchstart", function (event) {
            mainTempStartChange(event, $scope.addTemp);
        });
        $(".main-temp-sub,.slider-control-temp-disney-left,.slider-control-temp-disney-left-up").unbind("touchstart").bind("touchstart", function (event) {
            mainTempStartChange(event, $scope.subTemp);
        });
        $(".main-temp-add,.slider-control-temp-disney-right,.main-temp-sub,.slider-control-temp-disney-left,.slider-control-temp-disney-right-up,.slider-control-temp-disney-left-up").unbind("touchend").bind("touchend", function (event) {
            mainTempStopChange(event);
        });

        $(".main-temp-add,.main-temp-sub,.slider-control-temp-disney-right,.slider-control-temp-disney-left,.slider-control-temp-disney-right-up,.slider-control-temp-disney-left-up").unbind("touchcancel").bind("touchcancel", function (event) {
            clearInterval($scope.appRuntime.changeTempTimeOut);
        });
        /**
         $(".main-temp-add").unbind("touchstart").bind("touchstart",function(event){
			event.preventDefault();
			$(".main-temp-sub").unbind("touchstart");
            $(".main-temp-sub").unbind("touchend");

			if (!$scope.deviceStatus.deviceRunningStatus) {
				$scope.timeoutPopUp("关机下温度不可调节!");
			} else {
				if ($scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind) {
					$scope.timeoutPopUp("送风模式下温度不可调节!");
				} else {
					$scope.addTemp();
					$scope.appRuntime.changeTempTimeOut = setInterval(function(){
						$scope.addTemp();
					},300);
					setReceiveUploadIsUnallowed();
					$scope.acController.dataManager.getColdHotState().coldHotSwitch=0;
				    $scope.deviceStatus.coldHotSwitch=0;
				}
			}

			$scope.$apply();
		});

         $(".main-temp-add").unbind("touchend").bind("touchend",function(event){
			event.preventDefault();
			$(".main-temp-sub").unbind("touchstart");
            $(".main-temp-sub").unbind("touchend");

			clearInterval($scope.appRuntime.changeTempTimeOut);

			if (!$scope.deviceStatus.deviceRunningStatus) {

			} else {
				if ($scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind) {

				} else {
					if (!$scope.appConfig.supportDecimal) {
						$scope.acController.controlSetTemperature($scope.appRuntime.currentConfigTemp, 0);
					} else {
						$scope.acController.controlSetTemperature(parseInt($scope.appRuntime.currentConfigTemp), $scope.appRuntime.currentConfigTemp - parseInt($scope.appRuntime.currentConfigTemp));
					}
				}
			}

			$scope.$apply();
		});

         $(".main-temp-sub").unbind("touchstart").bind("touchstart",function(event){
			event.preventDefault();
			$(".main-temp-add").unbind("touchstart");
            $(".main-temp-add").unbind("touchend");

			if (!$scope.deviceStatus.deviceRunningStatus) {
				$scope.timeoutPopUp("关机下温度不可调节!");
			} else {
				if ($scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind) {
					$scope.timeoutPopUp("送风模式下温度不可调节!");
				} else {
					$scope.subTemp();
					$scope.appRuntime.changeTempTimeOut = setInterval(function(){
						$scope.subTemp();
					},300);
					setReceiveUploadIsUnallowed();
					$scope.acController.dataManager.getColdHotState().coldHotSwitch=0;
				    $scope.deviceStatus.coldHotSwitch=0;
				}
			}

			$scope.$apply();
		});

         $(".main-temp-sub").unbind("touchend").bind("touchend",function(event){
			event.preventDefault();
			$(".main-temp-add").unbind("touchstart");
            $(".main-temp-add").unbind("touchend");

			clearInterval($scope.appRuntime.changeTempTimeOut);
			if (!$scope.deviceStatus.deviceRunningStatus) {

			} else {
				if ($scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind) {

				} else {
					if (!$scope.appConfig.supportDecimal) {
						$scope.acController.controlSetTemperature($scope.appRuntime.currentConfigTemp, 0);
					} else {
						$scope.acController.controlSetTemperature(parseInt($scope.appRuntime.currentConfigTemp), $scope.appRuntime.currentConfigTemp - parseInt($scope.appRuntime.currentConfigTemp));
					}
				}
			}

			$scope.$apply();
		}); */
    }


    /******************************设备交互--业务逻辑*******************************/
    /*事件处理*/
    $scope.handleEvents = function () {
        $(document).bind('delay::operation::get::device::info', {}, function (event, message) {
            $scope.appRuntime.isPageBlocking = false;
            $scope.getCurrentdevicetype();
            $scope.$apply();
        });

        $(document).bind('updateViewMessage', {}, function (event, message) {
            $scope.isShabbatStatus = $scope.deviceStatus.shabbatStatus;
            $scope.$broadcast('shabbatPlay::init::toggle::switch', {
                'currentVal': $scope.isShabbatStatus
            });
            if ($scope.appRuntime.firstLoadHomePage) {
                $scope.$broadcast('ng::updateViewMessage', {});
                $scope.$apply(function () {
                    $scope.appRuntime.firstLoadHomePage = false;
                    //$scope.currentDeviceInfo = $scope.acController.dataManager.getCurrentDevice().deviceInfo;
                });
                //获取设备类型
                //$scope.getCurrentdevicetype();
            } else {
                $scope.$apply(function () {
                    $scope.$broadcast('ng::updateViewMessage', {});
                });
            }
        });

        $scope.$on('ng::updateViewMessage', function (event, message) {
//			$scope.$apply(function() {
            if ($scope.acController.dataManager.getDeviceCleaningStatus().selfCleaning) {
                $scope.acController.selfCleaningdeviceStatus();
            }
            if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool) {
                $scope.upNoWindFeelIsActive =
                    $scope.downNoWindFeelIsActive =
                        $scope.deviceStatus.upNoWindFeel =
                            $scope.deviceStatus.downNoWindFeel = false;
            }
            $scope.deviceStatus = $scope.acController.dataManager.getCurrentDevice().deviceStatus;
            $scope.appRuntime.currentModeIndex = $scope.deviceStatus.runningMode;
            $scope.deviceVolumeStatus = $scope.acController.dataManager.getVolumeState();

//			$scope.deviceStatus.currentIndoorTemp = Number($scope.deviceStatus.indoorTempInteger) + Number($scope.deviceStatus.indoorTempDecimal);
            $scope.deviceStatus.currentIndoorTemp = $scope.deviceStatus.indoorTemp;
            if (!$scope.appRuntime.isTouchModeChange) {
                $scope.runningModeName = $scope.acController.dataManager.getDeviceRunModeName($scope.deviceStatus.runningMode);
            }

            if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool &&
                $scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat) {
                $scope.deviceStatus.readyColdOrHot = false;
            } else {
                $scope.deviceStatus.readyColdOrHot = localStorage.getItem("ACDeviceReadyColdOrHot") == 1 ? true : false;
            }

            $scope.safeInvadeisActive = $scope.deviceStatus.securityStatus;

            $scope.updateMainView();
            $scope.setTimeIconControl();

            $scope.ballPanelActiveRule();
            $scope.changeTemp();

            /*温控球实时更新 和进行相关交互控制*/
            $scope.appRuntime.currentConfigTemp = $scope.appConfig.supportDecimal ? $scope.deviceStatus.temperatureInteger + $scope.deviceStatus.temperatureDecimal : $scope.deviceStatus.temperatureInteger;
            $scope.appRuntime.prevConfigTemp = $scope.appRuntime.currentConfigTemp;
//			alert($scope.appRuntime.currentConfigTemp);
            /*if ((!$scope.component.ballPanelTouch) && (!$scope.component.ballPanelTouching)) {

				/*if (!$scope.deviceStatus.deviceRunningStatus) {
					$scope.appRuntime.currentConfigTemp = $scope.deviceStatus.indoorTempInteger;
				}

				$scope.$broadcast('update::ballPanel', {
					tempReal: $scope.deviceStatus.indoorTempInteger,
					tempConfig: $scope.appRuntime.currentConfigTemp,
					mode: $scope.deviceStatus.runningMode,
					status: $scope.openCloseisActive
				});
			}*/

            //debug 计数器
            $scope.appRuntime.messageCount += 1;

            $scope.hasDisplayStatus = $scope.deviceStatus.screenDisplay;
            $scope.$broadcast('screenDisplay::init::toggle::switch', {
                'currentVal': $scope.hasDisplayStatus
            });
            $scope.deviceName = $scope.deviceStatus.deviceName;

            $scope.getPreventColdData();
            $scope.getElectricityData();

//			$scope.isWindBlow = $scope.deviceStatus.windDirectionStatus == 1 ? true : false;
//			$scope.isWindClose = $scope.deviceStatus.windDirectionStatus == 2 ? true : false;

            $scope.isGestureRecognitionOnOff = $scope.deviceStatus.gestureRecognitionOnOffStatus;
            $scope.isGestureRecognitionDirection = $scope.deviceStatus.gestureRecognitionDirectionStatus;

            //});

            $scope.$broadcast('update::ballPanel', {
                tempReal: $scope.deviceStatus.indoorTempInteger,
                tempConfig: $scope.appRuntime.currentConfigTemp,
                mode: $scope.deviceStatus.runningMode,
                status: $scope.openCloseisActive
            });
        });

        $(document).bind('updateHumidityMessage', {}, function (event, message) {
            $scope.$apply(function () {
                $scope.deviceStatus.humidityValue = $scope.acController.dataManager.getCurrentDevice().deviceStatus.humidityValue;
            });
        });

        $(document).bind('updateModeViewMessage', {}, function (event, message) {
            /*$scope.$apply(function() {
				if ((!$scope.component.ballPanelTouching) && ($scope.appRuntime.isModeChange) && ($scope.appRuntime.isStatusChange)) {
					$scope.updateControlView();
				}
			});*/
        });

        $(document).bind('notifyOperateFail', {}, function (event, message) {
            $scope.$apply(function () {
                $scope.timeoutPopUp("操作失败,请重试!");
            });
        });

        /*路由事件处理*/
        $scope.$on('$routeChangeSuccess', function (event, next, current) {
            $scope.isOverFlowAuto = false;

            /*$scope.currentDeviceInfo = $scope.acController.dataManager.getCurrentDevice().deviceInfo;
			alert($scope.currentDeviceInfo.hasPMV)*/

            //设备功能初始化
            if (next.loadedTemplateUrl === 'view/app/partials/electric.html') {
                $scope.acController.requestElectricQuantityStatus();
                setTimeout(function () {
                    $scope.getMonthElectricityData();
                }, 300);
            } else if (next.loadedTemplateUrl === 'view/app/partials/childQuilt.html') {
                $scope.acController.dataManager.resetCachePreventCold();
                $scope.getPreventColdData();
                $scope.acController.requestPreventColdAPNSRemindStatus();
                $scope.acController.requestPreventColdDeviceStatus();
                if ($scope.appConfig.pageLoadState === 'in') {
                    coreHelper.delayExecute(function () {
                        $scope.newSwitchPreventColdAPNSRemind();
                    }, 500);
                }
            } else if (next.loadedTemplateUrl === 'view/app/partials/comfortSleep.html') {
            	console.log("6666666");
                /*此处发码部分已经转移到setting路由处*/
                //请求睡眠曲线的值，请求完成发出”refreshSleepView“通知
                //界面编辑完成调用Controller的 controlSwitchSleep(Boolean isOpen)发码  add by yuxg 20150807
                if ($scope.appConfig.pageLoadState === 'in') {
                    $scope.acController.showLoading();
                }
                if (($scope.appConfig.firstRunInteractChart) || ($scope.appConfig.isRunInteractChart)) {
                    $scope.acController.initSleepCurve();
                    $scope.appConfig.firstRunInteractChart = false;
                } else {
                		 $scope.acController.hideLoading();
                    $scope.appCache.pullMenuData[0] = $scope.appRuntime.currentConfigTemp.toFixed(0);
                }

            } else if (next.loadedTemplateUrl === 'view/app/partials/intelCheck.html') {
                $scope.intelCheckShow = false;
                $scope.intelCheckBg = true;
                $scope.acController.getDeviceIntelCheckInfo();
                coreHelper.delayExecute(function () {
                    $("#intelCheckBtn").css("display", "block");
                }, 300);
            } else if (next.loadedTemplateUrl === 'view/app/partials/main.html' || next.loadedTemplateUrl === 'view/app/partials/themes/disney/main.html') {
                if ($scope.currentDeviceInfo.hasFilterScreen) {
                    $scope.acController.filterDirtyPluggingStatus();
                    $scope.filterDirtyPluggingjx();
                }
                if ($scope.currentDeviceInfo.hasChangesTemperature) {
                    setTimeout(function () {
                        $scope.acController.requestWindBlowingnewValueFA100();
                        $scope.acController.requestWindBlowWindCloseControlStatus();
                        $scope.acController.requestInitColdeHotStatusForFA100();
                    }, 600);
                }
//				alert("width"+screen.width);
//				alert("height"+screen.height);
                $scope.checkFilterMaintemance();

                setTimeout(function () {
                    $scope.changeTemp();
                }, 1000);
//				setTimeout(function(){
//					$scope.changeMain();
//				},1000) ;
                if ($scope.appConfig.pageLoadState === 'out') {
                    coreHelper.delayExecute($scope.updateControlView, 1);
                    coreHelper.delayExecute($scope.ballPanelActiveRule, 2);
                }
            } else if (next.loadedTemplateUrl === 'view/app/partials/setting.html') {
                if ($scope.currentDeviceInfo.hasFilterScreen) {
                    $scope.acController.filterDirtyPluggingStatus();
                }
                coreHelper.lockScroll($scope, [$('body')], false);
                if ($scope.currentDeviceInfo.hasYuyinVersion) {
                    setTimeout(function () {
                        $scope.acController.getYuyinVersion();
                        $("#ifNew").hide();
                    }, 100);
                }
                $scope.scanProcess = "";
                $scope.intelCheckBg = false;
                $scope.acController.dataManager.updateStrongPreventQueryState(1);
                clearTimeout($scope.appRuntime.queryStrongPreventDelay);
                $scope.acController.requestExternalUrl();
                //体检返回时取消体检
                $scope.intelCheckShow = false;
                $scope.intelCheckStatus = false;
                $(".intelCheckBg").stop(false, false);
                $(".intelCheckBg").css("width", "1%");
                $scope.intelCheckOperation = "开始体检";

            } else if (next.loadedTemplateUrl === 'view/app/partials/aboutAir.html') {
                $scope.acController.requestVideoUrl();
                $scope.acController.requestFAQContent();
            } else if (next.loadedTemplateUrl === 'view/app/partials/filterScreen.html') {
                coreHelper.delayExecute(function () {
                    $scope.acController.filterDirtyPluggingStatus();
                }, 50);
                coreHelper.delayExecute(function () {
                    $scope.filterDirtyPluggingjx();
                }, 50);

            } else if (next.loadedTemplateUrl === 'view/app/partials/screenCalibration.html') {
                coreHelper.delayExecute(function () {
                    $scope.acController.screenCalibrationStatus();
                }, 400);
            } else if (next.loadedTemplateUrl === 'view/app/partials/lvwangshuju.html') {
                coreHelper.delayExecute(function () {
                    $scope.acController.filterDirtyPluggingStatus();
                }, 400);
                coreHelper.delayExecute(function () {
                    $scope.filterDirtyPluggingshuju();
                }, 400);
            } else if (next.loadedTemplateUrl === 'view/app/partials/general.html') {
                /*睡眠曲线补充处理*/
                if ($scope.appConfig.pageLoadState === 'out') {
                    coreHelper.delayExecute(function () {
                        $scope.acController.initSleepCurve();
                    }, 1);
                }
            } else if (next.loadedTemplateUrl === 'view/app/partials/sound.html') {
                if ($scope.appConfig.pageLoadState === 'in') {
                    coreHelper.delayExecute(function () {
                        $scope.newSoundInit();
//						$scope.soundInit();
                    }, 400);
                }
            } else if (next.loadedTemplateUrl === 'view/app/partials/safeInvade.html') {
                $scope.acController.requestIntrusionRemindStatus();
                $scope.acController.requestSafeInvadeStatus();
                if ($scope.appConfig.pageLoadState === 'in') {
                    coreHelper.delayExecute(function () {
                        $scope.securityFunction();
                        $scope.invadeMessage();
                    }, 800);
                }
            } else if (next.loadedTemplateUrl === 'view/app/partials/intelControl.html') {
                $scope.acController.requestIntelligentControlStatus();
                if ($scope.appConfig.pageLoadState === 'in') {
                    coreHelper.delayExecute(function () {
                        $scope.intelControl();
                        //					$scope.gestureRecognize();
                        $scope.recognizeOnOff();
                        $scope.recognizeDirection();
                        $scope.windBlow();
                        $scope.windClose();
                        $scope.energySaving();
                        $scope.windSpeedSet();
                    }, 800);
                }
//			} else if (next.loadedTemplateUrl === 'view/app/partials/gestureRecognize.html') {
//				$scope.acController.requestGestureControlStatus();
//				if ($scope.appConfig.pageLoadState === 'in') {
//					coreHelper.delayExecute(function() {
//						$scope.recognizeOnOff();
//						$scope.recognizeDirection();
//					}, 500);
//				}
            } else if (next.loadedTemplateUrl === 'view/app/partials/show.html') {
                if ($scope.appConfig.pageLoadState === 'in') {
                    coreHelper.delayExecute(function () {
                        $scope.newScreenDisplayControl();
                    }, 400);
                }
            } else if (next.loadedTemplateUrl === 'view/app/partials/currentMonthElect.html') {
                $scope.currentMonthElectShow();
                $scope.monthDataPosition = "62px";
            } else if (next.loadedTemplateUrl === 'view/app/partials/strongPrevent.html') {
                $scope.acController.dataManager.updateCalibrationQueryState(1);
                clearTimeout($scope.appRuntime.queryCalibrationDelay);
                $scope.initQueryStrongPreventState();
            } else if (next.loadedTemplateUrl === 'view/app/partials/filterAlter.html') {
                $scope.acController.dataManager.updateStrongPreventQueryState(1);
                clearTimeout($scope.appRuntime.queryStrongPreventDelay);
                $scope.initQueryCalibrationState();
            } else if (next.loadedTemplateUrl === 'view/app/partials/mechineInfo.html') {
                //解析家电条码
                $scope.barcodeAnalysis();
            } else if (next.loadedTemplateUrl === 'view/app/partials/ladderControl.html') {
                //查询阶梯降温状态
                $scope.acController.requestLadderControlStatus();
                if ($scope.appConfig.pageLoadState === 'in') {
                    coreHelper.delayExecute(function () {
                        $scope.ladderControl();
                    }, 500);
                }
            } else if (next.loadedTemplateUrl === 'view/app/partials/operateIntro.html') {
                $scope.isOverFlowAuto = true;
            } else if (next.loadedTemplateUrl === 'view/app/partials/addWristband.html') {
                $scope.wristhandItems = [];
                coreHelper.delayExecute(function () {
                    $scope.filterCheckAnimate2('addWristbandCircle');
                }, 500);
            } else if (next.loadedTemplateUrl === 'view/app/partials/myWristband.html') {
                $scope.acController.requestWristbandStatus();
                coreHelper.delayExecute(function () {
                    $scope.myWristControl();
                }, 1000);
                $scope.debugInteligentSleep();
            } else if (next.loadedTemplateUrl === 'view/app/partials/blueToothUpgrade.html') {
                $scope.acController.getBluetoothVersion();
            }
            else if (next.loadedTemplateUrl === 'view/app/partials/operateIntro.html') {
                $scope.isOverFlowAuto = true;
            }
            //语音音量进入界面查询
            else if (next.loadedTemplateUrl === 'view/app/partials/iqSound.html') {
                coreHelper.delayExecute(function () {
                    $scope.acController.showLoading();
                    $scope.acController.initVoiceStatus();
                    $scope.acController.initVolumeStatus();
                }, 400);

                coreHelper.delayExecute(function () {
                    $scope.yybb();
                }, 400);

                coreHelper.delayExecute(function () {
                    $scope.zdyl();
                }, 400);
            }
            //以色列进入界面查询
            else if (next.loadedTemplateUrl === 'view/app/partials/IsraelCustom.html') {
                $scope.getDeviceStatus();
                coreHelper.delayExecute(function () {
                    $scope.shabbatSwitch();
                }, 400);
                coreHelper.delayExecute(function () {
                    $scope.dustFullMarkStatus = $scope.deviceStatus.dustFullMarkStatus;
                    $scope.filterReplaceStatus = $scope.deviceStatus.filterReplaceStatus;
                }, 400);
            }
            //冷热感进入界面查询
            else if (next.loadedTemplateUrl === 'view/app/partials/iqComfort.html') {

                coreHelper.delayExecute(function () {
                    $scope.acController.requestInitColdeHotStatus();
                }, 400);
            }
            //yb301进入界面查询
            else if (next.loadedTemplateUrl === 'view/app/partials/capacityYb.html') {
                coreHelper.delayExecute(function () {
                    $scope.acController.initColdWindStatus();
                    $scope.flf();
                    $scope.weatherReportbb();
                    $scope.timingWeather();
                }, 400);
            }
            //语音模块版本更新说明
            else if (next.loadedTemplateUrl === 'view/app/partials/voiceToUpgrade.html') {
                if ($scope.yuyinUpdateBtn) {
                    coreHelper.delayExecute(function () {
                        $scope.acController.requestYuyinVersionContent();
                        $scope.updateyuyinVersionContent();
                    }, 400);
                }
            } else if (next.loadedTemplateUrl === 'view/app/partials/selfStudy.html') {
                //自学习
                $scope.acController.showLoading();
                $scope.querySelfLearningCurve();
                coreHelper.delayExecute(function () {
                    $scope.querySelfLearningStatus();
                }, 500);
                coreHelper.delayExecute(function () {
                    $scope.controlSelfLearningPermissionStatus();
                }, 500);
                coreHelper.delayExecute(function () {
                    $scope.querySelfLearningTimeSlot();
                }, 600);

                coreHelper.delayExecute(function () {
                    $scope.initJqueryPlugin();
                }, 1000);
            } else if (next.loadedTemplateUrl === 'view/app/partials/userActionAnalysis.html') {
                //自学习运行日志
                $scope.querySelfLearningValueList();

                coreHelper.delayExecute(function () {
                    var isWindSpeedValuesInit = false;
                    $(".touch-tabs").touchTabs({
                        eventParam: "click",
                        onChange: function (index, content) {
                            if (index == 1) {
                                try {
                                    setTimeout(function () {
                                        if ($scope.appRuntime.selfLearningDateObj && !isWindSpeedValuesInit) {
                                            isWindSpeedValuesInit = true;
                                            $scope.initUserActionAnalyse(true);
                                        }
                                    }, 0);
                                } catch (e) {
                                }
                            }
                        }
                    });
                }, 500);
            }

            /*锁屏控制*/
            if ((next.loadedTemplateUrl === 'view/app/partials/comfortSleep.html') || (next.loadedTemplateUrl === 'view/app/partials/main.html')
                || next.loadedTemplateUrl === 'view/app/partials/themes/disney/main.html') {
                coreHelper.lockScroll($scope, [$('body')], true);
            } else {
                coreHelper.lockScroll($scope, [$('body')], false);
            }
        });

        $(document).bind('refreshScreenCalibrationStatus', {}, function (event, message) {
            $scope.$apply(function () {
                clearTimeout($scope.interval);
                $scope.getScreenCalibrationProgress();
            });
        });

        $(document).bind('refreshYuyinUpdateStatus', {}, function (event, message) {
            $scope.$apply(function () {
                clearTimeout($scope.interval);
                $scope.yuyinVersionCurrentVersionNum = $scope.acController.dataManager.getYuyinVersion().yuyinVersionCurrentVersion;
                $scope.getYuyinUpdateProgress();
                $scope.yuyinDeviceStatus = $scope.acController.dataManager.getYuyinVersion().yuyinDeviceStatus;
                $scope.checkDeviceUpdateStatus();
            });
        });
        $(document).bind('refreshYuyinbanbensmStatus', {}, function (event, message) {
            $scope.$apply(function () {
                $scope.yuyinVersionContent = $scope.acController.dataManager.getYuyinVersionContent().yuyinsmContent;
            });
        });


        $(document).bind('refreshPreventColdViewStatus', {}, function (event, message) {
            $scope.$apply(function () {
                $scope.hasChildQuiltStatus = $scope.acController.dataManager.getPreventColdAPNSRemind();
                $scope.$broadcast('init::toggle::switch', {
                    'currentVal': $scope.hasChildQuiltStatus
                });

            });
        });
        //语音界面更新
        $(document).bind('refreshControlVoiceStatus', {}, function (event, message) {
            $scope.$apply(function () {
                if ($scope.acController.dataManager.getVoiceState().toneStatus >= 2) {
                    $scope.wakeUpToneFstChecked = true;
                    $scope.wakeUpToneSecChecked = false;
                } else {
                    $scope.wakeUpToneFstChecked = false;
                    $scope.wakeUpToneSecChecked = true;
                }

                if ($scope.acController.dataManager.getVoiceState().voiceTimeLength == 10) {
                    $scope.wakeUpTimeFstChecked = true;
                    $scope.wakeUpTimeSecChecked = false;
                    $scope.wakeUpTimeTrdChecked = false;
                    $scope.wakeUpTimeFourChecked = false;
                    $scope.wakeUpTimeFifthChecked = false;
                } else if ($scope.acController.dataManager.getVoiceState().voiceTimeLength == 15) {
                    $scope.wakeUpTimeFstChecked = false;
                    $scope.wakeUpTimeSecChecked = true;
                    $scope.wakeUpTimeTrdChecked = false;
                    $scope.wakeUpTimeFourChecked = false;
                    $scope.wakeUpTimeFifthChecked = false;
                } else if ($scope.acController.dataManager.getVoiceState().voiceTimeLength == 20) {
                    $scope.wakeUpTimeFstChecked = false;
                    $scope.wakeUpTimeSecChecked = false;
                    $scope.wakeUpTimeTrdChecked = true;
                    $scope.wakeUpTimeFourChecked = false;
                    $scope.wakeUpTimeFifthChecked = false;
                } else if ($scope.acController.dataManager.getVoiceState().voiceTimeLength == 25) {
                    $scope.wakeUpTimeFstChecked = false;
                    $scope.wakeUpTimeSecChecked = false;
                    $scope.wakeUpTimeTrdChecked = false;
                    $scope.wakeUpTimeFourChecked = true;
                    $scope.wakeUpTimeFifthChecked = false;
                } else if ($scope.acController.dataManager.getVoiceState().voiceTimeLength == 30) {
                    $scope.wakeUpTimeFstChecked = false;
                    $scope.wakeUpTimeSecChecked = false;
                    $scope.wakeUpTimeTrdChecked = false;
                    $scope.wakeUpTimeFourChecked = false;
                    $scope.wakeUpTimeFifthChecked = true;
                } else {
                    $scope.wakeUpTimeFstChecked = false;
                    $scope.wakeUpTimeSecChecked = true;
                    $scope.wakeUpTimeTrdChecked = false;
                    $scope.wakeUpTimeFourChecked = false;
                    $scope.wakeUpTimeFifthChecked = false;
                }

                $scope.isBroadcast = $scope.acController.dataManager.getVoiceState().voiceBroadcastStatus;
                if ($scope.isBroadcast == 3) {
                    $scope.isBroadcast = true;
                } else {
                    $scope.isBroadcast = false;
                }
                $scope.$broadcast('soundPlay::init::toggle::switch', {
                    'currentVal': $scope.isBroadcast
                });
                if ($scope.isBroadcast) {
                    $("#preventInvadeDiv1").css("display", "block");
                } else {
                    $("#preventInvadeDiv1").css("display", "none");
                }

                $(document).unbind('soundPlay::update::toggle::switch').bind('soundPlay::update::toggle::switch', {}, function (event, data) {
                    $scope.$apply(function () {
                        if (data.currentVal) {
                            $scope.acController.dataManager.getVoiceState().voiceBroadcastStatus = 3;
                            $("#preventInvadeDiv1").css("display", "block");
                        } else {
                            $scope.acController.dataManager.getVoiceState().voiceBroadcastStatus = 2;
                            $("#preventInvadeDiv1").css("display", "none");
                        }
                        $scope.acController.controlVoiceStatus();
                    });
                });
                $scope.isAtuoVolume = $scope.acController.dataManager.getVolumeState().volumeControlType;
//		alert("$scope.isAtuoVolume is"+$scope.isAtuoVolume);

                if ($scope.isAtuoVolume == 1) {
                    $scope.$broadcast('slider:control:for:soundValue:disable', {});
                    $scope.$broadcast('autoPlay::init::toggle::switch', {
                        'currentVal': true
                    });
                } else if ($scope.isAtuoVolume == 2) {
                    $scope.$broadcast('slider:control:for:soundValue:enable', {});
                    $scope.$broadcast('autoPlay::init::toggle::switch', {
                        'currentVal': false
                    });
                }
            });
        });
//		//新防直吹界面更新
//		$(document).bind('refreshWindBlowingStatus', {}, function(event, message) {
//		$scope.$apply(function() {
//
//		});
//		});
        //冷热感控制界面更新
        $(document).bind('refreshControlColdHotStatus', {}, function (event, message) {
            $scope.$apply(function () {

//			if($scope.deviceStatus.upDownProduceWindStatus==1){
//				$scope.acController.dataManager.getColdHotState().coldHotSwitch=false;
//
//			}
                if ($scope.acController.dataManager.getColdHotState().coldHotStall <= 30) {
                    $scope.lenreFstChecked = true;
                    $scope.lenreSecChecked = false;
                    $scope.lenreTrdChecked = false;
                } else if ($scope.acController.dataManager.getColdHotState().coldHotStall <= 60) {
                    $scope.lenreFstChecked = false;
                    $scope.lenreSecChecked = true;
                    $scope.lenreTrdChecked = false;
                } else if ($scope.acController.dataManager.getColdHotState().coldHotStall <= 90) {
                    $scope.lenreFstChecked = false;
                    $scope.lenreSecChecked = false;
                    $scope.lenreTrdChecked = true;
                }
            });
        });
        //过滤网脏堵检测传感器
        $(document).bind('refreshFilterDirtyPluggingStatus', {}, function (event, message) {
            if ($scope.acController.dataManager.getFilterDirtyPlugging().percentageReadings >= 0x4B) {
                $scope.currenLevel = "goodState";
                $scope.filterMaintenance.runTimeData.currentBgCircle = "./view/public/images/green-c.png";
            } else if ($scope.acController.dataManager.getFilterDirtyPlugging().percentageReadings >= 0x37 &&
                $scope.acController.dataManager.getFilterDirtyPlugging().percentageReadings <= 0x45) {
                $scope.currenLevel = "midState";
                $scope.filterMaintenance.runTimeData.currentBgCircle = "./view/public/images/yellow-c.png";
            } else if ($scope.acController.dataManager.getFilterDirtyPlugging().percentageReadings < 0x37) {
                $scope.currenLevel = "badState";
                $scope.filterMaintenance.runTimeData.currentBgCircle = "./view/public/images/red-c.png";
            }
        });
        //防冷风界面更新
        $(document).bind('refreshControlColdWindStatus', {}, function (event, message) {
            $scope.iscoldWind = $scope.acController.dataManager.getDeviceColdWindStatus().coldWind;
            if ($scope.iscoldWind == 1) {
                $scope.iscoldWind = true;
            } else {
                $scope.iscoldWind = false;
            }
            $scope.$broadcast('preventColdWind::init::toggle::switch', {
                'currentVal': $scope.iscoldWind
            });
            $(document).unbind('preventColdWind::update::toggle::switch').bind('preventColdWind::update::toggle::switch', {}, function (event, data) {
                $scope.$apply(function () {
                    if (data.currentVal) {
                        $scope.acController.dataManager.getDeviceColdWindStatus().coldWind = 1;
                    } else {
                        $scope.acController.dataManager.getDeviceColdWindStatus().coldWind = 0;
                    }
                    $scope.acController.controlColdWindStatus();
                });
            });
        });
        //天气播报界面更新
        $(document).bind('refreshControlWeatherReportStatus', {}, function (event, message) {
            $scope.isWeatherReport = $scope.acController.dataManager.getDeviceWeatherReportStatus().weatherReport;
            if ($scope.isWeatherReport == 1) {
                $scope.isWeatherReport = true;
            } else {
                $scope.isWeatherReport = false;
            }
            $scope.$broadcast('weatherReport::init::toggle::switch', {
                'currentVal': $scope.isWeatherReport
            });
            $(document).unbind('weatherReport::update::toggle::switch').bind('weatherReport::update::toggle::switch', {}, function (event, data) {
                $scope.$apply(function () {
                    if (data.currentVal) {
                        $scope.acController.dataManager.getDeviceWeatherReportStatus().weatherReport = 1;
                    } else {
                        $scope.acController.dataManager.getDeviceWeatherReportStatus().weatherReport = 0;
                    }
                    $scope.acController.controlWeatherReportStatus();
                });
            });
        });
        //安防控制界面更新
        $(document).bind('refreshIntrusionViewStatus', {}, function (event, message) {
            $scope.$apply(function () {
                $scope.isSecurityStatus = $scope.deviceStatus.securityStatus;
                $scope.safeInvadeisActive = $scope.deviceStatus.securityStatus;
                $scope.$broadcast('safePrevent::init::toggle::switch', {
                    'currentVal': $scope.isSecurityStatus
                });

                $scope.hasIntrusionStatus = $scope.acController.dataManager.getIntrusionRemind();
                $scope.$broadcast('invadeFunc::init::toggle::switch', {
                    'currentVal': $scope.hasIntrusionStatus
                });
            });
        });
        //YB100原生通知界面刷新
        $(document).unbind('receiveMessageFromApp').bind('receiveMessageFromApp', {}, function (event, messageBack) {
            if (messageBack.messageType = "BY100Back") {
                $scope.acController.requestExclusiveModeStatus();
                $scope.acController.requestRequestFamilyStatus();
                $scope.acController.requestSafeInvadeStatus();
            }
        });

        //智能控制界面更新
        $(document).bind('refreshIntelViewStatus', {}, function (event, message) {
            $scope.$apply(function () {
                //风吹人、风避人
                $scope.isWindBlow = $scope.deviceStatus.windDirectionStatus == 1 ? true : false;
                $scope.isWindClose = $scope.deviceStatus.windDirectionStatus == 2 ? true : false;
                $scope.isWindSpeed = $scope.deviceStatus.windSpeedStatus;
                $scope.familyNumber = $scope.deviceStatus.familyNumber;
                $scope.$apply();
                if ($scope.deviceStatus.windDirectionStatus != 0 || $scope.deviceStatus.windSpeedStatus) {
                    $scope.smartWindFeeling = true;
                } else {
                    $scope.smartWindFeeling = false;
                }
                $scope.$broadcast('yb200-intelManage-smartWindFeeling::init::toggle::switch', {
                    'currentVal': $scope.smartWindFeeling
                });
                $scope.$broadcast('yb200-gesture-exclusive-onOff::init::toggle::switch', {
                    'currentVal': $scope.deviceStatus.exclusiveOnOffStatus
                });
                //智能控制
                $scope.isIntelligentControl = $scope.deviceStatus.intelligentControlStatus;
                if ($scope.isIntelligentControl) {
                    $("#preventInvadeDiv").css("display", "block");
                    $("#intelControlSpace").css("display", "block");
                } else {
                    $("#preventInvadeDiv").css("display", "none");
                    $("#intelControlSpace").css("display", "none");
                }
                $scope.$broadcast('intelManage::init::toggle::switch', {
                    'currentVal': $scope.isIntelligentControl
                });
                $scope.$broadcast('windBlow::init::toggle::switch', {
                    'currentVal': $scope.isWindBlow
                });
                $scope.$broadcast('windClose::init::toggle::switch', {
                    'currentVal': $scope.isWindClose
                });
                //无人节能
                $scope.isenergySavingStatus = $scope.deviceStatus.energySavingStatus;
                $scope.$broadcast('energySaving::init::toggle::switch', {
                    'currentVal': $scope.isenergySavingStatus
                });
            });
        });
        //查询PM2.5
        $(document).bind('refreshPMStatus', {}, function (event, message) {
            $scope.$apply(function () {
                $scope.PMNumber = $scope.deviceStatus.PMNumber;
            });
        });
        //手势识别更新
        $(document).bind('refreshGestureRecognitionViewStatus', {}, function (event, message) {
            $scope.$apply(function () {
                $scope.isGestureRecognitionOnOff = $scope.deviceStatus.gestureRecognitionOnOffStatus;
                $scope.isGestureRecognitionDirection = $scope.deviceStatus.gestureRecognitionDirectionStatus;
                $scope.$broadcast('recognizeOnOff::init::toggle::switch', {
                    'currentVal': $scope.isGestureRecognitionOnOff
                });
                $scope.$broadcast('recognizeDirectionBlow::init::toggle::switch', {
                    'currentVal': $scope.isGestureRecognitionDirection
                });
            });
        });


        $(document).bind('refreshLadderControlStatus', {}, function (event, message) {
            $scope.$apply(function () {
                $scope.isLadderControl = $scope.acController.dataManager.getLadderControlStatus();
                if ($scope.isLadderControl) {
                    $scope.pmvisActive = false;
                    $scope.PMVSrc = $sce.trustAsResourceUrl($scope.staticData.pmvSrc.off);
                    //增加ECO、自然风、无风感互斥
                    $scope.EcoisActive = false;
                    $scope.ecoSrc = $sce.trustAsResourceUrl($scope.staticData.ecoSrc.off);
                    $scope.natureWindisActive = false;
                    $scope.natureWindSrc = $sce.trustAsResourceUrl($scope.staticData.natureWindSrc.off);
                    $scope.noWindFeelisActive = false;
                    $scope.noWindFeelSrc = $sce.trustAsResourceUrl($scope.staticData.noWindFeelSrc.off);
                    $scope.deviceStatus.sleepStatus = false;
                    $scope.keepWarmoisActive = false;
                    $scope.keepWarmSrc = $sce.trustAsResourceUrl($scope.staticData.keepWarmSrc.off);
                }
                try {
                    $scope.$broadcast('ladderControlOnOff::init::toggle::switch', {
                        'currentVal': $scope.isLadderControl
                    });
                } catch (e) {
                }
            });
        });
        //风避人
//		$(document).bind('refreshwindAvoidViewStatus', {}, function(event, message) {
//		if($scope.acController.dataManager.getDeviceWindAvoidStatus().windAvoid){
//	    $scope.acController.dataManager.getColdHotState().coldHotSwitch=0;
//		$scope.deviceStatus.coldHotSwitch=0;
//		$scope.coldHotSwitchActive = false;
//		$scope.deviceStatus.noWindFeel =  false;
//		$scope.upDownisActive = false;
//		$scope.leftRightisActive = false;
//		$scope.acController.dataManager.getDeviceSoftWindFeelingStatus().softWindFeel = false;
//      $scope.deviceStatus.softWindFeelSwitchStatus = false;
//	    $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().straightBlow = false;
//	    $scope.deviceStatus.straightBlowStatus = false;
//	    $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().windFeelingFA100 = false;
//	    $scope.deviceStatus.windFeelingFA100tSwitchStatus = false;
//	    	$scope.isWindBlow = false;
//		$scope.deviceStatus.isWindBlow = false;
//		$scope.natureWindisActive = false;
//		$scope.natureWindSrc = $sce.trustAsResourceUrl($scope.staticData.natureWindSrc.off);
//	    }
//			});

        $(document).bind('refreshElecView', {}, function (event, message) {
            $scope.$apply(function () {
                $scope.getElectricityData();
            });
        });

        $(document).bind('refreshMonthElecView', {}, function (event, message) {
            $scope.$apply(function () {
                $scope.getMonthElectricityData();
            });
        });

//		$(document).bind('refreshSleepView', {}, function(event, message) {
//			$scope.$apply(function() {
//				$scope.sleepData = $scope.acController.dataManager.getSleepMode();
//				var tmpSleepData = [];
//				var settingTemp = $scope.deviceStatus.temperatureInteger == "--" ? 26 : $scope.deviceStatus.temperatureInteger;
//				if (settingTemp < 17) {
//					tmpSleepData[0] = 17;
//				} else if (settingTemp > 30) {
//					tmpSleepData[0] = 30;
//				} else {
//					tmpSleepData[0] = settingTemp;
//				}
//				var i = 0;
//				for (var item in $scope.sleepData.sleepCurveCustom) {
//					bridge.logToIOS("sleepdata=" + $scope.sleepData.sleepCurveCustom[item]);
//					if (i < 8) {
//						if ($scope.sleepData.sleepCurveCustom[item] < 17) {
//							tmpSleepData.push(17);
//						} else if ($scope.sleepData.sleepCurveCustom[item] > 30) {
//							tmpSleepData.push(30);
//						} else {
//							tmpSleepData.push($scope.sleepData.sleepCurveCustom[item]);
//						}
//						i++;
//					}
//				}
//
//				if (($scope.sleepData.selectSleepType == 0 || $scope.sleepData.selectSleepType == 1) && ($scope.deviceStatus.sleepStatus == true)) {
//					$scope.ifChooseSleepCurve = true;
//					if ($scope.sleepData.selectSleepType == 0) {
//						$scope.sleepCurveCustomStatus = false;
//						$scope.sleepCurveRecommendStatus = true;
//						$scope.currentSleepRecommendStatus = true;
//						$scope.currentSleepCustomStatus = false;
//					} else {
//						$scope.sleepCurveCustomStatus = true;
//						$scope.sleepCurveRecommendStatus = false;
//						$scope.currentSleepRecommendStatus = false;
//						$scope.currentSleepCustomStatus = true;
//					}
//					$scope.currentSleepOperation = "取消睡眠";
//					$scope.comfortSleepisActive = true;
//					$scope.currentSleepStatus = true;
//				} else {
//					$scope.currentSleepRecommendStatus = false;
//					$scope.currentSleepCustomStatus = false;
//					$scope.ifChooseSleepCurve = false;
//					$scope.sleepCurveCustomStatus = false;
//					$scope.sleepCurveRecommendStatus = false;
//					$scope.currentSleepOperation = "执行睡眠";
//					$scope.comfortSleepisActive = false;
//					$scope.currentSleepStatus = false;
//				}
//
//				/*缓存本地数据*/
//				$scope.appCache.pullMenuData = tmpSleepData;
//
//				$scope.debugComfortSleep(tmpSleepData);
//			});
//		});

        $(document).bind('refreshSleepView', {}, function (event, message) {
            $scope.$apply(function () {
                updateSleepCurveStatus();
                $scope.debugComfortSleep();
                $scope.acController.hideLoading();
            });
        });
        $(document).bind('updateSleepCurveStatus', {}, function (event, message) {
            $scope.$apply(function () {
                updateSleepCurveStatus();
            });
        });

        function updateSleepCurveStatus() {
            $scope.sleepData = $scope.acController.dataManager.getSleepMode();

            if (($scope.sleepData.selectSleepType == 0 || $scope.sleepData.selectSleepType == 1) && ($scope.deviceStatus.sleepStatus == true)) {
                $scope.ifChooseSleepCurve = true;
                if ($scope.sleepData.selectSleepType == 0) {
                    $scope.sleepCurveCustomStatus = false;
                    $scope.sleepCurveRecommendStatus = true;
                    $scope.currentSleepRecommendStatus = true;
                    $scope.currentSleepCustomStatus = false;
                } else {
                    $scope.sleepCurveCustomStatus = true;
                    $scope.sleepCurveRecommendStatus = false;
                    $scope.currentSleepRecommendStatus = false;
                    $scope.currentSleepCustomStatus = true;
                }
                $scope.currentSleepOperation = "取消睡眠";
                $scope.comfortSleepisActive = true;
                $scope.currentSleepStatus = true;
            } else {
                $scope.currentSleepRecommendStatus = false;
                $scope.currentSleepCustomStatus = false;
                $scope.ifChooseSleepCurve = false;
                $scope.sleepCurveCustomStatus = false;
                $scope.sleepCurveRecommendStatus = false;
                $scope.currentSleepOperation = "执行睡眠";
                $scope.comfortSleepisActive = false;
                $scope.currentSleepStatus = false;
            }
        }

        //智能曲线更新
        $(document).bind('refreshSleepInteligentView', {}, function (event, message) {
            $scope.$apply(function () {
                $scope.sleepData = $scope.acController.dataManager.getSleepMode();
                if (($scope.sleepData.selectSleepType == 2) && ($scope.deviceStatus.sleepStatus == true)) {
                    $scope.sleepCurveInteligentStatus = true;
                    $scope.currentInteligentSleep = "取消睡眠";
                } else {
                    $scope.sleepCurveInteligentStatus = false;
                    $scope.currentInteligentSleep = "执行睡眠";
                }

                $scope.debugInteligentSleep();
            });
        });

        $(document).bind('refreshSleepStatus', {}, function (event, message) {
            $scope.$apply(function () {
                $scope.sleepData = $scope.acController.dataManager.getSleepMode();
                if (($scope.sleepData.selectSleepType == 0 || $scope.sleepData.selectSleepType == 1) && ($scope.deviceStatus.sleepStatus == true)) {
                    $scope.ifChooseSleepCurve = true;
                    if ($scope.sleepData.selectSleepType == 0) {
                        $scope.sleepCurveCustomStatus = false;
                        $scope.sleepCurveRecommendStatus = true;
                        $scope.currentSleepRecommendStatus = true;
                        $scope.currentSleepCustomStatus = false;
                    } else {
                        $scope.sleepCurveCustomStatus = true;
                        $scope.sleepCurveRecommendStatus = false;
                        $scope.currentSleepRecommendStatus = false;
                        $scope.currentSleepCustomStatus = true;
                    }
                    $scope.currentSleepOperation = "取消睡眠";
                    $scope.comfortSleepisActive = true;
                    $scope.currentSleepStatus = true;
                } else {
                    $scope.currentSleepRecommendStatus = false;
                    $scope.currentSleepCustomStatus = false;
                    $scope.currentSleepOperation = "执行睡眠";
                    $scope.comfortSleepisActive = false;
                    $scope.currentSleepStatus = false;
                }

                if (($scope.sleepData.selectSleepType == 2) && ($scope.deviceStatus.sleepStatus == true)) {
                    $scope.sleepCurveInteligentStatus = true;
                    $scope.currentInteligentSleep = "取消睡眠";
                } else {
                    $scope.sleepCurveInteligentStatus = false;
                    $scope.currentInteligentSleep = "执行睡眠";
                }
            });
        });

        $(document).bind('refreshIntelCheckView', {}, function (event, message) {
            $scope.$apply(function () {
                $scope.getLastIntelCheckInfo();
            });
        });

        $(document).bind('updatePreventColdViewMsg', {}, function (event, message) {
            $scope.$apply(function () {
                var preventColdStatus = $scope.acController.dataManager.getPreventColdParameterModify();
                var sensity = preventColdStatus.beColdSensitivity;
                if (sensity == 0) {
                    $scope.coldSensity = '高';
                } else if (sensity == 1) {
                    $scope.coldSensity = '中';
                } else if (sensity == 2) {
                    $scope.coldSensity = '低';
                }

                $scope.coldMin = preventColdStatus.beColdMin;
                $scope.coldMax = preventColdStatus.beColdMax;
                $scope.coldTemperateRise = preventColdStatus.beColdTemperateRise;
                $scope.heatMin = preventColdStatus.beHeatMin;
                $scope.heatMax = preventColdStatus.beHeatMax;
                $scope.heatTemperateRise = preventColdStatus.beHeatTemperateRise;
            });
        });

        /*弹动菜单事件通信*/
        $(document).bind('pullMenu:open', {}, function () {
            $scope.$apply(function () {
                $scope.component.pullMenuStatus = true;
//				$("#pullMenuDown").fadeIn();
//				$("#pullMenuUp").fadeOut();
                $("#arror_top").addClass('top_arrow_up');    
                $("#arror_top_disney").addClass('top_arrow_up_disney');
            });
            $scope.showBallPanelTooltips($scope.component.ballPanelToolTipsPos, false, true);
        });
        $(document).bind('pullMenu:close', {}, function () {
            $scope.$apply(function () {
                $scope.component.pullMenuStatus = false;
                //$("#pullMenuDown").fadeOut();
                //$("#pullMenuUp").fadeIn();
                var ua = navigator.userAgent.toLowerCase();
                if (/android/.test(ua)) {
                    $('canvas').show();
                }

                $("#arror_top").removeClass('top_arrow_up');
                $("#arror_top_disney").removeClass('top_arrow_up_disney');
            });
        });

        $(document).bind('pullMenu:before:close', {}, function () {
            $scope.$apply(function () {
                $scope.component.pullMenuStatus = false;
                $("#pullMenuDown").fadeOut();
                $("#pullMenuUp").fadeIn();
                var ua = navigator.userAgent.toLowerCase();
                if (/android/.test(ua)) {
                    $('canvas').hide();
                }
            });
        });

        /*控制球事件通信*/
        $(document).bind('ballPanel:data:update', {}, function (event, message) {
            /*绕过angularjs dirty check 的机制 有些许性能的损耗*/
            if ((message.num !== $scope.appRuntime.defaultPlaceholder) && (message.num !== 17.1) && (!$scope.appRuntime.isTouchOpenClose)) {
                //alert(message.num);
                setTimeout(function () {
                    $scope.$apply(function () {
                        if ($scope.appConfig.supportDecimal) {
                            $scope.appRuntime.currentConfigTemp = message.num.toFixed(1);
                        } else {
                            $scope.appRuntime.currentConfigTemp = message.num.toFixed(0);
                        }
                    });
                }, 0);
            }
        });
        $(document).bind('ballPanel:status:close', {}, function () {
            $scope.$apply(function () {
                $scope.timeoutPopUp('关机或送风模式下温度不可调节');
            });
        });
        $(document).bind('ballPanel:interact:touchend', {}, function () {
            $scope.$apply(function () {
                $scope.component.ballPanelTouch = true;
            });
        });
        $(document).bind('ballPanel:interact:reset', {}, function () {
            $scope.$apply(function () {
                $scope.component.ballPanelTouch = false;
            });
        });
        $(document).bind('ballPanel:interact:touching:on', {}, function () {
            $scope.$apply(function () {
                $scope.component.ballPanelTouching = true;
            });
        });
        $(document).bind('ballPanel:interact:touching:off', {}, function () {
            $scope.$apply(function () {
                $scope.component.ballPanelTouching = false;
            });
        });
        $(document).bind('ballPanel:interact:value:change:none', {}, function () {
            $scope.$apply(function () {
                $scope.component.ballPanelValueChange = false;
            });
        });
        $(document).bind('ballPanel:interact:value:change:has', {}, function () {
            $scope.$apply(function () {
                $scope.component.ballPanelValueChange = true;
            });
        });
        $(document).bind('ballPanel:tooltips:position', {}, function (event, data) {
            $scope.component.ballPanelToolTipsPos = data;
        });
        $(document).bind('ballPanel:data:request', function (event, data) {
            try {
                if (!$scope.appConfig.supportDecimal) {
                    $scope.acController.controlSetTemperature(data.currentVal, 0);
                } else {
                    $scope.acController.controlSetTemperature(parseInt(data.currentVal), data.currentVal - parseInt(data.currentVal));
                }
            } catch (e) {
            }
        });
        //滤网检测开启失败后处理
        $(document).bind('updateStrongPreventViewMessageAfterFail', function (event, data) {
            $scope.$apply(function () {
                $scope.curStrongPreventState = 0;
                $scope.strongPreventOperation = "运行防霉";
                $("#strongCanvas").css("display", "none");
                $("#animateSworm").css("display", "none");
                $("#strongPreventBg").addClass("preventBgImg").removeClass("preventBgImgShield");
                $scope.strongPreventState = "未知";
            });
        });

        $(document).bind('updateStrongPreventViewMessage', {}, function (event, message) {
            $scope.$apply(function () {
                $scope.strongPreventData = $scope.acController.dataManager.getStrongPrevent();
                if ($scope.strongPreventData.P_rate == 0 || $scope.strongPreventData.P_real == 0 || $scope.strongPreventData.maxThreshold == 0) {
                    $("#strongCanvas").css("display", "block");
                    $("#animateSworm").css("display", "block");

                    $scope.animateTime = $scope.strongPreventData.animateTime;
                    $scope.filterCheckAnimate('strongCanvas', $scope.animateTime);
                    $scope.strongPreventOperation = "停止防霉";
                    $scope.strongPreventState = "正在防霉，剩余" + $scope.strongPreventData.remainingTime;
                    $scope.curStrongPreventState = 1;

                    $scope.appRuntime.queryStrongPreventDelay = setTimeout(function () {
                        $scope.initQueryStrongPreventState();
                    }, $scope.strongPreventData.queryInterval);
                } else if ($scope.strongPreventData.P_rate == '-1' || $scope.strongPreventData.P_real == '-1' || $scope.strongPreventData.maxThreshold == '-1') {
                    clearTimeout($scope.appRuntime.queryStrongPreventDelay);
                    $scope.strongPreventOperation = "运行防霉";
                    $scope.strongPreventState = "防霉失败";
                    $scope.curStrongPreventState = 0;
                    $("#strongCanvas").css("display", "none");
                    $("#animateSworm").css("display", "none");
                } else {
                    $scope.curStrongPreventState = 0;
                    $scope.strongPreventOperation = "运行防霉";
                    if ($scope.strongPreventData.finishFlag == 1) {
                        $("#strongCanvas").css("display", "none");
                        $("#animateSworm").css("display", "none");
                        $("#strongPreventBg").addClass("preventBgImgShield").removeClass("preventBgImg");
                        $scope.strongPreventState = "防霉完成，请放心使用";
                        if ($scope.strongPreventData.level == 1) {
                            $scope.strongPreventDesc = "滤网积尘少，请放心使用。";
                        } else if ($scope.strongPreventData.level == 2) {
                            $scope.strongPreventDesc = "滤网积尘多，建议清洁。";
                        } else if ($scope.strongPreventData.level == 3) {
                            $scope.strongPreventDesc = "滤网积尘多，建议清洁。";
                        }
                    } else {
                        $("#strongCanvas").css("display", "none");
                        $("#animateSworm").css("display", "none");
                        $("#strongPreventBg").addClass("preventBgImg").removeClass("preventBgImgShield");
                        $scope.strongPreventState = "未知";
                    }
                }
            });
        });
        //基准校准开启失败后处理
        $(document).bind('updateCalibrationViewMessageAfterFail', function (event, data) {
            $scope.$apply(function () {
                $("#filterCanvas").css("display", "none");
                $scope.curCalibrationState = 0;
                $scope.calibrationOperation = "运行校准";
                $scope.calibrationState = "未知";
            });
        });

        $(document).bind('updateCalibrationViewMessage', {}, function (event, message) {
            $scope.$apply(function () {
                $scope.calibrationData = $scope.acController.dataManager.getCalibration();
                if ($scope.calibrationData.P_rate == 0 || $scope.calibrationData.P_real == 0 || $scope.calibrationData.maxThreshold == 0) {
                    $("#filterCanvas").css("display", "block");
                    $scope.calibrationAnimateTime = $scope.calibrationData.animateTime;
                    $scope.filterCheckAnimate('filterCanvas', $scope.calibrationAnimateTime);
                    $scope.calibrationOperation = "停止校准";
                    $scope.calibrationState = "正在校准，剩余" + $scope.calibrationData.remainingTime;
                    $scope.curCalibrationState = 1;

                    $scope.appRuntime.queryCalibrationDelay = setTimeout(function () {
                        $scope.initQueryCalibrationState();
                    }, $scope.calibrationData.queryInterval);
                } else if ($scope.calibrationData.P_rate == '-1' || $scope.calibrationData.P_real == '-1' || $scope.calibrationData.maxThreshold == '-1') {
                    clearTimeout($scope.appRuntime.queryCalibrationDelay);
                    $scope.calibrationOperation = "运行校准";
                    $scope.calibrationState = "校准失败";
                    $scope.curCalibrationState = 0;
                    $("#filterCanvas").css("display", "none");
                } else {
                    $("#filterCanvas").css("display", "none");
                    $scope.curCalibrationState = 0;
                    $scope.calibrationOperation = "运行校准";
                    if ($scope.calibrationData.finishFlag == 2) {
                        if ($scope.calibrationData.level == 1) {
                            $scope.calibrationState = "干净";
                        } else if ($scope.calibrationData.level == 2) {
                            $scope.calibrationState = "脏";
                        } else if ($scope.calibrationData.level == 3) {
                            $scope.calibrationState = "严重脏";
                        }
                    } else {
                        $scope.calibrationState = "未知";
                    }
                }
            });
        });

        $(document).bind('homePage:apperance:change', {}, function (event, data) {
            if (data.status) {
                $scope.changeHomePageAppearance($scope.appConfig.activeColor);
            } else {
                $scope.changeHomePageAppearance($scope.appConfig.deactiveColor);
            }
        });

        //更新自学习结果数据
        $(document).bind('refreshSelfLearningViewStatus', {}, function (event, message) {
            $scope.$apply(function () {
                $scope.selfLearning = $scope.acController.dataManager.getSelfLearning();
                $scope.selfLearningPermission = $scope.selfLearning.selfLearningStatus;
                $scope.selfLearningStatus = $scope.selfLearning.selfLearningStatus;
                $scope.selfLearningSlotStart = $scope.selfLearning.selfLearningSlotStart;
                $scope.selfLearningSlotStop = $scope.selfLearning.selfLearningSlotStop;
                if ($scope.selfLearningSlotStart < 10) {
                    $scope.appRuntime.startTime = "0" + $scope.selfLearningSlotStart + ":00";
                } else {
                    $scope.appRuntime.startTime = $scope.selfLearningSlotStart + ":00";
                }
                if ($scope.selfLearningSlotStop < 10) {
                    $scope.appRuntime.stopTime = "0" + $scope.selfLearningSlotStop + ":00";
                } else {
                    $scope.appRuntime.stopTime = $scope.selfLearningSlotStop + ":00";
                }
                if ($scope.selfLearningStatus) {
                    $scope.appRuntime.selfLearningBtn = "取消";
                } else {
                    $scope.appRuntime.selfLearningBtn = "应用曲线";
                }
                $scope.$broadcast('selfLearningPermission::init::toggle::switch', {
                    'currentVal': $scope.selfLearningStatus
                });
            });
        });

        $(document).bind('refreshSelfLearningViewCurve', {}, function (event, message) {
            $scope.$apply(function () {
                $scope.appRuntime.selfLearningBtnShow = true;
                $scope.selfLearning = $scope.acController.dataManager.getSelfLearning();
                $scope.selfLearningCurve = $scope.selfLearning.selfLearningCurve;
                $scope.selfLearningSlotStart = $scope.selfLearning.selfLearningSlotStart;
                $scope.selfLearningSlotStop = $scope.selfLearning.selfLearningSlotStop;
                var selfLearningCurveObjs = eval($scope.selfLearningCurve);
                $scope.appRuntime.selfLearningTemp = new Array();
                $scope.appRuntime.selfLearningWindspeed = new Array();
                for (var i = 0; i < selfLearningCurveObjs.length; i++) {
                    var curveObj = buildSelfLearningValuesOf24Hours(selfLearningCurveObjs[i].value);
                    $scope.appRuntime.selfLearningTemp.push(curveObj.temp);
                    $scope.appRuntime.selfLearningWindspeed.push(curveObj.windSpeed);
                    break;//新需求只用当天曲线
                }
                coreHelper.delayExecute(function () {
                    $scope.initSelfLearning();
                }, 300);
            });
        });

        //更新用户操作记录数据
        $(document).bind('refreshSelfLearningViewValueList', {}, function (event, message) {
            $scope.$apply(function () {//如果用假数据也注释掉这句
                bridge.logToIOS("initqueryValueReceiveList=" + (new Date()));
                $scope.selfLearning = $scope.acController.dataManager.getSelfLearning();
                $scope.selfLearningValueList = $scope.selfLearning.selfLearningValueList;

                // //临时假数据
                // var temp = [
                // 	{"day":10, "slotStartDateTime":"2016-10-31","value":[]},
                // 	{"day":9, "slotStartDateTime":"2016-10-31","value":[]},
                // 	{"day":8, "slotStartDateTime":"2016-10-31","value":[]},
                // 	{"day":7, "slotStartDateTime":"2016-10-31","value":[]},
                // 	{"day":6, "slotStartDateTime":"2016-10-31","value":[]},
                // 	{"day":5, "slotStartDateTime":"2016-10-31","value":[]},
                // 	{"day":4, "slotStartDateTime":"2016-10-31","value":[]},
                // 	{"day":3, "slotStartDateTime":"2016-10-31","value":[]},
                // 	{"day":2, "slotStartDateTime":"2016-10-31","value":[]},
                // 	{"day":1, "slotStartDateTime":"2016-10-31","value":[]},
                // 	];
                // 	for (var i=0;i< 10;i++){
                // 		var t = temp[i];
                // 		for (var j=0;j<25;j++){
                // 			t.value.push({"time":j,"tempValue":26, "windSpeedValue":40});
                // 		}
                // 	}
                // 	var selfLearningValueObjs = temp;
                var selfLearningValueObjs = eval($scope.selfLearningValueList);
                $scope.appRuntime.selfLearningValueTemp = new Array();
                $scope.appRuntime.selfLearningValueWindspeed = new Array();
                $scope.appRuntime.selfLearningLength = selfLearningValueObjs.length;

                var selfLearningDateObj = new Array();
                var startDateSetting;
                var endDateSetting;
                for (var i = 0; i < selfLearningValueObjs.length; i++) {
                    var curveObj = buildSelfLearningValuesOf24Hours(selfLearningValueObjs[i].value);

                    $scope.appRuntime.selfLearningValueTemp.push(curveObj.temp);
                    $scope.appRuntime.selfLearningValueWindspeed.push(curveObj.windSpeed);
                    //运行日期
                    var formattedDate = selfLearningValueObjs[i].slotStartDateTime.replace(/-/g, '.');
                    var shortDate = formattedDate.substr(5);
                    selfLearningDateObj.push(shortDate);
                    if (i == 0) {
                        endDateSetting = formattedDate;
                    }
                    if (i == selfLearningValueObjs.length - 1) {
                        startDateSetting = formattedDate;
                    }
                }
                $scope.appRuntime.selfLearningDateObj = selfLearningDateObj;
                $scope.appRuntime.selfLearningCurveDate = endDateSetting + " - " + startDateSetting;
                coreHelper.delayExecute(function () {
                    $scope.initUserActionAnalyse(false);
                }, 0);

            });
        });

        /**自学习曲线 根据当天原始数据构建24小时数据 */
        function buildSelfLearningValuesOf24Hours(originValues) {
            var current24hOfTemp = [],
                current24hOfWindSpeed = [];
            for (var i = 0; i < 25; i++) {
                var temp = 0, windSpeed = 0;
                var filterArray = $filter("filter")(originValues, function (value) {
                    return value.time == i;
                });
                if (filterArray.length > 0) {
                    var value = filterArray[0];
                    temp = value.tempValue;
                    windSpeed = value.windSpeedValue;
                }
                current24hOfTemp.push(temp);
                current24hOfWindSpeed.push(windSpeed);
            }
            return {
                temp: current24hOfTemp,
                windSpeed: current24hOfWindSpeed
            };
        }

        $scope.transformForNotification("refreshAddWristbandViewStatus", function () {
            //todo...
            $scope.wristhandItems = $scope.acController.dataManager.getWristbandStatus().wristbandList;
            // $scope.wristbandNameItems = $scope.acController.dataManager.getWristbandStatus().wristbandNameList;
            $("#searchWristbandBg").removeClass("addwristbandBgImg").addClass("searchwristbandBgImgFinish");
        });

        $scope.transdate = function () {
            var currentDate = new Date();
            var endTime = $scope.getNowFormatDate();
            currentDate.setFullYear(endTime.substring(0, 4));
            currentDate.setMonth(endTime.substring(5, 7) - 1);
            currentDate.setDate(endTime.substring(8, 10));
            currentDate.setHours("00");
            currentDate.setMinutes("00");
            currentDate.setSeconds("00");
            return Date.parse(currentDate) / 1000;
        }

        $scope.getNowFormatDate = function () {
            var date = new Date();
            var seperator1 = "-";
            var seperator2 = ":";
            var month = date.getMonth() + 1;
            var strDate = date.getDate();
            if (month >= 1 && month <= 9) {
                month = "0" + month;
            }
            if (strDate >= 0 && strDate <= 9) {
                strDate = "0" + strDate;
            }
            var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate + " " + date.getHours() + seperator2 + date.getMinutes() + seperator2 + date.getSeconds();
            return currentdate;
        }

        //我的手环界面更新
        $(document).bind('refreshMyWristbandViewStatus', {}, function (event, message) {
            $scope.$apply(function () {
                $scope.isAutoOnStatus = $scope.deviceStatus.autoOnStatus;
                $scope.$broadcast('autoOn::init::toggle::switch', {
                    'currentVal': $scope.isAutoOnStatus
                });

                $scope.isAutoOffStatus = $scope.deviceStatus.autoOffStatus;
                $scope.$broadcast('autoOff::init::toggle::switch', {
                    'currentVal': $scope.isAutoOffStatus
                });
            });
        });


        $scope.transformForNotification("refreshDelWristbandSuccess", function () {
            //todo...
            // $scope.wristhandItems = $scope.acController.dataManager.getWristbandStatus().wristbandList;

            $scope.redirectPage('setting', 'out');
        });

        //删除手环后界面更新
        // $(document).bind('refreshDelWristbandSuccess', {}, function(event, message) {
        // 	// alert("aaaa");
        // 	$scope.redirectPage('setting','out');
        // });

        //进入添加手环界面
        $(document).bind('refreshRedirectAddWristbandView', {}, function (event, message) {
            $scope.redirectPage('wristband', 'in');
        });

        //进入我的手环界面
        $(document).bind('redirectMyWristbandView', {}, function (event, message) {
            $scope.redirectPage('my-wristband', 'in');
        });


        //进入我的手环界面
        $(document).bind('refreshMyWristbandView', {}, function (event, message) {
//			$scope.redirectPage('my-wristband','in');
            var wristbandObj = $scope.acController.dataManager.getWristbandStatus();
            $scope.wristbandDate = wristbandObj.wristbandDate;
            $scope.wristbandConsumption = wristbandObj.wristbandConsumption;
            $scope.wristbandSteps = wristbandObj.wristbandSteps;
            $scope.wristbandWalkTime = wristbandObj.wristbandWalkTime;
            $scope.wristbandRunDistance = wristbandObj.wristbandRunDistance;
            $scope.wristbandDayDistance = wristbandObj.wristbandDayDistance;
            $scope.$apply();
        });

        //更新蓝牙模块模式
        $scope.transformForNotification("refreshBluetoothMode", function () {
            var deviceBluetoothStatus = $scope.acController.dataManager.getDeviceBluetoothStatus();

            if (deviceBluetoothStatus.bluetoothNewestVersionProgress == 2 && ($scope.bluetoothCurrentVersionNum == $scope.bluetoothNewestVersionNum)) {
                $scope.updatedBluetooth = true;						//升级完成
                $scope.bluetoothMode2 = false;		//当前主机模式
                $scope.bluetoothMode1 = false;		//当前从机模式
                $scope.MACItems = [];
                $scope.MACItemsStatus = [];
            } else if (deviceBluetoothStatus.bluetoothNewestVersionProgress == 0 && ($scope.bluetoothCurrentVersionNum == $scope.bluetoothNewestVersionNum)) {
                $scope.newBluetoothUpdateBtn = true;		//已最新提示
                $scope.updatedBluetooth = false;						//升级完成
                $scope.bluetoothMode2 = false;		//当前主机模式
                $scope.bluetoothMode1 = false;		//当前从机模式
                $scope.MACItems = [];
                $scope.MACItemsStatus = [];
            } else {
                $scope.updatedBluetooth = false;						//升级完成
                if (deviceBluetoothStatus.currentBluetoothMode == "1") {
                    $scope.bluetoothMode2 = false;		//当前主机模式
                    $scope.bluetoothMode1 = true;		//当前从机模式
                } else {
                    $scope.bluetoothMode2 = true;		//当前主机模式
                    $scope.bluetoothMode1 = false;		//当前从机模式
                    $scope.MACItems = [];
                    $scope.MACItemsStatus = [];
                }
            }

        });


        //蓝牙界面信息更新
        $scope.transformForNotification("refreshUpgradeProgress", function () {
            var deviceBluetoothStatus = $scope.acController.dataManager.getDeviceBluetoothStatus();
            var bluetoothCurrentVersion = deviceBluetoothStatus.currentBluetoothSoftVersion;
            $scope.bluetoothCurrentVersionNum = bluetoothCurrentVersion.join('.').split("").reverse().join("");
            $scope.bluetoothNewestVersionProgress = deviceBluetoothStatus.bluetoothNewestVersionProgress;

            var SNStr = bridge.getCurrentDevSN();
            if ($scope.bluetoothCurrentVersionNum == $scope.bluetoothNewestVersionNum) {
                $scope.ifBluetoothNew = true;
                $scope.bluetoothUpdateBtn = false;
                $scope.newBluetoothUpdateBtn = true;
                $scope.updatedBluetooth = false;
                localStorage.setItem("ifClickBluetoothUpdate" + SNStr, false);
                $scope.MACItems = [];
                $scope.MACItemsStatus = [];
                $scope.bluetoothMode2 = false;		//当前主机模式
                $scope.bluetoothMode1 = false;		//当前从机模式
            } else {
                $scope.ifBluetoothNew = false;
                $scope.currentBluetoothMode = deviceBluetoothStatus.currentBluetoothMode;
                switch ($scope.bluetoothNewestVersionProgress) {
                    case -1: {
                        localStorage.setItem("ifClickBluetoothUpdate" + SNStr, false);
                        $scope.updateProgressError = false;			//升级错误
                        $scope.updateBluetoothProgressAnimate = false;		//升级动画
                        $scope.updatedBluetooth = false;						//升级完成
                        $scope.bluetoothUpdateBtn = true;			//升级按钮
                        $scope.newBluetoothUpdateBtn = false;		//已最新提示
                        $scope.isUpdatingBluetooth = false;					//静态正在升级

                        $scope.bluetoothMode2 = true;		//当前主机模式
                        $scope.bluetoothMode1 = false;		//当前从机模式

                        $scope.MACItemsStatus[$scope.currentUpgradeIndex] = "升级失败";
                    }
                        break;
                    case 0: {
                        localStorage.setItem("ifClickBluetoothUpdate" + SNStr, false);
                        $scope.updateProgressError = false;			//升级错误
                        $scope.updateBluetoothProgressAnimate = false;		//升级动画
                        $scope.updatedBluetooth = false;						//升级完成
                        $scope.bluetoothUpdateBtn = true;			//升级按钮
                        $scope.newBluetoothUpdateBtn = false;		//已最新提示
                        $scope.isUpdatingBluetooth = false;					//静态正在升级

                        $scope.bluetoothMode2 = true;		//当前主机模式
                        $scope.bluetoothMode1 = false;		//当前从机模式

                        $scope.MACItemsStatus[$scope.currentUpgradeIndex] = "升级";
                    }
                        break;
                    case 1: {
                        localStorage.setItem("ifClickBluetoothUpdate" + SNStr, true);
                        $scope.updateProgressError = false;			//升级错误
                        $scope.updateBluetoothProgressAnimate = true;		//升级动画
                        $scope.updatedBluetooth = false;						//升级完成
                        $scope.bluetoothUpdateBtn = false;			//升级按钮
                        $scope.newBluetoothUpdateBtn = false;		//已最新提示
                        $scope.isUpdatingBluetooth = true;					//静态正在升级
                        $scope.bluetoothUpgradeProgressValue = deviceBluetoothStatus.bluetoothUpgradeProgressValue;//升级进度值
                        $scope.updateUpgradeProgress($scope.bluetoothUpgradeProgressValue);

                        $scope.MACItemsStatus[$scope.currentUpgradeIndex] = "升级中";
                        $scope.bluetoothMode2 = false;		//当前主机模式
                        $scope.bluetoothMode1 = false;		//当前从机模式

                        $scope.queryBluetoothUpgradeDelay = setTimeout(function () {
                            $scope.acController.queryBluetoothUpgradeProgress();
                        }, $scope.queryProgressInterval);
                    }
                        break;
                    case 2: {
                        localStorage.setItem("ifClickBluetoothUpdate" + SNStr, false);
                        clearTimeout($scope.queryBluetoothUpgradeDelay);
                        $scope.updateProgressError = false;			//升级错误
                        $scope.updateBluetoothProgressAnimate = false;		//升级动画
                        $scope.updatedBluetooth = true;						//升级完成
                        $scope.bluetoothUpdateBtn = false;			//升级按钮
                        $scope.newBluetoothUpdateBtn = false;		//已最新提示
                        $scope.isUpdatingBluetooth = false;					//静态正在升级

                        $scope.bluetoothMode2 = false;		//当前主机模式
                        $scope.bluetoothMode1 = false;		//当前从机模式

                        $scope.MACItemsStatus[$scope.currentUpgradeIndex] = "升级成功";
                        $scope.MACItems = [];
                        $scope.MACItemsStatus = [];
                    }
                        break;
                }
            }
        });

        $scope.transformForNotification("refreshBluetoothMacView", function () {
            //todo...
            $scope.MACItems = $scope.acController.dataManager.getDeviceBluetoothStatus().bluetoothMacList;
            for (var i = 0; i < $scope.MACItems.length; i++) {
                $scope.MACItemsStatus[i] = "升级";
            }
            $scope.currentBluetoothUpgradeStatus = "刷新";
            $scope.currentBluetoothMode = "1";
            $scope.timeoutPopUp("蓝牙搜索完成!");
        });

    }
    $scope.transformForNotification = function (notice, callback) {
        $scope.$on(notice, function () {
            callback();
        });
        $(document).bind(notice, {}, function (event, message) {
            $scope.$broadcast(notice, {});
            $scope.$apply();
        });
    };

    /*变量监控*/
    $scope.watchVariable = function () {
        $scope.$watch('appRuntime.currentConfigTemp', function (oldValue, newValue) {
            if (oldValue !== newValue) {
                $scope.appRuntime.isTempChange = true;
//			$scope.acController.dataManager.getColdHotState().coldHotSwitch=0;
//			$scope.deviceStatus.coldHotSwitch=0;
//			$scope.coldHotSwitchActive = false;
            } else {
                $scope.appRuntime.isTempChange = false;
            }
        });

        $scope.$watch('deviceStatus.runningMode', function (oldValue, newValue) {
            if (oldValue !== newValue) {
                $scope.changesTemperatureActive = false;
                $scope.appRuntime.isModeChange = true;
                $scope.acController.dataManager.getColdHotState().coldHotSwitch = 0;
                $scope.deviceStatus.coldHotSwitch = false;
                $scope.coldHotSwitchActive = false;
                if ($scope.currentDeviceInfo.hasChangesTemperature) {
                    $scope.isWindBlow = false;
                    $scope.deviceStatus.isWindBlow = false;
                    $scope.deviceStatus.windDirectionStatus = 0;
                    $scope.acController.dataManager.getDeviceWindAvoidStatus().windAvoid = false;
                    $scope.deviceStatus.windAvoidStatus = false;
                }
                if ((oldValue == 4 ||
                        oldValue == 6 ||
                        oldValue == 7)
                    && (newValue == 4 ||
                        newValue == 6 ||
                        newValue == 7)
                ) {
                } else {
                    $scope.acController.dataManager.getDeviceWindBlowingStatus().windBlowing = false;
                    $scope.deviceStatus.windBlowingStatus = false;
                }

            } else {
                $scope.appRuntime.isModeChange = false;
            }
        });

        $scope.$watch('deviceStatus.deviceRunningStatus', function (oldValue, newValue) {
            if (oldValue !== newValue) {
                $scope.acController.dataManager.getColdHotState().coldHotSwitch = 0;
                $scope.deviceStatus.coldHotSwitch = 0;
                $scope.coldHotSwitchActive = false;

                $scope.appRuntime.isStatusChange = true;
            } else {
                $scope.appRuntime.isStatusChange = false;
            }

            if (oldValue !== newValue) {
                //	if ((!$scope.component.ballPanelTouching) && ($scope.appRuntime.isModeChange) && ($scope.appRuntime.isStatusChange)) {

                if (!$scope.appRuntime.isTouchOpenClose) {
                    $scope.updateControlView();
                }
                //	}
            }
        });

        $scope.$watch('openCloseisActive', function (oldValue, newValue) {
            if (oldValue !== newValue) {
                if ($scope.appRuntime.firstRunProg > 0) {
                    $scope.$broadcast('trigger::open::close::animation', {
                        tempReal: $scope.deviceStatus.indoorTempInteger,
                        tempConfig: $scope.appRuntime.currentConfigTemp,
                        status: oldValue
                    });
                }
                $scope.appRuntime.firstRunProg++;

                $scope.appRuntime.touchOpenCloseStatus = true;
            } else {
                $scope.appRuntime.touchOpenCloseStatus = false;
            }
        });

        $scope.$watch('deviceStatus.runningMode', function (oldValue, newValue) {
            if ((oldValue == 2) || (oldValue == 4)) {
                $scope.appConfig.isRunInteractChart = true;
            } else {
                $scope.appConfig.isRunInteractChart = false;
            }
        });

        //初始化球形控件tooltips
        $scope.$watch('component.ballPanelTouching', function (oldVal, newVal) {
            if (!newVal) {
                $scope.showBallPanelTooltips($scope.component.ballPanelToolTipsPos, true, false);
            } else {
                $scope.showBallPanelTooltips($scope.component.ballPanelToolTipsPos, false, false);
            }
        });

        $scope.$watch("deviceStatus.windSpeedValue", function (news, olds) {
            if ($scope.component.isChangeWindSpeed) {
                if (news !== olds) {
                    if (news > 100) {
                        $scope.$broadcast('slider:control:disable', {});
                        $scope.$broadcast('init::toggle::switch', {
                            'currentVal': true
                        });
                    } else {
                        $scope.$broadcast('slider:control:enable', {});
                        $scope.$broadcast('init::toggle::switch', {
                            'currentVal': false
                        });
                    }
                }
            }
        });

        $scope.$watch("deviceStatus.temperatureInteger", function (news, olds) {
            if (news !== olds) {
                if ((!$scope.component.ballPanelTouch) && (!$scope.component.ballPanelTouching) && ($scope.appRuntime.firstRunProg > 1)) {

                    $scope.$broadcast('update::ballPanel', {
                        tempReal: $scope.deviceStatus.indoorTempInteger,
                        tempConfig: $scope.appRuntime.currentConfigTemp,
                        mode: $scope.deviceStatus.runningMode,
                        status: $scope.openCloseisActive
                    });
                }
                $scope.appRuntime.firstRunProg++;
            }
        });

        $scope.$watch("deviceStatus.indoorTempInteger", function (news, olds) {
            if (news !== olds) {
                if ((!$scope.component.ballPanelTouch) && (!$scope.component.ballPanelTouching) && ($scope.appRuntime.firstRunProg > 1)) {

                    $scope.$broadcast('update::ballPanel', {
                        tempReal: $scope.deviceStatus.indoorTempInteger,
                        tempConfig: $scope.appRuntime.currentConfigTemp,
                        mode: $scope.deviceStatus.runningMode,
                        status: $scope.openCloseisActive
                    });
                }
                $scope.appRuntime.firstRunProg++;
            }
        });

        $scope.$watch("component.pullMenuStatus", function (news, olds) {
            if (news !== olds) {
                if (news) {
                    $scope.$broadcast('ballPanel:deactive');
                } else {
                    $scope.ballPanelActiveRule();
                }
            }
        });
    }


    $scope.ballPanelActiveRule = function () {
        if (!$scope.deviceStatus.deviceRunningStatus) {
//			$scope.$broadcast('ballPanel:deactive');
            $scope.runningModeColor = '#b3b3b3';
            $scope.runningModeColorDisney = '#b3b3b3';
        } else {
//			$scope.$broadcast('ballPanel:active');
            $scope.runningModeColor = '#0686FE';
            $scope.runningModeColorDisney = '#66C7FF';
        }
    }

    $scope.updateControlView = function () {
        if (!$scope.deviceStatus.deviceRunningStatus) {
            $scope.switchBallPanel(false, false);
        } else {
            if (($scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind) || ($scope.component.pullMenuStatus)) {
                $scope.switchBallPanel(false, true);
            } else {
                $scope.switchBallPanel(true, true);
            }
        }
    }
    $scope.updateyuyinVersionContent = function () {
        $scope.yuyinVersionContent = $scope.acController.dataManager.getYuyinVersionContent().yuyinsmContent;
//		alert(JSON.stringify($scope.acController.dataManager.getYuyinVersionContent()));
    }

    $scope.checkDeviceUpdateStatus = function () {
        coreHelper.delayExecute(function () {
            //alert("i am sure all is ok...");
            $scope.yuyinUpdateVersionNum = $scope.acController.dataManager.getYuyinVersion().yuyinUpdateVersion;
            $scope.yuyinVersionCurrentVersionNum = $scope.acController.dataManager.getYuyinVersion().yuyinVersionCurrentVersion;
            //alert($scope.householdNewestVersionNum +" "+$scope.householdCurrentVersionNum);
            if (($scope.yuyinUpdateVersionNum == "") ||
                ($scope.yuyinUpdateVersionNum == $scope.yuyinVersionCurrentVersionNum) ||
                ($scope.yuyinUpdateVersionNum == -1) || (($scope.yuyinDeviceStatus != 2) && ($scope.yuyinDeviceStatus != 4))) {
                $scope.ifNew = false;
                $scope.yuyinUpdateVersionNum = $scope.yuyinVersionCurrentVersionNum;
            } else {
                $scope.ifNew = true;
            }
            if (!$scope.ifNew) {
                $("#ifNew").hide();
            } else {
                $("#ifNew").show();
            }
            $scope.$apply();
        }, 1000);
    }

    /*路由跳转方案*/
    $scope.redirectPage = function (page, state) {
        //模型方法 路由导向
        if (page == "setting" && state == "out") {
            $scope.intelCheckShow = false;
            $scope.intelCheckStatus = false;
            $(".intelCheckBg").stop(false, false);
        }
        coreHelper.redirectPage($scope, page, state);
    };

    /*退出主程序*/
    $scope.quitApp = function () {
        try {
            $scope.acController.controlGoback();
        } catch (e) {
            console.log($scope._MSG_SYS_OUT_DEVICE);
        }
    }

    /*获得当前主机状态*/
    $scope.getDeviceStatus = function () {
        try {
            $scope.acController = new mdSmart.ACController();
            $scope.acController.requestDeviceStatus();         
            setTimeout(function () {
                $scope.acController.requestHumidityValue();
                $scope.acController.requestSelfCleaningValue();
                $scope.acController.requestInitColdeHotStatus();
                $scope.acController.requestWindSpeedStatus();
                $scope.acController.requestUpDownNoWindFeelStatus();
                $scope.acController.initColdWindStatus();
                $scope.acController.requestWindBlowingnewValue();
                $scope.acController.requestAvoidValue();
            }, 500);
        } catch (e) {
            console.log($scope._MSG_SYS_OUT_DEVICE);
        }
    }

    /*声音控制*/
    $scope.soundInit = function () {
        try {
            $scope.hasTone = $scope.acController.dataManager.getPromptTone();
            $scope.acController.dataManager.setPromptTone($scope.hasTone);
        } catch (e) {
        }
    }

    $scope.newSoundInit = function () {
        $scope.hasTone = $scope.acController.dataManager.getPromptTone();

        $(document).unbind('update::toggle::switch').bind('update::toggle::switch', {}, function (event, data) {
            //alert($scope.hasTone + "currentVal" + data.currentVal)
            $scope.$apply(function () {
                $scope.acController.dataManager.setPromptTone(data.currentVal);
            });
        });

        try {
            $scope.$broadcast('init::toggle::switch', {
                'currentVal': $scope.hasTone
            });
        } catch (e) {
        }

    }
//	$scope.soundControl = function() {
//		try {
//			$scope.hasTone = !$scope.hasTone;
//			$scope.acController.dataManager.setPromptTone($scope.hasTone);
//		} catch (e) {}
//	}

    //显示与亮度控制
//	$scope.screenDisplayControl = function() {
//		$scope.hasDisplayStatus = $scope.deviceStatus.screenDisplay;
//		try {
//			$scope.acController.controlSwitchScreenDisplay(!$scope.hasDisplayStatus);
//		} catch (e) {}
//	}

    $scope.newScreenDisplayControl = function () {
        $scope.hasDisplayStatus = $scope.deviceStatus.screenDisplay;

        $(document).unbind('screenDisplay::update::toggle::switch').bind('screenDisplay::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                $scope.acController.controlSwitchScreenDisplay(data.currentVal);
            });
        });

        try {
            $scope.$broadcast('screenDisplay::init::toggle::switch', {
                'currentVal': $scope.hasDisplayStatus
            });
        } catch (e) {
        }
    }

    // 显示条码信息
    $scope.barcodeAnalysis = function () {
        var deviceSN = bridge.getCurrentDevSN();
        var dataDeviceID = undefined;
        var deviceType = undefined;
        if (deviceSN != "") {
            if (deviceSN.length == '32') {
                dataDeviceID = deviceSN.substring(6, 28);
            } else if (deviceSN.length == '22') {
                dataDeviceID = deviceSN.substring(0, 22);
            } else {
                dataDeviceID = "";
            }
        } else {
            dataDeviceID = "";
        }

        // 编码版本
        var codeVersion = undefined;
        codeVersion = dataDeviceID.substring(0, 1);
        if (codeVersion == "D") {
            $scope.VERSION = "2011";
            $scope.barcodeAnalysisOld(dataDeviceID);
        } else if (codeVersion == "2") {
            $scope.VERSION = "2015";
            $scope.barcodeAnalysisNew(dataDeviceID);
        } else if (codeVersion == "3") {
            $scope.VERSION = "2017";
            $scope.barcodeAnalysisNew(dataDeviceID);
        } else {
            $scope.VERSION = "未知";
        }

        var productModel = undefined;
        productModel = dataDeviceID.substring(6, 11);
        // 产品型号
        $scope.productModel = productModel;
        // 家电条码
        $scope.productSN = dataDeviceID;
    }

    //旧条码解析
    $scope.barcodeAnalysisOld = function (dataDeviceID) {
        var productType = undefined;
        var productDate = undefined;
        var productPlace = undefined;
        var productMonth = undefined;
        var productBand = undefined;
        productDate = dataDeviceID.substring(11, 16);
        productPlace = dataDeviceID.substring(16, 17);
        productBand = dataDeviceID.substring(2, 3);
        // 产品品牌
        if (productBand == '0') {
            $scope.BAND = "OEM";
        } else if (productBand == '1') {
            $scope.BAND = "美的";
        } else if (productBand == '2') {
            $scope.BAND = "华凌";
        } else if (productBand == '3') {
            $scope.BAND = "小天鹅";
        } else if (productBand == '7') {
            $scope.BAND = "东芝";
        } else {
            $scope.BAND = "OEM";
        }

        // 生产日期
        if (productDate.substring(2, 3) == 'C') {
            productMonth = "12";
        } else if (productDate.substring(2, 3) == 'B') {
            productMonth = "11";
        } else if (productDate.substring(2, 3) == 'A') {
            productMonth = "10";
        } else {
            productMonth = "0" + productDate.substring(2, 3);
        }
        $scope.productDate = "20" + productDate.substring(0, 2) + "." + productMonth + "." + productDate.substring(3, 5);

        // 生产地点
        if (productPlace == '1') {
            $scope.productPlace = "顺德";
        } else if (productPlace == '2') {
            $scope.productPlace = "芜湖";
        } else if (productPlace == '3') {
            $scope.productPlace = "武汉";
        } else if (productPlace == '5') {
            $scope.productPlace = "重庆";
        } else if (productPlace == '7') {
            $scope.productPlace = "邯郸";
        } else if (productPlace == '8') {
            $scope.productPlace = "广州";
        } else if (productPlace == '9') {
            $scope.productPlace = "越南";
        } else {
            $scope.productPlace = "未知";
        }
    }

    //新条码解析
    $scope.barcodeAnalysisNew = function (dataDeviceID) {
        var productDate = undefined;
        var productPlace = undefined;
        var productMonth = undefined;
        productDate = dataDeviceID.substring(11, 15);
        productPlace = dataDeviceID.substring(15, 17);
        productBand = dataDeviceID.substring(2, 3);
        // 产品品牌
        if (productBand == '0') {
            $scope.BAND = "OEM";
        } else if (productBand == '1') {
            $scope.BAND = "美的";
        } else if (productBand == '2') {
            $scope.BAND = "华凌";
        } else if (productBand == '3') {
            $scope.BAND = "小天鹅";
        } else if (productBand == '7') {
            $scope.BAND = "东芝";
        } else if (productBand == '9') {
            $scope.BAND = "易酷";
        } else {
            $scope.BAND = "OEM";
        }

        // 生产日期
        if (productDate.substring(1, 2) == 'C') {
            productMonth = "12";
        } else if (productDate.substring(1, 2) == 'B') {
            productMonth = "11";
        } else if (productDate.substring(1, 2) == 'A') {
            productMonth = "10";
        } else {
            productMonth = "0" + productDate.substring(1, 2);
        }

        $scope.productDate = $scope.transformYear(productDate.substring(0, 1)) + "." + productMonth + "." + productDate.substring(2, 4);

        // 生产地点
        if (productPlace == '00') {
            $scope.productPlace = "越南";
        } else if (productPlace == '01') {
            $scope.productPlace = "顺德";
        } else if (productPlace == '02') {
            $scope.productPlace = "芜湖";
        } else if (productPlace == '03') {
            $scope.productPlace = "武汉";
        } else if (productPlace == '05') {
            $scope.productPlace = "重庆";
        } else if (productPlace == '06') {
            $scope.productPlace = "重庆";
        } else if (productPlace == '07') {
            $scope.productPlace = "邯郸";
        } else if (productPlace == '08') {
            $scope.productPlace = "广州";
        } else if (productPlace == '09') {
            $scope.productPlace = "合肥";
        } else {
            $scope.productPlace = "未知";
        }
    }

    //生产日期转换
    $scope.transformYear = function (productYear) {
        var transformYearValue = "";
        if (productYear == "5") {
            transformYearValue = "2015";
        } else if (productYear == "6") {
            transformYearValue = "2016";
        } else if (productYear == "7") {
            transformYearValue = "2017";
        } else if (productYear == "8") {
            transformYearValue = "2018";
        } else if (productYear == "9") {
            transformYearValue = "2019";
        } else if (productYear == "0") {
            transformYearValue = "2020";
        } else if (productYear == "1") {
            transformYearValue = "2021";
        } else if (productYear == "2") {
            transformYearValue = "2022";
        } else if (productYear == "3") {
            transformYearValue = "2023";
        } else if (productYear == "4") {
            transformYearValue = "2024";
        } else {
            transformYearValue = Number(productYear.charCodeAt()) - 65 + 2025;
        }
        return transformYearValue;
    }

    /* 根据最新界面，更新主界面*/
    $scope.updateMainView = function () {
        //去掉模式切变时背景色的渐变
//		try {
        $scope.initPMV();

        $scope.functionListProcess('deviceRunningStatus', 'openCloseisActive', 'openCloseSrc');

        $scope.functionListProcess('upDownProduceWindStatus', 'upDownisActive', 'upDownSwipeSrc');

        $scope.functionListProcess('upSwipeWindStatus', 'upisActive', 'upSwipeSrc');

        $scope.functionListProcess('downSwipeWindStatus', 'downisActive', 'downSwipeSrc');

        $scope.functionListProcess('leftRighProducetWindStatus', 'leftRightisActive', 'leftRightSwipeSrc');

        $scope.functionListProcess('swipeWindStatus', 'windisActive', 'swipeSrc');

        $scope.functionListProcess('ECOStatus', 'EcoisActive', 'ecoSrc');
        $scope.functionListProcess('keepWarmStatus', 'keepWarmoisActive', 'keepWarmSrc');
        $scope.functionListProcess('windBlowingStatus', 'windBlowingSwitchActive', 'windBlowingSwitchSrc');
        $scope.functionListProcess('sleepStatus', 'sleepisActive', 'sleepSrc');

        $scope.functionListProcess('timerCloseStatus', 'timerisActive', 'timerSrc');

        $scope.functionListProcess('timerOpenStatus', 'timerOpenisActive', 'timerOpenSrc');

        $scope.functionListProcess('noWindFeel', 'noWindFeelisActive', 'noWindFeelSrc');

        $scope.functionListProcess('readyColdOrHot', 'readyColdHotisActive', 'preColdSrc');

        $scope.functionListProcess('electricHeatStatus', 'electricHeatisActive', 'electricHeatSrc');

        $scope.functionListProcess('natureWindStatus', 'natureWindisActive', 'natureWindSrc');

        $scope.functionListProcess('purifyStatus', 'purifyisActive', 'purifySrc');

        $scope.functionListProcess('preventCool', 'childrenPreventColdisActive', 'childrenPreventColdSrc');

        $scope.functionListProcess('DryStatus', 'dryisActive', 'drySrc');

        $scope.functionListProcess('savingElectricStatus', 'savingElectricisActive', 'savingElectricSrc');

        $scope.functionListProcess('strongStatu', 'strongisActive', 'strongForceSrc');
        $scope.functionListProcess('comfortDryStatus', 'comfortDryisActive', 'comfortDrySrc');
        $scope.functionListProcess('manualDryStatus', 'manualDryisActive', 'manualDrySrc');
        $scope.functionListProcess('selfCleaningStatus', 'selfCleaningisActive', 'selfCleaningSrc');
        $scope.functionListProcess('coldHotSwitch', 'coldHotSwitchActive', 'coldHotSwitchSrc');
        $scope.functionListProcess('straightBlowStatus', 'straightBlowActive', 'straightBlowSrc');
        $scope.functionListProcess('softWindFeelSwitchStatus', 'softWindFeelSwitchActive', 'softWindFeelSwitchSrc');
        $scope.functionListProcess('windFeelingFA100tSwitchStatus', 'windFeelingFA100SwitchActive', 'windFeelingFA100SwitchSrc');

        if ($scope.currentDeviceInfo != undefined && $scope.currentDeviceInfo.hasPreventStraightLineWind) {
            $scope.functionListProcess('windSpeedStatus', 'preventStraightLineWindIsActive', 'preventStraightLineWindSrc');
        }
        $scope.functionListProcessFromStatus($scope.acController.dataManager.getDeviceColdWindStatus(), 'coldWind', 'childrenPreventWindisActive', 'childrenPreventWindSrc', $scope.openCloseisActive &&
            $scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool);
        //上下无风感，独立出来
        $scope.functionListProcess('upNoWindFeel', 'upNoWindFeelIsActive', 'upNoWindFeelSrc');//上无风感
        $scope.functionListProcess('downNoWindFeel', 'downNoWindFeelIsActive', 'downNoWindFeelSrc');//下无风感
        $scope.functionListProcessFromStatus($scope.deviceStatus, 'deviceRunningStatus', 'upDownNoWindFeelIsActive', 'upDownNoWindFeelSrc', ($scope.deviceStatus.upNoWindFeel || $scope.deviceStatus.downNoWindFeel));
        $scope.functionListProcessFromStatus($scope.deviceStatus, 'deviceRunningStatus', 'upDownNoWindFeelIsActive', 'upDownNoWindFeelYBSrc', ($scope.deviceStatus.upNoWindFeel || $scope.deviceStatus.downNoWindFeel));
//			 alert("UP:"+$scope.deviceStatus.upNoWindFeel+","+"DOWN:"+$scope.deviceStatus.downNoWindFeel+",UPDOWN:"+$scope.upDownNoWindFeelIsActive);
        $scope.functionListProcessFromStatus($scope.deviceStatus, 'deviceRunningStatus', 'changesTemperatureActive', 'changesTemperatureSrc', ($scope.deviceStatus.coldHotSwitch || $scope.deviceStatus.isWindBlow || $scope.deviceStatus.windAvoidStatus));
        $scope.functionListProcessFromStatus($scope.deviceStatus, 'deviceRunningStatus', 'windFeelFA100Active', 'windFeelFA100Src', ($scope.deviceStatus.straightBlowStatus || $scope.deviceStatus.softWindFeelSwitchStatus || $scope.deviceStatus.windFeelingFA100tSwitchStatus));
        $scope.initSetTimeIconControl();
//		} catch (e) {}
    }

    $scope.initPMV = function () {
        if ($scope.acController.dataManager.getCurrentDevice().deviceStatus.PMVMode == mdSmart.ACDataManager.ACPMVMode.PMVModeClose) {
            $scope.pmvisActive = false;
        } else {
            $scope.pmvisActive = true;
        }

        if ($scope.pmvisActive) {
            $scope.PMVSrc = $sce.trustAsResourceUrl($scope.staticData.pmvSrc.on);
        } else {
            $scope.PMVSrc = $sce.trustAsResourceUrl($scope.staticData.pmvSrc.off);
        }
    }

    /*获得外部资源*/
    $scope.getExtenalResource = function () {
        $(document).bind('obtainVideoUrl', function (event, data) {
            try {
                $scope.$apply(function () {
                    //url视频对象获取
                    $scope.videoUrlObj = $scope.acController.dataManager.getInstructionsUrls();
                    $scope.productInstructionUrl = $sce.trustAsResourceUrl($scope.videoUrlObj.ProductInstruction);
                    $scope.DailyUseUrl = $sce.trustAsResourceUrl($scope.videoUrlObj.DailyUse);
                    $scope.CleanMaintainUrl = $sce.trustAsResourceUrl($scope.videoUrlObj.CleanMaintain);
                    $scope.ContactUsUrl = $sce.trustAsResourceUrl($scope.videoUrlObj.ContactUs);
                    $scope.WifiControlUrl = $sce.trustAsResourceUrl($scope.videoUrlObj.WifiControl);
                    $scope.IntactTotalUrl = $sce.trustAsResourceUrl($scope.videoUrlObj.IntactTotal);
                });
            } catch (e) {
            }
        });
    }

    /*打开外部浏览器*/
    $scope.openExtenalWeb = function (page) {
        try {
            switch (page) {
                case 'midea-fan':
                    $scope.acController.requestOpenMideaFan();
                    break;
                case 'midea-store':
                    $scope.acController.requestOpenMideaStore();
                    break;
                case 'after-sale':
                    $scope.acController.requestOpenMideaAfterSale();
                    break;
            }
        } catch (e) {
        }
    }

    /*
	 * 主控制界面的控制方法
	 */
    /*关闭当前设备*/
    $scope.closeDevice = function () {

        $scope.appRuntime.isTouchOpenClose = true;
        $scope.appRuntime.touchOpenCloseStatus = true;
        try {
            if ($scope.deviceStatus.deviceRunningStatus) {
                $scope.acController.controlDeviceOnAndOff(false);
                $scope.acController.dataManager.getColdHotState().coldHotSwitch = false;
                $scope.acController.dataManager.getDeviceWindBlowingStatus().windBlowing = false;
                $scope.deviceStatus.windBlowingStatus = false;
                $scope.acController.dataManager.getDeviceCleaningStatus().selfCleaning = false;
                $scope.deviceStatus.selfCleaningStatus = false;
                $scope.deviceStatus.windSpeedStatus = false;
                $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().softWindFeel = false;
                $scope.deviceStatus.softWindFeelSwitchStatus = false;
                $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().straightBlow = false;
                $scope.deviceStatus.straightBlowStatus = false;
                $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().windFeelingFA100 = false;
                $scope.deviceStatus.windFeelingFA100tSwitchStatus = false;
                $scope.deviceStatus.windDirectionStatus = 0;
                $scope.changesTemperatureActive = false;
                $scope.isWindBlow = false;
                $scope.deviceStatus.isWindBlow = false;
                $scope.acController.dataManager.getDeviceWindAvoidStatus().windAvoid = false;
                $scope.deviceStatus.windAvoidStatus = false;
                processStatusAfterCloseDevice();
            } else {
                $scope.acController.controlDeviceOnAndOff(true);
            }
             	setTimeout(function(){
            if($scope.currentDeviceInfo.hasSafeInvade){         
            	$scope.acController.requestSafeInvadeStatus();	           	        	
            }
            },800);  
//          initColdWindStatus();
        } catch (e) {
        }

    }

    function processStatusAfterCloseDevice() {
        $scope.deviceStatus.coldHotSwitch = false;
        $scope.deviceStatus.windSpeedStatus = false;
        $scope.deviceStatus.upNoWindFeel = false;
        $scope.deviceStatus.downNoWindFeel = false;
    }

    /*切换空调模式*/
//	$scope.switchModel = function() {
//		try {
//
//			if (!$scope.deviceStatus.deviceRunningStatus) {
//				$scope.timeoutPopUp("关机下模式不可调节!");
//			} else {
//				$scope.appRuntime.currentModeIndex++;
//				//				$scope.appRuntime.currentModeIndex = $scope.appRuntime.currentModeIndex > 5 ? 1 : $scope.appRuntime.currentModeIndex;
//				if ($scope.appRuntime.currentModeIndex > 5) {
//					if ($scope.appRuntime.currentModeIndex >= 7) {
//						$scope.appRuntime.currentModeIndex = 2;
//					} else {
//						$scope.appRuntime.currentModeIndex = 1;
//					}
//				}
//				$scope.runningModeName = $scope.appRuntime.modeMap[$scope.appRuntime.currentModeIndex].status;
//
//				clearTimeout($scope.appRuntime.modeDelay);
//				$scope.appRuntime.modeDelay = setTimeout(function() {
//					$scope.acController.controlSwitchMode($scope.appRuntime.currentModeIndex);
//				}, 1000);
//
//				$scope.appRuntime.isTouchModeChange = true;
//				clearTimeout($scope.appRuntime.touchModeDelay);
//				$scope.appRuntime.touchModeDelay = setTimeout(function() {
//					$scope.appRuntime.isTouchModeChange = false;
//				}, 5000);
//
//			}
//		} catch (e) {}
//	}

    /*自学习控制*/
    $scope.switchSelfLearningTime = function () {
        $scope.closeModal('isSelfLearningTimeControl');
        $scope.appRuntime.startTime = $scope.appRuntime.scrollSelectorStart + ":00";
        $scope.appRuntime.stopTime = $scope.appRuntime.scrollSelectorStop + ":00";
        $scope.acController.controlSwitchSelfLearningTimeSlot($scope.appRuntime.scrollSelectorStart, $scope.appRuntime.scrollSelectorStop);
    }

    $scope.closeSelfLearning = function () {
        $scope.closeModal('isSelfLearningTimeControl');
    }

    $scope.openSelfLearning = function () {
        $scope.selfLearning = $scope.acController.dataManager.getSelfLearning();
        $scope.appRuntime.scrollSelectorStart = $scope.selfLearning.selfLearningSlotStart;
        $scope.appRuntime.scrollSelectorStop = $scope.selfLearning.selfLearningSlotStop;

        var timeDataSource = {
            left: [],
            right: []
        };
        for (var i = 0; i < 25; i++) {
            var d = {
                value: i,
                label: i + ':00'
            };
            timeDataSource.left.push(d);
            timeDataSource.right.push(d);
        }
        $scope.openModalExtende('isSelfLearningTimeControl', {data: timeDataSource}, {
            first: "selfStudyTimerStart",
            second: "selfStudyTimerEnd"
        }, function (event, data) {
            $scope.appRuntime.scrollSelectorStart = parseInt(data.index);
        }, function (event, data) {
            $scope.appRuntime.scrollSelectorStop = parseInt(data.index);
        });
    }

    /*模式控制*/
    $scope.switchModel = function (oldmodeValue, modeValue) {
        $scope.closeModal('isModeControl');
        if ($scope.deviceStatus.runningMode != modeValue) {
            $scope.acController.controlSwitchMode(modeValue);
            $scope.acController.dataManager.getColdHotState().coldHotSwitch = false;
            $scope.deviceStatus.coldHotSwitch = false;
            $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().softWindFeel = false;
            $scope.deviceStatus.softWindFeelSwitchStatus = false;
            $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().straightBlow = false;
            $scope.deviceStatus.straightBlowStatus = false;
            $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().windFeelingFA100 = false;
            $scope.deviceStatus.windFeelingFA100tSwitchStatus = false;

            if ((oldmodeValue == "抽湿运行" ||
                    oldmodeValue == "舒适抽湿" ||
                    oldmodeValue == "个性抽湿")
                && (modeValue == mdSmart.ACDataManager.ACRunMode.RunModeRemoveWet ||
                    modeValue == mdSmart.ACDataManager.ACRunMode.RunModeComfortDry ||
                    modeValue == mdSmart.ACDataManager.ACRunMode.RunModeManualDry)
            ) {
            } else {
                $scope.acController.dataManager.getDeviceWindBlowingStatus().windBlowing = false;
                $scope.deviceStatus.windBlowingStatus = false;
            }
            $scope.currentSleepRecommendStatus = false;
            $scope.currentSleepCustomStatus = false;
            $scope.ifChooseSleepCurve = false;
            $scope.sleepCurveCustomStatus = false;
            $scope.sleepCurveRecommendStatus = false;
            $scope.currentSleepOperation = "执行睡眠";
            $scope.comfortSleepisActive = false;
            $scope.currentSleepStatus = false;

            if (modeValue != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool) {
                //打开制冷模式，执行互斥
                $scope.upNoWindFeelIsActive =
                    $scope.downNoWindFeelIsActive =
                        $scope.deviceStatus.upNoWindFeel =
                            $scope.deviceStatus.downNoWindFeel = false;
                // $scope.childrenPreventWindisActive =
                // $scope.acController.dataManager.getDeviceColdWindStatus().coldWind =
                //$scope.deviceStatus.windSpeedStatus = false;
            } else {
//              initColdWindStatus();
            }
        }
    }

    $scope.closeModel = function () {
        $scope.closeModal('isModeControl');
    }

    $scope.openModel = function () {
        if (!$scope.deviceStatus.deviceRunningStatus) {
            $scope.timeoutPopUp("关机下模式不可调节!");
        } else {
            $scope.openModal('isModeControl', [], function (event, data) {
            });
        }
    };

    $scope.closeChangesTemperature = function () {
        $scope.closeModal('isChangesTemperatureControl');
    }

    $scope.openChangesTemperature = function () {
        $scope.openModal('isChangesTemperatureControl', [], function (event, data) {
        });
    };
    $scope.closeNoWindFeelModal = function () {
//		$scope.acController.controlNoWindFeelModalClose();
        $scope.closeModal('isNoWindFeelModal');
    }

    $scope.openNoWindFeelModal = function () {
        if (!$scope.deviceStatus.deviceRunningStatus) {
            $scope.timeoutPopUp("关机下风感不可调节!");
        } else {
            $scope.openModal('isNoWindFeelModal', [], function (event, data) {
            });
        }
    };

    /**
     * TODO 调用Controller里面的方法
     */
    $scope.getCurrentdevicetype = function () {
        try {
            $scope.currentDeviceInfo = $scope.acController.dataManager.getCurrentDevice().deviceInfo;
            //$scope.appConfig.supportDecimal = $scope.currentDeviceInfo.hasDot5Support;
            $scope.appConfig.supportDecimal = $scope.acController.dataManager.getCurrentDevice().deviceInfo.hasDot5Support;
        } catch (e) {
        }
    }

    $scope.openChangeWindSpeed = function () {
        /*无极风速调节*/

//		$scope.openModal('isChangeWindSpeed', [], function(event, data) {});
        if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool &&
            $scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat &&
            $scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind) {
            if ($scope.openCloseisActive) {
                $scope.timeoutPopUp("自动或抽湿模式下风速不可调节!");
            } else {
                $scope.timeoutPopUp("关机下风速不可调节!");
            }
        } else {
            $scope.currentDeviceInfo = $scope.acController.dataManager.getCurrentDevice().deviceInfo;
            if ($scope.currentDeviceInfo.hasNoPolar) {
                if ($scope.openCloseisActive) {
                    $scope.openModal('isChangeWindSpeed', [], function (event, data) {
                    });

                    $(document).unbind('update::toggle::switch').bind('update::toggle::switch', {}, function (event, data) {
                        $scope.$apply(function () {
                            $scope.component.toggleSwitchStatus = data.currentVal;
                            if ($scope.component.toggleSwitchStatus) {
                                $scope.deviceStatus.windSpeedValue = 101;
                                $scope.$broadcast('slider:control:disable', {});
                            } else {
                                $scope.deviceStatus.windSpeedValue = 100;
                                $scope.$broadcast('slider:control:enable', {});
                            }
                            $scope.acController.controlSetWindSpeedValue($scope.deviceStatus.windSpeedValue);
                            $scope.acController.dataManager.getColdHotState().coldHotSwitch = 0;
                            $scope.deviceStatus.coldHotSwitch = 0;
                        });
                    });

                    if ($scope.deviceStatus.windSpeedValue > 100) {
                        coreHelper.delayExecute(function () {
                            $scope.$broadcast('init::toggle::switch', {
                                'currentVal': true
                            });
                            $scope.$broadcast('slider:control:disable', {});
                        }, 100);
                    } else {
                        coreHelper.delayExecute(function () {
                            $scope.$broadcast('init::toggle::switch', {
                                'currentVal': false
                            });
                            $scope.$broadcast('slider:control:enable', {});
                        }, 100);
                    }

                } else {
                    $scope.timeoutPopUp("关机下风速不可调节!");
                }
            } else {
                if (!$scope.deviceStatus.deviceRunningStatus) {
                    $scope.timeoutPopUp("关机下风速不可调节!");
                } else {
                    $scope.isWindSpeedValueOpen = $scope.deviceStatus.windSpeedValue;
                    if ($scope.isWindSpeedValueOpen <= 20) {
                        $scope.acController.controlSetWindSpeedValue(40);
                    } else if ($scope.isWindSpeedValueOpen <= 40) {
                        $scope.acController.controlSetWindSpeedValue(60);
                    } else if ($scope.isWindSpeedValueOpen <= 60) {
                        $scope.acController.controlSetWindSpeedValue(80);
                    } else if ($scope.isWindSpeedValueOpen < 82) {
                        $scope.acController.controlSetWindSpeedValue(101);
                    } else {
                        $scope.acController.controlSetWindSpeedValue(20);
                    }
                }
            }
        }
    }

    $scope.closeChangeWindSpeed = function () {
        $scope.closeModal('isChangeWindSpeed');
    }

    $scope.switchChangeWindSpeed = function () {
        /*调节风速*/
        try {
            $(document).bind('slider:control:update', {}, function (event, data) {
                $scope.acController.controlSetWindSpeedValue(data.current);
            });
        } catch (e) {
        }
    }

    $scope.switchUpdownSwipeWind = function () {
        try {
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下上下摆风不可调节!");
            } else {
                $scope.isupDownProduceWindOpen = $scope.deviceStatus.upDownProduceWindStatus;
                $scope.acController.controlSwitchUpDownWind(!$scope.isupDownProduceWindOpen);
                $scope.acController.dataManager.getColdHotState().coldHotSwitch = 0;
                $scope.deviceStatus.coldHotSwitch = 0;
                $scope.acController.dataManager.getDeviceWindBlowingStatus().windBlowing = false;
                $scope.isWindClose = false;
                $scope.deviceStatus.windDirectionStatus = 0;
                $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().softWindFeel = false;
                $scope.deviceStatus.softWindFeelSwitchStatus = false;
                $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().straightBlow = false;
                $scope.deviceStatus.straightBlowStatus = false;
                $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().windFeelingFA100 = false;
                $scope.deviceStatus.windFeelingFA100tSwitchStatus = false;
                if ($scope.isupDownProduceWindOpen) {
                    $scope.deviceStatus.isWindBlow = false;
                    $scope.isWindBlow = false;
                    $scope.acController.dataManager.getDeviceWindAvoidStatus().windAvoid = false;
                    $scope.deviceStatus.windAvoidStatus = false;
                }
            }

        } catch (e) {
        }
    }

    $scope.switchUpSwipeWind = function () {
        try {
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下上摆风不可调节!");
            } else {
                $scope.isUpProduceWindOpen = $scope.deviceStatus.upSwipeWindStatus;
                $scope.acController.controlSwitchUpSwipeWind(!$scope.isUpProduceWindOpen);
                $scope.acController.dataManager.getDeviceWindBlowingStatus().windBlowing = false;
                $scope.deviceStatus.windBlowingStatus = false;
            }
        } catch (e) {
        }
    }

    $scope.switchDownSwipeWind = function () {
        try {
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下下摆风不可调节!");
            } else {
                $scope.isDownProduceWindOpen = $scope.deviceStatus.downSwipeWindStatus;
                $scope.acController.controlSwitchDownSwipeWind(!$scope.isDownProduceWindOpen);
                $scope.acController.dataManager.getDeviceWindBlowingStatus().windBlowing = false;
                $scope.deviceStatus.windBlowingStatus = false;
            }
        } catch (e) {
        }
    }

    $scope.switchLeftRightSwipeWind = function () {
        try {
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下左右摆风不可调节!");
            } else {
                $scope.isleftRighProducetWindOpen = $scope.deviceStatus.leftRighProducetWindStatus;
                $scope.acController.controlSwitchLeftRightWind(!$scope.isleftRighProducetWindOpen);
                $scope.acController.dataManager.getColdHotState().coldHotSwitch = 0;
                $scope.deviceStatus.coldHotSwitch = 0;
                $scope.isWindClose = false;
                $scope.deviceStatus.windDirectionStatus = 0;
                if ($scope.isleftRighProducetWindOpen) {
                    $scope.deviceStatus.isWindBlow = false;
                    $scope.isWindBlow = false;
                    $scope.acController.dataManager.getDeviceWindAvoidStatus().windAvoid = false;
                    $scope.deviceStatus.windAvoidStatus = false;
                }
            }
        } catch (e) {
        }
    }

    $scope.switchSwipeWind = function () {
        try {
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下摆风不可调节!");
            } else {
                $scope.isProduceWindOpen = $scope.deviceStatus.swipeWindStatus;
                $scope.acController.controlSwitchWind(!$scope.isProduceWindOpen);
            }
        } catch (e) {
        }
    }

    $scope.switchECO = function () {
        try {
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下ECO不可调节!");
            } else {
                if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool) {
                    $scope.timeoutPopUp("ECO只在制冷模式下有效!");
                } else {
                    $scope.isECOOpen = $scope.deviceStatus.ECOStatus;
                    $scope.acController.controlSwitchECO(!$scope.isECOOpen);
                }
            }
        } catch (e) {
        }
    }
    $scope.switchKeepWarm = function () {
        try {
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下舒省功能不可调节!");
            } else {
                if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool) {
                    $scope.timeoutPopUp("舒省功能只在制冷模式下有效!");
                } else {
                    $scope.isKeepWamOpen = $scope.deviceStatus.keepWarmStatus;
                    $scope.acController.controlKeepWarm(!$scope.isKeepWamOpen);
                }
            }
        } catch (e) {
        }
    }

    $scope.switchWindBlowing = function () {
        try {
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下防直吹功能不可调节!");
            } else {
                if (($scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat)
                    || $scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeAuto) {
                    $scope.timeoutPopUp("防直吹功能在自动模式或制热模式下无效!");
                } else {
                    $scope.iswindBlowing = $scope.acController.dataManager.getDeviceWindBlowingStatus().windBlowing;
                    $scope.acController.controlWindBlowingnew(!$scope.iswindBlowing);
                    if ($scope.deviceStatus.windBlowingStatus == 0) {
                        if ($scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool ||
                            $scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind
                        ) {
                            $scope.deviceStatus.windSpeedValue = 1;
                        }
                    }
                }
            }
        } catch (e) {
        }
    }

    $scope.switchStraightBlowForFA100 = function () {
        try {
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下防直吹功能不可调节!");
            } else {
                if (($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool)) {
                    $scope.timeoutPopUp("防直吹功能只在制冷下有效!");
                } else {
                    $scope.straightBlow = $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().straightBlow;
                    $scope.acController.controlNoWindFeelModalClose(!$scope.straightBlow);
                    if (!$scope.straightBlow) {
                        $scope.deviceStatus.windDirectionStatus = 0;
                        $scope.isWindBlow = false;
                        $scope.deviceStatus.isWindBlow = false;
                        $scope.acController.dataManager.getDeviceWindAvoidStatus().windAvoid = false;
                        $scope.deviceStatus.windAvoidStatus = false;
                        if (!$scope.windFeelFA100Active) {
                            $scope.deviceStatus.windSpeedValue = 102;
                        }
                    }
                }
            }
        } catch (e) {
        }
    }
    $scope.switchBreezeFeelsForFA100 = function () {
        try {
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下柔风感功能不可调节!");
            } else {
                if (($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool)) {
                    $scope.timeoutPopUp("柔风感功能只在制冷下有效!");
                } else {
                    $scope.softWindFeel = $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().softWindFeel;
                    $scope.acController.controlBreezeFeels(!$scope.softWindFeel);
                    if (!$scope.softWindFeel) {
                        $scope.isWindBlow = false;
                        $scope.deviceStatus.isWindBlow = false;
                        $scope.acController.dataManager.getDeviceWindAvoidStatus().windAvoid = false;
                        $scope.deviceStatus.windAvoidStatus = false;
                        $scope.deviceStatus.windDirectionStatus = 0;
                        if (!$scope.windFeelFA100Active) {
                            $scope.deviceStatus.windSpeedValue = 102;
                        }
                    }
                }
            }
        } catch (e) {
        }
    }
    $scope.switchWindFeelingForFA100 = function () {
        try {
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下无风感功能不可调节!");
            } else {
                if (($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool)) {
                    $scope.timeoutPopUp("无风感功能只在制冷下有效!");
                } else {
                    $scope.windFeelingFA100 = $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().windFeelingFA100;
                    $scope.acController.controlWindFeelingFA100(!$scope.windFeelingFA100);
                    if (!$scope.windFeelingFA100) {
                        $scope.isWindBlow = false;
                        $scope.deviceStatus.isWindBlow = false;
                        $scope.acController.dataManager.getDeviceWindAvoidStatus().windAvoid = false;
                        $scope.deviceStatus.windAvoidStatus = false;
                        if (!$scope.windFeelFA100Active) {
                            $scope.deviceStatus.windSpeedValue = 102;
                        }
                    }
                }
            }
        } catch (e) {
        }
    }
    /*冷热感*/
    $scope.switchColdHotSwitchValue = function () {
        try {
            if ($scope.openCloseisActive == false) {
                $scope.deviceStatus.runningMode = mdSmart.ACDataManager.ACRunMode.RunModeAuto
            }
            if ($scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeRemoveWet ||
                $scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind ||
                $scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeComfortDry ||
                $scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeManualDry) {
                $scope.timeoutPopUp("智能只在自动、制冷、制热模式下有效!");
            } else {
                $scope.iscoldHotSwitch = $scope.acController.dataManager.getColdHotState().coldHotSwitch;
                $scope.acController.controlColdHotStatus(!$scope.iscoldHotSwitch);
                if ($scope.iscoldHotSwitch == 0) {
                    $scope.deviceStatus.deviceRunningStatus = true;
                }
            }
        }
        catch (e) {
        }
    }
    /*冷热感*/
    $scope.switchColdHotSwitchValueForFA100 = function () {
        try {
            if ($scope.openCloseisActive == false) {
                $scope.deviceStatus.runningMode = mdSmart.ACDataManager.ACRunMode.RunModeAuto
            }
            if ($scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeRemoveWet ||
                $scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind ||
                $scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeComfortDry ||
                $scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeManualDry) {
                $scope.timeoutPopUp("知冷暖只在自动、制冷、制热模式下有效!");
            } else {
                $scope.iscoldHotSwitch = $scope.acController.dataManager.getColdHotState().coldHotSwitch;
                $scope.acController.controlColdHotStatusForFA100(!$scope.iscoldHotSwitch);
                $scope.isWindBlow = false;
                $scope.acController.dataManager.getDeviceWindAvoidStatus().windAvoid = false;
                $scope.deviceStatus.windAvoidStatus = false;
                $scope.deviceStatus.windDirectionStatus = 0;
                $scope.noWindFeelisActive = false;
                $scope.deviceStatus.noWindFeel = false;
                $scope.deviceStatus.upDownProduceWindStatus = 0;
                $scope.deviceStatus.leftRighProducetWindStatus = 0;
                $scope.upDownisActive = false;
                $scope.leftRightisActive = false;
                $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().softWindFeel = false;
                $scope.deviceStatus.softWindFeelSwitchStatus = false;
                $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().straightBlow = false;
                $scope.deviceStatus.straightBlowStatus = false;
                $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().windFeelingFA100 = false;
                $scope.deviceStatus.windFeelingFA100tSwitchStatus = false;
                if ($scope.iscoldHotSwitch == 0) {
                    $scope.deviceStatus.deviceRunningStatus = true;
                }
            }
        }
        catch (e) {
        }
    }

    $scope.switchSleep = function () {
        try {
            $scope.isSleepOpen = $scope.deviceStatus.sleepStatus;
            $scope.acController.controlSwitchSleep(!$scope.isSleepOpen);
        } catch (e) {
        }
    }

    /*定时关机控制*/
    $scope.setTimer = function () {
        try {
            $scope.acController.dataManager.getDeviceCleaningStatus().selfCleaning = false;
            $scope.deviceStatus.selfCleaningStatus = false;
            if ($scope.appRuntime.timerCurrentStatus) {
                $scope.closeModal('isScrollDateSelector');
                $scope.acController.controlSetTimerDeviceOnOff(true, $scope.appRuntime.timerMessage.currentHour, $scope.appRuntime.timerMessage.currentMin);
            } else {
                $scope.closeTimer();
            }
        } catch (e) {
        }
    }

    $scope.closeTimer = function () {
        try {
            $scope.closeModal('isScrollDateSelector');

            $scope.acController.controlSetTimerDeviceOnOff(false, 0, 0);
        } catch (e) {
        }
    };

    $scope.openTimerModal = function () {
        var scrollSelectorStartValue = 0;
        var setTime = 0;
        if ($scope.deviceStatus.deviceRunningStatus) {
            if ($scope.deviceStatus.timerCloseStatus) {
                setTime = $scope.deviceStatus.timerCloseTime;
            } else {
                setTime = -1;
            }
        } else {
            if ($scope.deviceStatus.timerOpenStatus) {
                setTime = $scope.deviceStatus.timerOpenTime;
            } else {
                setTime = -1;
            }
        }
        console.log("$scope.deviceStatus.timerOpenTime", $scope.deviceStatus.timerOpenTime);
        console.log("$scope.deviceStatus.timerCloseTime", $scope.deviceStatus.timerCloseTime);
        if (!$scope.currentDeviceInfo.hasTime1TO1) {
            if (0 < setTime && setTime <= 1440) {
                if (0 == (setTime % 30)) {
                    scrollSelectorStartValue = Math.floor(setTime / 60) * 2 + Math.floor((setTime % 60) / 30) - 1;
                } else {
                    scrollSelectorStartValue = Math.floor(setTime / 60) * 2 + Math.floor((setTime % 60) / 30);
                }
            } else {
                scrollSelectorStartValue = 0;
            }          
        } else {
            if (0 < setTime && setTime <= 1440) {
                //原始数据转换
                var time = parseInt(setTime / 60);
                var minute = setTime - time * 60;
                var minuteFormat = '0';

                //分钟处理
                if (time < 10) { //正常处理
                    if ((minute <= 30)&&(minute > 0)) {
                        minuteFormat = 30;
                    } else if (minute > 30) {
                        time = time + 1
                        minuteFormat = 0;
                    } else {
                    	   minuteFormat = 0;
                    }
                } else { //特殊处理
                    if (minute > 0) {
                        time = time + 1
                        //minuteFormat = 0;
                    } else {
                        //minuteFormat = 0;
                    }
                }
            
                //寻找滚轮索引
                var formatTime = time + ',' + minuteFormat;
                var colData = staticData.getTimerData().data.left;
                for (var i = 0; i < colData.length; i++) {
                    console.log("compare", formatTime, colData[i], colData[i].value)
                    if (formatTime == colData[i].value) {
                        scrollSelectorStartValue = i;
                        break;
                    }
                }
            } else {
                scrollSelectorStartValue = 0;
            }
            console.log("scrollSelectorStartValuehhhhhhhhh", setTime, scrollSelectorStartValue);  
        }
        
        $scope.appRuntime.scrollSelectorStart = scrollSelectorStartValue;
        $scope.openModal('isScrollDateSelector', staticData.getTimerData(), function (event, data, mod, pos, current) {
            $scope.appRuntime.timerCurrentStatus = current.status;
            $scope.preColdHeatControl();
            if (current.status) {
                var response = data.split(',');
                $scope.appRuntime.timerMessage = {
                    currentHour: response[0],
                    currentMin: response[1]
                };
                console.log("response[0].response[0]", response[0]);
                console.log("response[1].response[1]", response[1]);
            }
        });
    };

    /*PVM控制*/
    $scope.SwitchPMV = function () {
        try {
            if ($scope.appRuntime.pmvCurrentStatus) {
                $scope.closeModal('isScrollPmvSelector');
                $scope.isPMVModeOpen = $scope.deviceStatus.PMVMode;
                $scope.acController.controlSwitchPMV($scope.appRuntime.pmvMessage.currentValue);
            } else {
                $scope.closePmv();
            }
        } catch (e) {
        }
    }

    $scope.closePmv = function () {
        try {
            $scope.closeModal('isScrollPmvSelector');

            $scope.acController.controlSwitchPMV('-111');
        } catch (e) {
        }
    }

    $scope.openPmvModal = function () {
        if (!$scope.deviceStatus.deviceRunningStatus) {
            $scope.timeoutPopUp("PMV在关机状态下无效!");
        } else {
            if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool &&
                $scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat) {
                $scope.timeoutPopUp("PMV只在制冷，制热模式下有效!");
            } else {
                $scope.acController.dataManager.getColdHotState().coldHotSwitch = 0;
                $scope.deviceStatus.coldHotSwitch = 0;
                $scope.pmvisActive = $scope.acController.dataManager.getCurrentDevice().deviceStatus.PMVMode == mdSmart.ACDataManager.ACPMVMode.PMVModeClose ? false : true;
                $scope.pmvisActive = $scope.deviceStatus.PMVMode == mdSmart.ACDataManager.ACPMVMode.PMVModeClose ? false : true;
                $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().softWindFeel = false;
                $scope.deviceStatus.softWindFeelSwitchStatus = false;
                $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().straightBlow = false;
                $scope.deviceStatus.straightBlowStatus = false;
                $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().windFeelingFA100 = false;
                $scope.deviceStatus.windFeelingFA100tSwitchStatus = false;
                var scrollSelectorStartValue = 0;
                if ($scope.pmvisActive) {
                    scrollSelectorStartValue = $scope.deviceStatus.PMVMode * 2 + 6;
                } else {
                    scrollSelectorStartValue = 6;
                }
                $scope.appRuntime.scrollSelectorStart = scrollSelectorStartValue;

                $scope.openModal('isScrollPmvSelector', staticData.getPmvData(), function (event, data, mod, pos, current) {
                    $scope.appRuntime.pmvCurrentStatus = current.status;
                    if (current.status) {
                        $scope.appRuntime.pmvMessage = {
                            currentValue: data
                        };
                    }
                });
            }
        }
    }

    /*踢被子 探测敏感度控制*/
    $scope.SwitchCpcDetectionSensitivity = function () {
        $scope.closeModal('isCpcDetectionSensitivity');

        $scope.acController.dataManager.updateBeColdSensitivity($scope.appRuntime.sensitivityMessage.currentValue);
        $scope.acController.dataManager.updateBeHeatSensitivity($scope.appRuntime.sensitivityMessage.currentValue);
        $scope.acController.controlSetPreventColdParameter();
    }

    $scope.closeCpcDetectionSensitivity = function () {
        $scope.closeModal('isCpcDetectionSensitivity');
    }

    $scope.openCpcDetectionSensitivityModal = function () {
        var scrollSelectorStart = 0;
        var preventColdStatus = $scope.acController.dataManager.getPreventColdStatus();
        if (0 == preventColdStatus.beColdSensitivity) {
            scrollSelectorStart = 2;
        } else if (2 == preventColdStatus.beColdSensitivity) {
            scrollSelectorStart = 0;
        } else {
            scrollSelectorStart = 1;
        }
        $scope.appRuntime.scrollSelectorStart = scrollSelectorStart;

        $scope.openModal('isCpcDetectionSensitivity', staticData.getSensitivityData(), function (event, data) {
            $scope.appRuntime.sensitivityMessage = data;
            $scope.appRuntime.sensitivityMessage = {
                currentValue: data
            };
        });
    }

    /*踢被子制冷区间控制*/
    $scope.SwitchCpcColdInterval = function () {
        $scope.closeModal('isCpcColdInterval');

        $scope.acController.dataManager.updateBeColdMin($scope.appRuntime.clodTempIntervalMessage.start);
        $scope.acController.dataManager.updateBeColdMax($scope.appRuntime.clodTempIntervalMessage.end);
        $scope.acController.controlSetPreventColdParameter();
    }

    $scope.closeCpcColdInterval = function () {
        $scope.closeModal('isCpcColdInterval');
    }

    $scope.openCpcColdIntervalModal = function () {
        var scrollSelectorStart = 0;
        var scrollSelectorEnd = 0;
        var preventColdStatus = $scope.acController.dataManager.getPreventColdStatus();
        if (17 <= preventColdStatus.beColdMin && preventColdStatus.beColdMin <= 30) {
            scrollSelectorStart = preventColdStatus.beColdMin * 2 - 34;
        } else {
            scrollSelectorStart = 0;
        }

        if (17 <= preventColdStatus.beColdMax && preventColdStatus.beColdMax <= 30) {
            scrollSelectorEnd = preventColdStatus.beColdMax * 2 - 34;
        } else {
            scrollSelectorEnd = 0;
        }

        $scope.appRuntime.scrollSelectorStart = scrollSelectorStart;
        $scope.appRuntime.scrollSelectorEnd = scrollSelectorEnd;
        $scope.appRuntime.clodTempIntervalMessage = {
            start: '20',
            end: '20'
        };

        $scope.openModal('isCpcColdInterval', staticData.getCpcColdIntervalData(), function (event, data, mod, pos) {
            if ((data !== undefined) && (mod === 'mutiple') && (pos === 'left')) {
                $scope.appRuntime.clodTempIntervalMessage.start = data;
            }
            if ((data !== undefined) && (mod === 'mutiple') && (pos === 'right')) {
                $scope.appRuntime.clodTempIntervalMessage.end = data;
            }
        });
    }

    /*踢被子制热区间控制*/
    $scope.SwitchCpcHeatInterval = function () {
        $scope.closeModal('isCpcHeatInterval');

        $scope.acController.dataManager.updateBeHeatMin($scope.appRuntime.heatTempIntervalMessage.start);
        $scope.acController.dataManager.updatebeHeatMax($scope.appRuntime.heatTempIntervalMessage.end);
        $scope.acController.controlSetPreventColdParameter();
    }

    $scope.closeCpcHeatInterval = function () {
        $scope.closeModal('isCpcHeatInterval');
    }

    $scope.openCpcHeatIntervalModal = function () {
        var scrollSelectorStart = 0;
        var scrollSelectorEnd = 0;
        var preventColdStatus = $scope.acController.dataManager.getPreventColdStatus();
        if (17 <= preventColdStatus.beHeatMin && preventColdStatus.beHeatMin <= 30) {
            scrollSelectorStart = preventColdStatus.beHeatMin * 2 - 34;
        } else {
            scrollSelectorStart = 0;
        }
        if (17 <= preventColdStatus.beHeatMax && preventColdStatus.beHeatMax <= 30) {
            scrollSelectorEnd = preventColdStatus.beHeatMax * 2 - 34;
        } else {
            scrollSelectorEnd = 0;
        }
        $scope.appRuntime.scrollSelectorStart = scrollSelectorStart;
        $scope.appRuntime.scrollSelectorEnd = scrollSelectorEnd;

        $scope.appRuntime.heatTempIntervalMessage = {
            start: '20',
            end: '20'
        };

        $scope.openModal('isCpcHeatInterval', staticData.getCpcHeatIntervalData(), function (event, data, mod, pos) {
            if ((data !== undefined) && (mod === 'mutiple') && (pos === 'left')) {
                $scope.appRuntime.heatTempIntervalMessage.start = data;
            }
            if ((data !== undefined) && (mod === 'mutiple') && (pos === 'right')) {
                $scope.appRuntime.heatTempIntervalMessage.end = data;
            }
            /*if ($scope.appRuntime.heatTempIntervalMessage.start > $scope.appRuntime.heatTempIntervalMessage.end) {
				$scope.$broadcast('reachContraint::scrollSelector', {
					'adapteIndex': $scope.appRuntime.heatTempIntervalMessage.endIndex
				});
			}*/
        });
    }

    /*踢被子 制冷上升温度控制*/
    $scope.SwitchCpcColdTemperateRise = function () {
        $scope.closeModal('isCpcColdTemperateRise');

        $scope.acController.dataManager.updateBeColdTemperateRise($scope.appRuntime.coldTemperateRiseMessage.currentValue);
        $scope.acController.controlSetPreventColdParameter();
    }

    $scope.closeCpcColdTemperateRise = function () {
        $scope.closeModal('isCpcColdTemperateRise');
    }

    $scope.openCpcColdTemperateRiseModal = function () {
        var scrollSelectorStart = 0;
        var preventColdStatus = $scope.acController.dataManager.getPreventColdStatus();
        if (0 <= preventColdStatus.beColdTemperateRise && preventColdStatus.beColdTemperateRise <= 6) {
            scrollSelectorStart = preventColdStatus.beColdTemperateRise * 2;
        } else {
            scrollSelectorStart = 0;
        }

        $scope.appRuntime.scrollSelectorStart = scrollSelectorStart;

        $scope.openModal('isCpcColdTemperateRise', staticData.getCpcColdTemperateRiseData(), function (event, data) {
            $scope.appRuntime.coldTemperateRiseMessage = {
                currentValue: data
            };
        });
    }

    /*踢被子 制热上升温度控制*/
    $scope.SwitchCpcHeatTemperateRise = function () {
        $scope.closeModal('isCpcHeatTemperateRise');

        $scope.acController.dataManager.updateBeHeatTemperateRise($scope.appRuntime.heatTemperateRiseMessage.currentValue);
        $scope.acController.controlSetPreventColdParameter();
    }

    $scope.closeCpcHeatTemperateRise = function () {
        $scope.closeModal('isCpcHeatTemperateRise');
    }

    $scope.openCpcHeatTemperateRiseModal = function () {
        var scrollSelectorStart = 0;
        var preventColdStatus = $scope.acController.dataManager.getPreventColdStatus();
        if (0 <= preventColdStatus.beHeatTemperateRise && preventColdStatus.beHeatTemperateRise <= 6) {
            scrollSelectorStart = preventColdStatus.beHeatTemperateRise * 2;
        } else {
            scrollSelectorStart = 0;
        }
        $scope.appRuntime.scrollSelectorStart = scrollSelectorStart;
        $scope.openModal('isCpcHeatTemperateRise', staticData.getCpcHeatTemperateRiseData(), function (event, data) {
            $scope.appRuntime.heatTemperateRiseMessage = data;
            $scope.appRuntime.heatTemperateRiseMessage = {
                currentValue: data
            };
        });
    }

    $scope.switchPreColdHeat = function () {
        try {
            if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool &&
                $scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat) {
                $scope.timeoutPopUp("预冷预热只在制冷或制热模式下有效!");
            } else {
                $scope.isPreColdHeatOpen = localStorage.getItem("ACDeviceReadyColdOrHot") == 1 ? true : false;
                $scope.acController.controlSwitchPreColdHeat(!$scope.isPreColdHeatOpen);
            }
        } catch (e) {
        }
    }

    $scope.switchNoWindFeel = function () {
        try {
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下无风感不可调节!");
            } else {
                if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool) {
                    $scope.timeoutPopUp("无风感只在制冷模式下有效!");
                } else {
                    $scope.isNoWindFeel = $scope.deviceStatus.noWindFeel;
                    $scope.acController.controlSwitchNoWindFeel(!$scope.isNoWindFeel);
                    $scope.acController.dataManager.getDeviceWindBlowingStatus().windBlowing = false;
                    $scope.deviceStatus.windBlowingStatus = false;
                    $scope.acController.dataManager.getColdHotState().coldHotSwitch = 0;
                    $scope.deviceStatus.coldHotSwitch = 0;
                    $scope.coldHotSwitchActive = false;
                    $scope.isWindBlow = false;
                    $scope.acController.dataManager.getDeviceWindAvoidStatus().windAvoid = false;
                    $scope.deviceStatus.windAvoidStatus = false;
                    $scope.deviceStatus.windDirectionStatus = 0;
                }
            }
        } catch (e) {
        }
    }
    //自清洁
    $scope.switchSelfCleaning = function () {
        try {
            $scope.isselfCleaning = $scope.acController.dataManager.getDeviceCleaningStatus().selfCleaning;
            $scope.acController.controlSelfCleaning(!$scope.isselfCleaning);
            if ($scope.acController.dataManager.getDeviceCleaningStatus().selfCleaning &&
                $scope.deviceStatus.selfCleaningStatus) {
                $scope.deviceStatus.deviceRunningStatus = false;
                processStatusAfterCloseDevice();
            }


        } catch (e) {
        }
    }

    $scope.switchElectricHeat = function () {
        try {
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下电辅热不可调节!");
            } else {
                if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeAuto &&
                    $scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat) {
                    $scope.timeoutPopUp("电辅热只在自动，制热模式下有效!");
                } else {
                    $scope.isElecHeatHelperOpen = $scope.deviceStatus.electricHeatStatus;
                    $scope.acController.controlSwitchElecHeatHelper(!$scope.isElecHeatHelperOpen);
                }
            }
        } catch (e) {
        }
    }

    $scope.switchNatureWind = function () {
        try {
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下自然风不可调节!");
            } else {
                if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool &&
                    $scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind) {
                    $scope.timeoutPopUp("仅在制冷或送风模式下有效!");
                } else {
                    $scope.isNatureWindOpen = $scope.deviceStatus.natureWindStatus;
                    $scope.acController.controlSwitchNatureWind(!$scope.isNatureWindOpen);
                    if (!$scope.isNatureWindOpen) {
                        $scope.acController.dataManager.getColdHotState().coldHotSwitch = 0;
                        $scope.deviceStatus.coldHotSwitch = 0;
                        $scope.acController.dataManager.getDeviceWindBlowingStatus().windBlowing = false;
                        $scope.deviceStatus.windBlowingStatus = false;
                        $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().softWindFeel = false;
                        $scope.deviceStatus.softWindFeelSwitchStatus = false;
                        $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().straightBlow = false;
                        $scope.deviceStatus.straightBlowStatus = false;
                        $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().windFeelingFA100 = false;
                        $scope.deviceStatus.windFeelingFA100tSwitchStatus = false;
                        $scope.isWindBlow = false;
                        $scope.deviceStatus.isWindBlow = false;
                        $scope.acController.dataManager.getDeviceWindAvoidStatus().windAvoid = false;
                        $scope.deviceStatus.windAvoidStatus = false;
                    }
                }
            }
        } catch (e) {
        }
    }

    $scope.switchPurification = function () {
        try {
            $scope.ispurifyOpen = $scope.deviceStatus.purifyStatus;
            $scope.acController.controlSwitchAirPure(!$scope.ispurifyOpen);
            if ($scope.ispurifyOpen == 0) {
                $scope.acController.dataManager.getDeviceCleaningStatus().selfCleaning = false;
                $scope.deviceStatus.selfCleaningStatus = false;
            }
        } catch (e) {
        }
    }
    $scope.filterDirtyPluggingjx = function () {
        if ($scope.acController.dataManager.getFilterDirtyPlugging().percentageReadings >= 0x4B) {
            $scope.currenLevel = "goodState";
            $scope.filterMaintenance.runTimeData.currentBgCircle = "./view/public/images/green-c.png";
        } else if ($scope.acController.dataManager.getFilterDirtyPlugging().percentageReadings >= 0x37 &&
            $scope.acController.dataManager.getFilterDirtyPlugging().percentageReadings <= 0x45) {
            $scope.currenLevel = "midState";
            $scope.filterMaintenance.runTimeData.currentBgCircle = "./view/public/images/yellow-c.png";
        } else if ($scope.acController.dataManager.getFilterDirtyPlugging().percentageReadings < 0x37) {
            $scope.currenLevel = "badState";
            $scope.filterMaintenance.runTimeData.currentBgCircle = "./view/public/images/red-c.png";
        }
    }

    $scope.filterDirtyPluggingshuju = function () {
        $scope.acController.filterDirtyPluggingStatus();
        $scope.testStatus = $scope.acController.dataManager.getFilterDirtyPlugging().testStatus;
        $scope.currenLevel = $scope.acController.dataManager.getFilterDirtyPlugging().currenLevel;
        $scope.ADvalueLow = $scope.acController.dataManager.getFilterDirtyPlugging().ADvalueLow;
        $scope.ADvalueHigh = $scope.acController.dataManager.getFilterDirtyPlugging().ADvalueHigh;
        $scope.controlADrangeLow = $scope.acController.dataManager.getFilterDirtyPlugging().controlADrangeLow;
        $scope.controlADrangeHigh = $scope.acController.dataManager.getFilterDirtyPlugging().controlADrangeHigh;
        $scope.thresholdValue = $scope.acController.dataManager.getFilterDirtyPlugging().thresholdValue;
        $scope.dutyRatio = $scope.acController.dataManager.getFilterDirtyPlugging().dutyRatio;
        $scope.environmentValueLow = $scope.acController.dataManager.getFilterDirtyPlugging().environmentValueLow;
        $scope.environmentValueHigh = $scope.acController.dataManager.getFilterDirtyPlugging().environmentValueHigh;
        $scope.percentageReadings = $scope.acController.dataManager.getFilterDirtyPlugging().percentageReadings;
        $scope.fanRunTimeLow = $scope.acController.dataManager.getFilterDirtyPlugging().fanRunTimeLow;
        $scope.fanRunTimeHigh = $scope.acController.dataManager.getFilterDirtyPlugging().fanRunTimeHigh;
    }

    $scope.switchChildrenPreventCold = function () {
        try {
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下小天使不可调节!");
            } else {
                if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool &&
                    $scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeAuto &&
                    $scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat) {
                    $scope.timeoutPopUp("小天使只在自动，制热，制冷下有效!");
                } else {
                    $scope.ispreventCoolOpen = $scope.deviceStatus.preventCool;
                    $scope.acController.controlSwitchPreventCold(!$scope.ispreventCoolOpen);
                    if (!$scope.ispreventCoolOpen) {
                        $scope.acController.dataManager.getColdHotState().coldHotSwitch = 0;
                        $scope.deviceStatus.coldHotSwitch = 0;
                        $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().softWindFeel = false;
                        $scope.deviceStatus.softWindFeelSwitchStatus = false;
                        $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().straightBlow = false;
                        $scope.deviceStatus.straightBlowStatus = false;
                        $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().windFeelingFA100 = false;
                        $scope.deviceStatus.windFeelingFA100tSwitchStatus = false;
                    }
                }
            }
        } catch (e) {
        }
    }

    $scope.switchDry = function () {
        try {
            $scope.isDryOpen = $scope.deviceStatus.DryStatus;
            if (!$scope.deviceStatus.deviceRunningStatus && !$scope.isDryOpen) {
                $scope.timeoutPopUp("关机下不可开启干燥!");
            } else {
                if ($scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeAuto ||
                    $scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat ||
                    $scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind) {
                    $scope.timeoutPopUp("自动，制热，送风模式下无效!");
                } else {
                    $scope.acController.controlSwitchDry(!$scope.isDryOpen);
                }
            }
        } catch (e) {
        }
    }

    $scope.switchSavingElectric = function () {
        try {
            $scope.isSavingElectricOpen = $scope.deviceStatus.savingElectricStatus;
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下省电不可调节!");
            } else {
                if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool) {
                    $scope.timeoutPopUp("省电只在制冷模式下有效");
                } else {
                    $scope.acController.controlSwitchSavingElectric(!$scope.isSavingElectricOpen);
                }
            }

        } catch (e) {
        }
    }

    //控制儿童防着凉
//	$scope.switchPreventColdAPNSRemind = function() {
//		$scope.hasChildQuiltStatus = $scope.acController.dataManager.getPreventColdAPNSRemind();
//		try {
//			$scope.acController.controlSwitchPreventColdAPNSRemind(!$scope.hasChildQuiltStatus);
//		} catch (e) {}
//	}

    $scope.newSwitchPreventColdAPNSRemind = function () {
        $scope.hasChildQuiltStatus = $scope.acController.dataManager.getPreventColdAPNSRemind();

        $(document).unbind('update::toggle::switch').bind('update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                $scope.acController.controlSwitchPreventColdAPNSRemind(data.currentVal);
            });
        });
    }

    $scope.childQuiltSure = function () {
        $scope.acController.controlSetPreventColdParameter();
    }

    $scope.switchSelfLearn = function () {
    }
    //	强劲
    $scope.switchStrong = function () {
        try {
            $scope.isStrongOpen = $scope.deviceStatus.strongStatu;
            $scope.acController.controlSwitchTubro(!$scope.isStrongOpen);
        } catch (e) {
        }
    }
    //舒适抽湿
    $scope.switchComfortDry = function () {
        try {
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下舒适抽湿不可调节!");
            } else {
                $scope.acController.dataManager.getColdHotState().coldHotSwitch = 0;
                $scope.deviceStatus.coldHotSwitch = 0;
                $scope.iscomfortDryOpen = $scope.deviceStatus.comfortDryStatus;
                $scope.acController.controlComfortDry(!$scope.iscomfortDryOpen);
                $scope.currentSleepRecommendStatus = false;
                $scope.currentSleepCustomStatus = false;
                $scope.ifChooseSleepCurve = false;
                $scope.sleepCurveCustomStatus = false;
                $scope.sleepCurveRecommendStatus = false;
                $scope.currentSleepOperation = "执行睡眠";
                $scope.comfortSleepisActive = false;
                $scope.currentSleepStatus = false;
            }
        } catch (e) {
        }
    }

    $scope.openChangeSetHumitity = function () {
        if (!$scope.deviceStatus.deviceRunningStatus) {
            $scope.timeoutPopUp("关机下手动抽湿不可调节!");
        } else {
            $scope.currentDeviceInfo = $scope.acController.dataManager.getCurrentDevice().deviceInfo;
            $scope.acController.dataManager.getColdHotState().coldHotSwitch = 0;
            $scope.deviceStatus.coldHotSwitch = 0;
            $scope.currentSleepRecommendStatus = false;
            $scope.currentSleepCustomStatus = false;
            $scope.ifChooseSleepCurve = false;
            $scope.sleepCurveCustomStatus = false;
            $scope.sleepCurveRecommendStatus = false;
            $scope.currentSleepOperation = "执行睡眠";
            $scope.comfortSleepisActive = false;
            $scope.currentSleepStatus = false;

            if ($scope.openCloseisActive) {
                $scope.openModal('isChangeHumidity', [], function (event, data) {
                });

                $(document).unbind('update::toggle::switch').bind('update::toggle::switch', {}, function (event, data) {
                    $scope.$apply(function () {
                        $scope.component.toggleSwitchStatus = data.currentVal;
                        if ($scope.component.toggleSwitchStatus) {
                            $scope.$broadcast('slider:control:for:humidity:enable', {});
                            $scope.acController.controlManualDry($scope.component.toggleSwitchStatus, $scope.deviceStatus.setHumidityValue);
                        } else {
                            $scope.$broadcast('slider:control:for:humidity:disable', {});
                            $scope.acController.controlManualDry($scope.component.toggleSwitchStatus, $scope.deviceStatus.setHumidityValue);
                        }
                    });
                });

                if ($scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeManualDry) {
                    coreHelper.delayExecute(function () {
                        $scope.$broadcast('init::toggle::switch', {
                            'currentVal': true
                        });
                        $scope.$broadcast('slider:control:for:humidity:enable', {});
                    }, 100);
                } else {
                    coreHelper.delayExecute(function () {
                        $scope.$broadcast('init::toggle::switch', {
                            'currentVal': false
                        });
                        $scope.$broadcast('slider:control:for:humidity:disable', {});
                    }, 100);
                }
            } else {
                $scope.timeoutPopUp("关机状态不能调控湿度!");
            }
        }
    }

    $scope.switchPreventStraightLineWind = function () {
        try {
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下不可开启防直吹!");
            } else {
                $scope.preventStraightLineWindIsActive = $scope.deviceStatus.windSpeedStatus;
                $scope.acController.controlWindSpeedStatus(!$scope.preventStraightLineWindIsActive);
            }
        } catch (e) {
        }
    }

    $scope.openUpDownNoWindFeelModal = function () {
        allowsChangeNoWindFeel(function () {
            $scope.openModal('isUpDownNoWindFeelControl');
            //console.log($scope.upNoWindFeelIsActive+","+$scope.downNoWindFeelIsActive);
        });
    }

    //开关上无风感
    $scope.switchUpNoWindFeel = function () {
        allowsChangeNoWindFeel(function () {
            $scope.upNoWindFeelIsActive = !$scope.upNoWindFeelIsActive;
            $scope.upNoWindFeelSrc = $sce.trustAsResourceUrl($scope.staticData.upNoWindFeelSrc[$scope.upNoWindFeelIsActive ? "on" : "off"]);
            $scope.acController.controlSwitchUpDownNoWindFeel($scope.upNoWindFeelIsActive, $scope.downNoWindFeelIsActive);
            $scope.acController.dataManager.getDeviceWindBlowingStatus().windBlowing = false;
            $scope.deviceStatus.windBlowingStatus = false;
            if ($scope.upNoWindFeelIsActive) {
                $scope.deviceStatus.windSpeedValue = 102;
            }
        });
    }
    //开关下无风感
    $scope.switchDownNoWindFeel = function () {
        allowsChangeNoWindFeel(function () {
            $scope.downNoWindFeelIsActive = !$scope.downNoWindFeelIsActive;
            $scope.downNoWindFeelSrc = $sce.trustAsResourceUrl($scope.staticData.downNoWindFeelSrc[$scope.downNoWindFeelIsActive ? "on" : "off"]);
            $scope.acController.controlSwitchUpDownNoWindFeel($scope.upNoWindFeelIsActive, $scope.downNoWindFeelIsActive);
            $scope.acController.dataManager.getDeviceWindBlowingStatus().windBlowing = false;
            $scope.deviceStatus.windBlowingStatus = false;
            if ($scope.downNoWindFeelIsActive) {
                $scope.deviceStatus.windSpeedValue = 102;
            }
        });
    }

    function allowsChangeNoWindFeel(succeed) {
        allowsChangeState(succeed, "无风感");
    }

    function allowsChangeState(succeed, stateName) {
        if (!$scope.deviceStatus.deviceRunningStatus) {
            $scope.timeoutPopUp("关机时" + stateName + "不可调节!");
        } else {
            if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool) {
                $scope.timeoutPopUp(stateName + "只在制冷模式下有效!");
            } else if (succeed != null) {
                succeed();
            }
        }
    }

    //开关儿童防冷风
    $scope.switchChildrenPrenventWind = function () {
        allowsChangeState(function () {
            var deviceStatus = $scope.acController.dataManager.getDeviceColdWindStatus();
            $scope.acController.controlColdWindStatus(!deviceStatus.coldWind);
        }, "防冷风");
    }

    $scope.closeChangeSetHumidity = function () {
        $scope.closeModal('isChangeHumidity');
    }

    $scope.switchChangeSetHumidity = function () {
        /*调节风速*/
        try {
            $(document).bind('slider:control:for:humidity:update', {}, function (event, data) {
                $scope.acController.controlManualDry(true, data.current);
            });
        } catch (e) {
        }
    }
    $scope.switchChangeSetSoundValue = function () {
        /*音量手动调节*/
        try {
            $(document).unbind('slider:control:for:soundValue:update').bind('slider:control:for:soundValue:update', {}, function (event, data) {
                $scope.acController.dataManager.getVolumeState().manualAdjustment = data.current;
//				alert("soundValue=="+data.current+"/n sendValue=="+data.current*20);
                $scope.acController.controlVolumeStatus();
            });
        } catch (e) {
        }
    }

    /*初始化jQuery插件*/
    $scope.initJqueryPlugin = function () {

        // var lineChartData = {};
        // var lineChartDataWind = {};
        // $scope.appRuntime.selfLearningBtnShow = true;
        // var defaultData = [],defaultLabels = [];
        // for (var i = 0; i < 25;i++){
        // 	defaultData.push(i * 5);
        // 	defaultLabels.push(i);
        // }
        // lineChartData = {
        // 	labels: defaultLabels,
        // 	datasets: [{
        // 		label: null,
        // 		lineTension : 0,
        // 		borderWidth: 1,
        // 		backgroundColor: "rgba(51,153,255,0.2)",
        // 		borderColor: "rgba(51,153,255,1)",
        // 		pointRadius:0,
        // 		data: defaultData //$scope.appRuntime.selfLearningTemp[0]
        // 	}]
        // };

        // lineChartDataWind = {
        // 	labels: defaultLabels,
        // 	datasets: [{
        // 		label: null,
        // 		borderWidth: 1,
        // 		lineTension : 0,
        // 		backgroundColor: "rgba(255,135,46,0.5)",
        // 		borderColor: "rgba(255,135,46,1)",
        // 		pointRadius:0,
        // 		data: defaultData //$scope.appRuntime.selfLearningWindspeed[0]
        // 	}]
        // };
        // $scope.initScrollLineChart("temperature-study-result-wrapper", lineChartData);
        // $scope.initScrollLineChart("wind-study-result-wrapper", lineChartDataWind,true);

        // var lineChartData = {};
        // var lineChartDataWind = {};
        // $scope.appRuntime.selfLearningBtnShow = true;
        // var defaultData = [],defaultLabels = [];
        // for (var i = 0; i < 25;i++){
        // 	defaultData.push(0);
        // 	defaultLabels.push(i);
        // }
        // lineChartData = {
        // 	labels: defaultLabels,
        // 	datasets: [{
        // 		label: "My First dataset",
        // 		fillColor: "rgba(51,153,255,0.2)",
        // 		strokeColor: "rgba(51,153,255,1)",
        // 		pointColor: "rgba(51,153,255,1)",
        // 		pointStrokeColor: "#fff",
        // 		pointHighlightFill: "#fff",
        // 		pointHighlightStroke: "rgba(51,153,255,1)",
        // 		data: defaultData //$scope.appRuntime.selfLearningTemp[0]
        // 	}]
        // };

        // lineChartDataWind = {
        // 	labels: defaultLabels,
        // 	datasets: [{
        // 		label: "My First dataset",
        // 		fillColor: "rgba(255,135,46,0.5)",
        // 		strokeColor: "rgba(255,135,46,1)",
        // 		pointColor: "rgba(255,135,46,1)",
        // 		pointStrokeColor: "#fff",
        // 		pointHighlightFill: "#fff",
        // 		pointHighlightStroke: "rgba(255,135,46,1)",
        // 		data: defaultData //$scope.appRuntime.selfLearningWindspeed[0]
        // 	}]
        // };
        // $scope.initScrollLineChart("temperature-study-result-wrapper", lineChartData);
        // $scope.initScrollLineChart("wind-study-result-wrapper", lineChartDataWind);

        // $scope.appRuntime.maxTemp = $scope.tempSpeedMax[index][0];
        // $scope.appRuntime.minTemp = $scope.tempSpeedMin[index][0];
        // $scope.appRuntime.avgTemp = $scope.tempSpeedAvg[index][0];
        // $scope.appRuntime.maxWindspeed = $scope.tempSpeedMax[index][1];
        // $scope.appRuntime.minWindspeed = $scope.tempSpeedMin[index][1];
        // $scope.appRuntime.avgWindspeed = $scope.tempSpeedAvg[index][1];
        // $scope.$apply();
    };

    $scope.gotoSettingFromSetting = function() {
        $scope.intelCheckShow = false;
        $scope.intelCheckStatus = false;
        $(".intelCheckBg").stop(false, false);

        $scope.redirectPageCustom('setting','out');
    };

    $scope.redirectPageCustom = function(page, state) {
        if ((page == "setting" && state == "out") || (page == "main" && state == "out")) {
            coreHelper.redirectPage($scope, $scope.currentModule + page, state);
        } else {
            coreHelper.redirectPage($scope, page, state);
        }
    };

    //智能体检
    $scope.startIntelCheck = function () {
        if (!$scope.intelCheckStatus) {
            $scope.intelCheckShow = true;
            $(".intelCheckBg").css("width", "1%");
            $scope.checkScoreSize = "55px";
            $scope.checkFen = "15px";
            $scope.intelCheckDiv = true;
            $scope.intelCheckHeight = "138px";
            $scope.checkParame = "true";
            $scope.intelCheckStatus = !$scope.intelCheckStatus;
            $scope.intelCheckOperation = $scope.intelCheckStatus == true ? "取消体检" : "开始体检";
            $scope.acController.controlDeviceCheck();
            $(".intelCheckBg").stop(false, false).animate({
                width: '100%'
            }, {
                duration: 6000,
                easing: "linear",
                step: function (a, b) {
                    $scope.$apply(function () {
                        $scope.scanProcess = "正在扫描空调：" + (parseInt(a)) + "%";
                    });
                },
                complete: function () {
                    $scope.$apply(function () {
                        $scope.checkScoreSize = "75px";
                        $scope.checkFen = "20px";
                        $scope.intelCheckStatus = false;
                        $scope.intelCheckOperation = $scope.intelCheckStatus == true ? "取消体检" : "开始体检";
                        $scope.getLastIntelCheckInfo();
                        $scope.intelCheckDiv = false;
                        $scope.intelCheckHeight = "205px";

                    });

                }
            });
        } else {
            $scope.checkScoreSize = "75px";
            $scope.checkFen = "20px";
            $scope.intelCheckDiv = false;
            $scope.intelCheckStatus = !$scope.intelCheckStatus;
            $scope.intelCheckOperation = $scope.intelCheckStatus == true ? "取消体检" : "开始体检";
            $scope.getLastIntelCheckInfo();
            $(".intelCheckBg").stop(false, false);
            $(".intelCheckBg").css("width", "1%");
            $scope.intelCheckHeight = "205px";
            $scope.checkParame = "false";
        }
    }

    //点击智能体检进入界面时获取上次体检结果信息
    $scope.getLastIntelCheckInfo = function () {
        $scope.allDeviceCheckInfo = $scope.acController.dataManager.getDeviceCheckFinishStatus();
        $scope.checkParameters = $scope.allDeviceCheckInfo.checkParameters;
        $scope.faultNumber = $scope.allDeviceCheckInfo.checkFaultNum == "" ? "--" : $scope.allDeviceCheckInfo.checkFaultNum;
        $scope.checkNum = $scope.allDeviceCheckInfo.checkNum;
        $scope.checkScore = $scope.allDeviceCheckInfo.score == "" ? "--" : $scope.allDeviceCheckInfo.score;
        $scope.scanProcess = $scope.allDeviceCheckInfo.scanProcess;
        $scope.appRuntime.checkStatusColor = $scope.allDeviceCheckInfo.scoreLevel == 1 ? $scope.appRuntime.checkStatusColorNormal : $scope.appRuntime.checkStatusColorError;
        $scope.checkStatusColorBg = $scope.allDeviceCheckInfo.scoreLevel == 1 ? true : false;
        $scope.checkErrorMessages = $scope.allDeviceCheckInfo.checkFaultDetail;
    }

    //电量数据
    $scope.getElectricityData = function () {
        $scope.allElectricityData = $scope.acController.dataManager.getElectricQuantity();
        //实时功率
        $scope.currentPower = $scope.allElectricityData.realTimePower.power;
        $scope.currentRunTime = $scope.allElectricityData.realTimePower.runTime;
        $scope.currentRunElecQty = $scope.allElectricityData.realTimePower.runElecQty;
        $scope.allRunTime = $scope.allElectricityData.realTimePower.totalRunTime;
        $scope.allRunElecQty = $scope.allElectricityData.realTimePower.totalRunElecQty;

        if ($scope.allElectricityData.elecQty.currentWeekElecQty.totalElecQty == "" || $scope.allElectricityData.elecQty.currentWeekElecQty.totalElecQty == undefined) {
            $scope.totalWeekElecQuanty = "0.00";
        } else {
            $scope.totalWeekElecQuanty = $scope.allElectricityData.elecQty.currentWeekElecQty.totalElecQty;
        }

        $scope.ecoTime = $scope.allElectricityData.ecoRunningStatus.EcoTime;
        $scope.ecoElecQty = $scope.allElectricityData.ecoRunningStatus.EcoElecQty;

        //本月电量
        $scope.currentWeek = $scope.allElectricityData.elecQty.currentWeekElecQty.details;
        var p = getCurrentMonthAndDays();
        $scope.month = p.month;
        $scope.days = p.days;
        if ($scope.days == 29) {
            $scope.daysShow29 = true;
            $scope.daysShow30 = false;
            $scope.daysShow31 = false;
        } else if ($scope.days == 30) {
            $scope.daysShow29 = true;
            $scope.daysShow30 = true;
            $scope.daysShow31 = false;

        } else if ($scope.days == 31) {
            $scope.daysShow29 = true;
            $scope.daysShow30 = true;
            $scope.daysShow31 = true;
        }
    }

    //本月电量数据＋今日用电数据
    $scope.getMonthElectricityData = function () {
        $scope.allElectricityData = $scope.acController.dataManager.getElectricQuantity();

        //今日电量
        if ($scope.allElectricityData.todayElecQty == "" || $scope.allElectricityData.todayElecQty == undefined) {
            $scope.todayElecQuanty = "0.00";
        } else {
            $scope.todayElecQuanty = $scope.allElectricityData.todayElecQty;
        }

        if ($scope.allElectricityData.elecQty.currentMonthElecQty.totalElecQty == "" || $scope.allElectricityData.elecQty.currentMonthElecQty.totalElecQty == undefined) {
            $scope.totalElecQuanty = "0.00";
        } else {
            $scope.totalElecQuanty = $scope.allElectricityData.elecQty.currentMonthElecQty.totalElecQty;
        }

        //本月电量
        $scope.currentMonth = $scope.allElectricityData.elecQty.currentMonthElecQty.details;
        var electDataValue = [];
        for (var item in $scope.currentMonth) {
            bridge.logToIOS("electdata=" + $scope.currentMonth[item]);
            electDataValue.push($scope.currentMonth[item]);
        }

        $scope.$broadcast('simpleChart:init:data', {
            powerData: electDataValue
        });
        var currentDay = new Date().getDate();
        var currentMonthElec = [];
        if (currentDay == 1) {
            currentMonthElec[0] = electDataValue[0];
        } else {
            for (var i = 0; i < currentDay; i++) {
                currentMonthElec[i] = electDataValue[currentDay - 1 - i];
            }
        }
        $scope.currentMonthDays = currentDay + 1;
        $scope.currentMonthData = currentMonthElec;
    }

    //儿童防着凉数据
    $scope.getPreventColdData = function () {
        var preventColdStatus = $scope.acController.dataManager.getPreventColdStatus();

        var sensity = preventColdStatus.beColdSensitivity;
        if (sensity == 0) {
            $scope.coldSensity = '高';
        } else if (sensity == 1) {
            $scope.coldSensity = '中';
        } else if (sensity == 2) {
            $scope.coldSensity = '低';
        }

        $scope.coldMin = preventColdStatus.beColdMin;
        $scope.coldMax = preventColdStatus.beColdMax;
        $scope.coldTemperateRise = preventColdStatus.beColdTemperateRise;
        $scope.heatMin = preventColdStatus.beHeatMin;
        $scope.heatMax = preventColdStatus.beHeatMax;
        $scope.heatTemperateRise = preventColdStatus.beHeatTemperateRise;
    }

    //舒睡曲线
    $scope.changeSleepStatus = function () {
        if ($scope.sleepCurveCustomStatus) {
            $scope.acController.dataManager.selectCustomCurve();
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下舒睡不可用!");
            } else {
                if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool &&
                    $scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat) {
                    $scope.timeoutPopUp("舒睡只在制冷，制热模式下有效!");
                } else {
                    $scope.acController.controlSwitchSleep(!$scope.currentSleepCustomStatus);
                }
            }
        } else if ($scope.sleepCurveRecommendStatus) {
            $scope.acController.dataManager.selectRecommendCurve();
            if (!$scope.deviceStatus.deviceRunningStatus) {
                $scope.timeoutPopUp("关机下舒睡不可用!");
            } else {
                if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool &&
                    $scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat) {
                    $scope.timeoutPopUp("舒睡只在制冷，制热模式下有效!");
                } else {
                    $scope.acController.controlSwitchSleep(!$scope.currentSleepRecommendStatus);
                }
            }
        } else {
            $scope.timeoutPopUp("请先选择曲线!");
            //alert("请先选择曲线");
//			var functionParamers = {
//				title: "提示",
//				message: "请先选择曲线!",
//				btnText: "确定"
//			};
//			bridge.showAlert(functionParamers);
        }
    }

    //舒睡曲线选中
    $scope.changeSleepCurveRecommendStatus = function () {
        if (!$scope.sleepCurveRecommendStatus) {
            $scope.ifChooseSleepCurve = true;
            $scope.sleepCurveRecommendStatus = true;
            $scope.sleepCurveCustomStatus = false;
            if ($scope.sleepData.selectSleepType == 0 && ($scope.deviceStatus.sleepStatus == true)) {
                $scope.currentSleepOperation = "取消睡眠";
                $scope.currentSleepStatus = true;
            } else {
                $scope.currentSleepOperation = "执行睡眠";
                $scope.currentSleepStatus = false;
            }
        }
    }

    $scope.changeSleepCurveCustomStatus = function () {
        if (!$scope.sleepCurveCustomStatus) {
            $scope.ifChooseSleepCurve = true;
            $scope.sleepCurveCustomStatus = true;
            $scope.sleepCurveRecommendStatus = false;
            if ($scope.sleepData.selectSleepType == 1 && ($scope.deviceStatus.sleepStatus == true)) {
                $scope.currentSleepOperation = "取消睡眠";
                $scope.currentSleepStatus = true;
            } else {
                $scope.currentSleepOperation = "执行睡眠";
                $scope.currentSleepStatus = false;
            }
        }
    }


    /*睡眠曲线接口调试代码*/
    /*睡眠曲线接口调试代码*/
    $scope.debugComfortSleep = function (sleepData) {
        console.log("yyyyyyyyyyyyyy");
        $scope.sleepData = $scope.acController.dataManager.getSleepMode();
        var tmpSleepData = [];
        var settingTemp = $scope.deviceStatus.temperatureInteger == "--" ? 26 : $scope.deviceStatus.temperatureInteger;
        if (settingTemp < 17) {
            tmpSleepData[0] = 17;
        } else if (settingTemp > 30) {
            tmpSleepData[0] = 30;
        } else {
            tmpSleepData[0] = settingTemp;
        }
        var i = 0;
        for (var item in $scope.sleepData.sleepCurveCustom) {
            //bridge.logToIOS("sleepdata=" + $scope.sleepData.sleepCurveCustom[item]);
            if (i < 8) {
                if ($scope.sleepData.sleepCurveCustom[item] < 17) {
                    tmpSleepData.push(17);
                } else if ($scope.sleepData.sleepCurveCustom[item] > 30) {
                    tmpSleepData.push(30);
                } else {
                    tmpSleepData.push($scope.sleepData.sleepCurveCustom[item]);
                }
                i++;
            }
        }

        /*缓存本地数据*/
        $scope.appCache.pullMenuData = tmpSleepData;

        //alert(JSON.stringify($scope.appCache.pullMenuData));

        $(document).bind('interactChart:data:update', {}, function (event, data) {
            $scope.$apply(function () {
                $scope.appRuntime.sleepData = data.currentVal;
                $scope.acController.dataManager.selectCustomCurveValue($scope.appRuntime.sleepData);
            });
        });

        // $scope.$broadcast('init:interactChart', {
        // 	current: $scope.appCache.pullMenuData
        // });

        $.event.trigger("init:interactChart", [{current: $scope.appCache.pullMenuData}]);
    };


    /*智能睡眠曲线 */
    $scope.debugInteligentSleep = function () {
        console.log("mmmmmmmmmmmmmm");
        var tmpSleepData = [];
        var settingTemp = $scope.deviceStatus.temperatureInteger == "--" ? 26 : $scope.deviceStatus.temperatureInteger;
        if (settingTemp < 17) {
            tmpSleepData[0] = 17;
        } else if (settingTemp > 30) {
            tmpSleepData[0] = 30;
        } else {
            tmpSleepData[0] = settingTemp;
        }
        var i = 0;
        for (var item in $scope.sleepData.sleepCurveInteligent) {
            bridge.logToIOS("sleepdata=" + $scope.sleepData.sleepCurveInteligent[item]);
            if (i < 8) {
                if ($scope.sleepData.sleepCurveInteligent[item] < 17) {
                    tmpSleepData.push(17);
                } else if ($scope.sleepData.sleepCurveInteligent[item] > 30) {
                    tmpSleepData.push(30);
                } else {
                    tmpSleepData.push($scope.sleepData.sleepCurveInteligent[item]);
                }
                i++;
            }
        }

        /*缓存本地数据*/
        $scope.appCache.pullMenuInteligentData = tmpSleepData;

        $scope.$broadcast('init:interactChart', {
            current: tmpSleepData
        });
    };

//	$scope.debugComfortSleep = function(sleepData) {
//		$(document).bind('interactChart:data:update', {}, function(event, data) {
//			$scope.$apply(function() {
//				$scope.appRuntime.sleepData = data.currentVal;
//				$scope.acController.dataManager.selectCustomCurveValue($scope.appRuntime.sleepData);
//			});
//		});
//
//		$scope.$broadcast('init:interactChart', {
//			current: sleepData
//		});
//	};

    //电量展示选择
    $scope.goto_top_timer = function () {
        var y = $scope.goto_top_type == 1 ? document.documentElement.scrollTop : document.body.scrollTop;
        var moveby = 15;
        y -= Math.ceil(y * moveby / 100);

        if (y < 0) {
            y = 0;

        }
        if ($scope.goto_top_type == 1) {
            document.documentElement.scrollTop = y;

        } else {
            document.body.scrollTop = y;

        }
        if (y == 0) {
            clearInterval($scope.goto_top_itv);
            $scope.goto_top_itv = 0;
        }
    }
    $scope.goto_top = function () {
        if ($scope.goto_top_itv == 0) {

            if (document.documentElement && document.documentElement.scrollTop) {
                $scope.goto_top_type = 1;
                console.log('111');
            } else if (document.body && document.body.scrollTop) {
                $scope.goto_top_type = 2;
            } else {
                $scope.goto_top_type = 0;
            }
            if ($scope.goto_top_type > 0) {
                $scope.goto_top_itv = setInterval($scope.goto_top_timer, 50);
            }
        }
    }
    $scope.elecStaticTypeControl = function () {
        if ($scope.elecStaticTypeShow == false) {
            $scope.goto_top();

            coreHelper.lockScroll($scope, [$('body')], true);
            $scope.elecStaticTypeShow = true;
            $scope.layerIsActive = true;
            $scope.arrowUpDown = true;
            $scope.monthDataPosition = "163px";
        } else {
            coreHelper.lockScroll($scope, [$('body')], false);
            $scope.elecStaticTypeShow = false;
            $scope.layerIsActive = false;
            $scope.arrowUpDown = false;
            $scope.monthDataPosition = "62px";
        }
    }

    $scope.currentWeekElectShow = function () {
        if ($scope.currentWeek.one == null || $scope.currentWeek.one == undefined) {
            $scope.currentWeekShow = false;
        } else {
            $scope.currentWeekShow = true;
        }

        coreHelper.lockScroll($scope, [$('body')], false);
        $scope.currentWeekDataShow = true;
        $scope.currentElectTitle = "本周电量";
        $scope.currentMonthDataShow = false;
        $scope.blueWeekRowDivisActive = true;
        $scope.blueMonthRowDivisActive = false;
        $scope.elecStaticTypeShow = false;
        $scope.layerIsActive = false;
        $scope.arrowUpDown = false;
    }

    $scope.currentMonthElectShow = function () {
        coreHelper.lockScroll($scope, [$('body')], false);
        $scope.currentWeekShow = false;
        $scope.currentWeekDataShow = false;
        $scope.currentMonthDataShow = true;
        $scope.currentElectTitle = "本月电量";
        $scope.elecStaticTypeShow = false;
        $scope.blueMonthRowDivisActive = true;
        $scope.blueWeekRowDivisActive = false;
        $scope.layerIsActive = false;
        $scope.arrowUpDown = false;
        $scope.monthDataPosition = "62px";

    }

    //定时开关按钮控制
    $scope.setTimeIconControl = function () {
        var setTime = 0;
        if ($scope.deviceStatus.deviceRunningStatus) {
            setTime = $scope.deviceStatus.timerCloseTime;
        } else {
            setTime = $scope.deviceStatus.timerOpenTime;
        }

        if (0 < setTime && setTime <= 1440) {
//			$scope.setTimeIconIsActive = true;
            $scope.setTimeImgIsActive = false;
        } else {
//			$scope.setTimeIconIsActive = false;
            $scope.setTimeImgIsActive = true;
        }
    }

    $scope.initSetTimeIconControl = function () {
        var deviceStatus = $scope.deviceStatus;
        if (deviceStatus.upDownProduceWindStatus == 1 || deviceStatus.leftRighProducetWindStatus == 1) {
            $scope.acController.dataManager.getColdHotState().coldHotSwitch = 0;
            $scope.deviceStatus.coldHotSwitch = 0;
            $scope.coldHotSwitchActive = false;
        }

//		if($scope.appRuntime.isTempChange == true||$scope.appRuntime.isModeChange = true){
//			$scope.acController.dataManager.getColdHotState().coldHotSwitch=0;
//			$scope.deviceStatus.coldHotSwitch=0;
//			$scope.coldHotSwitchActive = false;
//		}

        if (deviceStatus.deviceRunningStatus) {
            if (deviceStatus.timerCloseStatus) {

                var setTime = deviceStatus.timerCloseTime;
                if (0 < setTime && setTime <= 1440) {

                    $scope.setTimeImgIsActive = false;
//					$scope.setTimeIconIsActive = true;
                    $scope.currentHour = Math.floor(setTime / 60);
                    $scope.currentMin = setTime % 60;
                }
            } else {
                $scope.setTimeImgIsActive = true;
//				$scope.setTimeIconIsActive = false;
            }

        } else {
            if (deviceStatus.timerOpenStatus) {
                var setTime = deviceStatus.timerOpenTime;
                if (0 < setTime && setTime <= 1440) {
                    $scope.setTimeImgIsActive = false;
//					$scope.setTimeIconIsActive = true;
                    $scope.currentHour = Math.floor(setTime / 60);
                    $scope.currentMin = setTime % 60;
                }
            } else {
                $scope.setTimeImgIsActive = true;
//				$scope.setTimeIconIsActive = false;
            }
        }
        if ($scope.currentHour < 10)
            $scope.currentHour = '0' + $scope.currentHour;
        else
            $scope.currentHour = $scope.currentHour;
        if ($scope.currentMin < 10)
            $scope.currentMin = '0' + $scope.currentMin;
        else $scope.currentMin = $scope.currentMin;
    }

    /********************************常用函数封装*********************************/
    /*icon列表控制逻辑封装*/
    $scope.functionListProcess = function (func, flag, source) {
        if ($scope['deviceStatus'][func]) {
            $scope[source] = $sce.trustAsResourceUrl($scope['staticData'][source]['on']);
            $scope[flag] = true;
        } else {
            $scope[source] = $sce.trustAsResourceUrl($scope['staticData'][source]['off']);
            $scope[flag] = false;
        }
    }
    $scope.functionListProcessFromStatus = function (obj, func, flag, source, otherCondi) {
        if (obj[func] && otherCondi) {
            $scope[source] = $sce.trustAsResourceUrl($scope['staticData'][source]['on']);
            $scope[flag] = true;
        } else {
            $scope[source] = $sce.trustAsResourceUrl($scope['staticData'][source]['off']);
            $scope[flag] = false;
        }
    }

    /*模态对话框底层函数封装*/
    $scope.openModal = function (templateFlag, selectorDataSource, callback) {
        /*控件初始化*/
        $scope['component'][templateFlag] = true;

        $scope.appRuntime.scrollSelector = selectorDataSource;

        $scope.$broadcast('show:modal');

        /*绑定滚动选择组件的回调事件*/
        $(document).unbind('update:scrollSelector').bind('update:scrollSelector', function (event, data) {
            if ((data.currentVal.status) || (data.currentVal.status == undefined)) {
                var response = ($scope.appRuntime.scrollSelector.data.left)[data.currentVal.index].value;
            }
            $scope.$apply(function () {
                callback(event, response, data.currentVal.mod, data.currentVal.pos, data.currentVal);
            });
        });

        $(document).unbind('close:modal:finit').bind('close:modal:finit', function (event, data) {
            $scope.appRuntime.countCloseModalEvent += 1;
            $scope['component'][templateFlag] = false;
            $scope['component']['isModeControl'] = false;
            $scope['component']['isScrollDateSelector'] = false;

            $scope.$apply();
        });
    }

    $scope.closeModal = function (templateFlag) {
        $scope['component'][templateFlag] = false;
        $scope.$broadcast('close:modal');
    }

    $scope.openModalExtende = function (templateFlag, selectorDataSource, scrollSelectorIds, callbackFirst, callbackSecond) {
        /*控件初始化*/
        $scope['component'][templateFlag] = true;

        $scope.appRuntime.scrollSelector = selectorDataSource;

        $scope.$broadcast('show:modal');

        /*绑定滚动选择组件的回调事件*/
        $(document).unbind('update:scrollSelector:' + scrollSelectorIds.first).bind('update:scrollSelector:' + scrollSelectorIds.first, function (event, data) {
            $scope.$apply(function () {
                callbackFirst(event, data.currentVal);
            });
        });

        $(document).unbind('update:scrollSelector:' + scrollSelectorIds.second).bind('update:scrollSelector:' + scrollSelectorIds.second, function (event, data) {
            $scope.$apply(function () {
                callbackSecond(event, data.currentVal);
            });
        });

        $(document).unbind('close:modal:finit').bind('close:modal:finit', function (event, data) {
            $scope.appRuntime.countCloseModalEvent += 1;
            $scope['component'][templateFlag] = false;
        });
    }

    /*控制球状态控制*/
    $scope.switchBallPanel = function (status, changeLook) {
        if (status) {
            //$scope.$broadcast('ballPanel:active');
            if (changeLook) {
                $scope.$broadcast('ballPanel:change:appearance:enable', {
                    current: $scope.appRuntime.currentConfigTemp,
                    tempReal: $scope.deviceStatus.indoorTempInteger,
                    mode: $scope.deviceStatus.runningMode,
                    status: $scope.openCloseisActive
                });
                $scope.changeHomePageAppearance($scope.appConfig.activeColor);
            } else {
                $scope.$broadcast('ballPanel:change:appearance:disable', {
                    current: $scope.appRuntime.currentConfigTemp,
                    tempReal: $scope.deviceStatus.indoorTempInteger,
                    mode: $scope.deviceStatus.runningMode,
                    status: $scope.openCloseisActive
                });
                $scope.changeHomePageAppearance($scope.appConfig.deactiveColor);
            }
        } else {
            //$scope.$broadcast('ballPanel:deactive');
            if (changeLook) {
                $scope.$broadcast('ballPanel:change:appearance:enable', {
                    current: $scope.appRuntime.currentConfigTemp,
                    tempReal: $scope.deviceStatus.indoorTempInteger,
                    mode: $scope.deviceStatus.runningMode,
                    status: $scope.openCloseisActive
                });
                $scope.changeHomePageAppearance($scope.appConfig.activeColor);
            } else {
                $scope.$broadcast('ballPanel:change:appearance:disable', {
                    current: $scope.appRuntime.currentConfigTemp,
                    tempReal: $scope.deviceStatus.indoorTempInteger,
                    mode: $scope.deviceStatus.runningMode,
                    status: $scope.openCloseisActive
                });
                $scope.changeHomePageAppearance($scope.appConfig.deactiveColor);
            }
        }
    };

    /*APP外观控制*/
    $scope.changeHomePageAppearance = function (color, isAnimate) {
        var homePageDom = [$('#ball-panel'), $('.home-positionFixed'), $('#main_model'), $(".pull-menu-container")];
        isAnimate = isAnimate == undefined ? false : isAnimate;
        if (isAnimate) {
            for (var i = 0; i < homePageDom.length; i++) {
                homePageDom[i].animate({
                    'backgroundColor': color
                }, 500);
            }
        } else {
            for (var i = 0; i < homePageDom.length; i++) {
                homePageDom[i].css({
                    'backgroundColor': color
                });
            }
        }
    };

    /*Tooltips提示功能*/
    $scope.showBallPanelTooltips = function (data, state, force) {
        if ($('canvas').offset() !== undefined) {
            var basePos = {
                x: $('canvas').offset().left,
                y: $('canvas').offset().top
            };

            if (!force) {
                if (state) {
                    $('.temp-tooltips').css({
                        left: basePos.x + data.pos.x - $('.temp-tooltips').width() / 2,
                        top: data.pos.y > 135 ? (basePos.y + data.pos.y - $('.temp-tooltips').height() - 41) : (basePos.y + data.pos.y - $('.temp-tooltips').height() - 61)
                    });

                    $('.temp-tooltips').stop(true, true).animate({
                        opacity: 0.8
                    }, 1000);
                } else {
                    setTimeout(function () {
                        $('.temp-tooltips').stop(true, true).animate({
                            opacity: 0
                        }, 1000);
                    }, 1000);
                }
            } else {
                $('.temp-tooltips').stop(true, true).css({
                    opacity: 0
                });
            }
        }
    };

    $scope.preLaunchComponent = function () {
    };

    /*超时弹出框*/
    $scope.timeoutPopUp = function (timeOutPopText) {
        setTimeout("$('.timeOutPopUp').stop(false,false).fadeIn()", 40);
        setTimeout("$('.timeOutPopUp').stop(false,false).fadeOut('slow')", 1000);
        $scope.component.popUpMessage = timeOutPopText;
    };

    /*工具函数*/
    $scope.lockScroll = function (lockScrollList) {
        for (var i = 0; i < lockScrollList.length; i++) {
            lockScrollList[i].bind('touchstart', function (e) {
                e.preventDefault();
            })
        }
    }
    // a canvas and a context2d to draw to
    $scope.filterCheckAnimate = function (animateId, animateRestTime) {

        $scope.filterCheckAnimateTime = 0;
        if (animateRestTime == 1200000) {
            animateRestTime = 1198000;
        }
        $scope.filterCheckAnimateTime = (1200000 - animateRestTime) / 1200000;

        var aniamteDelay = 0;
        var width = 160;
        var height = 160;
        var animateTime = 10;
        var canvas = document.getElementById(animateId);
        var ctx = canvas.getContext("2d");

        canvas.width = width;
        canvas.height = height;

//		aniamteDelay = setInterval(function() {
        $scope.update(ctx, width, height);
//		}, animateTime);

        setTimeout(function () {
            clearInterval(aniamteDelay);
        }, animateRestTime)
    }

    $scope.update = function (ctx, width, height) {
        var circle = {
            x: 80,
            y: 80,
            r: 77,
            lineWidth: 3,
            color: "#0686FE"
        }
        var moveStep = 0.000009;
        var angle = 0;
        var ox = circle.x;
        var oy = circle.y;
        var r = circle.r;

        ctx.clearRect(0, 0, width, height);

//		$scope.filterCheckAnimateTime += moveStep;
        angle = Math.PI * 2 * $scope.filterCheckAnimateTime;

        ctx.beginPath();
        ctx.lineWidth = circle.lineWidth;
        ctx.strokeStyle = circle.color;
        ctx.arc(ox, oy, circle.r, angle - 0.5 * Math.PI, Math.PI * 1.5, true);
        ctx.stroke();
    }
    $scope.filterCheckAnimate2 = function (animateId) {

        $scope.filterCheckAnimateTime = 0.00108;

        var aniamteDelay = 0;
        var width = 160;
        var height = 160;
        var animateTime = 100;
        var canvas = document.getElementById(animateId);
        var ctx = canvas.getContext("2d");

        canvas.width = width;
        canvas.height = height;
        $scope.filterCheckAnimateTime = 0;

        aniamteDelay = setInterval(function () {
            $scope.update2(ctx, width, height);
        }, animateTime);

        setTimeout(function () {
            clearInterval(aniamteDelay);
        }, 10000)
    }
    $scope.update2 = function (ctx, width, height) {
        var circle = {
            x: 80,
            y: 80,
            r: 77,
            lineWidth: 1,
            color: "#0769fc"
        }
        var moveStep = 0.0093;
        var angle = 0;
        var ox = circle.x;
        var oy = circle.y;
        var r = circle.r;

        ctx.clearRect(0, 0, width, height);

        $scope.filterCheckAnimateTime += moveStep;
        angle = Math.PI * 2 * $scope.filterCheckAnimateTime;

        ctx.beginPath();
        ctx.lineWidth = circle.lineWidth;
        ctx.strokeStyle = circle.color;
        ctx.arc(ox, oy, circle.r, angle - 0.5 * Math.PI, Math.PI * 1.5, true);
        ctx.stroke();
    }


    $scope.initQueryStrongPreventState = function () {
        $scope.acController.queryStrongPreventState();
        $scope.acController.queryStrongPreventValue();		//0406屏蔽
    }


    $scope.initQueryCalibrationState = function () {
        $scope.acController.queryCalibrationState();
        $scope.acController.queryCalibrationValue();			//0406屏蔽
    }


    //强力防霉
    $scope.startStrongPrevent = function () {
        if ($scope.deviceStatus.deviceRunningStatus || $scope.deviceStatus.deviceRunningStatus == undefined) {
            var functionParamers = {
                title: "提示",
                message: "亲，运行防霉会影响空调制冷、制热效果，请在关机后使用强力防霉功能。",
                btnText: "确定"
            };
            bridge.showAlert(functionParamers);
        } else {
            if (!$scope.curStrongPreventState) {
                $("#strongCanvas").css("display", "block");
                $("#strongPreventBg").addClass("preventBgImg").removeClass("preventBgImgShield");
                $scope.filterCheckAnimate('strongCanvas', 1198000);
                $scope.acController.startStrongPreventState();
            } else {
                $scope.acController.stopStrongPreventState();
            }
        }
    }

    //滤网校准
    $scope.startCalibration = function () {
        if ($scope.deviceStatus.deviceRunningStatus || $scope.deviceStatus.deviceRunningStatus == undefined) {
            var functionParamers = {
                title: "提示",
                message: "亲，运行校准会影响空调制冷、制热效果，请在关机后使用基准校准功能。",
                btnText: "确定"
            };
            bridge.showAlert(functionParamers);
        } else {
            if (!$scope.curCalibrationState) {
                $("#filterCanvas").css("display", "block");
                $scope.filterCheckAnimate('filterCanvas', 1198000);
                $scope.acController.startCalibrationState();
            } else {
                $scope.acController.stopCalibrationState();
            }
        }
    }

    //	安防功能
    $scope.securityFunction = function () {
        $scope.isSecurityStatus = $scope.deviceStatus.securityStatus;
        $(document).unbind('safePrevent::update::toggle::switch').bind('safePrevent::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                $scope.acController.controlSecurityStatus(data.currentVal);
            });
        });

        try {
            $scope.$broadcast('safePrevent::init::toggle::switch', {
                'currentVal': $scope.isSecurityStatus
            });
        } catch (e) {
        }
    }

    //	入侵消息推送
    $scope.invadeMessage = function () {
        $scope.hasIntrusionStatus = $scope.acController.dataManager.getIntrusionRemind();
        $(document).unbind('invadeFunc::update::toggle::switch').bind('invadeFunc::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                $scope.acController.controlSwitchIntrusionRemind(data.currentVal);
            });
        });

        try {
            $scope.$broadcast('invadeFunc::init::toggle::switch', {
                'currentVal': $scope.hasIntrusionStatus
            });
        } catch (e) {
        }
    }

    //	视频监控
    $scope.showVideo = function () {
        $scope.acController.controlVideoPlay();
    }

    //	智能控制
    $scope.intelControl = function () {
        $scope.isIntelligentControl = $scope.deviceStatus.intelligentControlStatus;
        if ($scope.isIntelligentControl) {
            $("#preventInvadeDiv").css("display", "block");
            $("#intelControlSpace").css("display", "block");
        } else {
            $("#preventInvadeDiv").css("display", "none");
            $("#intelControlSpace").css("display", "none");
        }

        $(document).unbind('intelManage::update::toggle::switch').bind('intelManage::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                $scope.acController.controlIntelligentStatus(data.currentVal);
                if (data.currentVal) {
                    $("#preventInvadeDiv").css("display", "block");
                    $("#intelControlSpace").css("display", "block");
                } else {
                    $("#preventInvadeDiv").css("display", "none");
                    $("#intelControlSpace").css("display", "none");
                }
            });
        });

        try {
            $scope.$broadcast('intelManage::init::toggle::switch', {
                'currentVal': $scope.isIntelligentControl
            });
        } catch (e) {
        }
    }

    //阶梯降温
    $scope.ladderControl = function () {
        $(document).unbind('ladderControlOnOff::update::toggle::switch').bind('ladderControlOnOff::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                if (!$scope.deviceStatus.deviceRunningStatus || $scope.deviceStatus.deviceRunningStatus == undefined) {
                    $scope.$broadcast('ladderControlOnOff::init::toggle::switch', {
                        'currentVal': false
                    });
                    $scope.timeoutPopUp("关机下健康降温不可用!");
//					var functionParamers = {
//						title: "提示",
//						message: "关机下健康降温不可用!",
//						btnText: "确定"
//					};
//					bridge.showAlert(functionParamers);
                } else {
                    if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool) {
                        $scope.$broadcast('ladderControlOnOff::init::toggle::switch', {
                            'currentVal': false
                        });
                        $scope.timeoutPopUp("健康降温只在制冷模式下有效!");
//						var functionParamers = {
//							title: "提示",
//							message: "健康降温只在制冷模式下有效!",
//							btnText: "确定"
//						};
//						bridge.showAlert(functionParamers);
                    } else {
                        $scope.acController.controlLadderControlStatus(data.currentVal);
                    }
                }
            });
        });
    }

    //手势识别开关机
    $scope.recognizeOnOff = function () {
        var recognizeDirectionStatus = 0;

        $scope.$broadcast('recognizeOnOff::init::toggle::switch', {
            'currentVal': $scope.isGestureRecognitionOnOff
        });
        $(document).unbind('recognizeOnOff::update::toggle::switch').bind('recognizeOnOff::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                if (!$scope.isGestureRecognitionOnOff) {
                    recognizeDirectionStatus = 0;
                } else {
                    recognizeDirectionStatus = $scope.isGestureRecognitionDirection;
                }

                $scope.acController.controlGestureRecognitionStatus(data.currentVal, recognizeDirectionStatus);

                $scope.$broadcast('recognizeDirectionBlow::init::toggle::switch', {
                    'currentVal': recognizeDirectionStatus
                });
            });
        });
    }

    //手势识别定向风
    $scope.recognizeDirection = function () {
        var recognizeOnOffStatus = 0;

        $scope.$broadcast('recognizeDirectionBlow::init::toggle::switch', {
            'currentVal': $scope.isGestureRecognitionDirection
        });
        $(document).unbind('recognizeDirectionBlow::update::toggle::switch').bind('recognizeDirectionBlow::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                if (!$scope.isGestureRecognitionDirection) {
                    recognizeOnOffStatus = 0;
                } else {
                    recognizeOnOffStatus = $scope.isGestureRecognitionOnOff;
                }

                $scope.acController.controlGestureRecognitionStatus(recognizeOnOffStatus, data.currentVal);

                $scope.$broadcast('recognizeOnOff::init::toggle::switch', {
                    'currentVal': recognizeOnOffStatus
                });
            });
        });
    }
    $scope.windBlowForFA100 = function () {
        if (!$scope.deviceStatus.deviceRunningStatus) {
            $scope.timeoutPopUp("关机状态下风吹人无效!");
        } else {
            if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool &&
                $scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat &&
                $scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeAuto) {
                $scope.timeoutPopUp("风吹人在抽湿模式和送风模式下无效!");
            } else {
                if ($scope.deviceStatus.windDirectionStatus == 1) {
                    $scope.windDirection = 0;
                } else if ($scope.deviceStatus.windDirectionStatus == 0 || $scope.deviceStatus.windDirectionStatus == 2) {
                    $scope.windDirection = 1;
                } else {
                    $scope.windDirection = 0;
                }
                $scope.isWindBlow = $scope.deviceStatus.windDirectionStatus == 1 ? true : false;
                $scope.acController.controlWindDirectionStatusOpenForFA100($scope.windDirection);
                if ($scope.windDirection == 1) {
                    $scope.acController.dataManager.getColdHotState().coldHotSwitch = 0;
                    $scope.deviceStatus.coldHotSwitch = 0;
                    $scope.coldHotSwitchActive = false;
                    $scope.deviceStatus.noWindFeel = false;
                    $scope.deviceStatus.upDownProduceWindStatus = 1;
                    $scope.deviceStatus.leftRighProducetWindStatus = 1;
                    $scope.upDownisActive = true;
                    $scope.leftRightisActive = true;
                    $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().softWindFeel = false;
                    $scope.deviceStatus.softWindFeelSwitchStatus = false;
                    $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().straightBlow = false;
                    $scope.deviceStatus.straightBlowStatus = false;
                    $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().windFeelingFA100 = false;
                    $scope.deviceStatus.windFeelingFA100tSwitchStatus = false;
                    $scope.acController.dataManager.getDeviceWindAvoidStatus().windAvoid = false;
                    $scope.deviceStatus.windAvoidStatus = false;
                }
            }
        }
    }
    $scope.windCloseForFA100 = function () {
        if (!$scope.deviceStatus.deviceRunningStatus) {
            $scope.timeoutPopUp("关机状态下风避人无效!");
        } else {
            if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool &&
                $scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat &&
                $scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeAuto) {
                $scope.timeoutPopUp("风避人在抽湿模式和送风模式下无效!");
            } else {
                var windAvoid = $scope.acController.dataManager.getDeviceWindAvoidStatus().windAvoid;
//		if($scope.deviceStatus.windDirectionStatus == 2){
//			$scope.windDirection =0;
//		}else if($scope.deviceStatus.windDirectionStatus == 0||$scope.deviceStatus.windDirectionStatus == 1){
//			$scope.windDirection =2;
//		}else{
//			$scope.windDirection =0;
//		}
                $scope.acController.controlWindDirectionStatuscloseForFA100(!windAvoid);
                if (!windAvoid) {
                    $scope.acController.dataManager.getColdHotState().coldHotSwitch = 0;
                    $scope.deviceStatus.coldHotSwitch = 0;
                    $scope.coldHotSwitchActive = false;
                    $scope.deviceStatus.noWindFeel = false;
                    $scope.deviceStatus.upDownProduceWindStatus = 0;
                    $scope.deviceStatus.leftRighProducetWindStatus = 0;
                    $scope.upDownisActive = false;
                    $scope.leftRightisActive = false;
                    $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().softWindFeel = false;
                    $scope.deviceStatus.softWindFeelSwitchStatus = false;
                    $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().straightBlow = false;
                    $scope.deviceStatus.straightBlowStatus = false;
                    $scope.acController.dataManager.getDeviceSoftWindFeelingStatus().windFeelingFA100 = false;
                    $scope.deviceStatus.windFeelingFA100tSwitchStatus = false;
                    $scope.deviceStatus.windDirectionStatus = 0;
                    $scope.isWindBlow = false;
                    $scope.deviceStatus.isWindBlow = false;
                }
            }
        }
    }
    //	风吹人
    $scope.windBlow = function () {
        var windDirection = 0;

        $scope.$broadcast('windBlow::init::toggle::switch', {
            'currentVal': $scope.isWindBlow
        });

        $(document).unbind('windBlow::update::toggle::switch').bind('windBlow::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                if (!$scope.isWindBlow) {
                    $scope.isWindBlow = true;
                    $scope.isWindClose = false;
                    windDirection = 1;
                    $scope.$broadcast('windClose::init::toggle::switch', {
                        'currentVal': false
                    });
                } else {
                    $scope.isWindBlow = false;
                    $scope.isWindClose = true;
                    windDirection = 2;
                    $scope.$broadcast('windClose::init::toggle::switch', {
                        'currentVal': true
                    });
                }

                $scope.acController.controlWindDirectionStatus(windDirection);
//				if (windDirection == 1) {
//					$scope.$broadcast('windClose::init::toggle::switch', {
//						'currentVal': false
//					});
//				} else {
//					$scope.$broadcast('windClose::init::toggle::switch', {
//						'currentVal': true
//					});
//				}
            });
        });

    }

    //	风避人
    $scope.windClose = function () {
        var windDirection = 0;

        $scope.$broadcast('windClose::init::toggle::switch', {
            'currentVal': $scope.isWindClose
        });

        $(document).unbind('windClose::update::toggle::switch').bind('windClose::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                if (!$scope.isWindClose) {
                    $scope.isWindClose = true;
                    $scope.isWindBlow = false;
                    windDirection = 2;
                    $scope.$broadcast('windBlow::init::toggle::switch', {
                        'currentVal': false
                    });
                } else {
                    $scope.isWindClose = false;
                    $scope.isWindBlow = true;
                    windDirection = 1;
                    $scope.$broadcast('windBlow::init::toggle::switch', {
                        'currentVal': true
                    });
                }

                $scope.acController.controlWindDirectionStatus(windDirection);
//				if (windDirection == 2) {
//					$scope.$broadcast('windBlow::init::toggle::switch', {
//						'currentVal': false
//					});
//				} else {
//					$scope.$broadcast('windBlow::init::toggle::switch', {
//						'currentVal': true
//					});
//				}
            });
        });
    }

    //	无人自动节能
    $scope.energySaving = function () {
        $scope.isenergySavingStatus = $scope.deviceStatus.energySavingStatus;

        $(document).unbind('energySaving::update::toggle::switch').bind('energySaving::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                $scope.acController.controlEnergySavingStatus(data.currentVal, 0, 0, 0, 0, 0);
            });
        });

        try {
            $scope.$broadcast('energySaving::init::toggle::switch', {
                'currentVal': $scope.isenergySavingStatus
            });
        } catch (e) {
        }
    };
    //	智能风
    $scope.windSpeedSet = function () {
        $scope.isWindSpeed = $scope.deviceStatus.windSpeedStatus;

        $(document).unbind('intelWind::update::toggle::switch').bind('intelWind::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                $scope.acController.controlWindSpeedStatus(data.currentVal);
            });
        });

        try {
            $scope.$broadcast('intelWind::init::toggle::switch', {
                'currentVal': $scope.isWindSpeed
            });
        } catch (e) {
        }
    };

    //控制自学习是否允许打开的开关
    $scope.controlSelfLearningPermissionStatus = function () {
        $scope.$broadcast('selfLearningPermission::init::toggle::switch', {
            'currentVal': $scope.selfLearningStatus
        });

        $(document).unbind('selfLearningPermission::update::toggle::switch').bind('selfLearningPermission::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                $scope.acController.controlSwitchSelfLearningStatus(data.currentVal);
            });
        });
    }

    //控制自学习是否开启
    $scope.controlSelfLearningStatus = function () {
        if ($scope.selfLearningStatus) {
            $scope.acController.controlSwitchSelfLearningStatus(false);
        } else {
            $scope.acController.controlSwitchSelfLearningStatus(true);
        }
    }

    $scope.querySelfLearningTimeSlot = function () {
        $scope.acController.querySwitchSelfLearningTimeSlot();
    }

    $scope.querySelfLearningStatus = function () {
        $scope.acController.querySwitchSelfLearningStatus();
    }

    $scope.querySelfLearningCurve = function () {
        $scope.acController.querySelfLearningCurve();
    }

    $scope.querySelfLearningValueList = function () {
        bridge.logToIOS("initquery=" + (new Date()));
        $scope.appRuntime.userActionselected = new Array();
        for (var i = 0; i < 10; i++) {
            if (i == 0) {
                $scope.appRuntime.userActionselected.push(true);
            } else {
                $scope.appRuntime.userActionselected.push(false);
            }
        }

        // $.event.trigger("refreshSelfLearningViewValueList", {});
        $scope.acController.querySelfLearningValueList();
    }

    //自学习曲线
    $scope.initSelfLearning = function () {
        $scope.appRuntime.selfLearningLabel = new Array();
        var start = 0;//$scope.selfLearningSlotStart;
        var stop = 24;//$scope.selfLearningSlotStop - 1;
        for (var i = start; i <= stop; i++) {
            $scope.appRuntime.selfLearningLabel.push(i);
        }
        var lineChartData = {
            labels: $scope.appRuntime.selfLearningLabel,
            datasets: [{
                label: null,
                lineTension: 0,
                borderWidth: 1,
                backgroundColor: "rgba(51,153,255,0.2)",
                borderColor: "rgba(51,153,255,1)",
                pointRadius: 0,
                data: $scope.appRuntime.selfLearningTemp[0]
            }]
        };
        $scope.initScrollLineChart("temperature-study-result-wrapper", lineChartData);

        var lineChartDataWind = {
            labels: $scope.appRuntime.selfLearningLabel,
            datasets: [{
                label: null,
                borderWidth: 1,
                lineTension: 0,
                backgroundColor: "rgba(255,135,46,0.5)",
                borderColor: "rgba(255,135,46,1)",
                pointRadius: 0,
                data: $scope.appRuntime.selfLearningWindspeed[0]
            }]
        };
        $scope.initScrollLineChart("wind-study-result-wrapper", lineChartDataWind, true);
    };

    $scope.initUserActionAnalyse = function (isWindSpeedType) {
        $scope.appRuntime.selfLearningLabel = new Array();
        var start = 0;
        var stop = 24;
        var defaultXAxes = [],
            days = isWindSpeedType ? $scope.appRuntime.selfLearningValueWindspeed.length : $scope.appRuntime.selfLearningValueTemp.length;
        for (var i = start; i <= stop; i++) {
            defaultXAxes.push(i);
        }

        /*初始化*/
        var lineChartData = {
            labels: defaultXAxes
        };
        if (!isWindSpeedType) {
            lineChartData.datasets = [{
                label: null,
                lineTension: 0,
                borderWidth: 1,
                backgroundColor: "rgba(51,153,255,0.2)",
                borderColor: "rgba(51,153,255,1)",
                pointRadius: 0,
                data: $scope.appRuntime.selfLearningValueTemp[0]
            }];
        } else {
            lineChartData.datasets = [{
                label: null,
                borderWidth: 1,
                lineTension: 0,
                backgroundColor: "rgba(255,135,46,0.5)",
                borderColor: "rgba(255,135,46,1)",
                pointRadius: 0,
                data: $scope.appRuntime.selfLearningValueWindspeed[0]
            }];
        }

        for (var i = 0; i < days; i++) {
            if (!isWindSpeedType) {
                lineChartData.datasets[0].data = $scope.appRuntime.selfLearningValueTemp[i];
                console.log(lineChartData.datasets[0].data);
                $scope.initScrollLineChart("dynamic-user-chart-" + i, lineChartData);
            } else {
                lineChartData.datasets[0].data = $scope.appRuntime.selfLearningValueWindspeed[i];
                $scope.initScrollLineChart("dynamic-user-chart-wind-" + i, lineChartData, true);
            }
        }
    };

    $scope.initScrollLineChart = function (container, datasets, isWindSpeedType) {
        var chartScroll = new IScroll('#' + container, {
            scrollX: true,
            scrollY: false,
            click: false,
            mouseWheel: true,
            preventDefault: false
        });

        var ctx2 = $("#" + container + " canvas")[0].getContext("2d");
        var lineSetting = {
            type: 'line',
            data: datasets,
            options: {
                responsive: false,
                legend: {
                    display: false
                },
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        };
        if (isWindSpeedType) {
            lineSetting.options.scales.yAxes[0].ticks.max = 100;
        }
        window.myLine = new Chart(ctx2, lineSetting);
        // window.myLine = new Chart(ctx2).Line(datasets, {
        // 	responsive: false,
        // 	animation: true,
        // 	bezierCurve : false,
        // 	scaleShowLabels : true,
        // 	scaleLabel : "<%=value > 100 ? '自动风' : value %>",
        // 	pointDot : false,
        // 	datasetStrokeWidth:1,
        // 	tooltipTemplate: function (d) {
        // 		return d.label + ":00 - "+
        // 	}
        // });
       if(coreHelper.isAndroid()){
        var startPointY = {};
        var endPointY = {};
        document.addEventListener('touchstart', function (e) {
            startPointY = e.changedTouches[0].pageY;
        }, {
            capture: true,
            passive: false
        });

        document.addEventListener('touchmove', function (e) {
            endPointY = e.changedTouches[0].pageY;

            //if (($(e.target)[0].tagName === 'svg') || ($(e.target)[0].tagName === 'path')) {
            if (Math.abs(startPointY - endPointY) < 50) {
                e.preventDefault();
            }
            //}
        }, {
            capture: true,
            passive: false
        });
        }
    };
    //过滤网校准
    $scope.screenCalibrationStart = function () {
        if (!$scope.deviceStatus.deviceRunningStatus) {
            $scope.timeoutPopUp("关机状态下不可校准!");
        } else {
            $scope.acController.controlScreenCalibration();
            $scope.noScreenCalibration = false;//未校准
            $scope.screenCalibrationIng = true;//正在校准
            $scope.screenCalibrationStatic = false;//静态校准
            $scope.screenCalibrationFail = false;//校准失败
            $scope.noRuning = false;//空调未开机，无法校准
            $scope.screenCalibrationSuccessful = false;//校准成功
        }
    }
    $scope.getScreenCalibrationProgress = function () {
        $scope.screenCalibrationStatus = parseInt($scope.acController.dataManager.getScreenCalibration().screenCalibrationStatus);
        switch ($scope.screenCalibrationStatus) {
            case 0:
                $scope.noScreenCalibration = true;//未校准
                $scope.screenCalibrationIng = false;//正在校准
                $scope.screenCalibrationStatic = false;//静态校准
                $scope.screenCalibrationFail = false;//校准失败
                $scope.noRuning = false;//空调未开机，无法校准
                $scope.screenCalibrationSuccessful = false;//校准成功
                $scope.interval = setInterval(function () {
                    $scope.acController.screenCalibrationStatus();
                    $scope.$apply();
                }, 3000);
                break;
            case 1:
                $scope.noScreenCalibration = false;//未校准
                $scope.screenCalibrationIng = true;//正在校准
                $scope.screenCalibrationStatic = false;//静态校准
                $scope.screenCalibrationFail = false;//校准失败
                $scope.noRuning = false;//空调未开机，无法校准
                $scope.screenCalibrationSuccessful = false;//校准成功
                $scope.interval = setInterval(function () {
                    $scope.acController.screenCalibrationStatus();
                    $scope.$apply();
                }, 3000);
                break;
            case 2:
                $scope.noScreenCalibration = false;//未校准
                $scope.screenCalibrationIng = false;//正在校准
                $scope.screenCalibrationStatic = false;//静态校准
                $scope.screenCalibrationFail = true;//校准失败
                $scope.noRuning = false;//空调未开机，无法校准
                $scope.screenCalibrationSuccessful = false;//校准成功
                break;
            case 3:
                $scope.noScreenCalibration = false;//未校准
                $scope.screenCalibrationIng = false;//正在校准
                $scope.screenCalibrationStatic = false;//静态校准
                $scope.screenCalibrationFail = false;//校准失败
                $scope.noRuning = true;//空调未开机，无法校准
                $scope.screenCalibrationSuccessful = false;//校准成功
                $scope.interval = setInterval(function () {
                    $scope.acController.screenCalibrationStatus();
                    $scope.$apply();
                }, 500);
                break;
            case 4:
                $scope.noScreenCalibration = false;//未校准
                $scope.screenCalibrationIng = false;//正在校准
                $scope.screenCalibrationStatic = false;//静态校准
                $scope.screenCalibrationFail = false;//校准失败
                $scope.noRuning = false;//空调未开机，无法校准
                $scope.screenCalibrationSuccessful = true;//校准成功
                $scope.interval = setInterval(function () {
                    $scope.acController.screenCalibrationStatus();
                    $scope.$apply();
                }, 3000);
                break;
        }
    }

    //	yuyin升级
    $scope.updateToYuyinVersion = function () {
        $scope.acController.startUpdateYuyinVersion();
        $scope.yuyinUpdateBtn = false;//升级
        $scope.updateYuyinProgressAnimate = true;//正在升级
        $scope.updatedYuyin = false;//升级完成
        $scope.updateYuyinProgressError = false;//升级失败
        $scope.isUpdatingYuyin = false;//静态正在升级
        $scope.newYuyinUpdateBtn = false;//已最新

    }
    $scope.getYuyinUpdateProgress = function () {
        //设备状态
        $scope.yuyinDeviceStatus = $scope.acController.dataManager.getYuyinVersion().yuyinDeviceStatus;
        //目前设备版本
        $scope.yuyinVersionCurrentVersionNum = $scope.acController.dataManager.getYuyinVersion().yuyinVersionCurrentVersion;
        //设备已下载版本
        $scope.yuyinUpdateVersionNum = $scope.acController.dataManager.getYuyinVersion().yuyinUpdateVersion;
        if (($scope.yuyinVersionCurrentVersionNum <= $scope.yuyinUpdateVersionNum) && $scope.yuyinDeviceStatus == 2) {
            $scope.yuyinUpdateBtn = true;//升级
            $scope.updateYuyinProgressAnimate = false;//正在升级
            $scope.updatedYuyin = false;//升级完成
            $scope.updateYuyinProgressError = false;//升级失败
            $scope.isUpdatingYuyin = false;//静态正在升级
            $scope.newYuyinUpdateBtn = false;//已最新
        } else {
            //目前设备版本
            $scope.yuyinVersionCurrentVersionNum = $scope.acController.dataManager.getYuyinVersion().yuyinVersionCurrentVersion;
            //设备已下载版本
            $scope.yuyinUpdateVersionNum = $scope.acController.dataManager.getYuyinVersion().yuyinUpdateVersion;
            //设备状态
            $scope.yuyinDeviceStatus = $scope.acController.dataManager.getYuyinVersion().yuyinDeviceStatus;
            if (($scope.yuyinUpdateVersionNum == "" ||
                    $scope.yuyinUpdateVersionNum == -1 ||
                    $scope.yuyinUpdateVersionNum == $scope.yuyinVersionCurrentVersionNum) && (
                    $scope.yuyinDeviceStatus != 5 &&
                    $scope.yuyinDeviceStatus != 6)) {
                $scope.yuyinUpdateVersionNum = $scope.yuyinVersionCurrentVersionNum;
                $scope.yuyinUpdateBtn = false;//升级
                $scope.updateYuyinProgressAnimate = false;//正在升级
                $scope.updatedYuyin = false;//升级完成
                $scope.updateYuyinProgressError = false;//升级失败
                $scope.isUpdatingYuyin = false;//静态正在升级
                $scope.newYuyinUpdateBtn = true;//已最新
            } else {
                switch ($scope.yuyinDeviceStatus) {
                    case 0:
                        $scope.yuyinUpdateBtn = false;//升级
                        $scope.updateYuyinProgressAnimate = false;//正在升级
                        $scope.updatedYuyin = false;//升级完成
                        $scope.updateYuyinProgressError = false;//升级失败
                        $scope.isUpdatingYuyin = false;//静态正在升级
                        $scope.newYuyinUpdateBtn = true;//已最新
                        break;
                    case 1:
                        $scope.yuyinUpdateBtn = false;//升级
                        $scope.updateYuyinProgressAnimate = false;//正在升级
                        $scope.updatedYuyin = false;//升级完成
                        $scope.updateYuyinProgressError = false;//升级失败
                        $scope.isUpdatingYuyin = false;//静态正在升级
                        $scope.newYuyinUpdateBtn = true;//已最新
                        break;
                    case 2:
                        $scope.yuyinUpdateBtn = true;//升级
                        $scope.updateYuyinProgressAnimate = false;//正在升级
                        $scope.updatedYuyin = false;//升级完成
                        $scope.updateYuyinProgressError = false;//升级失败
                        $scope.isUpdatingYuyin = false;//静态正在升级
                        $scope.newYuyinUpdateBtn = false;//已最新
                        break;
                    case 3:
                        $scope.yuyinUpdateBtn = false;//升级
                        $scope.updateYuyinProgressAnimate = false;//正在升级
                        $scope.updatedYuyin = false;//升级完成
                        $scope.updateYuyinProgressError = false;//升级失败
                        $scope.isUpdatingYuyin = false;//静态正在升级
                        $scope.newYuyinUpdateBtn = true//已最新
                        break;
                    case 4:
                        $scope.yuyinUpdateBtn = false;//升级
                        $scope.updateYuyinProgressAnimate = false;//正在升级
                        $scope.updatedYuyin = false;//升级完成
                        $scope.updateYuyinProgressError = false;//升级失败
                        $scope.isUpdatingYuyin = true;//静态正在升级
                        $scope.newYuyinUpdateBtn = false;//已最新
                        $scope.interval = setInterval(function () {
                            $scope.acController.getYuyinVersion();
                            $scope.$apply();
                        }, 5000);
                        break;
                    case 5:
                        $scope.yuyinUpdateBtn = false;//升级
                        $scope.updateYuyinProgressAnimate = false;//正在升级
                        $scope.updatedYuyin = true;//升级完成
                        $scope.updateYuyinProgressError = false;//升级失败
                        $scope.isUpdatingYuyin = false;//静态正在升级
                        $scope.newYuyinUpdateBtn = false;//已最新
                        break;
                    case 6:
                        $scope.yuyinUpdateBtn = false;//升级
                        $scope.updateYuyinProgressAnimate = false;//正在升级
                        $scope.updatedYuyin = false;//升级完成
                        $scope.updateYuyinProgressError = true;//升级失败
                        $scope.isUpdatingYuyin = false;//静态正在升级
                        $scope.newYuyinUpdateBtn = false;//已最新
                        break;
                }
            }
        }
    };

    //预冷预热
    $scope.preColdHeatControl = function () {
        $(document).unbind('preColdHeat::update::toggle::switch').bind('preColdHeat::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool &&
                    $scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat) {
                    $scope.timeoutPopUp("预冷预热只在制冷或制热模式下有效!");
                    $scope.$broadcast('preColdHeat::init::toggle::switch', {
                        'currentVal': false
                    });
                } else {
                    $scope.acController.controlSwitchPreColdHeat(data.currentVal);
                }
            });
        });

//		$scope.isPreColdHeatOpen = localStorage.getItem("ACDeviceReadyColdOrHot") == 1 ? true : false;
        $scope.isPreColdHeatOpen = $scope.deviceStatus.readyColdOrHot;
        $scope.$broadcast('preColdHeat::init::toggle::switch', {
            'currentVal': $scope.isPreColdHeatOpen
        });
    }


    $scope.myWristControl = function () {
        $scope.isAutoOnStatus = $scope.deviceStatus.autoOnStatus;
        $(document).unbind('autoOn::update::toggle::switch').bind('autoOn::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                $scope.acController.controlAutoOn(data.currentVal);
            });
        });

        $scope.$broadcast('autoOn::init::toggle::switch', {
            'currentVal': $scope.isAutoOnStatus
        });

        $scope.isAutoOffStatus = $scope.deviceStatus.autoOffStatus;
        $(document).unbind('autoOff::update::toggle::switch').bind('autoOff::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                $scope.acController.controlAutoOff(data.currentVal);
            });
        });
        $scope.$broadcast('autoOff::init::toggle::switch', {
            'currentVal': $scope.isAutoOffStatus
        });
    }

    //搜索小米手环
    $scope.searchWristband = function () {
        $scope.redirectPage('add-wristband', 'in');
        coreHelper.delayExecute(function () {
            $scope.acController.searchWristbandList();
        }, 500);
        // $scope.acController.searchWristbandList();
    }

    //搜索小米手环
    $scope.searchWristbandRefresh = function () {
        $scope.wristhandItems = [];
        $scope.filterCheckAnimate2('addWristbandCircle');
        $("#searchWristbandBg").removeClass("searchwristbandBgImgFinish").addClass("addwristbandBgImg");
        $scope.$apply();
        $scope.acController.searchWristbandList();
    }

    //绑定小米手环
    $scope.bindWristband = function (wristbandIndex) {
        $scope.acController.bindWristbandData($scope.wristhandItems[wristbandIndex]);
    }

    //删除小米手环
    $scope.delWristbandData = function () {
        $scope.acController.delWristbandData();
    }

    //点击我的手环菜单，根据是否绑定及登录进入相应界面
    $scope.clickWristbandMenu = function () {
        $scope.acController.ifHasBindWristbandData();
    }

    //小米智能曲线
    $scope.executeIntelligentCurve = function () {
        $scope.acController.dataManager.selectInteligentCurve();
        $scope.acController.controlSwitchSleep(!$scope.sleepCurveInteligentStatus);
    }

    //绑定蓝牙模块MAC地址，调用升级接口
    $scope.bindBluetoothMAC = function (bluetoothMacIndex) {
//		var deviceBluetoothMAC = "88:0F:10:C0:23:BC";			//0298
//		var deviceBluetoothMAC = "E8:B8:52:5B:8E:86";			//研究院空调
        var SNStr = bridge.getCurrentDevSN();
        var ifClickBluetoothUpgrade = localStorage.getItem("ifClickBluetoothUpdate" + SNStr);

        $scope.bluetoothMode2 = false;		//当前主机模式
        $scope.bluetoothMode1 = false;		//当前从机模式
//		if (!ifClickBluetoothUpgrade) {
        $scope.MACItemsStatus[bluetoothMacIndex] = "升级中";
        $scope.currentUpgradeIndex = bluetoothMacIndex;

        $scope.updateProgressError = false;			//升级错误
        $scope.updateBluetoothProgressAnimate = true;		//升级动画
        $scope.updatedBluetooth = false;						//升级完成
        $scope.bluetoothUpdateBtn = false;			//升级按钮
        $scope.newBluetoothUpdateBtn = false;		//已最新提示
        $scope.isUpdatingBluetooth = true;					//静态正在升级

        var SNStr = bridge.getCurrentDevSN();
        localStorage.setItem("ifClickBluetoothUpdate" + SNStr, true);
        $scope.acController.updateBluetoothSoftVersion($scope.MACItems[bluetoothMacIndex]);
//		}
    }


    //设置从机模式
    $scope.setBluetoothModeSlave = function () {
        $scope.MACItems = [];
        $scope.MACItemsStatus = [];
        $scope.acController.setBluetoothMode(1);
    }

    //搜索蓝牙模块MAC地址
    $scope.searchBluetoothMac = function () {
        $scope.MACItems = [];
        $scope.MACItemsStatus = [];
        $scope.acController.getBluetoothMac();
    }

    //升级蓝牙模块版本
    $scope.updateBluetoothVersion = function () {
        $scope.MACItems = [];
        $scope.MACItemsStatus = [];
        if ($scope.currentBluetoothMode == 2) {
            $scope.acController.setBluetoothMode(1);
        } else {
            $scope.acController.getBluetoothMac();
        }
    }

    //蓝牙模块升级进度更新
    $scope.updateUpgradeProgress = function (deg) {
        $scope.setProgressValue(deg, 100, 50, "bluetooth_updateProgressAnimate");
    }

    //动态设置动画进度
    $scope.setProgressValue = function (startValue, endValue, proTime, animationName) {
        var keyframe = document.styleSheets[8];
        var proRuleWebkit = "";

//		if (startValue < 80) {
//			proRuleWebkit = "@-webkit-keyframes "+animationName+"{"
//							+"0% {width:0px;} "
//							+"10%{width:"+ (startValue * 0.75) +"px;}"
//							+"100%{width:"+ (startValue * 0.8) +"px;}}";
//		} else {
//			proRuleWebkit = "@-webkit-keyframes "+animationName+"{"
//							+"0% {width:0px;} "
//							+"10%{width:"+(startValue * 0.75) +"px;}"
//							+"100%{width:70px;}}";
//		}
//		keyframe.insertRule(proRuleWebkit,0);
//		var divRule = ".bluetooth_updateProgressAnimate {-webkit-animation:"+animationName+" "+proTime+"s linear 0s normal forwards;}"
//		keyframe.insertRule(divRule,1);

        if (startValue > 0) {
            proRuleWebkit = "@-webkit-keyframes " + animationName + "{"
                + "0% {width:0px;} "
                + "10%{width:" + (startValue * 0.75) + "px;}"
                + "100%{width:70px;}}";


            keyframe.insertRule(proRuleWebkit, 0);
            var divRule = ".bluetooth_updateProgressAnimate {-webkit-animation:" + animationName + " " + proTime + "s linear 0s normal forwards;}"
            keyframe.insertRule(divRule, 1);
        }

//		var proRule = "";
//		if (startValue < 80) {
//			proRule = "@-o-keyframes "+animationName+"{"
//						+"0% {width:0px;} "
//						+"10%{width:"+(startValue * 0.75) +"px;}"
//						+"100%{width:"+(startValue * 0.8) +"px;}}";
//		} else{
//			proRule = "@-o-keyframes "+animationName+"{"
//						+"0% {width:0px;} "
//						+"10%{width:"+(startValue * 0.75) +"px;}"
//						+"100%{width:70px;}}";
//		}
//		keyframe.insertRule(proRule,2);
//		var divRule = ".bluetooth_updateProgressAnimate {-o-animation:"+animationName+" "+proTime+"s linear 0s normal forwards;}"
//		keyframe.insertRule(divRule,3);

    }
    //防冷风
    $scope.flf = function () {
        $scope.isColdWind = $scope.acController.dataManager.getDeviceColdWindStatus().coldWind;
        if ($scope.isColdWind == 1) {
            $scope.isColdWind = true;
        } else {
            $scope.isColdWind = false;
        }
        $scope.$broadcast('preventColdWind::init::toggle::switch', {
            'currentVal': $scope.isColdWind
        });
        $(document).unbind('preventColdWind::update::toggle::switch').bind('preventColdWind::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                if (data.currentVal) {
                    $scope.acController.dataManager.getDeviceColdWindStatus().coldWind = 1;
                } else {
                    $scope.acController.dataManager.getDeviceColdWindStatus().coldWind = 0;
                }
                $scope.acController.controlColdWindStatus();
            });
        });
    }
    //以色列功能
    $scope.shabbatSwitch = function () {
        $scope.isShabbatStatus = $scope.deviceStatus.shabbatStatus;
        $scope.$broadcast('shabbatPlay::init::toggle::switch', {
            'currentVal': $scope.isShabbatStatus
        });
        $(document).unbind('shabbatPlay::update::toggle::switch').bind('shabbatPlay::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                $scope.acController.controlShabbat(!$scope.isShabbatStatus);
            });
        });
    }
    //清除尘满时间
    $scope.controlScavengingFlowerRunningTime = function () {
        $scope.acController.controlScavengingFlowerRunningTime(true);
    }
    //天气播报
    $scope.weatherReportbb = function () {
        $scope.isWeatherReport = $scope.acController.dataManager.getDeviceWeatherReportStatus().weatherReport;
        if ($scope.isWeatherReport == 1) {
            $scope.isWeatherReport = true;
        } else {
            $scope.isWeatherReport = false;
        }
        $scope.$broadcast('weatherReport::init::toggle::switch', {
            'currentVal': $scope.isWeatherReport
        });
        $(document).unbind('weatherReport::update::toggle::switch').bind('weatherReport::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                if (data.currentVal) {
                    $scope.acController.dataManager.getDeviceWeatherReportStatus().weatherReport = 1;
                } else {
                    $scope.acController.dataManager.getDeviceWeatherReportStatus().weatherReport = 0;
                }
                $scope.acController.controlWeatherReportStatus();
            });
        });
    }
    //语音播报
    $scope.yybb = function () {
        $scope.isBroadcast = $scope.acController.dataManager.getVoiceState().voiceBroadcastStatus;
        if ($scope.isBroadcast == 3) {
            $scope.isBroadcast = true;
        } else {
            $scope.isBroadcast = false;
        }
        $scope.$broadcast('soundPlay::init::toggle::switch', {
            'currentVal': $scope.isBroadcast
        });
//		if($scope.isBroadcast){
//			$("#preventInvadeDiv1").css("display","block");
//		} else {
//			$("#preventInvadeDiv1").css("display","none");
//		}

        $(document).unbind('soundPlay::update::toggle::switch').bind('soundPlay::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
//				if(data.currentVal){
//					$scope.acController.dataManager.getVoiceState().voiceBroadcastStatus = 3;
//					$("#preventInvadeDiv1").css("display","block");
//				} else {
//					$scope.acController.dataManager.getVoiceState().voiceBroadcastStatus = 2;
//					$("#preventInvadeDiv1").css("display","none");
//				}
                $scope.acController.controlVoiceStatus();
            });
        });
    }
    //自动音量
    $scope.zdyl = function () {
        $scope.isAtuoVolume = $scope.acController.dataManager.getVolumeState().volumeControlType;
        if ($scope.isAtuoVolume == 1) {
            $scope.isAtuoVolume = true;
        } else if ($scope.isAtuoVolume == 2) {
            $scope.isAtuoVolume = false;
        }
        $scope.$broadcast('autoPlay::init::toggle::switch', {
            'currentVal': $scope.isAtuoVolume
        });
        $(document).unbind('autoPlay::update::toggle::switch').bind('autoPlay::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                if (data.currentVal) {
                    $scope.$broadcast('slider:control:for:soundValue:disable', {});
                    $scope.acController.dataManager.getVolumeState().volumeControlType = 1;

                } else {

                    $scope.$broadcast('slider:control:for:soundValue:enable', {});
                    $scope.acController.dataManager.getVolumeState().volumeControlType = 2;
                }
                $scope.acController.controlVolumeStatus();
            });
        });
    }
    //唤醒词
    $scope.hxc = function (awaken) {
        $scope.acController.dataManager.getVoiceLocalState().awakenStatusLocal = awaken;
    };
    //上电播报
    $scope.shangdian = function () {
        var initialPowerBroadcastSwitch = $scope.acController.dataManager.getVoiceState().initialPowerBroadcastSwitch;
        var sdbb = 0xff;
        if (initialPowerBroadcastSwitch == 0) {
            sdbb = 0
        }
        else if (initialPowerBroadcastSwitch == 1) {
            sdbb = 1
        }
    }
    //友情播报
    $scope.youqiang = function () {
        var friendshipBroadcastSwitch = $scope.acController.dataManager.getVoiceState().friendshipBroadcastSwitch;
        var yqbb = 0xff;
        if (friendshipBroadcastSwitch == 0) {
            yqbb = 0
        }
        else if (friendshipBroadcastSwitch == 1) {
            yqbb = 1
        }
    }
    //安全播报开关
    $scope.anquan = function () {
        var safetyBroadcastSwitch = $scope.acController.dataManager.getVoiceState().safetyBroadcastSwitch;
        var aqbb = 0xff;
        if (safetyBroadcastSwitch == 0) {
            aqbb = 0
        }
        else if (safetyBroadcastSwitch == 1) {
            aqbb = 1
        }
    }
    //天气预报开关
    $scope.tianqi = function () {
        var weatherBroadcastSwitch = $scope.acController.dataManager.getVoiceState().weatherBroadcastSwitch;
        var aqbb = 0xff;
        if (weatherBroadcastSwitch == 0) {
            tqbb = 0
        }
        else if (weatherBroadcastSwitch == 1) {
            tqbb = 1
        }
    }
    //维护信息播报
    $scope.weihu = function () {
        var informationBroadcast = $scope.acController.dataManager.getVoiceState().informationBroadcast;
        var whxxbb = 0xff;
        if (informationBroadcast == 0) {
            tqbb = 0
        }
        else if (informationBroadcast == 1) {
            whxxbb = 1
        }
    }
    $scope.getVoiceData = function () {
        $scope.voiceStatus = $scope.acController.dataManager.getVoiceState();
        $scope.voice.voiceSwitch = $scope.voiceStatus.voiceSwitch;
    };
    //语音控制
    $scope.voiceControl = function () {
        $scope.acController.controlVoiceStatus();
    };
    //音量控制
    $scope.VolumeControl = function () {
        $scope.acController.controlVolumeStatus();
    };

    //冷热感控制
    $scope.coldHotControl = function () {
        $scope.acController.controlColdHotStatus();
        $scope.acController.controlColdHotStatus1();
    };
    //iq
    //语音：唤醒词
    $scope.chooseWakeUpWordFst = function () {
        $scope.wakeUpWordFstChecked = true;
        $scope.wakeUpWordSecChecked = false;
        $scope.wakeUpWordTrdChecked = false;
        $scope.hxc(0);
        $scope.acController.controlVoiceStatus();
    }

    $scope.chooseWakeUpWordSec = function () {
        $scope.wakeUpWordFstChecked = false;
        $scope.wakeUpWordSecChecked = true;
        $scope.wakeUpWordTrdChecked = false;
        $scope.hxc(1);
        $scope.acController.controlVoiceStatus();
    }

    $scope.chooseWakeUpWordTrd = function () {
        $scope.wakeUpWordFstChecked = false;
        $scope.wakeUpWordSecChecked = false;
        $scope.wakeUpWordTrdChecked = true;
        $scope.hxc(2);
        $scope.acController.controlVoiceStatus();
    }

    //语音：播报声调
    $scope.chooseWakeUpToneFst = function () {
        $scope.wakeUpToneFstChecked = true;
        $scope.wakeUpToneSecChecked = false;
        $scope.acController.dataManager.getVoiceState().toneStatus = 2;
        $scope.acController.controlVoiceStatus();
    };

    $scope.chooseWakeUpToneSec = function () {
        $scope.wakeUpToneFstChecked = false;
        $scope.wakeUpToneSecChecked = true;
        $scope.acController.dataManager.getVoiceState().toneStatus = 1;
        $scope.acController.controlVoiceStatus();
    };

    //语音：识别限时
    $scope.chooseWakeUpTimeFst = function () {
        $scope.wakeUpTimeFstChecked = true;
        $scope.wakeUpTimeSecChecked = false;
        $scope.wakeUpTimeTrdChecked = false;
        $scope.wakeUpTimeFourChecked = false;
        $scope.wakeUpTimeFifthChecked = false;
        $scope.acController.dataManager.getVoiceState().voiceTimeLength = 10;
        $scope.acController.controlVoiceStatus();
    };

    $scope.chooseWakeUpTimeSec = function () {
        $scope.wakeUpTimeFstChecked = false;
        $scope.wakeUpTimeSecChecked = true;
        $scope.wakeUpTimeTrdChecked = false;
        $scope.wakeUpTimeFourChecked = false;
        $scope.wakeUpTimeFifthChecked = false;
        $scope.acController.dataManager.getVoiceState().voiceTimeLength = 15;
        $scope.acController.controlVoiceStatus();
    };

    $scope.chooseWakeUpTimeTrd = function () {
        $scope.wakeUpTimeFstChecked = false;
        $scope.wakeUpTimeSecChecked = false;
        $scope.wakeUpTimeTrdChecked = true;
        $scope.wakeUpTimeFourChecked = false;
        $scope.wakeUpTimeFifthChecked = false;
        $scope.acController.dataManager.getVoiceState().voiceTimeLength = 20;
        $scope.acController.controlVoiceStatus();
    };

    $scope.chooseWakeUpTimeFour = function () {
        $scope.wakeUpTimeFstChecked = false;
        $scope.wakeUpTimeSecChecked = false;
        $scope.wakeUpTimeTrdChecked = false;
        $scope.wakeUpTimeFourChecked = true;
        $scope.wakeUpTimeFifthChecked = false;
        $scope.acController.dataManager.getVoiceState().voiceTimeLength = 25;
        $scope.acController.controlVoiceStatus();
    };

    $scope.chooseWakeUpTimeFifth = function () {
        $scope.wakeUpTimeFstChecked = false;
        $scope.wakeUpTimeSecChecked = false;
        $scope.wakeUpTimeTrdChecked = false;
        $scope.wakeUpTimeFourChecked = false;
        $scope.wakeUpTimeFifthChecked = true;
        $scope.acController.dataManager.getVoiceState().voiceTimeLength = 30;
        $scope.acController.controlVoiceStatus();
    };
    //冷热感三个档位
    $scope.lenreFst = function () {
        $scope.lenreFstChecked = true;
        $scope.lenreSecChecked = false;
        $scope.lenreTrdChecked = false;
        $scope.acController.dataManager.getColdHotState().coldHotStall = 20;
        $scope.acController.controlColdHotStatus1();
    };
    $scope.lenreSec = function () {
        $scope.lenreFstChecked = false;
        $scope.lenreSecChecked = true;
        $scope.lenreTrdChecked = false;
        $scope.acController.dataManager.getColdHotState().coldHotStall = 50;
        $scope.acController.controlColdHotStatus1();
    };
    $scope.lenreTrd = function () {
        $scope.lenreFstChecked = false;
        $scope.lenreSecChecked = false;
        $scope.lenreTrdChecked = true;
        $scope.acController.dataManager.getColdHotState().coldHotStall = 80;
        $scope.acController.controlColdHotStatus1();
    };

    //滤网保养
    //查询家电激活时间
    $scope.getCreateTime = function (callback) {
        console.log("<<<<<<<<<<<<<getCreateTime<<<<<<<<<<<");

        bridge.getUserInfo(function (userInfo) {
            $scope.requestServerData('/acfilter/queryDeviceCreateTime', {
                    "userId": parseInt(userInfo.userId),
                    "deviceId": bridge.getCurrentApplianceID()
                },
                function (data) {
                    var jsonString = JSON.stringify(data);
                    var resultEnv = coreHelper.getResultData(jsonString);
                    var locationTime = coreHelper.getLocalTime(resultEnv.createTime)
                    callback(locationTime);

                    console.log(data);
                },
                function (error) {
                    console.log(error);
                });
        });
    };

    $scope.requestServerData = function (url, params, success, fail) {
        var functionParamers = {
            queryStrings: {
                "serviceUrl": url
            },
            transmitData: params
        };

        var cmdId = bridge.requestDataTransmit(functionParamers, function (messageBack) {
            console.log("success request", messageBack);
            success(messageBack);
            $scope.$apply();
        }, function (errorMessage) {
            console.log("error request");
            fail(errorMessage);
            $scope.$apply();
        });
    };

    $scope.goToFilterMaintanceModule = function () {
        $scope.acController.showLoading();
        $scope.setFilterMaintenanceRemind(true);

        $scope.filterMaintenance.runTimeData.applianceId = bridge.getCurrentApplianceID();

        bridge.getUserInfo(function (userInfo) {
            $scope.filterMaintenance.runTimeData.userId = parseInt(userInfo.userId);
            $scope.getCreateTime(function (data) {
                console.log("getCreateTime");
                console.log(data);
                $scope.filterMaintenance.runTimeData.locationTime = data;
            });


            //检查滤网是否初次使用
            $scope.requestServerData('/acfilter/queryFilterCleanRecords', {
                    "userId": parseInt(userInfo.userId),
                    "deviceId": bridge.getCurrentApplianceID()
                },
                function (data) {
                    console.log("检查滤网是否初次使用");
                    console.log(data);
                    if (data.result.returnData.errCode == 5007) {
                        $scope.acController.hideLoading();
                    }
                    $scope.$apply();
                    clearTimeout($scope.filterMaintenance.runTimeData.networkTimeout);

                    if ((data.errorCode == 0) && (data.result != undefined)) {
                        var record = data.result.returnData.result;
                        if (record.length == 0) {
                            $scope.redirectPage('welcome', 'in');
                        } else {
                            $scope.redirectPage('cleanpanel', 'in');
                            $scope.filterMaintenance.isFirstEnterPage = true;
                        }
                    }
                    $scope.acController.hideLoading();
                },
                function (error) {
                    console.log(error);
                });
        });

        $scope.filterMaintenance.runTimeData.networkTimeout = setTimeout(function () {
            $scope.acController.hideLoading();
            $scope.$apply(function () {
                $scope.timeoutPopUp("网络超时, 请重试~");
            });
        }, 15000);

        //debug
        //$scope.redirectPage('cleanpanel','in');
        //$scope.redirectPage('welcome','in');
        //$scope.filterMaintenance.isFirstEnterPage = true;

    };

    $scope.checkFilterMaintemance = function () {
        var applianceId = bridge.getCurrentApplianceID();

        bridge.getUserInfo(function (userInfo) {
            var userId = parseInt(userInfo.userId);

            $scope.getCreateTime(function (data) {
//						console.log("getCreateTime");
//						console.log(data);
                $scope.filterMaintenance.runTimeData.locationTime = data;
            });

            //检查滤网是否健康
            $scope.requestServerData('/acfilter/queryFilterPurify', {
                    "userId": userId,
                    "deviceId": applianceId
                },
                function (data) {
                    console.log("检查滤网是否健康");
                    console.log(data);

                    if ((data.errorCode == 0) && (data.result != undefined)) {
                        if (data.result.returnData.result != undefined) {
                            var point = data.result.returnData.result.curPurify;
                            if ((point != undefined) && (point <= 75)) {
                                if ($scope.getFilterMaintenanceRemind()) {
                                    $("#filter-maintenance-tooltips").show();
                                }
                                $scope.filterMaintenance.isToolDirty = true;
                            }
                        }
                    }
                },
                function (error) {
                    console.log(error);
                });

            //检查滤网是否初次使用
            $scope.requestServerData('/acfilter/queryFilterCleanRecords', {
                    "userId": userId,
                    "deviceId": applianceId
                },
                function (data) {
                    console.log("检查滤网是否初次使用");
                    console.log(data);

                    if ((data.errorCode == 0) && (data.result != undefined)) {
                        var record = data.result.returnData.result;
                        if (record.length == 0) {
                            if ($scope.getFilterMaintenanceRemind()) {
                                $("#filter-maintenance-tooltips").show();
                            }
                        }
                    }
                },
                function (error) {
                    console.log(error);
                });
        });
    }

    $scope.cleanFilterRecord = function () {
        var applianceId = bridge.getCurrentApplianceID();

        bridge.getUserInfo(function (userInfo) {
            var userId = parseInt(userInfo.userId);

            $scope.timeoutPopUp("开始清理滤网数据");

            $scope.requestServerData('/acfilter/removeFilterRecord', {
                    "userId": userId,
                    "deviceId": applianceId
                },
                function (data) {
                    console.log(data);
                    $scope.timeoutPopUp("滤网数据清理成功");
                },
                function (error) {
                    console.log(error);
                    $scope.timeoutPopUp("滤网数据清理失败");
                });
        });
    }

    $scope.goFilterOperationBranch = function () {
        if ($scope.filterMaintenance.isToolDirty) {
            //$scope.redirectPage('cleanpanel', 'in');
            //$scope.filterMaintenance.isFirstEnterPage = true;
            $scope.goToFilterMaintanceModule();
        } else {
            $scope.filterMaintenance.runTimeData.applianceId = bridge.getCurrentApplianceID();
            bridge.getUserInfo(function (userInfo) {
                $scope.filterMaintenance.runTimeData.userId = parseInt(userInfo.userId);
                $scope.redirectPage('welcome', 'in');
            });
        }
    }

    $scope.getFilterMaintenanceRemind = function () {
        var isRemind = localStorage.getItem(bridge.getCurrentApplianceID() + "_FilterMaintenanceRemind");

        if ((isRemind == "1") || (isRemind == undefined)) {
            return true;
        } else {
            return false;
        }
    };

    $scope.setFilterMaintenanceRemind = function (isRemind) {
        if (isRemind) {
            localStorage.setItem(bridge.getCurrentApplianceID() + "_FilterMaintenanceRemind", "1");
        } else {
            localStorage.setItem(bridge.getCurrentApplianceID() + "_FilterMaintenanceRemind", "0");
        }
    };
});