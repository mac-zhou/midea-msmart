//YB200的拓展控制器
mideaACApp.controller('YB200Controller', function ($scope, $rootScope, $location, $sce, deviceCommand, deviceRequest, staticData, coreHelper, $filter) {
    $scope.init = function () {
    	    $scope.requestPM =0;
        console.log("YB200Controller startup...");
        $scope.appRuntime.tempControlMaxDelay = 0;
        $scope.appRuntime.tempControlTimeInterval = 0;

        $scope.appRuntime.pageActiveColor = "#007dff";
        $scope.appRuntime.pageInactiveColor = "#b3b3b3";
        $scope.appRuntime.pageCurrentColor = $scope.appRuntime.pageActiveColor;

        $scope.initSliderComponent = {};
        $scope.initPullMenuComponent = {};

        $scope.handleSubRouteChange();
        $scope.watchSubVariable();

//		coreHelper.delayExecute(function(){
//			$scope.initTempTouchAction();
//		}, 1000);

        $scope.YB200Controller = {
            status: {
                isIntelligentControl: false,
                isIntelligentGuestControl: false,
                isGestureRecognitionDirection: false,
                isGestureRecognitionOnOff: false
            },
            statusHome: {
                isIntelligentControl: false,
                isIntelligentGuestControl: false,
                isGestureRecognitionOnOff: false,
                isSecurityControl: false,
                exclusiveOnOffStatus: false
            },
            component: {
                dialog: {
                    intelWindClose: {
                        title: '提醒',
                        content: ' 手势控制将由“定点送风”切换为 “手势开关机”',
                        button: ["取消", "确认"]
                    },
                    intelWindOpen: {
                        title: '提醒',
                        content: '手势控制将由“手势开关机”切换为 “定点送风”',
                        button: ["取消", "确认"]
                    },
                    exclusive: {
                        title: '提醒',
                        content: '家人列表为空时不能开启专属模式',
                        button: ["取消", "去添加"]
                    },
                    gestureControlPermiss: {
                        title: '提醒',
                        content: '已启用智能安防功能,手势控制功能不可用',
                        button: ["ok"]
                    },
                    intelWindlPermiss: {
                        title: '提醒',
                        content: '已启用智能安防功能, 智能送风功能不可用',
                        button: ["ok"]
                    },
                    secutityProtect: {
                        title: '提醒',
                        content: '智能安防与手势控制、智能送风功能都使用到摄像头,开启入侵保护后,上述两项功能将暂时关闭,确定要开启么?',
                        button: ["取消", "确认"]
                    }
                }
            }
        };
    };

    $scope.handleSubRouteChange = function () {
        $scope.$on('$routeChangeSuccess', function (event, next, current) {
            if (next.loadedTemplateUrl === 'view/app/partials/themes/yb200/main.html') {
                coreHelper.delayExecute(function () {
                    $scope.initTempTouchAction();
                }, 1000);
                $scope.acController.requestRequestFamilyStatus();
                $scope.acController.requestLadderControlStatus();
                $scope.acController.requestIntelligentControlStatus();
                $scope.acController.requestSafeInvadeStatus();
                $scope.acController.requestExclusiveModeStatus();
                $scope.smartWindFeelingPageData();
                 $scope.acController.requestPMStatus();
                clearInterval($scope.requestPM);
                $scope.requestPM = setInterval(function(){
                $scope.acController.requestPMStatus();
                },60000);             
                setTimeout(function () {
                    $scope.initSliderComponent = new initSliderComponent();
                    $scope.initSliderComponent.init($scope.appRuntime.currentConfigTemp);
                    $scope.initPullMenuComponent = new initPullMenuComponent();
                    $scope.initPullMenuComponent.init();
                }, 0);
            }

            if (next.loadedTemplateUrl === 'view/app/partials/themes/yb200/intelligencewind.html') {
                coreHelper.delayExecute(function () {
                    $scope.acController.requestIntelligentControlStatus();
                    $scope.initIntelWindPageData();
                }, 800);
            }

            if (next.loadedTemplateUrl === 'view/app/partials/themes/yb200/gesturecontrol.html') {
                $scope.acController.requestIntelligentControlStatus();
                $scope.acController.requestExclusiveModeStatus();
                $scope.acController.requestRequestFamilyStatus();
                $scope.initGestureControlPageData();
                $scope.initExclusiveControlPageData();
                coreHelper.delayExecute(function () {
                    $scope.initGestureControlPageData();
                    $scope.initExclusiveControlPageData();
                }, 800);
            }

            if (next.loadedTemplateUrl === 'view/app/partials/themes/yb200/securityprotect-setting.html') {
                $scope.acController.requestIntrusionRemindStatus();
            }
        });
    };

    $scope.watchSubVariable = function () {
        $scope.$watch("appRuntime.currentConfigTemp", function (news, olds) {
            if (news != olds) {
                $scope.initSliderComponent.init(news);
            }
        });

        $scope.$watch("deviceStatus.intelligentControlStatus", function (news, olds) {
            if (news != olds) {
                $scope.YB200Controller.statusHome.isIntelligentControl = news;
                $scope.YB200Controller.status.intelligentControlStatus = news;
            }
        });

        $scope.$watch("deviceStatus.gestureRecognitionOnOffStatus", function (news, olds) {
            if (news != olds) {
                $scope.YB200Controller.statusHome.isIntelligentGuestControl = $scope.deviceStatus.gestureRecognitionDirectionStatus || news;
                $scope.YB200Controller.statusHome.isGestureRecognitionOnOff = news;
                $scope.YB200Controller.status.isGestureRecognitionOnOff = news;
            }
        });

        $scope.$watch("deviceStatus.windSpeedValue", function (news, olds) {
            if ((news == 100) && (olds > 100)) {
                $scope.deviceStatus.windSpeedStatus = false;
            }
        });

        $scope.$watch("deviceStatus.gestureRecognitionDirectionStatus", function (news, olds) {
            if (news != olds) {
                $scope.YB200Controller.statusHome.isIntelligentGuestControl = $scope.deviceStatus.gestureRecognitionOnOffStatus || news;
            }
        });

        $scope.$watch("deviceStatus.securityStatus", function (news, olds) {
            if (news != olds) {
                $scope.YB200Controller.statusHome.isSecurityControl = news;
            }

            if (news) {
                //首页状态特殊处理
                $scope.YB200Controller.statusHome.isIntelligentControl = false;
                $scope.YB200Controller.statusHome.isGestureRecognitionOnOff = false;

                //更多页面特殊状态处理
                $scope.YB200Controller.status.intelligentControlStatus = false;
                $scope.YB200Controller.status.isGestureRecognitionOnOff = false;

            } else {
                //首页状态特殊处理
                $scope.YB200Controller.statusHome.isIntelligentControl = $scope.deviceStatus.intelligentControlStatus;
                $scope.YB200Controller.statusHome.isGestureRecognitionOnOff = $scope.deviceStatus.gestureRecognitionOnOffStatus;

                //更多页面特殊状态处理
                $scope.YB200Controller.status.intelligentControlStatus = $scope.deviceStatus.intelligentControlStatus;
                $scope.YB200Controller.status.isGestureRecognitionOnOff = $scope.deviceStatus.gestureRecognitionOnOffStatus;
            }
        });

        $scope.$watch("deviceStatus.runningMode", function (news, olds) {
            if (news != olds) {
                if (news != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool || news == mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat) {
                    $scope.acController.dataManager.setLadderControlStatus(false);
                }
            }
        });

        $scope.$watch("deviceStatus.deviceRunningStatus", function (news, olds) {
            if (news != olds) {
                if (!news) {
                    $scope.acController.dataManager.setLadderControlStatus(false);

                    $scope.appRuntime.pageCurrentColor = $scope.appRuntime.pageInactiveColor;
                } else {
                    $scope.appRuntime.pageCurrentColor = $scope.appRuntime.pageActiveColor;
                }
            }
        });

//		$scope.$watch("deviceStatus.upDownProduceWindStatus", function(news, olds){
//			if(news != olds) {
//				if(news) {
//					$scope.deviceStatus.intelligentControlStatus = false;
//				}
//			}
//		});
//		
//		$scope.$watch("deviceStatus.leftRighProducetWindStatus", function(news, olds){
//			if(news != olds) {
//				if(news) {
//					$scope.deviceStatus.intelligentControlStatus = false;
//				}
//			}
//		});

        $scope.$watch("pmvisActive", function (news, olds) {
            if (news != olds) {
                if (news) {
                    $scope.acController.dataManager.setLadderControlStatus(false);
                }
            }
        });
    };

    /*
     * 业务逻辑
     */
    $scope.openSmartWindModule = function () {
        if (!$scope.deviceStatus.deviceRunningStatus) {
            $scope.timeoutPopUp("关机智能风感不可调节!");
        } else {
            $scope.redirectPage('intelligence-wind', 'in');
        }
    };

    $scope.openGestureControlModule = function () {
        $scope.redirectPage('gesture-control', 'in');
    };

    $scope.openIntelSecurity = function () {
        $scope.acController.controlVideoPlay();
    };
    $scope.jumpIntoFaceRegistered = function () {
        $scope.acController.controlJumpIntoFaceRegistered();
    };
    $scope.gotoSettingModule = function () {
        $scope.redirectPage('yb200-setting', 'in');
    };
    $scope.gotoSettingModuleDisney = function () {
        $scope.redirectPage('mq200-setting', 'in');
    };

    $scope.switchEnergySavingStatus = function () {
        if ($scope.deviceStatus.deviceRunningStatus && ($scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool || $scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat)) {
            $scope.acController.controlEnergySavingStatus(!$scope.deviceStatus.energySavingStatus, 0, 0, 0, 0, 0);
        } else {
            $scope.timeoutPopUp("无人节能只在开机制冷制热模式下有效!");
        }
    };

    $scope.switchLadderTemp = function () {
        if ($scope.deviceStatus.deviceRunningStatus) {
            if ($scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool) {
                $scope.timeoutPopUp("健康降温只在制冷模式下有效!");
            } else {
                $scope.acController.controlLadderControlStatus(!$scope.acController.dataManager.getLadderControlStatus());
            }
        } else {
            $scope.timeoutPopUp("关机下健康降温不可用!");
        }
    };

    $scope.isValidTempControl = function () {
        if ($scope.deviceStatus.deviceRunningStatus && $scope.deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind) {
            return true;
        } else {
            return false;
        }
    };

    $scope.isCoolHeatMode = function () {
        if ($scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool || $scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat) {
            return true;
        } else {
            return false;
        }
    };

    $scope.isDeviceOn = function () {
        return $scope.deviceStatus.deviceRunningStatus;
    };

    $scope.initTempTouchAction = function () {
        var subTempBtn = $(".slider-control-temp-left");
        var addTempBtn = $(".slider-control-temp-right");
        var tempCtrlBtn = $(".slider-control-temp-left, .slider-control-temp-right");
        var tempHistory = $scope.appRuntime.currentConfigTemp;

        addTempBtn.unbind("touchstart").bind("touchstart", function (event) {
            event.preventDefault();

            if ($scope.isValidTempControl()) {
                $scope.tempChangeAnimate(true);
                $scope.appRuntime.tempControlTimeInterval = setInterval(function () {
                    $scope.tempChangeAnimate(true);
                }, 300);
                setReceiveUploadIsUnallowed();
            }
        });

        subTempBtn.unbind("touchstart").bind("touchstart", function (event) {
            event.preventDefault();

            if ($scope.isValidTempControl()) {
                $scope.tempChangeAnimate(false);
                $scope.appRuntime.tempControlTimeInterval = setInterval(function () {
                    $scope.tempChangeAnimate(false);
                }, 300);
                setReceiveUploadIsUnallowed();
            }
        });

        tempCtrlBtn.unbind("touchend").bind("touchend", function (event) {
            event.preventDefault();

            clearInterval($scope.appRuntime.tempControlTimeInterval);
            if ($scope.isValidTempControl()) {
                $scope.acController.controlSetTemperature(parseInt($scope.appRuntime.currentConfigTemp), $scope.appRuntime.currentConfigTemp - parseInt($scope.appRuntime.currentConfigTemp));
            } else {
                $scope.timeoutPopUp("关机下或送风模式下温度不可调节");
                $scope.$apply();
            }
        });

        tempCtrlBtn.unbind("touchcancel").bind("touchcancel", function (event) {
            event.preventDefault();
            clearInterval($scope.appRuntime.tempControlTimeInterval);
            $scope.appRuntime.currentConfigTemp = tempHistory;
        });
    };

    $scope.tempChangeAnimate = function (isUp) {
        if (isUp) {
            $scope.appRuntime.currentConfigTemp += 0.5;
        } else {
            $scope.appRuntime.currentConfigTemp -= 0.5;
        }

        if ($scope.appRuntime.currentConfigTemp < 17) {
            $scope.appRuntime.currentConfigTemp = 17;
        }
        if ($scope.appRuntime.currentConfigTemp > 30) {
            $scope.appRuntime.currentConfigTemp = 30;
        }

        $scope.$apply();
    };

    $scope.tempAction = function (isUp) {
        if ($scope.isValidTempControl()) {
            if (isUp) {
                $scope.appRuntime.currentConfigTemp += 0.5;
            } else {
                $scope.appRuntime.currentConfigTemp -= 0.5;
            }

            if ($scope.appRuntime.currentConfigTemp < 17) {
                $scope.appRuntime.currentConfigTemp = 17;
            }
            if ($scope.appRuntime.currentConfigTemp > 30) {
                $scope.appRuntime.currentConfigTemp = 30;
            }

            clearTimeout($scope.appRuntime.tempControlMaxDelay);
            $scope.appRuntime.tempControlMaxDelay = setTimeout(function () {
                $scope.acController.controlSetTemperature(parseInt($scope.appRuntime.currentConfigTemp), $scope.appRuntime.currentConfigTemp - parseInt($scope.appRuntime.currentConfigTemp));
            }, 500);
        } else {
            $scope.timeoutPopUp("关机下或送风模式下温度不可调节");
        }
    };

    $scope.inCurrentMode = function (mode) {
        if ($scope.deviceStatus.runningMode != undefined) {
            if (mode == 'RunModeRemoveWet') {
                return $scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeRemoveWet || $scope.deviceStatus.runningMode == 6 || $scope.deviceStatus.runningMode == 7;
            } else {
                return $scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode[mode];
            }
        } else {
            return false;
        }
    };

    $scope.shortcutControlSecurityProtect = function () {
        if ($scope.deviceStatus.angleEyeStatus) {
			if(!$scope.deviceStatus.securityStatus) {
				$scope.showMobileAlert($scope.YB200Controller.component.dialog.secutityProtect, function(index){
					if(index == 1) {
						$scope.acController.controlSecurityStatus(!$scope.deviceStatus.securityStatus);
					}
				});
			} else {
            $scope.acController.controlSecurityStatus(!$scope.deviceStatus.securityStatus);
			}
        } else {
            $scope.timeoutPopUp("天使眼已经关闭, 请用遥控器开启!");
        }
    };

    $scope.smartWindFeelingPageData = function () {
        $(document).unbind('yb200-intelManage-smartWindFeeling::update::toggle::switch').bind('yb200-intelManage-smartWindFeeling::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                if (!$scope.deviceStatus.deviceRunningStatus) {
                    $scope.timeoutPopUp("关机智能风感不可调节!");
                } else {
                    if (!$scope.smartWindFeeling) {
                        $scope.isWindBlow = true;
                        $scope.isWindClose = false;
                        $scope.isWindSpeed = false;
                    }
                    $scope.acController.controlSmartWindFeelingStatus(!$scope.smartWindFeeling);
                }
            });
        });
        try {
            $scope.$broadcast('yb200-intelManage-smartWindFeeling::init::toggle::switch', {
                'currentVal': $scope.smartWindFeeling
            });
        } catch (e) {
        }
    };
    $scope.initIntelWindPageData = function () {
        console.log("initIntelWindPageData...");

        $(document).unbind('yb200-intelManage::update::toggle::switch').bind('yb200-intelManage::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                if (!$scope.deviceStatus.securityStatus) {
                    $scope.YB200Controller.status.intelligentControlStatus = data.currentVal;
                    $scope.acController.controlIntelligentStatus(data.currentVal);
                } else {
                    $scope.showMobileAlert($scope.YB200Controller.component.dialog.intelWindlPermiss, function (index) {
                    });
                    $scope.$broadcast('yb200-intelManage::init::toggle::switch', {
                        'currentVal': $scope.YB200Controller.status.intelligentControlStatus
                    });
                }
            });
        });

        $(document).unbind('yb200-gesture-recognition-direction::update::toggle::switch').bind('yb200-gesture-recognition-direction::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
                if (data.currentVal) {
                    $scope.showMobileAlert($scope.YB200Controller.component.dialog.intelWindOpen, function (index) {
                        if (index == 1) {
                            $scope.controlGestureRecognitionDirection();
                        } else {
                            $scope.$broadcast('yb200-gesture-recognition-direction::init::toggle::switch', {
                                'currentVal': $scope.YB200Controller.status.isGestureRecognitionDirection
                            });
                        }
                    });
                } else {
                    $scope.controlGestureRecognitionDirection();
                }
            });
        });

        try {
            $scope.$broadcast('yb200-intelManage::init::toggle::switch', {
                'currentVal': $scope.YB200Controller.status.intelligentControlStatus
            });
        } catch (e) {
        }

        try {
            $scope.YB200Controller.status.isGestureRecognitionDirection = $scope.deviceStatus.gestureRecognitionDirectionStatus;
            $scope.$broadcast('yb200-gesture-recognition-direction::init::toggle::switch', {
                'currentVal': $scope.YB200Controller.status.isGestureRecognitionDirection
            });
        } catch (e) {
        }
    };

    $scope.initGestureControlPageData = function () {
        console.log("initGestureControlPageData...");

        $(document).unbind('yb200-gesture-recognition-onOff::update::toggle::switch').bind('yb200-gesture-recognition-onOff::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {

                //手势总开关的测试代码
                //				$scope.YB200Controller.status.isIntelligentGuestControl = data.currentVal;
                //				//$scope.acController.controlIntelligentStatus(data.currentVal);
                //				if(!data.currentVal) {
                //					$scope.acController.controlGestureRecognitionStatus(0, 0);
                //				} else {
                //					$scope.isGestureRecognitionOnOff = $scope.deviceStatus.gestureRecognitionDirectionStatus;
                //					$scope.isGestureRecognitionDirection = $scope.deviceStatus.gestureRecognitionOnOffStatus;
                //				}
                //$scope.YB200Controller.status.isGestureRecognitionOnOff = data.currentVal;
                if (!$scope.deviceStatus.securityStatus) {
                    if (data.currentVal) {
                        $scope.showMobileAlert($scope.YB200Controller.component.dialog.intelWindClose, function (index) {
                            if (index == 1) {
                                $scope.controlGestureRecognitionOnOff();
                            } else {
                                $scope.$broadcast('yb200-gesture-recognition-onOff::init::toggle::switch', {
                                    'currentVal': $scope.YB200Controller.status.isGestureRecognitionOnOff
                                });
                            }
                        });
                    } else {
                        $scope.controlGestureRecognitionOnOff();
                    }
                } else {
                    $scope.showMobileAlert($scope.YB200Controller.component.dialog.gestureControlPermiss, function (index) {
                    });
                    $scope.$broadcast('yb200-gesture-recognition-onOff::init::toggle::switch', {
                        'currentVal': $scope.YB200Controller.status.isGestureRecognitionOnOff
                    });
                }
            });
        });

        try {
            $scope.$broadcast('yb200-gesture-recognition-onOff::init::toggle::switch', {
                'currentVal': $scope.YB200Controller.status.isGestureRecognitionOnOff
            });
        } catch (e) {
        }
    };
    $scope.initExclusiveControlPageData = function () {
        console.log("initGestureControlPageData...");
        $(document).unbind('yb200-gesture-exclusive-onOff::update::toggle::switch').bind('yb200-gesture-exclusive-onOff::update::toggle::switch', {}, function (event, data) {
            $scope.$apply(function () {
//					alert("jjjjjjjj"+$scope.deviceStatus.exclusiveOnOffStatus);
                if ($scope.deviceStatus.familyNumber == 0) {
                    $scope.showMobileAlert($scope.YB200Controller.component.dialog.exclusive, function (index) {
                        if (index == 1) {
                            $scope.acController.controlJumpIntoFaceRegistered();
                        } else {
                            $scope.$broadcast('yb200-gesture-exclusive-onOff::init::toggle::switch', {
                                'currentVal': $scope.deviceStatus.exclusiveOnOffStatus
                            });
                        }
                    });
                } else {
                    $scope.controlExclusiveOnOff();
                }
            });
        });
        try {
            $scope.$broadcast('yb200-gesture-exclusive-onOff::init::toggle::switch', {
                'currentVal': $scope.deviceStatus.exclusiveOnOffStatus
            });
        } catch (e) {
        }
    };

    $scope.controlGestureRecognitionOnOff = function () {
        $scope.YB200Controller.status.isGestureRecognitionOnOff = !$scope.deviceStatus.gestureRecognitionOnOffStatus;
        if (!$scope.deviceStatus.gestureRecognitionOnOffStatus) {
            $scope.YB200Controller.status.isGestureRecognitionDirection = $scope.deviceStatus.gestureRecognitionOnOffStatus;
        }
        $scope.acController.controlGestureRecognitionStatus($scope.YB200Controller.status.isGestureRecognitionOnOff, $scope.YB200Controller.status.isGestureRecognitionDirection);
    };
    $scope.controlExclusiveOnOff = function () {
//		$scope.YB200Controller.status.isExclusiveOnOffStatus = !$scope.deviceStatus.exclusiveOnOffStatus;
//		if(!$scope.deviceStatus.exclusiveOnOffStatus){
//			$scope.YB200Controller.status.isExclusiveOnOffStatus = $scope.deviceStatus.exclusiveOnOffStatus;
//		}
        $scope.acController.controlExclusiveModeStatus(!$scope.deviceStatus.exclusiveOnOffStatus);
    };
    $scope.controlGestureRecognitionDirection = function () {
        if (!$scope.YB200Controller.status.isGestureRecognitionDirection) {
            $scope.YB200Controller.status.isGestureRecognitionOnOff = $scope.YB200Controller.status.isGestureRecognitionDirection;
        }
        $scope.YB200Controller.status.isGestureRecognitionDirection = !$scope.YB200Controller.status.isGestureRecognitionDirection;
        $scope.acController.controlGestureRecognitionStatus($scope.YB200Controller.status.isGestureRecognitionOnOff, $scope.YB200Controller.status.isGestureRecognitionDirection);
    };

    $scope.controlWindBlow = function () {
        var windDirection = 0;
        $scope.isWindBlow = true;
        $scope.isWindClose = false;
        $scope.isWindSpeed = false;
        windDirection = 1;
        $scope.acController.controlWindDirectionStatus(windDirection);
    };

    $scope.controlWindClose = function () {
        var windDirection = 0;
        $scope.isWindClose = true;
        $scope.isWindBlow = false;
        $scope.isWindSpeed = false;
        windDirection = 2;
        $scope.acController.controlWindDirectionStatus(windDirection);
    };

    $scope.controlWindSpeed = function () {
        $scope.isWindClose = false;
        $scope.isWindBlow = false;
        $scope.isWindSpeed = true;
        $scope.acController.controlWindSpeedStatus(1);
        $scope.deviceStatus.windSpeedValue = 102;
    };

    $scope.configSecurityProctect = function (isReceviePushMsg) {
        $scope.acController.controlSwitchIntrusionRemind(isReceviePushMsg);
    };

    $scope.redirectPage = function (page, state) {
        //模型方法 路由导向
        // if (page == "setting" && state == "out") {
        // 	$scope.intelCheckShow = false;
        // 	$scope.intelCheckStatus = false;
        // 	$(".intelCheckBg").stop(false, false);
        // }

        if ((page == "setting" && state == "out") || (page == "main" && state == "out")) {
            coreHelper.redirectPage($scope, $scope.currentModule + page, state);
        } else {
            coreHelper.redirectPage($scope, page, state);
        }
    };

    /*
     * 页面组件
     */
    function initSliderComponent() {
        var _container = $(".slider-control-temp-container .component");
        var _preValue = 0;
        var _curValue = 0;

        _container.slider({
            animate: "slow",
            range: "min",
            min: 17,
            max: 30,
            step: 0.5,
            change: function (event, ui) {
            },
            slide: function (event, ui) {
                if ($scope.isValidTempControl()) {
                    $scope.appRuntime.currentConfigTemp = ui.value;
                    $scope.$apply();
                }
            },
            start: function (event, ui) {
                _preValue = ui.value;
            },
            stop: function (event, ui) {
                _curValue = ui.value;
                if (_preValue !== _curValue) {
                    if ($scope.isValidTempControl()) {
                        $scope.acController.controlSetTemperature(parseInt($scope.appRuntime.currentConfigTemp), $scope.appRuntime.currentConfigTemp - parseInt($scope.appRuntime.currentConfigTemp));
                    } else {
                        _container.slider("value", $scope.appRuntime.currentConfigTemp);
                        $scope.timeoutPopUp("关机下或送风模式下温度不可调节");
                        $scope.$apply();
                    }
                }
            }
        });

        function init(value) {
            _container.slider("value", value);
        }

        return {
            init: init
        }
    }

    /*
     * 工具函数
     */
    $scope.showMobileAlert = function (option, confirm) {
        var dia = Zepto.dialog(option);
        dia.on("dialog:action", function (e) {
            console.log(e.index);
            confirm(e.index);
        });
        dia.on("dialog:hide", function (e) {
            console.log("dialog hide")
        });
    };
});