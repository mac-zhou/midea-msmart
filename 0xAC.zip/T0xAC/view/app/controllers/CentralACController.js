mideaACApp.controller('CentralACController', function($scope, $rootScope, $location, $sce, deviceCommand, deviceRequest, staticData, coreHelper, $filter) {
	var tmpLocationAddr = 0;
	var timeControlFlag;
	var tmpCheckCount = 0;
	var totalControlTimeFlag = null;
	var tmpCurrentStatusLength = 0;
	var onLineStatusCache = [];
	var onLineDeviceAddrCache = [];
	var unit_status = [];
	var pageFlag = false;//是否进入卡片页标志
	var pageNumber = 0;//进入的分机号
	var closeActiveFlag = true;//默认允许接收主动上传
	
	
	
	$scope.init = function() {
		
		$(document).bind('recieveMessage', {}, function(event, message) {
			
			return;
			
			if(closeActiveFlag == false){
				return;
			}
			
//		console.log("messagemessagemessage:",message);
          _ACDriver.parseMessageProtocol(message);
          $scope.statusSynchro(message[11]);
          $scope.dealWithModeFiresb(message[11],$scope.devicelistItems[message[11]].mode);
          $scope.refreshSystemCurrent();
         
          //判断是否进入控制页，如果在控制页，则根据分机号进行更新
          if(pageFlag == true){
          	if(pageNumber == message[11]){
          		$scope.updateMainView_sleep(message[11]);
          	}
          	_ACDriver.deviceStatus.locationOrder  = pageNumber;
          }
          $scope.$apply();
	});
		
		
//		$scope.appConfig.isCentralAC = true;

		$scope.appRuntime.currentRunState = 0;
		$scope.appRuntime.currentDeviceIndex = 0;
		$scope.appRuntime.duokongxuanzhong = [];
		$scope.appRuntime.tempCtrlTimer = 0;
		$scope.devicelistItems = [];
		
		$scope.appRuntime.sleepCurveData = [];

		$scope.resetBootControllerFeature();
		$scope.handleVaribleListener();
		$scope.handleEvents();
		$scope.showLoading();
		$scope.currentSleepOperation = "执行睡眠";
		$scope.deviceStatusGroupSelectFlag = [0, 0, 0, 0, 0, 0, 0, 0]; //0:默认没有被选中,1:选中

		//引入数据容器
		$scope.staticData = staticData.getIconResource();
		$scope.openCloseisActive = false;
		$scope.switchModelisActive = false;
		$scope.changeWindisActive = false;
		$scope.EcoisActive = false;
		$scope.sleepisActive = false;
		$scope.timerisActive = false;
		$scope.timerOpenisActive = false;
		$scope.electricHeatisActive = false;
		$scope.dryisActive = false;
		$scope.sleepFunctionStatus = false;

		$scope.comfortSleepisActive = false;
		$scope.preventStraightLineWindIsActive = false;

		$scope.zhileng = false;
		$scope.zhilengg = true;
		$scope.zhire = false;
		$scope.zhireg = true;
		$scope.zhidong = false;
		$scope.zhidongg = true;
		$scope.songfeng = false;
		$scope.songfengg = true;
		$scope.choushi = false;
		$scope.choushig = true;
		$scope.colorz = "#808080";
		$scope.colorl = "#808080";
		$scope.colorc = "#808080";
		$scope.colors = "#808080";
		$scope.colorr = "#808080";
		$scope.quankongmoshi = 1;

		$scope.fengsuzidong = false;
		$scope.fengsuzidongg = true;
		$scope.fengsudifeng = false;
		$scope.fengsudifengg = true;
		$scope.fengsuzhongfeng = false;
		$scope.fengsuzhongfengg = true;
		$scope.fengsugaofeng = false;
		$scope.fengsugaofengg = true;
		$scope.colorfengsuzidong = "#808080";
		$scope.colorfengsudifeng = "#808080";
		$scope.colorfengsuzhongfeng = "#808080";
		$scope.colorfengsugaofeng = "#808080";
		$scope.quankongfengsu = 102;
		$scope.quankongwendu = 26;

		$scope.appRuntime.networkDelay = setTimeout(function() {
			$scope.hideLoading();
			$scope.timeoutPopUp("网络超时，请重试");
		}, 20000);

		$scope.initPhysicBack();

	};

	$scope.updateMainView_sleep = function(addr) {
		if(addr == undefined) {
			addr = 0;
		}

		$scope.functionListProcessExtra(parseInt($scope.devicelistItems[addr].sleepFunctionStatus) == 1, 'sleepisActive', 'sleepSrc');
		$scope.functionListProcessExtra(parseInt($scope.deviceStatusGroup[addr].timingClose.value) == 1, 'timerisActive', 'timerSrc');
		$scope.functionListProcessExtra(parseInt($scope.deviceStatusGroup[addr].timingOpen.value) == 1, 'timerOpenisActive', 'timerOpenSrc');
		$scope.functionListProcessExtra(parseInt($scope.deviceStatusGroup[addr].electricHeat.value) == 1, 'electricHeatisActive', 'electricHeatSrc');
		$scope.functionListProcessExtra((parseInt($scope.deviceStatusGroup[addr].dry.value) == 1) && ((parseInt($scope.devicelistItems[addr].mode) == 2) || (parseInt($scope.devicelistItems[addr].mode) == 3)), 'dryisActive', 'drySrc');
		
		if(parseInt($scope.devicelistItems[addr].sleepFunctionStatus)==1) {
			$scope.currentSleepOperation = "取消睡眠";
		} else {
			$scope.currentSleepOperation = "执行睡眠";
		}
		
	}

	//localStorage
	$scope.setLsVar = function(pApplianceType,pKey,pValue){
		var myLsKey = "T0x"+pApplianceType.toString(16);
		var myLsJson = localStorage[myLsKey] == undefined?{}:JSON.parse(localStorage[myLsKey]);
		myLsJson[pKey] = pValue;
		localStorage[myLsKey] = JSON.stringify(myLsJson);
	};
	$scope.getLsVar = function(pApplianceType,pKey){
		var myLsKey = "T0x"+pApplianceType.toString(16);
		var myLsJson = localStorage[myLsKey] == undefined?{}:JSON.parse(localStorage[myLsKey]);
		return myLsJson[pKey];
	};
	
	$scope.initPhysicBack = function() {
		bridge.setAndroidGoBack = function() {
			var url = location.href;
			var urlLength = url.length;
			if(url != '' && urlLength >= 2) {
				last2Char = url.substring(urlLength - 2, urlLength);
				if(url.indexOf("central-ac") != -1 || last2Char === '#/') {
					location.href = "iosbridge://goBack";
				} else if((url.indexOf("quankong-ac") != -1) || (url.indexOf("duokong-ac") != -1)) {
					//history.back(-1); 
					$scope.redirectPage('central-ac', 'in');
					$scope.$apply();
				}else if(url.indexOf("main_new") != -1) {
					//history.back(-1); 
					$scope.redirectPage('central-ac', 'in');
					$scope.$apply();
				}else if(url.indexOf("comfort-sleep_new") != -1) {
					//history.back(-1); 
					$scope.redirectPage('main_new', 'in');
					$scope.$apply();
				}
			}
		}
	}

	$scope.initDeviceManagerPage = function() {
		$scope.deviceStatusGroup = []; //8
        for(var i = 0; i < 8; i++) {
   			$scope.deviceStatusGroup[i] = coreHelper.clone(_ACDriver.deviceStatus);
 		 }

  //先查询分机在线状态，再查询分机详细状态
  //查询分机在线状态
  var cmdBytes = _ACDriver.controlDeviceStatus_JZ(false);
  bridge.startCmdProcess(cmdBytes, function(messageBack) {
   //解析分机状态
// _ACDriver.parseMessageProtocol(messageBack);
	var receiveMessageBody = messageBack.slice(10, messageBack.length - 1);
	$scope.statusSynchro_new(receiveMessageBody);
   
   //在线状态刷新
   if((messageBack[13] == 0x04) && (messageBack[14] == 0x0A)) {
    //分区地址从0开始
    tmpLocationAddr = 0;
    var receiveMessageBody = messageBack.slice(19, 27);
    var tv = [];
    //筛选在线状态分机
    for(var si = 0; si < receiveMessageBody.length; si++) {
    	if(receiveMessageBody[si] == 4){
    		$scope.timeoutPopUp((tmpLocationAddr+1)+"号分机发生模式冲突！");
    	}
    	
     if((receiveMessageBody[si] == 1) || (receiveMessageBody[si] == 3)||(receiveMessageBody[si] == 4)) {
      	tv[tmpLocationAddr] = si;
      	onLineDeviceAddrCache[tmpLocationAddr] = si;
      	tmpLocationAddr = tmpLocationAddr + 1;
     }
    }
    tmpLocationAddr = 0;
//  console.log('分机状态tv：' + tv);
    
    //2017-07-27增加在线状态缓存
    onLineStatusCache = tv;
    
    //有在线状态分机，刷分机详细状态,定时查询
    if(tv.length > 0) {
     
     var reapetCount = 0;
     var reapetFlag = true;
     tmpCurrentStatusLength = tv.length;
      timeControlFlag = setInterval(function() {
      cmdBytes = _ACDriver.cmdNewProtocol4MutableItemDeviceQueue_JZ(tv[tmpLocationAddr]);
      if(reapetFlag){
       reapetFlag = false;
       bridge.startCmdProcess(cmdBytes, function(messageBack) {
       	reapetFlag = true;
        _ACDriver.parseMessageProtocol(messageBack);
	
//      console.log('旧协议数据:' + messageBack);
//      console.log('旧协议数据tmpLocationAddr:' + tmpLocationAddr);
//      console.log('旧协议数据tv:' + tv);
        
        $scope.statusSynchro(messageBack[11]);

        if(tv[parseInt(tmpLocationAddr)] == messageBack[11]){
               
               tmpLocationAddr = parseInt(tmpLocationAddr) + 1;
               tmpLocationAddr = parseInt(tmpLocationAddr);
               
               if(tmpLocationAddr >= tv.length) {
                 clearInterval(timeControlFlag);
                 $scope.dealWithModeFireForAll();
                 //刷新连接状态
                 $scope.refreshSystemCurrent();
                 $scope.$apply();
                 $scope.hideLoading();
//               console.log('正常－数据刷完');
               }
        }
//      else if(tmpLocationAddr >= tv.length) {
//      	         clearInterval(timeControlFlag);
//      			 tmpLocationAddr = 0;
//               console.log('地址异常！');
//      }
        
        }, function(errorInfo) {
//         $scope.hideLoading();
			  reapetFlag = true;
               tmpLocationAddr = parseInt(tmpLocationAddr) + 1;
               tmpLocationAddr = parseInt(tmpLocationAddr);
               if(tmpLocationAddr >= tv.length) {
                 clearInterval(timeControlFlag);
                 //刷新连接状态
                 $scope.refreshSystemCurrent();
                 $scope.$apply();
                 $scope.hideLoading();
//               console.log('异常－数据刷完');
               }
       });
      }
     }, 550);
     if(tmpLocationAddr >= tv.length) {
                 clearInterval(timeControlFlag);
                  $scope.dealWithModeFireForAll();
                 //刷新连接状态
                 $scope.refreshSystemCurrent();
                 $scope.$apply();
                 $scope.hideLoading();
//               console.log('正常－数据刷完');
               }
    } else {
     //刷新连接状态
     $scope.refreshSystemCurrent();
     $scope.$apply();
    }
    } else {
    //属性协议控制查询处理部分
    //alert('success_0:' + messageBack);
   }
  }, function(errorInfo) {
   //alert(JSON.stringify(errorInfo));
  });
	};

	$scope.handleEvents = function() {
		$scope.$on('$routeChangeSuccess', function(event, next, current) {
//			console.log("ggggggggggg",event, next, current);
			if(next.loadedTemplateUrl === 'view/app/partials/central-ac/device-manager.html') {
				setTimeout(function() {
                     	
					$scope.isLoadDeviceMgrPage(next,current);
					if($scope.isLoadDeviceMgrPage(next,current)){
//						$scope.showLoading();
//						console.log("okokokokokokokokokoo",event, next, current);
						$scope.initDeviceManagerPage();
//						console.log("cccccccccc",event, next, current);
					}
				}, 500);
			}

			if(next.loadedTemplateUrl === 'view/app/partials/comfortSleep_new.html') {
				setTimeout(function() {
					//alert('tmpLocationAddr:' + tmpLocationAddr);
					requestSleepCurve(tmpLocationAddr);
				}, 500);
			}
			if(next.loadedTemplateUrl === 'view/app/partials/central-ac/duokong-ac.html') {
				setTimeout(function() {
					$scope.switchChangeSetWenDuValue();
					$scope.$broadcast('slider:control:for:wenduValue:init', {
						'current': $scope.quankongwendu
					});
				}, 500);
			}
			if(next.loadedTemplateUrl === 'view/app/partials/central-ac/quankong-ac.html') {
				setTimeout(function() {
					$scope.switchChangeSetWenDuValue();
					$scope.$broadcast('slider:control:for:wenduValue:init', {
						'current': $scope.quankongwendu
					});
				}, 500);
			}

			if(next.loadedTemplateUrl === 'view/app/partials/main_new.html') {
				$scope.resetBootControllerFeature();
				setTimeout(function() {
				$scope.updateMainView($scope.appRuntime.currentDeviceIndex); //只在进入这个界面的第一次调用
				},500);
//				setTimeout(function() {
//				_ACDriver.deviceStatus.locationOrder = index;
//					if($scope.devicelistItems[index].runningState == 1) {
//						var cmdBytes = _ACDriver.queryTimerDeviceOnOff(false);
//					} else {
//						var cmdBytes = _ACDriver.queryTimerDeviceOnOff(true);
//					}
//					$scope.sendCMD(cmdBytes, 0, 0);
//					}, 500);
						}
		});
	}

	$scope.handleVaribleListener = function() {
		$scope.$watch("appRuntime.currentRunState", function(news, olds) {
			if(news == 1) {
				$scope.changeHomePageAppearance($scope.appConfig.activeColor);
			} else {
				$scope.changeHomePageAppearance($scope.appConfig.deactiveColor);
			}
		});

		$scope.$watch("devicelistItems", function(news, olds) {
			if(news.length > 0) {
				clearTimeout($scope.appRuntime.networkDelay);
				$scope.hideLoading();
			}
		});
		
		$scope.$watch("songfeng", function(news, olds) {
			if(news != olds) {
				if($scope.songfeng) {
			$scope.$broadcast('slider:control:for:wenduValue:disable', {});
		} else {
			$scope.$broadcast('slider:control:for:wenduValue:enable', {});
		}
			}
		});
	};
	

	$scope.isLoadDeviceMgrPage = function(next,current) {
		if(current != undefined) {
			if(current.loadedTemplateUrl == undefined) {
//				console.log("load first page @@@@@@@@@@@");
				return true;
			} else if(((current.loadedTemplateUrl == "view/app/partials/central-ac/quankong-ac.html") || (current.loadedTemplateUrl == "view/app/partials/central-ac/duokong-ac.html"))&&
			next.loadedTemplateUrl =="view/app/partials/central-ac/device-manager.html" ) {
				//刷新连接状态
					$scope.refreshSystemCurrent();
                     $scope.$apply();
//                   console.log("unit_status:",unit_status);
//				console.log("load first page %%%%%%%%%%");
				return false;
			}else if((current.loadedTemplateUrl == "view/app/partials/main_new.html")&&
			next.loadedTemplateUrl =="view/app/partials/central-ac/device-manager.html" ) {
//				console.log("load first page &&&&&&&&&&&");
				return false;
			}
		} else {
			if(next != undefined) {
//				console.log("load first page **********");
				return true;
			} else {
//				console.log("load first page 。。。。。。。");
				return false;
			}
		}
	}

	//2017-07-04 状态同步
	function refreshNewVerForFen(p1, p2, p3) {
//		console.log('refreshNewVerForFen:' + 'p1:' + p1 + ';' + 'p2:' + p2);

		if((p1[0] == 0x01) && (p1[1] == 0x00)) {
			$scope.deviceStatusGroup[p3].runningState.value = p2[0]; //2017-04-17 开关状态
			$scope.deviceStatusGroup[p3].noPolarWindSpeedValue.value = 102;
			if($scope.deviceStatusGroup[p3].runningState.value==1 && ($scope.deviceStatusGroup[p3].settingMode.value == 1 ||
			$scope.deviceStatusGroup[p3].settingMode.value == 4)){
				$scope.deviceStatusGroup[p3].electricHeat.value = 1;
			}else{
				$scope.deviceStatusGroup[p3].electricHeat.value = 0;
			}
		} else if((p1[0] == 0x02) && (p1[1] == 0x00)) {
			
			$scope.deviceStatusGroup[p3].settingMode.value = p2[0]; //2017-04-17 模式状态
			if($scope.deviceStatusGroup[p3].settingMode.value == 1 ||
				$scope.deviceStatusGroup[p3].settingMode.value == 4) {
				$scope.deviceStatusGroup[p3].electricHeat.value = 1;
			} else {
				$scope.deviceStatusGroup[p3].electricHeat.value = 0;
			}

			$scope.deviceStatusGroup[p3].noPolarWindSpeedValue.value = 102;
			$scope.deviceStatusGroup[p3].sleepFunctionStatus.value = 0;
			
			
//			$scope.currentSleepOperation = "执行睡眠";
		} else if((p1[0] == 0x03) && (p1[1] == 0x00)) {
//			console.log("-----------p2-------------:" + p2);
			$scope.deviceStatusGroup[p3].settingTemperature.value = (p2[0] - 50) / 2; //2017-04-17 设定温度
			if($scope.deviceStatusGroup[p3].settingTemperature.value < 17){
				$scope.deviceStatusGroup[p3].settingTemperature.value = 26 ;
			}
			
		} else if((p1[0] == 0x04) && (p1[1] == 0x00)) {
			//		_ACDriver.deviceStatus.indoorTemperature = p2[0];					//2017-04-17 室内温度
		} else if((p1[0] == 0x05) && (p1[1] == 0x00)) {;
		} else if((p1[0] == 0x06) && (p1[1] == 0x00)) {
			$scope.deviceStatusGroup[p3].noPolarWindSpeedValue.value = p2[0]; //2017-04-17 设定风速
		} else if((p1[0] == 0x07) && (p1[1] == 0x00)) {;
		} else if((p1[0] == 0x08) && (p1[1] == 0x00)) {;
		} else if((p1[0] == 0x09) && (p1[1] == 0x00)) {;
		} else if((p1[0] == 0x0a) && (p1[1] == 0x00)) {;
		} else if((p1[0] == 0x0B) && (p1[1] == 0x00)) {
//			console.log("定时开_p2:",p2);
//			console.log("定时开_p1:",p1);
			$scope.deviceStatusGroup[p3].timingOpen.value = p2[0]; //2017-04-17 定时开
			if(parseInt($scope.deviceStatusGroup[p3].timingOpen.value) > 1)
			$scope.deviceStatusGroup[p3].timingOpen.value = 1;
			$scope.deviceStatusGroup[p3].timingOpenAbsoluteHours.value = p2[1]; //2017-04-17 小时
			$scope.deviceStatusGroup[p3].timingOpenAbsoluteMinutes.value = p2[2]; //2017-04-17 分
		} else if((p1[0] == 0x0C) && (p1[1] == 0x00)) {
//			console.log("定时guan:",p2);
			$scope.deviceStatusGroup[p3].timingClose.value = p2[0]; //2017-04-17 定时开
			if(parseInt($scope.deviceStatusGroup[p3].timingClose.value) > 1)
			$scope.deviceStatusGroup[p3].timingClose.value = 1;
			$scope.deviceStatusGroup[p3].timingCloseAbsoluteHours.value = p2[1]; //2017-04-17 小时
			$scope.deviceStatusGroup[p3].timingCloseAbsoluteMinutes.value = p2[2]; //2017-04-17 分
		} else if((p1[0] == 0x0D) && (p1[1] == 0x00)) {;
		} else if((p1[0] == 0x0E) && (p1[1] == 0x00)) {;
		} else if((p1[0] == 0x0F) && (p1[1] == 0x00)) {
			$scope.deviceStatusGroup[p3].electricHeat.value = p2[0];
		} else if((p1[0] == 0x10) && (p1[1] == 0x00)) {
			$scope.deviceStatusGroup[p3].dry.value = p2[0];
		} else if((p1[0] == 0x11) && (p1[1] == 0x00)) {
			$scope.deviceStatusGroup[p3].sleepFunctionStatus.value = p2[0]; //2017-04-18 舒睡状态
			
			if($scope.deviceStatusGroup[p3].sleepFunctionStatus.value == 3) {
				$scope.deviceStatusGroup[p3].sleepFunctionStatus.value = 1;
			}else{
				$scope.deviceStatusGroup[p3].sleepFunctionStatus.value = 0;
			}
			
			$scope.deviceStatusGroup[p3].sleepTimeFirst.value = (p2[2] - 50) / 2; //第1小时舒睡温度
			if($scope.deviceStatusGroup[p3].sleepTimeFirst.value <= 17){
				$scope.deviceStatusGroup[p3].sleepTimeFirst.value = 26;
			}
			$scope.deviceStatusGroup[p3].sleepTimeSecond.value = (p2[3] - 50) / 2; //第2小时舒睡温度
			if($scope.deviceStatusGroup[p3].sleepTimeSecond.value <= 17){
				$scope.deviceStatusGroup[p3].sleepTimeSecond.value = 26;
			}
			$scope.deviceStatusGroup[p3].sleepTimeThird.value = (p2[4] - 50) / 2; //第3小时舒睡温度
			if($scope.deviceStatusGroup[p3].sleepTimeThird.value <= 17){
				$scope.deviceStatusGroup[p3].sleepTimeThird.value = 26;
			}
			$scope.deviceStatusGroup[p3].sleepTimeFourth.value = (p2[5] - 50) / 2; //第4小时舒睡温度
			if($scope.deviceStatusGroup[p3].sleepTimeFourth.value <= 17){
				$scope.deviceStatusGroup[p3].sleepTimeFourth.value = 26;
			}
			$scope.deviceStatusGroup[p3].sleepTimeFifth.value = (p2[6] - 50) / 2; //第5小时舒睡温度
			if($scope.deviceStatusGroup[p3].sleepTimeFifth.value <= 17){
				$scope.deviceStatusGroup[p3].sleepTimeFifth.value = 26;
			}
			$scope.deviceStatusGroup[p3].sleepTimeSixth.value = (p2[7] - 50) / 2; //第6小时舒睡温度
			if($scope.deviceStatusGroup[p3].sleepTimeSixth.value <= 17){
				$scope.deviceStatusGroup[p3].sleepTimeSixth.value = 26;
			}
			$scope.deviceStatusGroup[p3].sleepTimeSeventh.value = (p2[8] - 50) / 2; //第7小时舒睡温度
			if($scope.deviceStatusGroup[p3].sleepTimeSeventh.value <= 17){
				$scope.deviceStatusGroup[p3].sleepTimeSeventh.value = 26;
			}
			$scope.deviceStatusGroup[p3].sleepTimeEighth.value = (p2[9] - 50) / 2; //第8小时舒睡温度
			if($scope.deviceStatusGroup[p3].sleepTimeSeventh.value<=17){
				$scope.deviceStatusGroup[p3].sleepTimeSeventh.value = 26;
			}
			$scope.deviceStatusGroup[p3].sleepTimeNinth.value = (p2[10] - 50) / 2; //第9小时舒睡温度	
			if($scope.deviceStatusGroup[p3].sleepTimeNinth.value <= 17){
				$scope.deviceStatusGroup[p3].sleepTimeNinth.value = 26;
			}
//			console.log("---$scope.deviceStatusGroup[p3]---:",$scope.deviceStatusGroup[p3]);
		}
		else if((p1[0] == 0x04) && (p1[1] == 0x0a)){
			
//			console.log("分机状态:" + p2);
			
			if(p2[0] == p2[1]){
				unit_status[0] = p2[2];
				unit_status[1] = p2[3];
				unit_status[2] = p2[4];
				unit_status[3] = p2[5];
				unit_status[4] = p2[6];
				unit_status[5] = p2[7];
				unit_status[6] = p2[8];
				unit_status[7] = p2[9];
			}
		}
		else {
			//return;
		}
		 		
	}

	//2017-07-04 新协议返回解析 并同步状态
	$scope.statusSynchro_new = function(pReceiveMessageBody) {
		deviceAddr = pReceiveMessageBody[1]; //同步分区地址

		tmpLocationAddr = deviceAddr;

//		console.log("pReceiveMessageBody:" + pReceiveMessageBody);
		if(deviceAddr > 7) {
			$scope.timeoutPopUp('设备地址异常!');
			return;
		}

		
		var dealCount = pReceiveMessageBody[2]; //属性个数
//		console.log("nnnnnnnnnn",pReceiveMessageBody);

		var si = 0;
		var sj = 0;
		var NewCmdType = []; //属性命令
		var NewCmdLength = 0; //属性长度
		var NewValue = []; //属性值
		var sk = 3;

		for(si = 0; si < dealCount; si++) {
			NewCmdType[0] = pReceiveMessageBody[sk];
			NewCmdType[1] = pReceiveMessageBody[sk + 1]; //高位

			NewCmdLength = parseInt(pReceiveMessageBody[sk + 3]);
			if(pReceiveMessageBody[sk + 2] == 0x00) {
				for(sj = 0; sj < NewCmdLength; sj++) {
					NewValue[sj] = pReceiveMessageBody[sk + 4 + sj];
				}
				refreshNewVerForFen(NewCmdType, NewValue, deviceAddr);
			} else {
				//			alert('设置失败！');
			}

			sk = sk + 3 + NewCmdLength + 1;
//			console.log("2017-07-08-----:" + sk + ';si"' + si);
		}
		for(var si = 0; si < 8; si++){
        if(($scope.deviceStatusGroup[si].settingMode.value != 4)&&($scope.deviceStatusGroup[si].settingMode.value != 1)){
         $scope.deviceStatusGroup[si].electricHeat.value = 0;
         }
        if(($scope.deviceStatusGroup[si].settingMode.value != 4)&&($scope.deviceStatusGroup[si].settingMode.value != 2)){
        	$scope.deviceStatusGroup[si].sleepFunctionStatus.value = 0;
        }
       }     
	}

	//状态同步
	$scope.statusSynchro = function(p1) {
		$scope.deviceStatusGroup[p1] = coreHelper.clone(_ACDriver.deviceStatus);
//		console.log("旧协议数据处理:$scope.deviceStatusGroup" + p1 + ":" + $scope.deviceStatusGroup[p1])
		//console.log("2017-07-05----statusSynchro", p1);
		//console.log("2017-07-05----$scope.deviceStatusGroup[p1]", $scope.deviceStatusGroup[p1]);
	}
	
	$scope.gotocardPage = function(){
		//标记是否进入卡片页
		pageFlag = false;//退出控制页
		$scope.redirectPage('central-ac', 'in');
	}

	$scope.gotoDevicePage = function(index) {
		clearInterval(timeControlFlag);
		$scope.appRuntime.currentDeviceIndex = index; //新页面索引注视
		$scope.redirectPage('main_new', 'in');
		//查分机定时状态
		_ACDriver.deviceStatus.locationOrder = index;
		
		//标记是否进入卡片页
		pageFlag = true;//进入卡片页
	    pageNumber = index;//进入的分机号
		
		if($scope.devicelistItems[$scope.appRuntime.currentDeviceIndex].runningState == 1) {
			var cmdBytes = _ACDriver.queryTimerDeviceOnOff(false);
		} else {
			var cmdBytes = _ACDriver.queryTimerDeviceOnOff(true);
		}
		$scope.sendCMD(cmdBytes, 0, 0);

	}

	$scope.refreshSystemCurrent = function() {
//		console.log("refreshSystemCurrent-$scope.deviceStatusGroup",$scope.deviceStatusGroup);
//		console.log("refreshSystemCurrent-$scope.unit_status",unit_status);
		$scope.devicelistItems = [{
				addr: 0,
				name: "1号分机",
				runningState:$scope.deviceStatusGroup[0].runningState.value == 1 || $scope.deviceStatusGroup[0].runningState.value == 0 ? $scope.deviceStatusGroup[0].runningState.value : 0,
				tempSetValue: parseInt($scope.deviceStatusGroup[0].settingTemperature.value),
				mode: parseInt($scope.deviceStatusGroup[0].settingMode.value),
				windSpeed: parseInt($scope.deviceStatusGroup[0].noPolarWindSpeedValue.value),
				isShow:  unit_status[0] == 1 || unit_status[0] == 3||  unit_status[0] == 4 ? true : false,
				modeShow: unit_status[0] == 4 ? true : false,
				electricHeat: $scope.deviceStatusGroup[0].electricHeat.value,
				DryStatus: $scope.deviceStatusGroup[0].dry.value,
				timingOpen: $scope.deviceStatusGroup[0].timingOpen.value,
				timingOpenAbsoluteHours: $scope.deviceStatusGroup[0].timingOpenAbsoluteHours.value,
				timingOpenAbsoluteMinutes: $scope.deviceStatusGroup[0].timingOpenAbsoluteMinutes.value,
				timingClose: $scope.deviceStatusGroup[0].timingClose.value,
				timingCloseAbsoluteHours: $scope.deviceStatusGroup[0].timingCloseAbsoluteHours.value,
				timingCloseAbsoluteMinutes: $scope.deviceStatusGroup[0].timingCloseAbsoluteMinutes.value,
				sleepFunctionStatus: parseInt($scope.deviceStatusGroup[0].sleepFunctionStatus.value),
				colour: parseInt($scope.deviceStatusGroup[0].runningState.value) == 1 ? '#0686FE' : '#b3b3b3',
				indoorTemperature: $scope.deviceStatusGroup[0].indoorTemperature.value,
				outdoorTemperature: $scope.deviceStatusGroup[0].outdoorTemperature.value,
				indoorTemperatureDot: $scope.deviceStatusGroup[0].indoorTemperatureDot.value,
				outdoorTemperatureDot: $scope.deviceStatusGroup[0].outdoorTemperatureDot.value
			},
			{
				addr: 1,
				name: "2号分机",
				runningState: $scope.deviceStatusGroup[1].runningState.value == 1 || $scope.deviceStatusGroup[1].runningState.value == 0 ? $scope.deviceStatusGroup[1].runningState.value : 0,
				tempSetValue: parseInt($scope.deviceStatusGroup[1].settingTemperature.value),
				mode: parseInt($scope.deviceStatusGroup[1].settingMode.value),
				windSpeed: parseInt($scope.deviceStatusGroup[1].noPolarWindSpeedValue.value),
				isShow:  unit_status[1] == 1 ||  unit_status[1] == 3|| unit_status[1] == 4 ? true : false,
				modeShow: unit_status[1] == 4 ? true : false,
				electricHeat: $scope.deviceStatusGroup[1].electricHeat.value,
				DryStatus: $scope.deviceStatusGroup[1].dry.value,
				timingOpen: $scope.deviceStatusGroup[1].timingOpen.value,
				timingOpenAbsoluteHours: $scope.deviceStatusGroup[1].timingOpenAbsoluteHours.value,
				timingOpenAbsoluteMinutes: $scope.deviceStatusGroup[1].timingOpenAbsoluteMinutes.value,
				timingClose: $scope.deviceStatusGroup[1].timingClose.value,
				timingCloseAbsoluteHours: $scope.deviceStatusGroup[1].timingCloseAbsoluteHours.value,
				timingCloseAbsoluteMinutes: $scope.deviceStatusGroup[1].timingCloseAbsoluteMinutes.value,
				sleepFunctionStatus: parseInt($scope.deviceStatusGroup[1].sleepFunctionStatus.value),
				colour: parseInt($scope.deviceStatusGroup[1].runningState.value) == 1 ? '#0686FE' : '#b3b3b3',
				indoorTemperature: $scope.deviceStatusGroup[1].indoorTemperature.value,
				outdoorTemperature: $scope.deviceStatusGroup[1].outdoorTemperature.value,
				indoorTemperatureDot: $scope.deviceStatusGroup[1].indoorTemperatureDot.value,
				outdoorTemperatureDot: $scope.deviceStatusGroup[1].outdoorTemperatureDot.value
			},
			{
				addr: 2,
				name: "3号分机",
				runningState: $scope.deviceStatusGroup[2].runningState.value == 1 || $scope.deviceStatusGroup[2].runningState.value == 0 ? $scope.deviceStatusGroup[2].runningState.value : 0,
				tempSetValue: parseInt($scope.deviceStatusGroup[2].settingTemperature.value),
				mode: parseInt($scope.deviceStatusGroup[2].settingMode.value),
				windSpeed: parseInt($scope.deviceStatusGroup[2].noPolarWindSpeedValue.value),
				isShow:  unit_status[2] == 1 || unit_status[2] == 3 || unit_status[2] == 4 ? true : false,
				modeShow:unit_status[2] == 4 ? true : false,
				electricHeat: $scope.deviceStatusGroup[2].electricHeat.value,
				DryStatus: $scope.deviceStatusGroup[2].dry.value,
				timingOpen: $scope.deviceStatusGroup[2].timingOpen.value,
				timingOpenAbsoluteHours: $scope.deviceStatusGroup[2].timingOpenAbsoluteHours.value,
				timingOpenAbsoluteMinutes: $scope.deviceStatusGroup[2].timingOpenAbsoluteMinutes.value,
				timingClose: $scope.deviceStatusGroup[2].timingClose.value,
				timingCloseAbsoluteHours: $scope.deviceStatusGroup[2].timingCloseAbsoluteHours.value,
				timingCloseAbsoluteMinutes: $scope.deviceStatusGroup[2].timingCloseAbsoluteMinutes.value,
				sleepFunctionStatus: parseInt($scope.deviceStatusGroup[2].sleepFunctionStatus.value),
				colour: parseInt($scope.deviceStatusGroup[2].runningState.value) == 1 ? '#0686FE' : '#b3b3b3',
				indoorTemperature: $scope.deviceStatusGroup[2].indoorTemperature.value,
				outdoorTemperature: $scope.deviceStatusGroup[2].outdoorTemperature.value,
				indoorTemperatureDot: $scope.deviceStatusGroup[2].indoorTemperatureDot.value,
				outdoorTemperatureDot: $scope.deviceStatusGroup[2].outdoorTemperatureDot.value
			},
			{
				addr: 3,
				name: "4号分机",
				runningState: $scope.deviceStatusGroup[3].runningState.value == 1 || $scope.deviceStatusGroup[3].runningState.value == 0 ? $scope.deviceStatusGroup[3].runningState.value : 0,
				tempSetValue: parseInt($scope.deviceStatusGroup[3].settingTemperature.value),
				mode: parseInt($scope.deviceStatusGroup[3].settingMode.value),
				windSpeed: parseInt($scope.deviceStatusGroup[3].noPolarWindSpeedValue.value),
				isShow: unit_status[3] == 1 || unit_status[3] == 3 || unit_status[3] == 4? true : false,
				modeShow:unit_status[3] == 4 ? true : false,
				electricHeat: $scope.deviceStatusGroup[3].electricHeat.value,
				DryStatus: $scope.deviceStatusGroup[3].dry.value,
				timingOpen: $scope.deviceStatusGroup[3].timingOpen.value,
				timingOpenAbsoluteHours: $scope.deviceStatusGroup[3].timingOpenAbsoluteHours.value,
				timingOpenAbsoluteMinutes: $scope.deviceStatusGroup[3].timingOpenAbsoluteMinutes.value,
				timingClose: $scope.deviceStatusGroup[3].timingClose.value,
				timingCloseAbsoluteHours: $scope.deviceStatusGroup[3].timingCloseAbsoluteHours.value,
				timingCloseAbsoluteMinutes: $scope.deviceStatusGroup[3].timingCloseAbsoluteMinutes.value,
				sleepFunctionStatus: parseInt($scope.deviceStatusGroup[3].sleepFunctionStatus.value),
				colour: parseInt($scope.deviceStatusGroup[3].runningState.value) == 1 ? '#0686FE' : '#b3b3b3',
				indoorTemperature: $scope.deviceStatusGroup[3].indoorTemperature.value,
				outdoorTemperature: $scope.deviceStatusGroup[3].outdoorTemperature.value,
				indoorTemperatureDot: $scope.deviceStatusGroup[3].indoorTemperatureDot.value,
				outdoorTemperatureDot: $scope.deviceStatusGroup[3].outdoorTemperatureDot.value
			},
			{
				addr: 4,
				name: "5号分机",
				runningState: $scope.deviceStatusGroup[4].runningState.value == 1 || $scope.deviceStatusGroup[4].runningState.value == 0 ? $scope.deviceStatusGroup[4].runningState.value : 0,
				tempSetValue: parseInt($scope.deviceStatusGroup[4].settingTemperature.value),
				mode: parseInt($scope.deviceStatusGroup[4].settingMode.value),
				windSpeed: parseInt($scope.deviceStatusGroup[4].noPolarWindSpeedValue.value),
				isShow: unit_status[4] == 1 || unit_status[4] == 3 || unit_status[4] == 4 ? true : false,
				modeShow:unit_status[4] == 4 ? true : false,
				electricHeat: $scope.deviceStatusGroup[4].electricHeat.value,
				DryStatus: $scope.deviceStatusGroup[4].dry.value,
				timingOpen: $scope.deviceStatusGroup[4].timingOpen.value,
				timingOpenAbsoluteHours: $scope.deviceStatusGroup[4].timingOpenAbsoluteHours.value,
				timingOpenAbsoluteMinutes: $scope.deviceStatusGroup[4].timingOpenAbsoluteMinutes.value,
				timingClose: $scope.deviceStatusGroup[4].timingClose.value,
				timingCloseAbsoluteHours: $scope.deviceStatusGroup[4].timingCloseAbsoluteHours.value,
				timingCloseAbsoluteMinutes: $scope.deviceStatusGroup[4].timingCloseAbsoluteMinutes.value,
				sleepFunctionStatus: parseInt($scope.deviceStatusGroup[4].sleepFunctionStatus.value),
				colour: parseInt($scope.deviceStatusGroup[4].runningState.value) == 1 ? '#0686FE' : '#b3b3b3',
				indoorTemperature: $scope.deviceStatusGroup[4].indoorTemperature.value,
				outdoorTemperature: $scope.deviceStatusGroup[4].outdoorTemperature.value,
				indoorTemperatureDot: $scope.deviceStatusGroup[4].indoorTemperatureDot.value,
				outdoorTemperatureDot: $scope.deviceStatusGroup[4].outdoorTemperatureDot.value
			},
			{
				addr: 5,
				name: "6号分机",
				runningState: $scope.deviceStatusGroup[5].runningState.value == 1 || $scope.deviceStatusGroup[5].runningState.value == 0 ? $scope.deviceStatusGroup[5].runningState.value : 0,
				tempSetValue: parseInt($scope.deviceStatusGroup[5].settingTemperature.value),
				mode: parseInt($scope.deviceStatusGroup[5].settingMode.value),
				windSpeed: parseInt($scope.deviceStatusGroup[5].noPolarWindSpeedValue.value),
				isShow: unit_status[5] == 1 || unit_status[5] == 3|| unit_status[5] == 4 ? true : false,
				modeShow:unit_status[5] == 4 ? true : false,
				electricHeat: $scope.deviceStatusGroup[5].electricHeat.value,
				DryStatus: $scope.deviceStatusGroup[5].dry.value,
				timingOpen: $scope.deviceStatusGroup[5].timingOpen.value,
				timingOpenAbsoluteHours: $scope.deviceStatusGroup[5].timingOpenAbsoluteHours.value,
				timingOpenAbsoluteMinutes: $scope.deviceStatusGroup[5].timingOpenAbsoluteMinutes.value,
				timingClose: $scope.deviceStatusGroup[5].timingClose.value,
				timingCloseAbsoluteHours: $scope.deviceStatusGroup[5].timingCloseAbsoluteHours.value,
				timingCloseAbsoluteMinutes: $scope.deviceStatusGroup[5].timingCloseAbsoluteMinutes.value,
				sleepFunctionStatus: parseInt($scope.deviceStatusGroup[5].sleepFunctionStatus.value),
				colour: parseInt($scope.deviceStatusGroup[5].runningState.value) == 1 ? '#0686FE' : '#b3b3b3',
				indoorTemperature: $scope.deviceStatusGroup[5].indoorTemperature.value,
				outdoorTemperature: $scope.deviceStatusGroup[5].outdoorTemperature.value,
				indoorTemperatureDot: $scope.deviceStatusGroup[5].indoorTemperatureDot.value,
				outdoorTemperatureDot: $scope.deviceStatusGroup[5].outdoorTemperatureDot.value
			},
			{
				addr: 6,
				name: "7号分机",
				runningState: $scope.deviceStatusGroup[6].runningState.value == 1 || $scope.deviceStatusGroup[6].runningState.value == 0 ? $scope.deviceStatusGroup[6].runningState.value : 0,
				tempSetValue: parseInt($scope.deviceStatusGroup[6].settingTemperature.value),
				mode: parseInt($scope.deviceStatusGroup[6].settingMode.value),
				windSpeed: parseInt($scope.deviceStatusGroup[6].noPolarWindSpeedValue.value),
				isShow: unit_status[6] == 1 || unit_status[6] == 3|| unit_status[6] == 4 ? true : false,
				modeShow:unit_status[6] == 4 ? true : false,
				electricHeat: $scope.deviceStatusGroup[6].electricHeat.value,
				DryStatus: $scope.deviceStatusGroup[6].dry.value,
				timingOpen: $scope.deviceStatusGroup[6].timingOpen.value,
				timingOpenAbsoluteHours: $scope.deviceStatusGroup[6].timingOpenAbsoluteHours.value,
				timingOpenAbsoluteMinutes: $scope.deviceStatusGroup[6].timingOpenAbsoluteMinutes.value,
				timingClose: $scope.deviceStatusGroup[6].timingClose.value,
				timingCloseAbsoluteHours: $scope.deviceStatusGroup[6].timingCloseAbsoluteHours.value,
				timingCloseAbsoluteMinutes: $scope.deviceStatusGroup[6].timingCloseAbsoluteMinutes.value,
				sleepFunctionStatus: parseInt($scope.deviceStatusGroup[6].sleepFunctionStatus.value),
				colour: parseInt($scope.deviceStatusGroup[6].runningState.value) == 1 ? '#0686FE' : '#b3b3b3',
				indoorTemperature: $scope.deviceStatusGroup[6].indoorTemperature.value,
				outdoorTemperature: $scope.deviceStatusGroup[6].outdoorTemperature.value,
				indoorTemperatureDot: $scope.deviceStatusGroup[6].indoorTemperatureDot.value,
				outdoorTemperatureDot: $scope.deviceStatusGroup[6].outdoorTemperatureDot.value
			},
			{
				addr: 7,
				name: "8号分机",
				runningState: $scope.deviceStatusGroup[7].runningState.value == 1 || $scope.deviceStatusGroup[7].runningState.value == 0 ? $scope.deviceStatusGroup[7].runningState.value : 0,
				tempSetValue: parseInt($scope.deviceStatusGroup[7].settingTemperature.value),
				mode: parseInt($scope.deviceStatusGroup[7].settingMode.value),
				windSpeed: parseInt($scope.deviceStatusGroup[7].noPolarWindSpeedValue.value),
				isShow: unit_status[7] == 1 || unit_status[7] == 3 || unit_status[7] == 4 ? true : false,
				modeShow:unit_status[7] == 4 ? true : false,
				electricHeat: $scope.deviceStatusGroup[7].electricHeat.value,
				DryStatus: $scope.deviceStatusGroup[7].dry.value,
				timingOpen: $scope.deviceStatusGroup[7].timingOpen.value,
				timingOpenAbsoluteHours: $scope.deviceStatusGroup[7].timingOpenAbsoluteHours.value,
				timingOpenAbsoluteMinutes: $scope.deviceStatusGroup[7].timingOpenAbsoluteMinutes.value,
				timingClose: $scope.deviceStatusGroup[7].timingClose.value,
				timingCloseAbsoluteHours: $scope.deviceStatusGroup[7].timingCloseAbsoluteHours.value,
				timingCloseAbsoluteMinutes: $scope.deviceStatusGroup[7].timingCloseAbsoluteMinutes.value,
				sleepFunctionStatus: $scope.deviceStatusGroup[7].sleepFunctionStatus.value,
				colour: parseInt($scope.deviceStatusGroup[7].runningState.value) == 1 ? '#0686FE' : '#b3b3b3',
				indoorTemperature: $scope.deviceStatusGroup[7].indoorTemperature.value,
				outdoorTemperature: $scope.deviceStatusGroup[7].outdoorTemperature.value,
				indoorTemperatureDot: $scope.deviceStatusGroup[7].indoorTemperatureDot.value,
				outdoorTemperatureDot: $scope.deviceStatusGroup[7].outdoorTemperatureDot.value
			},
		];
		$scope.appRuntime.currentRunState = $scope.devicelistItems[$scope.appRuntime.currentDeviceIndex].runningState;
	}
	

	$scope.refreshDeviceCurrent = function() {
		var fenjizt = _ACDriver.deviceStatus;
		var locationAddress = _ACDriver.deviceStatus.locationOrder;
		var tempSetValue = _ACDriver.deviceStatus.settingTemperature.value + 16;
	}

	//温度加
	$scope.addTempA = function(addr) {
		changeTempData(false, $scope.appRuntime.currentDeviceIndex);
	}

	//温度减
	$scope.subTempB = function(addr) {
		changeTempData(true, $scope.appRuntime.currentDeviceIndex);
	}

	function changeTempData(isSubTemp, addr) {
//		console.log("$scope.deviceStatusGroup[addr]",$scope.deviceStatusGroup[addr]);
		if($scope.devicelistItems[addr].runningState == 0) {
//			console.log("$scope.devicelistItems[addr].runningState00000:",$scope.devicelistItems[addr].runningState);
			$scope.timeoutPopUp("关机下温度不可调节!");
		} else if($scope.devicelistItems[addr].mode == 5) {
			$scope.timeoutPopUp("送风模式温度不可调节!");
		} else {
//			console.log("parseInt($scope.devicelistItems[addr].tempSetValue)",parseInt($scope.devicelistItems[addr].tempSetValue));
//			console.log("$scope.devicelistItems[addr].tempSetValue)",$scope.devicelistItems[addr].tempSetValue);
//			console.log("addr",addr);
			if(parseInt($scope.devicelistItems[addr].tempSetValue)<0){
				$scope.devicelistItems[addr].tempSetValue = 26;
			}
			if(isSubTemp) {
				//减
				if(parseInt($scope.devicelistItems[addr].tempSetValue) <= 17) {
					$scope.devicelistItems[addr].tempSetValue = 17;
				} else {
//					$scope.devicelistItems[addr].tempSetValue--;
					$scope.devicelistItems[addr].tempSetValue = parseInt($scope.devicelistItems[addr].tempSetValue) - 1;
				}
			} else {
				//加
				if(parseInt($scope.devicelistItems[addr].tempSetValue) >= 30) {
					$scope.devicelistItems[addr].tempSetValue = 30;
				} else {
					$scope.devicelistItems[addr].tempSetValue = parseInt($scope.devicelistItems[addr].tempSetValue) + 1;
				}
			}
			
//			console.log('$scope.devicelistItems[addr].tempSetValue_2' + $scope.devicelistItems[addr].tempSetValue);
//			console.log("-----addr------",addr);
			
			clearTimeout($scope.appRuntime.tempCtrlTimer);
			$scope.appRuntime.tempCtrlTimer = setTimeout(function() {
				_ACDriver.deviceStatus.locationOrder = addr;
				var cmdBytes = _ACDriver.controlSetTemperature(parseInt($scope.devicelistItems[addr].tempSetValue));
				$scope.sendCMD(cmdBytes, 0, 0);
			}, 500);

			$(".currentTemp").html($scope.devicelistItems[addr].tempSetValue);
		}
	}
	
	//兼容逻辑
	$scope.resetBootControllerFeature = function() {
		$scope.$on('ng::updateViewMessage', function(event, message) {});
		$(document).unbind('updateViewMessage');
		$(".main-temp-add,.main-temp-sub").unbind("touchstart").unbind("touchend").unbind("touchcancel");
	};

	$scope.closeDevice = function(addr) {
		
		if($scope.devicelistItems[addr].runningState == 1) {
			$scope.devicelistItems[addr].runningState = 0;
			$scope.deviceStatusGroup[addr].sleepFunctionStatus.value = 0;
			$scope.deviceStatusGroup[addr].electricHeat.value = 0;
		} else {
			$scope.devicelistItems[addr].runningState = 1;
		}
		_ACDriver.deviceStatus.locationOrder = addr;

		var cmdBytes = _ACDriver.controlDeviceOnAndOff($scope.devicelistItems[addr].runningState);
		$scope.sendCMD(cmdBytes, 0, 0);
		$scope.deviceStatusGroup[addr].timingClose.value = 0;
		$scope.deviceStatusGroup[addr].timingCloseAbsoluteHours.value = 0;
		$scope.deviceStatusGroup[addr].timingCloseAbsoluteMinutes.value = 0;
		$scope.deviceStatusGroup[addr].timingOpen.value = 0;
		$scope.deviceStatusGroup[addr].timingOpenAbsoluteHours.value = 0;
		$scope.deviceStatusGroup[addr].timingOpenAbsoluteMinutes.value = 0;
		
		//2017-08-17 只有一台机器开机，则不显示模式冲突,如果多台，则执行模式冲突判断
	    var tmpModekj_3_buffer = 0 ;
	  	for(var si = 0 ; si < tmpCurrentStatusLength; si++){
		  	if($scope.devicelistItems[si].runningState == 1){
		  		tmpModekj_3_buffer = tmpModekj_3_buffer + 1;
		  	}
	    }
	    if(tmpModekj_3_buffer <= 1){
	   	  	for(var si = 0 ; si < tmpCurrentStatusLength; si++){
	   	  		if(unit_status[si] != 2){
	    			unit_status[si] = 1;
	    			}
	    	  	}
	    }
	    else{
	    		var runMode = $scope.devicelistItems[addr].mode;
	    		$scope.dealWithModeFire(addr,runMode);
	    }
		
		
	};

	$scope.openDevice = function() {
		_ACDriver.runningState = 1; //开机
		_ACDriver.controlDeviceOnAndOff(_ACDriver.runningState);
	};

	$scope.openModel = function(addr) {
		if(!$scope.devicelistItems[addr].runningState == 1) {
			$scope.timeoutPopUp("关机下模式不可调节!");
		} else {
			$scope.openModal('isModeControl', [], function(event, data) {});
		}
	};

	$scope.dealWithModeFireForAll = function(){
	   var tmpflag = 0;
	   var tmpMode_1_count = 0;
	   var tmpMode_2_count = 0;
	   var tmpMode_1_buffer = [0,0,0,0,0,0,0,0];
	   var tmpMode_2_buffer = [0,0,0,0,0,0,0,0];
		
	  var tmpAddr;
	   for(var si = 0 ; si < tmpCurrentStatusLength; si++){
	   		
	   		tmpAddr = onLineDeviceAddrCache[si];
	   		
			if($scope.deviceStatusGroup[tmpAddr].runningState.value == 1){
				if((($scope.deviceStatusGroup[tmpAddr].settingMode.value == 4))){
					tmpMode_2_buffer[tmpAddr] = 1;
					tmpMode_2_count = tmpMode_2_count + 1;
				}
				else if((($scope.deviceStatusGroup[tmpAddr].settingMode.value == 2) || 
				              ($scope.deviceStatusGroup[tmpAddr].settingMode.value == 3) || 
				              ($scope.deviceStatusGroup[tmpAddr].settingMode.value == 5))){
					tmpMode_1_buffer[tmpAddr] = 1;
					tmpMode_1_count = tmpMode_1_count + 1;
				}
		  	}
			else{
				tmpMode_2_buffer[tmpAddr] = 0;
				tmpMode_1_buffer[tmpAddr] = 0;
			}
		}
	   	   
	    if((tmpMode_1_count > 0) && (tmpMode_2_count > 0)){
	    		for(var si = 0 ; si < tmpCurrentStatusLength; si++){
	    			
	    			tmpAddr = onLineDeviceAddrCache[si];
	    			
//	    			if(tmpMode_2_buffer[tmpAddr] == 1){
//	    				unit_status[tmpAddr] = 4;
//	    			}
//	    			else if(tmpMode_1_buffer[tmpAddr] == 1){
//	    				unit_status[tmpAddr] = 4;
//	    			}	
	    			if((tmpMode_2_buffer[tmpAddr] == 1) || (tmpMode_1_buffer[tmpAddr] == 1)){
	    				unit_status[tmpAddr] = 4;
	    			}
	    			else{
	    				unit_status[tmpAddr] = 1;
	    			}
	    		}
	    }
	    else{
	    		for(var si = 0 ; si < tmpCurrentStatusLength; si++){
	    			
	    			tmpAddr = onLineDeviceAddrCache[si];
	    			
	    			if(unit_status[tmpAddr] != 2){
	    			unit_status[tmpAddr] = 1;
	    			}
	    		}
	    }	    
	}

	$scope.dealWithModeFire = function(addr,runMode){
		var tmpflag = 0;
		var tmpAddr;
		for(var si = 0; si < tmpCurrentStatusLength; si++){
			tmpAddr = onLineDeviceAddrCache[si];
			if(addr != tmpAddr){
					if(((runMode==2) || (runMode==3)|| (runMode==5)) && 
					   ($scope.devicelistItems[tmpAddr].mode == 4)&&($scope.devicelistItems[tmpAddr].runningState == 1)){
					   		tmpflag = 1;
					   		si = tmpCurrentStatusLength + 1;//退出
				    }
					else if(($scope.devicelistItems[tmpAddr].runningState == 1)&&(runMode==4)  && 
					   (($scope.devicelistItems[tmpAddr].mode == 2)||($scope.devicelistItems[tmpAddr].mode == 3)||($scope.devicelistItems[tmpAddr].mode == 5))){
					   		tmpflag = 2;
					   		si = tmpCurrentStatusLength + 1;//退出
					   		
				    }  
				    else{
				    		
				    }
		   }
		}
		
		if(tmpflag > 0&&$scope.devicelistItems[addr].runningState==1){
			$scope.timeoutPopUp("发生模式冲突！");
		} else{
			$scope.devicelistItems[addr].modeShow = false ;
		}
	   $scope.devicelistItems[addr].mode = runMode;
	   
	   var tmpMode_1_count = 0;
	   var tmpMode_2_count = 0;
	   var tmpMode_3_count = 0;
	   var tmpMode_1_buffer = [0,0,0,0,0,0,0,0];
	   var tmpMode_2_buffer = [0,0,0,0,0,0,0,0];
	   var tmpMode_3_buffer = [0,0,0,0,0,0,0,0];

	   for(var si = 0 ; si < tmpCurrentStatusLength; si++){
	   		tmpAddr = onLineDeviceAddrCache[si];
			if($scope.devicelistItems[tmpAddr].runningState == 1){	   	
				if((($scope.devicelistItems[tmpAddr].mode == 4))){
					tmpMode_2_buffer[tmpAddr] = 1;
					tmpMode_2_count = tmpMode_2_count + 1;
				}
				else if((($scope.devicelistItems[tmpAddr].mode == 2) || ($scope.devicelistItems[tmpAddr].mode == 3) || ($scope.devicelistItems[tmpAddr].mode == 5))){
					tmpMode_1_buffer[tmpAddr] = 1;
					tmpMode_1_count = tmpMode_1_count + 1;
				}
		  	}
			else{
				tmpMode_2_buffer[tmpAddr] = 0;
				tmpMode_1_buffer[tmpAddr] = 0;
			}
		}
	   	   
//	   	   console.log("unit_statusunit_statusunit_status1:",unit_status);
//	   	   console.log("tmpMode_1_count:",tmpMode_1_count);
//	   	   console.log("tmpMode_1_buffer:",tmpMode_1_buffer);
//	   	   console.log("tmpMode_2_count:",tmpMode_2_count);
//	   	   console.log("tmpMode_2_buffer:",tmpMode_2_buffer);
		    if((tmpMode_1_count > 0) && (tmpMode_2_count > 0)){
		    		for(var si = 0 ; si < tmpCurrentStatusLength; si++){
		    			tmpAddr = onLineDeviceAddrCache[si];
//		    			if(tmpMode_2_buffer[tmpAddr] == 1){
//		    				unit_status[tmpAddr] = 4;
//		    			}
//		    			else if(tmpMode_1_buffer[tmpAddr] == 1){
//		    				unit_status[tmpAddr] = 4;
//		    			}	
		    			if((tmpMode_2_buffer[tmpAddr] == 1) || (tmpMode_1_buffer[tmpAddr] == 1)){
		    				unit_status[tmpAddr] = 4;
		    			}
		    			else{
		    				unit_status[tmpAddr] = 1;
		    			}
		    		}
		    }
		    else{
		    		for(var si = 0 ; si < tmpCurrentStatusLength; si++){
		    			tmpAddr = onLineDeviceAddrCache[si];
		    			if(unit_status[tmpAddr] != 2){
	    			        unit_status[tmpAddr] = 1;
	    			}
		    		}
		    }
//		    console.log("unit_statusunit_statusunit_status2:",unit_status);
	}
	$scope.dealWithModeFiresb = function(addr,runMode){
	   $scope.devicelistItems[addr].mode = runMode;
	   var tmpMode_1_count = 0;
	   var tmpMode_2_count = 0;
	   var tmpMode_1_buffer = [0,0,0,0,0,0,0,0];
	   var tmpMode_2_buffer = [0,0,0,0,0,0,0,0];
	
	   var tmpAddr;
	   for(var si = 0 ; si < tmpCurrentStatusLength; si++){
	   		
	   		tmpAddr = onLineDeviceAddrCache[si];
	   		
			if($scope.deviceStatusGroup[tmpAddr].runningState.value== 1){	   	
				if((($scope.deviceStatusGroup[tmpAddr].settingMode.value == 4))){
					tmpMode_2_buffer[tmpAddr] = 1;
					tmpMode_2_count = tmpMode_2_count + 1;
				}
				else if((($scope.deviceStatusGroup[tmpAddr].settingMode.value == 2) || 
						 ($scope.deviceStatusGroup[tmpAddr].settingMode.value == 3) || 
						 ($scope.deviceStatusGroup[tmpAddr].settingMode.value == 5))){
					tmpMode_1_buffer[tmpAddr] = 1;
					tmpMode_1_count = tmpMode_1_count + 1;
				}
		  	}
			else{
				tmpMode_2_buffer[tmpAddr] = 0;
				tmpMode_1_buffer[tmpAddr] = 0;
			}
		}
//	   	   console.log("active_unit_status1:",unit_status);
//	   	   console.log("tmpMode_1_count:",tmpMode_1_count);
//	   	   console.log("tmpMode_1_buffer:",tmpMode_1_buffer);
//	   	   console.log("tmpMode_2_count:",tmpMode_2_count);
//	   	   console.log("tmpMode_2_buffer:",tmpMode_2_buffer);	   	   
		    if((tmpMode_1_count > 0) && (tmpMode_2_count > 0)){
		    		for(var si = 0 ; si < tmpCurrentStatusLength; si++){
		    			tmpAddr = onLineDeviceAddrCache[si];
//		    			if(tmpMode_2_buffer[tmpAddr] == 1){
//		    				unit_status[tmpAddr] = 4;
//		    			}
//		    			else if(tmpMode_1_buffer[tmpAddr] == 1){
//		    				unit_status[tmpAddr] = 4;
//		    			}
		    			if((tmpMode_2_buffer[tmpAddr] == 1) || (tmpMode_1_buffer[tmpAddr] == 1)){
		    				unit_status[tmpAddr] = 4;
		    			}
		    			else{
		    				unit_status[tmpAddr] = 1;
		    			}
		    		}
		    }
		    else{
		    		for(var si = 0 ; si < tmpCurrentStatusLength; si++){
		    			tmpAddr = onLineDeviceAddrCache[si];
		    			if(unit_status[tmpAddr] != 2){
	    			       unit_status[tmpAddr] = 1;
	    			}
		    		}
		    }
//		    console.log("active_unit_status2:",unit_status);
	}
	
	//切换模式循环运行
	$scope.controlSwitchMode = function(addr) {
//		for(var si = 0; si < tmpCurrentStatusLength; si++){
//			if(($scope.devicelistItems[si].mode == 4)&&(unit_status[si] = 4)){
//				unit_status[si] = 4;
//			}else{
//				unit_status[si] = 1;
//			}
//		}
		
		var runMode = 1;
		
		if($scope.devicelistItems[addr].runningState == 0) {
			$scope.timeoutPopUp("关机下模式不可调节!");
		} else {
			var deviceStatus = parseInt($scope.devicelistItems[addr].mode);
			if(deviceStatus != undefined) {
//				console.log("ffffffffff",deviceStatus);
				runMode = deviceStatus + 1;
				if(runMode > 5) {
					if(runMode >= 7) {
						runMode = 2;
					} else {
						runMode = 1;
					}
				}
			} else {
				runMode = 1;
			}
			
		$scope.dealWithModeFire(addr,runMode);	
			
//		var tmpflag = 0;
//		for(var si = 0; si < tmpCurrentStatusLength; si++){
//			if(addr != si){
//					if(((runMode==2) || (runMode==3)|| (runMode==5)) && 
//					   ($scope.devicelistItems[si].mode == 4)&&($scope.devicelistItems[si].runningState == 1)){
//					   		tmpflag = 1;
//					   		si = tmpCurrentStatusLength + 1;//退出
//					   		
//				    }
//					else if(($scope.devicelistItems[si].runningState == 1)&&(runMode==4)  && 
//					   (($scope.devicelistItems[si].mode == 2)||($scope.devicelistItems[si].mode == 3)||($scope.devicelistItems[si].mode == 5))){
//					   		tmpflag = 2;
//					   		si = tmpCurrentStatusLength + 1;//退出
//					   		
//				    }  
//				    else{
//				    		
//				    }
//		   }
//		}
//		
//		$scope.devicelistItems[addr].mode = runMode;
//		console.log("runMode:" +runMode);
//		console.log("addr:" +addr);
//
//	   var tmpMode_1_count = 0;
//	   var tmpMode_2_count = 0;
//	   var tmpMode_3_count = 0;
//	   var tmpMode_1_buffer = [0,0,0,0,0,0,0,0];
//	   var tmpMode_2_buffer = [0,0,0,0,0,0,0,0];
//	   var tmpMode_3_buffer = [0,0,0,0,0,0,0,0];
//
//	   for(var si = 0 ; si < tmpCurrentStatusLength; si++){
//			if($scope.devicelistItems[si].runningState == 1){	   	
//				if((($scope.devicelistItems[si].mode == 4))){
//					tmpMode_2_buffer[si] = 1;
//					tmpMode_2_count = tmpMode_2_count + 1;
//				}
//				else if((($scope.devicelistItems[si].mode == 2) || ($scope.devicelistItems[si].mode == 3) || ($scope.devicelistItems[si].mode == 5))){
//					tmpMode_1_buffer[si] = 1;
//					tmpMode_1_count = tmpMode_1_count + 1;
//				}
//		  	}
//			else{
//				tmpMode_2_buffer[si] = 0;
//				tmpMode_1_buffer[si] = 0;
//			}
//		}
//	   
////	   console.log("--------tmpMode_1_count--------:",tmpMode_1_count);
////	   console.log("--------tmpMode_2_count--------:",tmpMode_2_count);
////	   console.log("--------tmpMode_1_buffer--------:",tmpMode_1_buffer);
////	   console.log("--------tmpMode_2_buffer--------:",tmpMode_2_buffer);
//	   
//	   
//		    if((tmpMode_1_count > 0) && (tmpMode_2_count > 0)){
//		    		for(var si = 0 ; si < tmpCurrentStatusLength; si++){
//		    			if(tmpMode_2_buffer[si] == 1){
//		    				unit_status[si] = 4;
//		    			}
//		    			else if(tmpMode_1_buffer[si] == 1){
//		    				unit_status[si] = 4;
//		    			}	    			
//		    		}
//		    }
//		    else{
//		    		for(var si = 0 ; si < tmpCurrentStatusLength; si++){
//		    			unit_status[si] = 1;
//		    		}
//		    }
	   
			$scope.devicelistItems[addr].mode = runMode;

			clearTimeout($scope.appRuntime.tempCtrlTimer);
			$scope.appRuntime.tempCtrlTimer = setTimeout(function() {
				_ACDriver.deviceStatus.locationOrder = addr;
				var cmdBytes = _ACDriver.controlComfortMode(runMode);
				$scope.sendCMD(cmdBytes, function(data){

				}, 0);
			}, 500);
		}
	}

	$scope.selectWindSpeedValue = function(addr, windValue) {
		if(($scope.devicelistItems[addr].runningState == 1) &&
			($scope.devicelistItems[addr].mode == 1 ||
				$scope.devicelistItems[addr].mode == 3)) {
			$scope.timeoutPopUp("自动或抽湿模式下风速不可调节!");
		} else if($scope.devicelistItems[addr].runningState == 0) {
			$scope.timeoutPopUp("关机下风速不可调节!");
		} else {
			$scope.isWindSpeedValueOpen = $scope.deviceStatusGroup[addr].noPolarWindSpeedValue.value;

			if($scope.isWindSpeedValueOpen <= 20) {
				_ACDriver.noPolarWindSpeedValue = 40;
			} else if($scope.isWindSpeedValueOpen <= 40) {
				_ACDriver.noPolarWindSpeedValue = 60;
			} else if($scope.isWindSpeedValueOpen <= 60) {
				_ACDriver.noPolarWindSpeedValue = 80;
			} else if($scope.isWindSpeedValueOpen <= 80) {
				_ACDriver.noPolarWindSpeedValue = 102;
			} else if($scope.isWindSpeedValueOpen <= 102) {
				_ACDriver.noPolarWindSpeedValue = 40;
			} else {
				_ACDriver.noPolarWindSpeedValue = 40;
			}

			_ACDriver.deviceStatus.locationOrder = addr;

			var cmdBytes = _ACDriver.controlComfortWindSpeed(_ACDriver.noPolarWindSpeedValue);
			$scope.devicelistItems[addr].windSpeed = _ACDriver.noPolarWindSpeedValue;
			$scope.sendCMD(cmdBytes, 0, 0);
			console.log(_ACDriver);
		};
	}

	/*模式控制*/
	$scope.switchModel = function(addr, modeValue) {
		
	    var tmpflag = 0;
		for(si = 0; si < tmpCurrentStatusLength; si++){
			if(addr != si){
					if(((modeValue==2) || (modeValue==3)) && 
					   ($scope.devicelistItems[si].mode == 4)&&($scope.devicelistItems[si].runningState == 1)){
					   		tmpflag = 1;
					   		si = tmpCurrentStatusLength + 1;//退出
				    }
					else if(($scope.devicelistItems[si].runningState == 1)&&(modeValue==4)  && 
					   (($scope.devicelistItems[si].mode == 2)||($scope.devicelistItems[si].mode == 3))){
					   		tmpflag = 2;
					   		si = tmpCurrentStatusLength + 1;//退出
				    }   
		   }
		}
		
		if(tmpflag > 0){
			$scope.hideLoading();
			$scope.timeoutPopUp("请检查其他分机的模式状态！");
			return;
		}		
		
		$scope.closeModal('isModeControl');
		
		if($scope.deviceStatus.runningMode != modeValue) {
			$scope.devicelistItems[addr].mode = modeValue; //制冷模式

			_ACDriver.deviceStatus.locationOrder = addr;

			var cmdBytes = _ACDriver.controlComfortMode(modeValue);
			$scope.sendCMD(cmdBytes, 0, 0);
		}
	}

	$scope.closeChangeWindSpeed = function() {
		$scope.closeModal('isChangeWindSpeed');
	}

	$scope.switchChangeWindSpeed = function() {
		/*调节风速*/
		try {
			$(document).bind('slider:control:update', {}, function(event, data) {
				$scope.selectWindSpeedValue(data.current);
			});
		} catch(e) {}
	}

	$scope.switchElectricHeat = function(addr) {
		try {
			if($scope.devicelistItems[addr].runningState == 0) {
				$scope.timeoutPopUp("关机下电辅热不可调节!");
			} else {
				if((parseInt($scope.devicelistItems[addr].mode) != 1) &&
					(parseInt($scope.devicelistItems[addr].mode) != 4)) {
					$scope.timeoutPopUp("电辅热只在分机处于自动或者制热模式下有效!");
				} else {
					_ACDriver.deviceStatus.locationOrder = addr;
					if(parseInt($scope.devicelistItems[addr].electricHeat) == 1) {
						var cmdBytes = _ACDriver.controlSwitchElecHeatHelper(false); //设置电辅热开
						$scope.devicelistItems[addr].electricHeat = 0;
					} else {
						var cmdBytes = _ACDriver.controlSwitchElecHeatHelper(true); //设置电辅热开
						$scope.devicelistItems[addr].electricHeat = 1;
					}

					$scope.sendCMD(cmdBytes, 0, 0);
				}
			}
		} catch(e) {}
	};

	$scope.switchDry = function(addr) {
		try {
			if(($scope.devicelistItems[addr].runningState == 0) && ($scope.devicelistItems[addr].DryStatus == 0)) {
				$scope.timeoutPopUp("关机下不可开启干燥!");
			} else {

				if((parseInt($scope.devicelistItems[addr].mode) == 1) ||
					(parseInt($scope.devicelistItems[addr].mode) == 4) ||
					(parseInt($scope.devicelistItems[addr].mode) == 5)) {
					$scope.timeoutPopUp("干燥只在分机处于制冷或者抽湿模式下有效!");
				} else {
					_ACDriver.deviceStatus.locationOrder = addr;
					if(parseInt($scope.devicelistItems[addr].DryStatus) == 1) {
						var cmdBytes = _ACDriver.controlComfortDry(false); //设置电辅热开
						$scope.devicelistItems[addr].DryStatus = 0;
					} else {
						var cmdBytes = _ACDriver.controlComfortDry(true); //设置电辅热开
						$scope.devicelistItems[addr].DryStatus = 1;
					}

					$scope.sendCMD(cmdBytes, 0, 0);
				}
			}
		} catch(e) {}
	};

	/*定时关机控制*/
	$scope.setTimer = function(addr) {
		try {
			if($scope.appRuntime.timerCurrentStatus) {
				$scope.closeModal('isScrollDateSelector');

				_ACDriver.deviceStatus.locationOrder = addr;
				
//				console.log("$scope.devicelistItems[addr].runningState:" , $scope.devicelistItems[addr].runningState);
				if(parseInt($scope.devicelistItems[addr].runningState)) {
					var cmdBytes = _ACDriver.controlSetTimerDeviceOnOff(true, 1, $scope.appRuntime.timerMessage.currentHour, $scope.appRuntime.timerMessage.currentMin);
					$scope.deviceStatusGroup[addr].timingClose.value = 1;
					$scope.deviceStatusGroup[addr].timingOpen.value = 0;
					$scope.deviceStatusGroup[addr].timingOpenAbsoluteHours.value = 0;
					$scope.deviceStatusGroup[addr].timingOpenAbsoluteMinutes.value = 0;
//					console.log("$scope.deviceStatusGroup[addr].timingClose.value = 1;",$scope.deviceStatusGroup[addr].timingClose.value)
				} else {
					var cmdBytes = _ACDriver.controlSetTimerDeviceOnOff(false, 1, $scope.appRuntime.timerMessage.currentHour, $scope.appRuntime.timerMessage.currentMin);
					$scope.deviceStatusGroup[addr].timingOpen.value = 1;
					$scope.deviceStatusGroup[addr].timingClose.value = 0;
					$scope.deviceStatusGroup[addr].timingCloseAbsoluteHours.value = 0;
					$scope.deviceStatusGroup[addr].timingCloseAbsoluteMinutes.value = 0;
//					console.log("$scope.deviceStatusGroup[addr].timingOpen.value = 1;",$scope.deviceStatusGroup[addr].timingOpen.value);
				}

				$scope.sendCMD(cmdBytes, 0, 0);
//				alert(cmdBytes);
			} else {
				$scope.closeTimer(addr);
			}
		} catch(e) {}
	}

	$scope.closeTimer = function(addr) {
		try {
			$scope.closeModal('isScrollDateSelector');
			_ACDriver.deviceStatus.locationOrder = addr;

			if(parseInt($scope.devicelistItems[addr].runningState)) {
				var cmdBytes = _ACDriver.controlSetTimerDeviceOnOff(false, 0, 0, 0);
			} else {
				var cmdBytes = _ACDriver.controlSetTimerDeviceOnOff(true, 0, 0, 0);
			}

			$scope.sendCMD(cmdBytes, 0, 0);
			$scope.deviceStatusGroup[addr].timingClose.value = 0;
			$scope.deviceStatusGroup[addr].timingCloseAbsoluteHours.value = 0;
			$scope.deviceStatusGroup[addr].timingCloseAbsoluteMinutes.value = 0;
			$scope.deviceStatusGroup[addr].timingOpen.value = 0;
			$scope.deviceStatusGroup[addr].timingOpenAbsoluteHours.value = 0;
			$scope.deviceStatusGroup[addr].timingOpenAbsoluteMinutes.value = 0;
		} catch(e) {}
	};

	$scope.openTimerModal = function(addr) {
		$scope.appRuntime.deviceRunningStatus = $scope.devicelistItems[addr].runningState;
		var scrollSelectorStartValue = 0;
		var setTime = 0;

		if(parseInt($scope.devicelistItems[addr].runningState)) {
			if(parseInt($scope.deviceStatusGroup[addr].timingClose.value)) {
				setTime = parseInt($scope.deviceStatusGroup[addr].timingCloseAbsoluteHours.value * 60) +
					parseInt($scope.deviceStatusGroup[addr].timingCloseAbsoluteMinutes.value);
			} else {
				setTime = -1;
			}
		} else {
			if(parseInt($scope.deviceStatusGroup[addr].timingOpen.value)) {
				setTime = parseInt($scope.deviceStatusGroup[addr].timingOpenAbsoluteHours.value * 60) +
					parseInt($scope.deviceStatusGroup[addr].timingOpenAbsoluteMinutes.value);
			} else {
				setTime = -1;
			}
		}

		if(0 < setTime && setTime <= 1440) {
			if(0 == (setTime % 30)) {
				scrollSelectorStartValue = Math.floor(setTime / 60) * 2 + Math.floor((setTime % 60) / 30) - 1;
			} else {
				scrollSelectorStartValue = Math.floor(setTime / 60) * 2 + Math.floor((setTime % 60) / 30);
			}
		} else {
			scrollSelectorStartValue = 0;
		}
		$scope.appRuntime.scrollSelectorStart = scrollSelectorStartValue;

		$scope.openModal('isScrollDateSelector', staticData.getTimerData(), function(event, data, mod, pos, current) {
			$scope.appRuntime.timerCurrentStatus = current.status;

			if(current.status) {
				var response = data.split(',');
				$scope.appRuntime.timerMessage = {
					currentHour: response[0],
					currentMin: response[1]
				};
			}
		});
	};
	
	$scope.gotoDeviceshuimianPage = function(addr) {
		if($scope.devicelistItems[addr].runningState == 0) {
			$scope.timeoutPopUp("关机状态睡眠不可设置!");
		}else if((parseInt($scope.devicelistItems[addr].mode)) == 1 || (parseInt($scope.devicelistItems[addr].mode)) == 5 ||
			(parseInt($scope.devicelistItems[addr].mode)) == 3) {
			$scope.timeoutPopUp("睡眠只在分机处于制冷或者制热下有效!");
		} else{
		$scope.redirectPage('comfort-sleep_new','in');
		}
	}

	//睡眠初始化
	function requestSleepCurve(addr) {
		dealSleepStatusForFen(addr);
	}

	function dealSleepStatusForFen(addr) {
		
		var tmpsleetDataBuffer;
		tmpsleetDataBuffer = $scope.getLsVar(0x10 + parseInt(addr),"tmpsleetDataBuffer");
		
		if(tmpsleetDataBuffer == undefined){
			$scope.appRuntime.sleepCurveData[0] = $scope.deviceStatusGroup[addr].settingTemperature.value;
			$scope.appRuntime.sleepCurveData[1] = 26;
			$scope.appRuntime.sleepCurveData[2] = 26;
			$scope.appRuntime.sleepCurveData[3] = 26;
			$scope.appRuntime.sleepCurveData[4] = 26;
			$scope.appRuntime.sleepCurveData[5] = 26;
			$scope.appRuntime.sleepCurveData[6] = 26;
			$scope.appRuntime.sleepCurveData[7] = 26;
			$scope.appRuntime.sleepCurveData[8] = 26;
			$scope.appRuntime.sleepCurveData[9] = 26;
		}
		else{
			$scope.appRuntime.sleepCurveData[0] = $scope.deviceStatusGroup[addr].settingTemperature.value;
			$scope.appRuntime.sleepCurveData[1] = tmpsleetDataBuffer[0];
			$scope.appRuntime.sleepCurveData[2] = tmpsleetDataBuffer[1];
			$scope.appRuntime.sleepCurveData[3] = tmpsleetDataBuffer[2];
			$scope.appRuntime.sleepCurveData[4] = tmpsleetDataBuffer[3];
			$scope.appRuntime.sleepCurveData[5] = tmpsleetDataBuffer[4];
			$scope.appRuntime.sleepCurveData[6] = tmpsleetDataBuffer[5];
			$scope.appRuntime.sleepCurveData[7] = tmpsleetDataBuffer[6];
			$scope.appRuntime.sleepCurveData[8] = tmpsleetDataBuffer[7];
			$scope.appRuntime.sleepCurveData[9] = tmpsleetDataBuffer[7];
		}
//		console.log("tmpsleetDataBuffertmpsleetDataBuffer:",tmpsleetDataBuffer);
		
		var tmpStatus;
		var tmpLength;

		var sleepReceiveMsg = [11];
		var tmpBf = [9];

		sleepReceiveMsg[0] = $scope.devicelistItems[addr].sleepFunctionStatus;
		sleepReceiveMsg[1] = 9;
		
		$scope.appCache.pullMenuData[addr] = $scope.appRuntime.sleepCurveData;
		
		setTimeout(function(){
			if(parseInt($scope.devicelistItems[addr].sleepFunctionStatus)==1) {
				$scope.currentSleepOperation = "取消睡眠";
			} else {
				$scope.currentSleepOperation = "执行睡眠";
			}
			$scope.$apply();
		},500);
		
		$scope.$apply();		
//		console.log("$scope.appRuntime.sleepCurveData:", $scope.appRuntime.sleepCurveData);
		
		$scope.$broadcast('init:interactChart', {
			current: $scope.appRuntime.sleepCurveData
		});
	};

	$(document).bind('interactChart:data:update', {}, function(event, data) {
		$scope.$apply(function() {
			$scope.appRuntime.sleepCurveData = data.currentVal;
			//$scope.acController.dataManager.selectCustomCurveValue($scope.appRuntime.sleepData);
			//$scope.sleepData = $scope.acController.dataManager.getSleepMode();
		});
	});

	//舒睡曲线
	$scope.changeSleepStatus_new = function(isOpen, addr) {
		if($scope.devicelistItems[addr].runningState == 0) {
			$scope.timeoutPopUp("关机状态睡眠不可设置!");

		} else if((parseInt($scope.devicelistItems[addr].mode)) == 1 || (parseInt($scope.devicelistItems[addr].mode)) == 5 ||
			(parseInt($scope.devicelistItems[addr].mode)) == 3) {
			$scope.timeoutPopUp("睡眠只在分机处于制冷或者制热下有效!");
		} else {
			var addr = _ACDriver.deviceStatus.locationOrder;
			var tmpBf = [11];

			tmpBf[1] = 9;
//			console.log("$scope.appRuntime.sleepCurveData:",$scope.appRuntime.sleepCurveData);
			
			$scope.deviceStatusGroup[addr].sleepTimeFirst.value = $scope.appRuntime.sleepCurveData[1];
			$scope.deviceStatusGroup[addr].sleepTimeSecond.value = $scope.appRuntime.sleepCurveData[2];
			$scope.deviceStatusGroup[addr].sleepTimeThird.value = $scope.appRuntime.sleepCurveData[3];
			$scope.deviceStatusGroup[addr].sleepTimeFourth.value = $scope.appRuntime.sleepCurveData[4];
			$scope.deviceStatusGroup[addr].sleepTimeFifth.value = $scope.appRuntime.sleepCurveData[5];
			$scope.deviceStatusGroup[addr].sleepTimeSixth.value = $scope.appRuntime.sleepCurveData[6];
			$scope.deviceStatusGroup[addr].sleepTimeSeventh.value = $scope.appRuntime.sleepCurveData[7];
			$scope.deviceStatusGroup[addr].sleepTimeEighth.value = $scope.appRuntime.sleepCurveData[8];
			$scope.deviceStatusGroup[addr].sleepTimeNinth.value = $scope.appRuntime.sleepCurveData[8];

			
			for(var i=0; i<$scope.appRuntime.sleepCurveData.length; i++) {
				tmpBf[i+2] = $scope.appRuntime.sleepCurveData[i + 1];
			}
//			console.log("$scope.appRuntime.sleepCurveData:",$scope.appRuntime.sleepCurveData);
			
			//save sleep data
		
		var tmpsleetDataBuffer = [];
		tmpsleetDataBuffer[0] = $scope.appRuntime.sleepCurveData[1];
		tmpsleetDataBuffer[1] = $scope.appRuntime.sleepCurveData[2];
		tmpsleetDataBuffer[2] = $scope.appRuntime.sleepCurveData[3];
		tmpsleetDataBuffer[3] = $scope.appRuntime.sleepCurveData[4];
		tmpsleetDataBuffer[4] = $scope.appRuntime.sleepCurveData[5];
		tmpsleetDataBuffer[5] = $scope.appRuntime.sleepCurveData[6];
		tmpsleetDataBuffer[6] = $scope.appRuntime.sleepCurveData[7];
		tmpsleetDataBuffer[7] = $scope.appRuntime.sleepCurveData[8];
		tmpsleetDataBuffer[8] = $scope.appRuntime.sleepCurveData[8];
		$scope.setLsVar(0x10 + parseInt(addr),"tmpsleetDataBuffer",tmpsleetDataBuffer);
//		console.log('tmpsleetDataBuffer:' + tmpsleetDataBuffer);
			
			if(isOpen) {
				tmpBf[0] = 1;
				$scope.currentSleepOperation = "取消睡眠";
				$scope.devicelistItems[addr].sleepFunctionStatus = 1;
				$scope.deviceStatusGroup[addr].settingTemperature.value=tmpBf[2];
			} else {
				tmpBf[0] = 0;
				$scope.currentSleepOperation = "执行睡眠";
				$scope.devicelistItems[addr].sleepFunctionStatus = 0;
			}

			var cmdBytes = _ACDriver.setLocalSleepStatus(tmpBf);


			$scope.sendCMD(cmdBytes, 0, 0);
//			console.log("睡眠发码：",cmdBytes);

		}
	}

	$scope.qukongmoshizhidong = function() {
		$scope.zhileng = false;
		$scope.zhilengg = true;
		$scope.zhire = false;
		$scope.zhireg = true;
		$scope.zhidong = true;
		$scope.zhidongg = false;
		$scope.songfeng = false;
		$scope.songfengg = true;
		$scope.choushi = false;
		$scope.choushig = true;
		$scope.colorz = "#0686FE";
		$scope.colorl = "#808080";
		$scope.colorc = "#808080";
		$scope.colors = "#808080";
		$scope.colorr = "#808080";
		$scope.quankongmoshi = 1;
		$scope.qukongfengsuzidong();
	}

	$scope.qukongmoshizhileng = function() {
		$scope.zhileng = true;
		$scope.zhilengg = false;
		$scope.zhire = false;
		$scope.zhireg = true;
		$scope.zhidong = false;
		$scope.zhidongg = true;
		$scope.songfeng = false;
		$scope.songfengg = true;
		$scope.choushi = false;
		$scope.choushig = true;
		$scope.colorl = "#0686FE";
		$scope.colorz = "#808080";
		$scope.colorc = "#808080";
		$scope.colors = "#808080";
		$scope.colorr = "#808080";
		$scope.quankongmoshi = 2;
		$scope.qukongfengsuzidong();
	}

	$scope.qukongmoshichoushi = function() {
		$scope.zhileng = false;
		$scope.zhilengg = true;
		$scope.zhire = false;
		$scope.zhireg = true;
		$scope.zhidong = false;
		$scope.zhidongg = true;
		$scope.songfeng = false;
		$scope.songfengg = true;
		$scope.choushi = true;
		$scope.choushig = false;
		$scope.colorc = "#0686FE";
		$scope.colorz = "#808080";
		$scope.colorl = "#808080";
		$scope.colors = "#808080";
		$scope.colorr = "#808080";
		$scope.quankongmoshi = 3;
		$scope.qukongfengsuzidong();

	}

	$scope.qukongmoshizhire = function() {
		$scope.zhileng = false;
		$scope.zhilengg = true;
		$scope.zhire = true;
		$scope.zhireg = false;
		$scope.zhidong = false;
		$scope.zhidongg = true;
		$scope.songfeng = false;
		$scope.songfengg = true;
		$scope.choushi = false;
		$scope.choushig = true;
		$scope.colorr = "#0686FE";
		$scope.colorc = "#808080";
		$scope.colorz = "#808080";
		$scope.colorl = "#808080";
		$scope.colors = "#808080";
		$scope.quankongmoshi = 4;
		$scope.qukongfengsuzidong();
	}

	$scope.qukongmoshisongfeng = function() {
		$scope.zhileng = false;
		$scope.zhilengg = true;
		$scope.zhire = false;
		$scope.zhireg = true;
		$scope.zhidong = false;
		$scope.zhidongg = true;
		$scope.songfeng = true;
		$scope.songfengg = false;
		$scope.choushi = false;
		$scope.choushig = true;
		$scope.colors = "#0686FE";
		$scope.colorr = "#808080";
		$scope.colorc = "#808080";
		$scope.colorz = "#808080";
		$scope.colorl = "#808080";
		$scope.quankongmoshi = 5;
		$scope.qukongfengsuzidong();
	}

	$scope.qukongfengsuzidong = function() {
		$scope.fengsuzidong = true;
		$scope.fengsuzidongg = false;
		$scope.fengsudifeng = false;
		$scope.fengsudifengg = true;
		$scope.fengsuzhongfeng = false;
		$scope.fengsuzhongfengg = true;
		$scope.fengsugaofeng = false;
		$scope.fengsugaofengg = true;

		$scope.colorfengsuzidong = "#0686FE";
		$scope.colorfengsudifeng = "#808080";
		$scope.colorfengsuzhongfeng = "#808080";
		$scope.colorfengsugaofeng = "#808080";

		$scope.quankongfengsu = 102;
	}

	$scope.qukongfengsudifeng = function() {
		if($scope.zhidong || $scope.choushi) {
			$scope.timeoutPopUp("自动或抽湿模式下风速不可调！");
		} else {
			$scope.fengsuzidong = false;
			$scope.fengsuzidongg = true;
			$scope.fengsudifeng = true;
			$scope.fengsudifengg = false;
			$scope.fengsuzhongfeng = false;
			$scope.fengsuzhongfengg = true;
			$scope.fengsugaofeng = false;
			$scope.fengsugaofengg = true;

			$scope.colorfengsuzidong = "#808080";
			$scope.colorfengsudifeng = "#0686FE";
			$scope.colorfengsuzhongfeng = "#808080";
			$scope.colorfengsugaofeng = "#808080";

			$scope.quankongfengsu = 40;
		}
	}
	$scope.qukongfengsuzhongfeng = function() {
		if($scope.zhidong || $scope.choushi) {
			$scope.timeoutPopUp("自动或抽湿模式下风速不可调！");
		} else {
			$scope.fengsuzidong = false;
			$scope.fengsuzidongg = true;
			$scope.fengsudifeng = false;
			$scope.fengsudifengg = true;
			$scope.fengsuzhongfeng = true;
			$scope.fengsuzhongfengg = false;
			$scope.fengsugaofeng = false;
			$scope.fengsugaofengg = true;

			$scope.colorfengsuzidong = "#808080";
			$scope.colorfengsudifeng = "#808080";
			$scope.colorfengsuzhongfeng = "#0686FE";
			$scope.colorfengsugaofeng = "#808080";

			$scope.quankongfengsu = 60;
		}
	}
	$scope.qukongfengsugaofeng = function() {
		if($scope.zhidong || $scope.choushi) {
			$scope.timeoutPopUp("自动或抽湿模式下风速不可调！");
		} else {
			$scope.fengsuzidong = false;
			$scope.fengsuzidongg = true;
			$scope.fengsudifeng = false;
			$scope.fengsudifengg = true;
			$scope.fengsuzhongfeng = false;
			$scope.fengsuzhongfengg = true;
			$scope.fengsugaofeng = true;
			$scope.fengsugaofengg = false;

			$scope.colorfengsuzidong = "#808080";
			$scope.colorfengsudifeng = "#808080";
			$scope.colorfengsuzhongfeng = "#808080";
			$scope.colorfengsugaofeng = "#0686FE";

			$scope.quankongfengsu = 80;
		}

	}
	$scope.quanguan = function() {
		$scope.fengsuzidong = false;
		$scope.fengsuzidongg = true;
		$scope.fengsudifeng = false;
		$scope.fengsudifengg = true;
		$scope.fengsuzhongfeng = false;
		$scope.fengsuzhongfengg = true;
		$scope.fengsugaofeng = false;
		$scope.fengsugaofengg = true;
		$scope.zhileng = false;
		$scope.zhilengg = true;
		$scope.zhire = false;
		$scope.zhireg = true;
		$scope.zhidong = false;
		$scope.zhidongg = true;
		$scope.songfeng = false;
		$scope.songfengg = true;
		$scope.choushi = false;
		$scope.choushig = true;
		$scope.colorl = "#808080";
		$scope.colorz = "#808080";
		$scope.colorc = "#808080";
		$scope.colors = "#808080";
		$scope.colorr = "#808080";
		$scope.colorfengsuzidong = "#808080";
		$scope.colorfengsudifeng = "#808080";
		$scope.colorfengsuzhongfeng = "#808080";
		$scope.colorfengsugaofeng = "#808080";
	}

	$scope.duokongfengji = function(isOpen, addr) {
		if(isOpen) {
			$scope.appRuntime.duokongxuanzhong[addr] = true;
		} else {
			$scope.appRuntime.duokongxuanzhong[addr] = false;
		}

	}

	$scope.switchChangeSetWenDuValue = function() {
		if($scope.songfeng) {
			$scope.$broadcast('slider:control:for:wenduValue:disable', {});
		} else {
			$scope.$broadcast('slider:control:for:wenduValue:enable', {});
		}

		$(document).bind('slider:control:for:wenduValue:update', {}, function(event, data) {
			$scope.quankongwendu = data.current;
			$scope.$apply();			
		});
		
		//alert("wenduValue=="+data.current);

	}

	//先查询分机在线状态，再根据选中状态发码
	$scope.loopControlPro = function(type) {
		if(type == 1 && $scope.zhilengg && 
		   $scope.zhireg && $scope.zhidongg && 
		   $scope.choushig && $scope.songfengg) {
				$scope.timeoutPopUp("请选择模式！");
			} else if(type == 1 && $scope.fengsuzidongg && 
				      $scope.fengsudifengg && $scope.fengsuzhongfengg && 
				      $scope.fengsugaofengg) {
				$scope.timeoutPopUp("请选择风速！");
			} else {
				
				if(type == 0) {
					$scope.quanguan();
				}
				
				clearTimeout(totalControlTimeFlag);
				
				closeActiveFlag = false;
				$scope.showLoading();
				
				var tv = onLineStatusCache;
				var reapetCount = 0;
				//设定为全选状态
				$scope.deviceStatusGroupSelectFlag[0] = 1;
				$scope.deviceStatusGroupSelectFlag[1] = 1;
				$scope.deviceStatusGroupSelectFlag[2] = 1;
				$scope.deviceStatusGroupSelectFlag[3] = 1;
				$scope.deviceStatusGroupSelectFlag[4] = 1;
				$scope.deviceStatusGroupSelectFlag[5] = 1;
				$scope.deviceStatusGroupSelectFlag[6] = 1;
				$scope.deviceStatusGroupSelectFlag[7] = 1;

				tmpLocationAddr = 0;
				if(tv.length == 0){
					$scope.hideLoading();
					$scope.timeoutPopUp("没有可控的分机！");
					return;
				}

//             	console.log("在线状态分机:",tv);
				//有在线状态分机，刷分机详细状态,定时查询
				if(tv.length > 0) {
					
//						//清除模式冲突
//						for(var si = 0; si < 8; si++){
//							unit_status[si]  = 1;
//						}
//						console.log("unit_statusunit_statusunit_status",unit_status);
	
						var controlMsg = [];
						controlMsg[0] = type; //开关状态
						controlMsg[1] = $scope.quankongmoshi; //模式
						controlMsg[2] = $scope.quankongwendu; //温度
						controlMsg[3] = $scope.quankongfengsu; //风速
												
						var reapetFlag = true;
						timeControlFlag = setInterval(function() {
							tmpLocationAddr = parseInt(tmpLocationAddr);
							
							$scope.devicelistItems[tv[tmpLocationAddr]].runningState = type;
							$scope.devicelistItems[tv[tmpLocationAddr]].mode = $scope.quankongmoshi;
							$scope.devicelistItems[tv[tmpLocationAddr]].tempSetValue = $scope.quankongwendu;
							$scope.devicelistItems[tv[tmpLocationAddr]].windSpeed = $scope.quankongfengsu;
							$scope.devicelistItems[tv[tmpLocationAddr]].modeShow = false;
							
							$scope.deviceStatusGroup[tv[tmpLocationAddr]].runningState.value = type;
							$scope.deviceStatusGroup[tv[tmpLocationAddr]].settingMode.value = $scope.quankongmoshi;
							$scope.deviceStatusGroup[tv[tmpLocationAddr]].settingTemperature.value = $scope.quankongwendu;
							$scope.deviceStatusGroup[tv[tmpLocationAddr]].noPolarWindSpeedValue.value = $scope.quankongfengsu;
							unit_status[tv[tmpLocationAddr]]  = 1;

							if($scope.deviceStatusGroupSelectFlag[tv[tmpLocationAddr]] == 1) {
									_ACDriver.deviceStatus.locationOrder = tv[tmpLocationAddr];
									cmdBytes = _ACDriver.loopControlDevice(controlMsg);
//									console.log("全控：",cmdBytes);
									if(reapetFlag){
											reapetFlag = false;
											bridge.startCmdProcess(cmdBytes, function(messageBack) {
//								    console.log("全控返回：",messageBack);
											
											tmpLocationAddr = tmpLocationAddr + 1;
											tmpLocationAddr = parseInt(tmpLocationAddr);
											reapetFlag = true;
											if(tmpLocationAddr >= tv.length) {
												clearInterval(timeControlFlag);
												tmpLocationAddr = 0;
												setTimeout(function(){
												$scope.hideLoading();
												closeActiveFlag = true;
												},1000);
											}
										}, function(errorInfo) {
											//收到超时或者错误回复，滚动发下一条
											tmpLocationAddr = tmpLocationAddr + 1;
											tmpLocationAddr = parseInt(tmpLocationAddr);
											
											reapetFlag = true;
											if(tmpLocationAddr >= tv.length) {
												clearInterval(timeControlFlag);
												tmpLocationAddr = 0;
												$scope.timeoutPopUp("网络超时，请重试");
												setTimeout(function(){
												$scope.hideLoading();
												closeActiveFlag = true;
												},1000);
											}
											//如果效果不理想，启用重发逻辑,并屏蔽上面滚动发码过程
//											reapetCount = reapetCount + 1;
//											reapetFlag = true;
//											if(reapetCount >= 10) {
//												clearInterval(timeControlFlag);
//												$scope.hideLoading();
//											}										
										});	
								}
							}
						}, 1000);
						
//						setTimeout(function() {
//									clearInterval(timeControlFlag);
//									tmpLocationAddr = 0;
//									$scope.hideLoading();
//								},50000);
							
				}
				else{
					$scope.timeoutPopUp("没有可控分机");
				}
		}
	}

	//多控制
	$scope.loopControlProduokong = function(addr, type) {
			if(type == 1 && $scope.zhilengg && 
				$scope.zhireg && $scope.zhidongg && 
				$scope.choushig && $scope.songfengg) {
					    $scope.timeoutPopUp("请选择模式！");
			} else if(type == 1 && $scope.fengsuzidongg && 
				      $scope.fengsudifengg && $scope.fengsuzhongfengg &&
				      $scope.fengsugaofengg) {
						$scope.timeoutPopUp("请选择风速！");
			} else {

                clearTimeout(totalControlTimeFlag);
				$scope.showLoading();
				
				if(tmpCurrentStatusLength == 0){
					$scope.hideLoading();
					$scope.timeoutPopUp("没有可控的分机！");
					return;
				}					  
					  var tv = [];
					  var tc = 0;
					
					  var selectFlag = 0;

					  //测试，设定为全选状态
					  for(var i = 0; i < 8; i++) {
							if($scope.appRuntime.duokongxuanzhong[i]) {
								$scope.deviceStatusGroupSelectFlag[i] = 1;
								
								tv[tc] = i;
								tc = tc + 1;
								
								selectFlag = 1;
							} else {
								$scope.deviceStatusGroupSelectFlag[i] = 0;
							}
						}
							
					  if(selectFlag == 0) {
							$scope.hideLoading();
							$scope.timeoutPopUp("请选需要的分机");
							return;
						}
					  
					  var tk;
					 //取最新分机状态
//					 console.log("onLineDeviceAddrCache.length:",onLineDeviceAddrCache.length);
//					 console.log("onLineDeviceAddrCache:",onLineDeviceAddrCache);
//					 console.log("scope.deviceStatusGroupSelectFlag:",$scope.deviceStatusGroupSelectFlag);
					 for(var si = 0; si < onLineDeviceAddrCache.length; si++){
					 	
					 	tk = onLineDeviceAddrCache[si];
						if($scope.deviceStatusGroupSelectFlag[tk] == 1) {				
							$scope.devicelistItems[tk].runningState = type;
							$scope.devicelistItems[tk].mode = $scope.quankongmoshi;
							$scope.devicelistItems[tk].tempSetValue = $scope.quankongwendu;
							$scope.devicelistItems[tk].windSpeed = $scope.quankongfengsu;
//							console.log("$scope.quankongmoshi:",$scope.quankongmoshi);
//							console.log("$scope.devicelistItems[tk]:",$scope.devicelistItems[tk]);
					 }	
					}					  
		
						var tmpAddr;
						//测试，设定为全选状态
						for(var si = 0; si < tmpCurrentStatusLength; si++) {
							
							tmpAddr = onLineDeviceAddrCache[si];
							
							if($scope.deviceStatusGroupSelectFlag[tmpAddr]) {
								selectFlag = 1;
							} else {
								selectFlag = 0;
								si = 10;
							}
						}	
						
							
						var reapetCount = 0;
						var reapetFlag = true;
						
						tmpLocationAddr = 0;

						//有在线状态分机，刷分机详细状态,定时查询
						if(tv.length > 0) {
				
								var si = 0;
								var tmpflag = 0;
								if((type == 1) && (selectFlag == 0)){
//								for(si = 0; si < tmpCurrentStatusLength; si++){
//									
//									tmpAddr = onLineDeviceAddrCache[si];
//									
//									if((($scope.quankongmoshi==2) || ($scope.quankongmoshi==3) || ($scope.quankongmoshi==5)) && 
//									   ($scope.devicelistItems[tmpAddr].mode == 4) && 
//									   ($scope.devicelistItems[tmpAddr].runningState == 1)){
//									   		tmpflag = 1;
//									   		si = tmpCurrentStatusLength + 1;//退出
//								    }
//									else if(($scope.devicelistItems[tmpAddr].runningState == 1)&&
//									        ($scope.quankongmoshi==4)  && (($scope.devicelistItems[tmpAddr].mode == 2) || 
//									        ($scope.devicelistItems[tmpAddr].mode == 3)||($scope.devicelistItems[tmpAddr].mode == 5))){
//									   		tmpflag = 2;
//									   		si = tmpCurrentStatusLength + 1;//退出
//								    }   
//								}
	   var tmpMode_1_count = 0;
	   var tmpMode_2_count = 0;
	   var tmpMode_3_count = 0;
	   var tmpMode_1_buffer = [0,0,0,0,0,0,0,0];
	   var tmpMode_2_buffer = [0,0,0,0,0,0,0,0];
	   var tmpMode_3_buffer = [0,0,0,0,0,0,0,0];
	   var tmpAddr;
	   
	   for(var si = 0 ; si < tmpCurrentStatusLength; si++){
	   		tmpAddr = onLineDeviceAddrCache[si];
			if($scope.devicelistItems[tmpAddr].runningState == 1){	   	
				if((($scope.devicelistItems[tmpAddr].mode == 4))){
					tmpMode_2_buffer[tmpAddr] = 1;
					tmpMode_2_count = tmpMode_2_count + 1;
				}
				else if((($scope.devicelistItems[tmpAddr].mode == 2) || ($scope.devicelistItems[tmpAddr].mode == 3) || ($scope.devicelistItems[tmpAddr].mode == 5))){
					tmpMode_1_buffer[tmpAddr] = 1;
					tmpMode_1_count = tmpMode_1_count + 1;
				}
		  	}
			else{
				tmpMode_2_buffer[tmpAddr] = 0;
				tmpMode_1_buffer[tmpAddr] = 0;
			}
		}
	   
//	   	   console.log("tmpMode_1_buffer:",tmpMode_1_buffer);
//	   	   console.log("tmpMode_2_buffer:",tmpMode_2_buffer);
//	   	   console.log("tmpMode_1_count:",tmpMode_1_count);
//	   	   console.log("tmpMode_2_count:",tmpMode_2_count);
	   	   
		    if((tmpMode_1_count > 0) && (tmpMode_2_count > 0)){
				tmpflag = 1;
		    }
		    else{
				tmpflag = 0;
		    }
								
			if(tmpflag > 0){
				$scope.hideLoading();
				$scope.timeoutPopUp("发生模式冲突，请检查其他分机的模式状态！");
				clearInterval(timeControlFlag);
				return;
			}		
		}
									
//								//清除模式冲突
								var tmpAddr;
								for(var si = 0; si < tmpCurrentStatusLength; si++){
									tmpAddr = onLineDeviceAddrCache[si];
									
									if(unit_status[tmpAddr] != 2){
									   unit_status[tmpAddr]  = 1;
									}
									
								}
//								
								//$scope.$watch("appRuntime.timeControlFlag", function(news, olds){})
								//$scope.appRuntime.timeControlFlag
								timeControlFlag = setInterval(function() {								
								var controlMsg = [];
									controlMsg[0] = type; //开关状态
									controlMsg[1] = $scope.quankongmoshi; //模式
									controlMsg[2] = $scope.quankongwendu; //温度
									controlMsg[3] = $scope.quankongfengsu; //风速

									if($scope.deviceStatusGroupSelectFlag[tv[tmpLocationAddr]] == 1) {
										
										tmpLocationAddr = parseInt(tmpLocationAddr);
										
										$scope.devicelistItems[tv[tmpLocationAddr]].runningState = type;
										$scope.devicelistItems[tv[tmpLocationAddr]].mode = $scope.quankongmoshi;
										$scope.devicelistItems[tv[tmpLocationAddr]].tempSetValue = $scope.quankongwendu;
										$scope.devicelistItems[tv[tmpLocationAddr]].windSpeed = $scope.quankongfengsu;
										$scope.devicelistItems[tv[tmpLocationAddr]].modeShow = false;
							
										$scope.deviceStatusGroup[tv[tmpLocationAddr]].runningState.value = type;
							            $scope.deviceStatusGroup[tv[tmpLocationAddr]].settingMode.value = $scope.quankongmoshi;
							            $scope.deviceStatusGroup[tv[tmpLocationAddr]].settingTemperature.value = $scope.quankongwendu;
							            $scope.deviceStatusGroup[tv[tmpLocationAddr]].noPolarWindSpeedValue.value = $scope.quankongfengsu;
							            unit_status[tv[tmpLocationAddr]]  = 1;
										_ACDriver.deviceStatus.locationOrder = tv[tmpLocationAddr];
										cmdBytes = _ACDriver.loopControlDevice(controlMsg);
//										$scope.sendCMDSimulation(cmdBytes, 0, 0);
										if(reapetFlag){
												reapetFlag = false;
												bridge.startCmdProcess(cmdBytes, function(messageBack) {
				//								success(messageBack);
												tmpLocationAddr = tmpLocationAddr + 1;
												tmpLocationAddr = parseInt(tmpLocationAddr);
												
												reapetFlag = true;
												if(tmpLocationAddr >= tmpCurrentStatusLength) {
													clearInterval(timeControlFlag);
													tmpLocationAddr = 0;
											
													
													
												setTimeout(function(){
												$scope.hideLoading();
												closeActiveFlag = true;
												},1000);
												}
											}, function(errorInfo) {
												//收到超时或者错误回复，滚动发下一条
												tmpLocationAddr = tmpLocationAddr + 1;
												tmpLocationAddr = parseInt(tmpLocationAddr);
												
												reapetFlag = true;
												if(tmpLocationAddr >= tmpCurrentStatusLength) {
													clearInterval(timeControlFlag);
													tmpLocationAddr = 0;
												setTimeout(function(){
												$scope.hideLoading();
												closeActiveFlag = true;
												},1000);
													$scope.timeoutPopUp("网络超时，请重试");
												}
												$scope.hideLoading();
												$scope.timeoutPopUp("网络超时，请重试");
												//如果效果不理想，启用重发逻辑,并屏蔽上面滚动发码过程
	//											reapetCount = reapetCount + 1;
	//											reapetFlag = true;
	//											if(reapetCount >= 10) {
	//												clearInterval(timeControlFlag);
	//												$scope.hideLoading();
	//											}										
											});	
										}
									}
									else{
										tmpLocationAddr = tmpLocationAddr + 1;
										tmpLocationAddr = parseInt(tmpLocationAddr);
										reapetFlag = true;
										if(tmpLocationAddr >= tmpCurrentStatusLength) {
											clearInterval(timeControlFlag);
											tmpLocationAddr = 0;
											setTimeout(function(){
												$scope.hideLoading();
												closeActiveFlag = true;
												},1000);
										}										
									}
								}, 1000);
								
//								setTimeout(function() {
//									clearInterval(timeControlFlag);
//									tmpLocationAddr = 0;
//									$scope.hideLoading();
//								},50000);
								
						}
						else{
							$scope.timeoutPopUp("没有可控分机");
						}
			}
	}

	$scope.sendCMD = function(cmdBytes, success, fail) {
		$scope.showLoading();
			totalControlTimeFlag = setTimeout(function() {
					$scope.hideLoading();
					$scope.timeoutPopUp("网络超时，请重试！");
				},15000);
				
		bridge.startCmdProcess(cmdBytes, function(messageBack) {
			$scope.hideLoading();
			clearTimeout(totalControlTimeFlag);
			var receiveMessageBody = messageBack.slice(10, messageBack.length - 1);
			$scope.statusSynchro_new(receiveMessageBody);
			$scope.refreshSystemCurrent();
			$scope.updateMainView($scope.appRuntime.currentDeviceIndex);
			$scope.$apply();
			success(messageBack);
		}, function(errorInfo) {
			$scope.hideLoading();
			$scope.timeoutPopUp("网络超时，请重试");
			clearTimeout(totalControlTimeFlag);
			fail(errorInfo);
			$scope.refreshSystemCurrent();
			$scope.updateMainView($scope.appRuntime.currentDeviceIndex);
			//$scope.updateMainView(cmdBytes[11]);
			$scope.$apply();
		});
	};
	

	$scope.updateMainView = function(addr) {
		if(addr == undefined) {
			addr = 0;
		}

//		console.log("$scope.deviceStatusGroup[addr].timingClose_00:" + $scope.devicelistItems[addr].timingClose);
//		console.log("$scope.deviceStatusGroup.timingOpen_00:" + $scope.devicelistItems[addr].timingOpen);
//		console.log("$scope.deviceStatusGroup[addr].electricHeat.value_00:" + $scope.devicelistItems[addr].electricHeat);
//		console.log("$scope.deviceStatusGroup[addr].DryStatus.value_00:" + $scope.devicelistItems[addr].DryStatus);
//		console.log("$scope.deviceStatusGroup[addr].sleepFunctionStatus_00:" + $scope.devicelistItems[addr].sleepFunctionStatus);
//		console.log("$scope.devicelistItems[addr].mode_00:" + $scope.devicelistItems[addr].mode);
//		console.log("$scope.devicelistItems[addr].sleepFunctionStatus_00:" + $scope.devicelistItems[addr].sleepFunctionStatus);
//		console.log("$scope.devicelistItems[addr].DryStatus", (parseInt($scope.devicelistItems[addr].DryStatus) == 1) && ((parseInt($scope.devicelistItems[addr].mode) == 2) || (parseInt($scope.devicelistItems[addr].mode) == 3)));
		//去掉模式切变时背景色的渐变
		$scope.functionListProcessExtra(parseInt($scope.devicelistItems[addr].timingClose) == 1, 'timerisActive', 'timerSrc');
		$scope.functionListProcessExtra(parseInt($scope.devicelistItems[addr].timingOpen) == 1, 'timerOpenisActive', 'timerOpenSrc');
		$scope.functionListProcessExtra(parseInt($scope.devicelistItems[addr].electricHeat) == 1, 'electricHeatisActive', 'electricHeatSrc');
		$scope.functionListProcessExtra((parseInt($scope.devicelistItems[addr].DryStatus) == 1) && ((parseInt($scope.devicelistItems[addr].mode) == 2) || (parseInt($scope.devicelistItems[addr].mode) == 3)), 'dryisActive', 'drySrc');
		$scope.functionListProcessExtra(parseInt($scope.devicelistItems[addr].sleepFunctionStatus) == 1, 'sleepisActive', 'sleepSrc');
	}

	/*icon列表控制逻辑封装*/
	$scope.functionListProcessExtra = function(func, flag, source) {
		if(func) {
			$scope[source] = $sce.trustAsResourceUrl($scope['staticData'][source]['on']);
			$scope[flag] = true;
		} else {
			$scope[source] = $sce.trustAsResourceUrl($scope['staticData'][source]['off']);
			$scope[flag] = false;
		}
	}

	$scope.sendCMDSimulation = function(cmdBytes, success, fail) {

		bridge.startCmdProcess(cmdBytes, function(messageBack) {
			$scope.hideLoading();
			clearTimeout(totalControlTimeFlag);
			;
//			$scope.$apply();
			success(messageBack);
		}, function(errorInfo) {
			$scope.hideLoading();
			clearTimeout(totalControlTimeFlag);
			fail(errorInfo);
//			$scope.$apply();
		});
		
	};
	
	//单独查询在线状态
	$scope.queryOnlineStatus = function(){
  		//查询分机在线状态
  		var cmdBytes = _ACDriver.controlDeviceStatus_JZ(false);
  		bridge.startCmdProcess(cmdBytes, function(messageBack) {
			var receiveMessageBody = messageBack.slice(10, messageBack.length - 1);
			$scope.statusSynchro_new(receiveMessageBody);
			$scope.refreshSystemCurrent();
		}, function(errorInfo) {
			;
		});
  	}

	$scope.quitApp = function() {
		try {
			clearInterval(timeControlFlag);
			bridge.goBack();
		} catch(e) {
//			console.log(e);
		}
	};

	$scope.showLoading = function() {
		coreHelper.lockScroll($scope, [$('.loadingWrapper-single')], true);
		$(".loadingWrapper-single").css({
			"height": $(document).height(),
			"display": "block"
		});
	}

	$scope.hideLoading = function() {
		coreHelper.lockScroll($scope, [$('.loadingWrapper-single')], false);
		$(".loadingWrapper-single").css({
			"display": "none"
		});
	}

	/*超时弹出框*/
	$scope.timeoutPopUp = function(timeOutPopText) {
		setTimeout("$('.timeOutPopUp').stop(false,false).fadeIn()", 40);
		setTimeout("$('.timeOutPopUp').stop(false,false).fadeOut('slow')", 1000);
		$scope.component.popUpMessage = timeOutPopText;
		$scope.$apply();
	};
});