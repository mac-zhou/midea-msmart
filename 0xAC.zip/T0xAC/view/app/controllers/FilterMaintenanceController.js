mideaACApp.controller('FilterMaintenanceController', function($scope, $rootScope, $location, $sce, deviceCommand, deviceRequest, staticData, coreHelper, $filter) {
	$scope.init = function() {
		console.log("FilterMaintenanceController...");
		
		$scope.requestdata = '';
		$scope.cleanTimeChoosed = false;
		$scope.cleanTime = '';
		$scope.cleanTimeCoosedStatus = [false, false, false, false, false, false, false];
		$scope.filterMaintenance.runTimeData.circleComponent = {};
		$scope.filterMaintenance.runTimeData.showVideo = false;
	
		$scope.handleVariableObserver();
		$scope.handleRouteChange();
	};

	$scope.handleRouteChange = function() {
		$scope.$on('$routeChangeSuccess', function(event, next, current) {
			if(next.loadedTemplateUrl === 'view/app/partials/filter-maintenance/cleanpanel.html') {
				$scope.initCleanPanelData();
				$scope.initCleanListData();
				$scope.initCleanPanelPageComponent();
			} else if(next.loadedTemplateUrl === 'view/app/partials/filter-maintenance/record.html') {
				//$scope.initCleanListData();
				$scope.filterMaintenance.isFirstEnterPage = false;
			} else if(next.loadedTemplateUrl === 'view/app/partials/filter-maintenance/cleandetail.html') {
				$scope.filterMaintenance.isFirstEnterPage = false;
			} else if(next.loadedTemplateUrl === 'view/app/partials/filter-maintenance/cleantime.html') {
				$scope.extraCleanTimeListData();
				$scope.filterMaintenance.isFirstEnterPage = true;
			} else if(next.loadedTemplateUrl === 'view/app/partials/filter-maintenance/start.html') {
				$scope.extraStartPageData();
			} else if(next.loadedTemplateUrl === 'view/app/partials/filterScreen.html') {
				setTimeout(function() {
					bridge.getUserInfo(function(userInfo) {
						$scope.filterMaintenance.runTimeData.userId = parseInt(userInfo.userId);
					});
					$scope.filterMaintenance.runTimeData.applianceId = bridge.getCurrentApplianceID();
					$scope.getCleanVideo(function(data) {
						$scope.filterMaintenance.runTimeData.cleanUrl = $sce.trustAsResourceUrl(data);
					});
					$scope.acController.filterDirtyPluggingStatus();
					if($scope.acController.dataManager.getFilterDirtyPlugging().percentageReadings>=0x4B) {
						$scope.currenLevel = "goodState";
					}else if($scope.acController.dataManager.getFilterDirtyPlugging().percentageReadings>=0x37&&
		            $scope.acController.dataManager.getFilterDirtyPlugging().percentageReadings<=0x45) {
						$scope.currenLevel = "midState";
					} else if($scope.acController.dataManager.getFilterDirtyPlugging().percentageReadings<0x37) {
						$scope.currenLevel = "badState";
					}
					$scope.initCleanPanelPageComponent();
					if($scope.currenLevel == 'goodState') {
						$scope.filterMaintenance.runTimeData.progressComponent.init(100);
					}else if($scope.currenLevel == 'midState') {
						$scope.filterMaintenance.runTimeData.progressComponent.init(50);
					}else if($scope.currenLevel == 'badState') {
						$scope.filterMaintenance.runTimeData.progressComponent.init(0);
					}
				}, 1500);
				
				setTimeout(function(){
					$scope.filterMaintenance.runTimeData.showVideo = true;
				},1);
			}
		});
	};
	
	$scope.handleVariableObserver = function() {
		$scope.$watch("filterMaintenance.isFirstEnterPage", function(newVal, oldVal) {
			if(newVal) {
				$scope.filterMaintenance.runTimeData.animateTag = "";
			} else {
				$scope.filterMaintenance.runTimeData.animateTag = "-static";
			}
		});
	}

	/*=================================Start Page=========================================*/
	$scope.extraStartPageData = function() {
		console.log("extraStartPageData", $scope.filterMaintenance.runTimeData.locationTime)
		$scope.filterMaintenance.runTimeData.locationTime = $scope.filterMaintenance.runTimeData.locationTime == undefined ? "--年--月--日" : $scope.filterMaintenance.runTimeData.locationTime;
	};

	/*=================================Main Panel=========================================*/
	$scope.initCleanPanelPageComponent = function() {
		//$scope.filterMaintenance.runTimeData.circleComponent = new initCircleComponent();

		$scope.filterMaintenance.runTimeData.progressComponent = new initProgressComponent();

		//todo debug
		/*$scope.filterMaintenance.currentCleanStateValue = 98.72;
		$scope.calculateCurrentCleanState();
		if($scope.filterMaintenance.isFirstEnterPage) {
			$scope.filterMaintenance.runTimeData.progressComponent.refresh(parseInt($scope.filterMaintenance.currentCleanStateValue));
			animateNumber($(".animate-num"), $scope.filterMaintenance.currentCleanStateValue);
		} else {
			$scope.filterMaintenance.runTimeData.progressComponent.init(parseInt($scope.filterMaintenance.currentCleanStateValue));
		}
		console.log($scope.filterMaintenance.isFirstEnterPage);*/

		initVideoComponent();
	};

	$scope.initCleanPanelData = function() {
		var animateNumDom = $(".animate-num .animate-num-msg");

		$scope.calculateCurrentCleanState();
		animateNumDom.html($scope.filterMaintenance.currentCleanStateValue);

		//查询当前清清度
		$scope.getCurrentCleanStatus(function(data) {
			console.log("getCurrentCleanStatus");
			console.log(data);

			$scope.filterMaintenance.runTimeData.cleanStatusMsg = data;
			$scope.filterMaintenance.currentCleanStateValue = data.curPurify >= 0 ? data.curPurify : 0;
			$scope.filterMaintenance.currentCleanStateValue = parseInt($scope.filterMaintenance.currentCleanStateValue);

			if($scope.filterMaintenance.isFirstEnterPage) {} else {
				animateNumDom.html($scope.filterMaintenance.currentCleanStateValue);
			}

			$scope.calculateCurrentCleanState();

			setTimeout(function() {
				//$scope.filterMaintenance.runTimeData.circleComponent.refresh(parseInt($scope.filterMaintenance.currentCleanStateValue));
				if($scope.filterMaintenance.isFirstEnterPage) {
					animateNumber(animateNumDom, $scope.filterMaintenance.currentCleanStateValue);
					$scope.filterMaintenance.runTimeData.progressComponent.refresh(parseInt($scope.filterMaintenance.currentCleanStateValue));
				} else {
					animateNumDom.html($scope.filterMaintenance.currentCleanStateValue);
					$scope.filterMaintenance.runTimeData.progressComponent.init(parseInt($scope.filterMaintenance.currentCleanStateValue));
				}
			}, 1000);
		});

		//查询滤网视频
		$scope.getCleanVideo(function(data) {
			console.log("getCleanVideo");
			console.log(data);
			$scope.filterMaintenance.runTimeData.cleanUrl = $sce.trustAsResourceUrl(data);
		});
	};

	$scope.calculateCurrentCleanState = function() {
		for(item in $scope.filterMaintenance.cleanPanel) {
			if(($scope.filterMaintenance.currentCleanStateValue >= $scope.filterMaintenance.cleanPanel[item].valueRange[0]) && (($scope.filterMaintenance.currentCleanStateValue <= $scope.filterMaintenance.cleanPanel[item].valueRange[1]))) {
				$scope.filterMaintenance.currentCleanState = item;
				break;
			}
		}
	}

	$scope.goToCleanPanel = function() {
		if($scope.filterMaintenance.isTimerSelected) {
			$scope.setFilterCleanTimeSubProcess(function() {
				$scope.goToUrl('/cleanpanel');
				$scope.filterMaintenance.isFirstEnterPage = true;
			}, function(data) {
				$scope.timeoutPopUp("亲～服务器错误, 请重新选择日期～");
			});
		}
	};

	$scope.goToRecordPage = function() {
		$scope.goToUrl('/record');
	};

	$scope.goToCleanDetail = function(index) {
		$scope.filterMaintenance.runTimeData.currentCleanStatusPageIndex = index;

		if($scope.filterMaintenance.runTimeData.cleanStatusMsgHis[index].detail.kind == 0) {
			$scope.redirectPage('cleandetail', 'in');
		} else {
			//$scope.timeoutPopUp("亲～没有更多记录了～");
		}
	};

	/*=================================Clean List=========================================*/
	$scope.extraCleanTimeListData = function() {
		//查询滤网清洗记录
		$scope.getRecord(function(data) {
			console.log("getRecord")
			console.log(data);

			$scope.filterMaintenance.runTimeData.recordList = data[0];
			$scope.filterMaintenance.runTimeData.recordListBool = data[1];

			$scope.formatDateToCleanList(data[0][0]);
			$scope.getSelectedDateIndex();

			//new require
			for(var i = 0; i < $scope.filterMaintenance.cleanTimeList.length; i++) {
				$scope.filterMaintenance.cleanTimeList[i].isChecked = false;
			}

			console.log("$scope.filterMaintenance.lastCleanTimeIndex");
			console.log($scope.filterMaintenance.lastCleanTimeIndex + " " + data[0][0]);
		});
	}

	$scope.cleanTimeClicked = function(target, $index) {
		for(var i = 0; i < $scope.filterMaintenance.cleanTimeList.length; i++) {
			if($scope.filterMaintenance.cleanTimeList[i].time == target.innerText) {
				$scope.filterMaintenance.cleanTimeList[i].isChecked = !$scope.filterMaintenance.cleanTimeList[i].isChecked;
			} else {
				$scope.filterMaintenance.cleanTimeList[i].isChecked = false;
			}
		}

		$scope.getSelectedDateIndex();

		if($scope.filterMaintenance.cleanTimeList[$index].isChecked) {
			$scope.setFilterCleanTimeSubProcess(function() {
				$scope.calculateCurrentCleanState();
				$scope.redirectPage('cleanpanel', 'in');
			}, function(data) {
				//alert(JSON.stringify(data));
				$scope.timeoutPopUp(data.result.returnData.errMsg);
			});
		}
	}

	$scope.getSelectedDateIndex = function() {
		for(var i = 0; i < $scope.filterMaintenance.cleanTimeList.length; i++) {
			if($scope.filterMaintenance.cleanTimeList[i].isChecked) {
				$scope.filterMaintenance.isTimerSelected = true;
				$scope.filterMaintenance.lastCleanTimeIndex = i;
				break;
			} else {
				$scope.filterMaintenance.isTimerSelected = false;
			}
		}

		console.log($scope.filterMaintenance.lastCleanTimeIndex);
	};

	$scope.resetCleanTimeList = function() {
		for(var i = 0; i < $scope.filterMaintenance.cleanTimeList.length; i++) {
			$scope.filterMaintenance.cleanTimeList[i].isChecked = false;
		}
	}

	$scope.formatDateToCleanList = function(date) {
		var _date = date.split("-");
		var inTs = Date.parse(new Date(_date[0], _date[1] - 1, _date[2])) / 1000;
		var currentTs = Date.parse(new Date()) / 1000;
		var dayDiff = parseInt((currentTs - inTs) / (3600 * 24));

		//console.log("---------formatDateToCleanList-------");
		//console.log(date);
		//console.log(dayDiff);
		//var inTs = new Date(inTs);
		//console.log(inTs.getFullYear() + "-"+inTs.getMonth()+"-"+inTs.getDate());
		$scope.resetCleanTimeList();

		for(var i = 0; i < $scope.filterMaintenance.cleanTimeList.length - 1; i++) {
			if((dayDiff >= $scope.filterMaintenance.cleanTimeList[i].rule) && (dayDiff < $scope.filterMaintenance.cleanTimeList[i + 1].rule)) {
				$scope.filterMaintenance.cleanTimeList[i].isChecked = true;
			} else {
				$scope.filterMaintenance.cleanTimeList[i].isChecked = false;
			}
		}

		if(dayDiff >= $scope.filterMaintenance.cleanTimeList[$scope.filterMaintenance.cleanTimeList.length - 1].rule) {
			$scope.filterMaintenance.cleanTimeList[$scope.filterMaintenance.cleanTimeList.length - 1].isChecked = true;
		}
	};

	$scope.setFilterCleanTime = function() {
		$scope.setFilterCleanTimeSubProcess(function() {}, function(data) {
			$scope.timeoutPopUp("亲～服务器错误～");
		});
	};

	$scope.setFilterCleanTimeSubProcess = function(success, fail) {
		//测试设置清洗时间
		$scope.acController.showLoading();

		$scope.getSelectedDateIndex();

		var calculateRule = $scope.filterMaintenance.cleanTimeList[$scope.filterMaintenance.lastCleanTimeIndex].rule;
		var currentTimeStamp = Date.parse(new Date());
		var setTimeStamp = new Date(currentTimeStamp - calculateRule * 3600 * 24 * 1000);
		var year = setTimeStamp.getFullYear();
		var month = (setTimeStamp.getMonth() + 1) < 10 ? "0" + (setTimeStamp.getMonth() + 1) : (setTimeStamp.getMonth() + 1);
		var day = setTimeStamp.getDate() < 10 ? "0" + setTimeStamp.getDate() : setTimeStamp.getDate();
		var setTime = year + "-" + month + "-" + day;

		if($scope.filterMaintenance.lastCleanTimeIndex == 0) {
			setTime = "";
		}

		console.log('setTime');
		console.log(setTime);

		$scope.filterMaintenance.runTimeData.networkTimeout = setTimeout(function() {
			$scope.acController.hideLoading();
			$scope.$apply(function() {
				$scope.timeoutPopUp("网络超时, 请重试~");
			});
		}, 5000);

		$scope.setCleanTime(setTime, function(data, Info) {
			console.log("setCleanTime");
			console.log(data);

			clearTimeout($scope.filterMaintenance.runTimeData.networkTimeout);

			$scope.filterMaintenance.runTimeData.setCleanTimeFlag = data;
			$scope.acController.hideLoading();

			if(!$scope.filterMaintenance.runTimeData.setCleanTimeFlag) {
				console.log("滤网清洗时间有误");
				fail(Info);
			} else {
				success();
			}
		});
	};

	/*=================================Record Detail=========================================*/
	$scope.initCleanListData = function() {
		//查询滤网洁净度记录
		$scope.getCurrentCleanStatusRecord('2016-01-01', '2017-05-08', 10, function(data) {
			console.log("getCurrentCleanStatusRecord");
			console.log(data);

			$scope.filterMaintenance.runTimeData.cleanStatusMsgHis = [];

			for(var i = 0; i < data.length; i++) {
				var record = {
					time: data[i].day == undefined ? "--" : data[i].day,
					point: data[i].curPurify == undefined ? 0 : data[i].curPurify,
					detail: {
						acUsedTime: data[i].runDuration == undefined ? 0 : data[i].runDuration,
						cleanStatus: data[i].increPurify == undefined ? 0 : Math.abs(data[i].increPurify),
						kind: data[i].kind == undefined ? 0 : data[i].kind,
						windSetTime: {
							hight: data[i].highWindDuration == undefined ? 0 : data[i].highWindDuration,
							mid: data[i].middleWindDuration == undefined ? 0 : data[i].middleWindDuration,
							low: data[i].lowWindDuration == undefined ? 0 : data[i].lowWindDuration,
							auto: data[i].autoWindDuration == undefined ? 0 : data[i].autoWindDuration,
						},
						modeSetTime: {
							cool: data[i].codeModeDuration == undefined ? 0 : data[i].codeModeDuration,
							hot: data[i].hotModeDuration == undefined ? 0 : data[i].hotModeDuration,
							wind: data[i].windModeDuration == undefined ? 0 : data[i].windModeDuration,
							humidity: data[i].humiModeDuration == undefined ? 0 : data[i].humiModeDuration,
							auto: data[i].autoModeDuration == undefined ? 0 : data[i].autoModeDuration,
						},
						weather: {
							desc: data[i].weather == undefined ? "--" : data[i].weather,
							aqi: data[i].aqi == undefined ? 0 : data[i].aqi,
							maxTemp: data[i].maxTemp == undefined ? 0 : data[i].maxTemp,
							minTemp: data[i].minTemp == undefined ? 0 : data[i].minTemp,
							humidity: data[i].humidity == undefined ? 0 : data[i].humidity
						}
					}
				};
				$scope.filterMaintenance.runTimeData.cleanStatusMsgHis.push(record);
			}

			console.log($scope.filterMaintenance.runTimeData.cleanStatusMsgHis);
		});
	};

	$scope.goToPrevCleanStatusHis = function() {
		if($scope.filterMaintenance.runTimeData.currentCleanStatusPageIndex > 0) {
			$scope.filterMaintenance.runTimeData.currentCleanStatusPageIndex--;

			if($scope.filterMaintenance.runTimeData.cleanStatusMsgHis[$scope.filterMaintenance.runTimeData.currentCleanStatusPageIndex].detail.kind == 1) {
				$scope.goToPrevCleanStatusHis();
			}
		} else {
			//$scope.filterMaintenance.runTimeData.currentCleanStatusPageIndex = $scope.filterMaintenance.runTimeData.cleanStatusMsgHis.length - 1;
			$scope.timeoutPopUp("亲，已经到底了～");
		}
	}

	$scope.goToNextCleanStatusHis = function() {
		if($scope.filterMaintenance.runTimeData.currentCleanStatusPageIndex < ($scope.filterMaintenance.runTimeData.cleanStatusMsgHis.length - 1)) {
			$scope.filterMaintenance.runTimeData.currentCleanStatusPageIndex++;

			if($scope.filterMaintenance.runTimeData.cleanStatusMsgHis[$scope.filterMaintenance.runTimeData.currentCleanStatusPageIndex].detail.kind == 1) {
				$scope.goToNextCleanStatusHis();
			}
		} else {
			//$scope.filterMaintenance.runTimeData.currentCleanStatusPageIndex = 0;
			$scope.timeoutPopUp("亲，已经到底了～");
		}
	}

	/*
	 * **********************************网络接口封装***********************************
	 */
	//查询滤网清洗记录
	$scope.getRecord = function(callback) {
		$scope.requestServerData('/acfilter/queryFilterCleanRecords', {
				"userId": $scope.filterMaintenance.runTimeData.userId,
				"deviceId": $scope.filterMaintenance.runTimeData.applianceId
			},
			function(data) {
				var jsonString = JSON.stringify(data);
				var resultEnv = coreHelper.getResultData(jsonString);
				var recordList = resultEnv;
				var recordListBool = coreHelper.isEmpty(recordList);
				callback([recordList, recordListBool]);

				console.log(data);
			},
			function(error) {
				console.log(error);
			});
	};

	//新增滤网清洗,p1:为时间，格式要求如2017-05-07
	$scope.setCleanTime = function(p1, callback) {
		var params = {
			"userId": $scope.filterMaintenance.runTimeData.userId,
			"deviceId": $scope.filterMaintenance.runTimeData.applianceId,
		};

		if(p1 != "") {
			params.day = p1;
		}

		$scope.requestServerData('/acfilter/addFilterCleanRecord', params,
			function(data) {
				var jsonString = JSON.stringify(data);
				var setCleanTimeFlag = coreHelper.getCommandResult(jsonString);
				callback(setCleanTimeFlag, data);

				console.log(data);
			},
			function(error) {
				console.log(error);
			});
	};

	//查询当前滤网洁净度
	$scope.getCurrentCleanStatus = function(callback) {
		$scope.requestServerData('/acfilter/queryFilterPurify', {
				"userId": $scope.filterMaintenance.runTimeData.userId,
				"deviceId": $scope.filterMaintenance.runTimeData.applianceId
			},
			function(data) {
				var jsonString = JSON.stringify(data);
				var cleanStatusMsg = coreHelper.getResultData(jsonString);
				callback(cleanStatusMsg);

				console.log(data);
			},
			function(error) {
				console.log(error);
			});
	};

	//查询滤网洁净度记录
	//p3:numbwer优先
	$scope.getCurrentCleanStatusRecord = function(p1, p2, p3, callback) {
		$scope.requestServerData('/acfilter/queryFilterPurifyRecords', {
				"userId": $scope.filterMaintenance.runTimeData.userId,
				"deviceId": $scope.filterMaintenance.runTimeData.applianceId,
				"beginDate": '',
				"endDate": '',
				"number": p3
			},
			function(data) {
				var jsonString = JSON.stringify(data);
				var cleanStatusMsgHis = coreHelper.getResultData(jsonString);
				callback(cleanStatusMsgHis);

				console.log("/acfilter/queryFilterPurifyRecords", jsonString);
			},
			function(error) {
				console.log(error);
			});
	};

	//查询滤网清洗视频
	$scope.getCleanVideo = function(callback) {
		$scope.requestServerData('/acfilter/queryFilterCleanVideos', {
				"userId": $scope.filterMaintenance.runTimeData.userId,
				"deviceId": $scope.filterMaintenance.runTimeData.applianceId
			},
			function(data) {
				var jsonString = JSON.stringify(data);
				var cleanUrl = coreHelper.getResultData(jsonString)[0].url;
				callback(cleanUrl);
				console.log("ffffffffffffffff", cleanUrl);
			},
			function(error) {
				console.log(error);
			});
	};

	/*
	 *********************************页面组件*********************************
	 */
	function initCircleComponent() {
		var canvas = document.getElementById('canvas'), //获取canvas元素
			context = canvas.getContext('2d'), //获取画图环境，指明为2d
			centerX = 150,
			centerY = 120;
		rad = (Math.PI * 2 / 100), //将360度分成100份，那么每一份就是rad度
			speed = 60 * 2; //加载的快慢就靠它了 60Hz/s

		context.clearRect(0, 0, canvas.width, canvas.height);

		//绘制蓝色外圈
		function blueCircle(n) {
			context.save();
			context.strokeStyle = "#FFFFFF"; //设置描边样式
			context.lineWidth = 4; //设置线宽
			context.beginPath(); //路径开始
			context.arc(centerX, centerY, 80, -Math.PI / 2, -Math.PI / 2 + n * rad, false); //用于绘制圆弧context.arc(x坐标，y坐标，半径，起始角度，终止角度，顺时针/逆时针)
			context.stroke(); //绘制	
		}

		//绘制白色外圈
		function whiteCircle() {
			context.save();
			context.beginPath();
			context.strokeStyle = "rgba(0, 0, 0, .3)";
			context.lineWidth = 1.5;
			context.arc(centerX, centerY, 80, 0, Math.PI * 2, false);
			context.stroke();
			context.closePath();
			context.restore();
		}

		//百分比文字绘制
		function text(n) {
			context.save(); //save和restore可以保证样式属性只运用于该段canvas元素
			context.fillStyle = "white"; //设置描边样式	
			if(n == 100) {

				context.font = "small-caps lighter 52px arial"; //设置字体大小和字体
				context.fillText(n.toFixed(0) + "%", centerX - 60, centerY + 30); //绘制字体，并且指定位置
			} else {

				context.font = "small-caps lighter 55px arial"; //设置字体大小和字体
				context.fillText(n.toFixed(0) + "%", centerX - 45, centerY + 30); //绘制字体，并且指定位置
			}

			//var persent = context.fillText("%", centerX+20, centerY + 50);
			context.restore();
		}

		function cleanTitle() {
			context.save(); //save和restore可以保证样式属性只运用于该段canvas元素
			context.fillStyle = "white"; //设置描边样式						
			context.font = "small-caps lighter 15px sans-serif"; //设置字体大小和字体
			//	content.fontWeight = '100';
			context.fillText('滤网洁净度', centerX - 35, centerY - 30); //绘制字体，并且指定位置
			context.restore();
		}

		function presentageUnit() {
			//	context.save(); //save和restore可以保证样式属性只运用于该段canvas元素
			//	context.fillStyle = "white"; //设置描边样式						
			//	context.font = "small-caps lighter 30px sans-serif"; //设置字体大小和字体
			//context.fillText('%', centerX + 40, centerY + 40); //绘制字体，并且指定位置
			//	context.restore();
		}

		function setVal(val) {
			var start = 100;
			var dynamicSpeed = (100 - val) / speed;

			//动画循环
			function drawFrame() {
				context.clearRect(0, 0, canvas.width, canvas.height);
				whiteCircle();
				cleanTitle();
				presentageUnit();
				text(start);
				blueCircle(start);

				/*if(speed > (val - 1)) speed = (val - 1);
					speed += 0.5 * (val * 2);*/

				if(start > val) {
					start -= dynamicSpeed;
					start = parseInt(start);
				}
				requestAnimationFrame(drawFrame, canvas);
			};
			drawFrame();
		}

		function initCircleProgress() {
			whiteCircle();
			cleanTitle();
			presentageUnit();
			text(0);
			blueCircle(0);
		}

		initCircleProgress();
		setVal(100);

		return {
			refresh: setVal
		}
	}

	function initVideoComponent() {
		//videojs
		$('.screen').css('width', $('.strainer-clean-video').width());
		window.onresize = function() {
			$('.screen').css('width', $('.strainer-clean-video').width());
		}
	}

	function initProgressComponent() {
		var animateConfig = {
			curve: "easeInOutBounce",
			duration: 2000
		};

		var container = $(".progress-component");
		var arrow = container.find(".nav-arrows");
		var maxWidth = container.find(".nav-line").width() - arrow.width();
		var interval = parseInt(100 / 3);
		var arrowClass = {
			blue: "blue-arrows",
			yellow: "yellow-arrows",
			red: "red-arrows"
		};

		arrow.css({
			left: maxWidth
		});

		function cleanArrowEffect() {
			arrow.removeClass(arrowClass.blue).removeClass(arrowClass.yellow).removeClass(arrowClass.red);
			return arrow;
		}

		function redraw(value, time) {
			var currentPos = (value / 100) * maxWidth;
			var currentValue = value;

			arrow.stop(false, false).animate({
				left: currentPos,
			}, {
				duration: time,
				easing: animateConfig.curve,
				step: function(a, b) {
					currentValue = (a / maxWidth) * 100;
					if(currentValue <= interval) {
						cleanArrowEffect().addClass(arrowClass.red);
					} else if((currentValue > interval) && (currentValue <= interval * 2)) {
						cleanArrowEffect().addClass(arrowClass.yellow);
					} else if(currentValue > interval * 2) {
						cleanArrowEffect().addClass(arrowClass.blue);
					}
				},
				complete: function() {}
			});
		}

		function init(value) {
			redraw(value, 1);
		}

		function refresh(value) {
			redraw(value, animateConfig.duration);
		}

		return {
			init: init,
			refresh: refresh
		}

	}

	function animateNumber(container, target) {
		var processResult = target;
		var startIntValue = 100;
		var startFloatValue = 0.99;
		var intTargetValue = parseInt(target);
		var floatTargetValue = (target - intTargetValue).toFixed(2);
		console.log("target");
		console.log(target);

		if((target >= 0) && (target <= 100)) {
			$("#placeHolder").stop(false, false).animate({
				width: '100%',
			}, {
				duration: 5000,
				easing: "linear",
				step: function(a, b) {
					if(startIntValue > intTargetValue) {
						startIntValue -= 1;
					}
					//if(startFloatValue > floatTargetValue) {
					//startFloatValue -= 0.01;
					//}

					//console.log(startIntValue);
					//console.log(startFloatValue);

					//processResult = startIntValue + startFloatValue;
					processResult = startIntValue;

					//container.html(Math.abs(processResult).toFixed(2));
					container.html(processResult);
				},
				complete: function() {}
			});
		}
	};

	$scope.quitFilterMaintenanceModule = function() {
		$scope.redirectPage('setting', 'out');
		$scope.setFilterMaintenanceRemind(false);
	};

	/*
	 * Util
	 */
	$scope.goToUrl = function(path) {
		$location.path(path);
	};

	$scope.changeDateFormat = function(date) {
		if(date != "--年--月--日") {
			return date.split("/")[0] + "年" + date.split("/")[1] + "月" + date.split("/")[2] + "日";
		} else {
			return date;
		}
	};
});