mideaACApp.directive('swipeMenu', ['$compile',
	function($compile) {
		return {
			restrict: 'AE',
			replace: true,
			templateUrl: 'view/app/partials/helpers/swipeMenu.html',
			link: function($scope, element, attrs) {
				/*var swiper = new Swiper('.swipe-menu', {
					pagination: '.swipe-menu .swiper-pagination',
					paginationClickable: true,
					slidesPerView: 4
				});*/
			}
		}
	}
]);