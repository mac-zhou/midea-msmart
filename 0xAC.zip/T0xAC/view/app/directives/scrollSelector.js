mideaACApp.directive('scrollSelector', ['$compile',
	function($compile) {
		return {
			restrict: 'AE',
			replace: false,
			templateUrl: 'view/app/partials/helpers/scrollSelector.html',
			link: function($scope, ele, attrs) {
				/*声明和定义组件类*/

				/*插件模式*/
				var option = attrs.option !== undefined ? attrs.option : 'single';
				var pos = attrs.pos !== undefined ? attrs.pos : 'left';

				$scope.appRuntime.scrollSelectorOption = option;

				function scrollDateSelector(params) {
					var that = this;
					that.params = params;
					that.listHeight = params.listHeight !== undefined ? params.listHeight : 250;
					that.numItems = params.numItems !== undefined ? params.numItems : 5;
					that.itemHeight = that.listHeight / that.numItems;
					that.numMarginItem = params.numMarginItem !== undefined ? params.numMarginItem : 2;
					that.currentActiveIndex = that.params.currentActiveItem;
					that.domQuery = params.domQuery !== undefined ? params.domQuery : '.scroll-date-selector .time-list ul';
					that.flipCenterTop = params.flipCenterTop !== undefined ? params.flipCenterTop : '63';

					that.totalItems = $(that.domQuery+" li").length-1;
					
					if (params.listHeight !== undefined) {
						$(that.domQuery).parent().css({
							height: params.listHeight
						});
					}

					if (params.flipCenterTop !== undefined) {
						$(that.domQuery).parent().parent().find('.flip-center').css({
							top: params.flipCenterTop + 'px'
						});
					}

					that.init();
				};

				/*组件初始化*/
				scrollDateSelector.prototype.init = function() {
					console.log('init scroll selector');
					var that = this;

					that.setActiveItem(that.currentActiveIndex);

					that._scrollContainer = $(that.domQuery).pep({
						axis: "y",
						useCSSTranslation: false,
						startPos: that.setCurrentPos(that.params.currentActiveItem),
						velocityMultiplier: 5,
						drag: function(ev, obj) {
							//that.setEffect(ev, obj);
							that.outOfBounds(ev, obj);
						},
						stop: function(ev, obj) {
							//that.outOfBounds(ev, obj);
							that.itemAlignement(ev, obj);
							that.setEffect(ev, obj);
						},
						rest: function(ev, obj) {
							that.outOfBounds(ev, obj);
							that.itemAlignement(ev, obj);
						}
					});
					setTimeout(function(){
						that.handleEvent();
					},1);				
				};

				/*设置当前活动项的坐标*/
				scrollDateSelector.prototype.setCurrentPos = function(itemIndex) {
					var that = this;

					var pos = {};
					if (false) { //测试代码 尚不稳定
						itemIndex = itemIndex === 0 ? that.numMarginItem : itemIndex;
						var pos = {
							'left': 0,
							'top': that.itemHeight * (itemIndex)
						}
					} else {
						var pos = {
							'left': 0,
							'top': -that.itemHeight * (itemIndex - that.numMarginItem)
						}
					}
					return pos;
				};

				/*激活当前活动项*/
				scrollDateSelector.prototype.setActiveItem = function(index) {
					var that = this;

					setTimeout(function() {
						$(that.domQuery + " li:eq(" + index + ")").removeClass('list-item-deactive').addClass('list-item-active');
						$(that.domQuery + " li:not(:eq(" + index + "))").removeClass('list-item-active').addClass('list-item-deactive');
					}, 1);
				}

				/*用于边界检测*/
				scrollDateSelector.prototype.outOfBounds = function(ev, obj) {
					/*
					 * A obj.$el.outerHeight() 子容器的高度
					 * B obj.$el.parent().outerHeight() 父容器的高度
					 * A>B and if pos = A-B then has collision
					 */
					var that = this;

					var currentItemMargin = that.numMarginItem * that.itemHeight;

					if (-obj.$el.position().top > (obj.$el.outerHeight() - obj.$el.parent().outerHeight() + currentItemMargin)) {
						setTimeout(function() {
							obj.$el.css({
								top: -obj.$el.outerHeight() + obj.$el.parent().outerHeight() - currentItemMargin
							})						
							that.setActiveItem(that.totalItems);
						}, 100);
					}

					if (obj.$el.position().top > currentItemMargin) {
						setTimeout(function() {
							obj.$el.css({
								top: currentItemMargin
							});
							that.setActiveItem(0);
						}, 100);					
					}

				};

				/*用于平滑对齐*/
				scrollDateSelector.prototype.itemAlignement = function(ev, obj) {
					var that = this;

					var delay = 1;
					setTimeout(function() {
						obj.$el.css({
							top: -Math.round((-obj.$el.position().top) / that.itemHeight) * that.itemHeight
						});
						that.setEffect(ev, obj);
					}, delay);

					setTimeout(function() {
						that.handleEvent();
					}, delay + 1);
				};

				/*用于设置运动过程中list项目的效果*/
				scrollDateSelector.prototype.setEffect = function(ev, obj) {
					var that = this;

					that.currentActiveIndex = that.calculateCurrentActiveIndex(obj);
					that.setActiveItem(that.currentActiveIndex);
				};

				/*获得当前激活的坐标*/
				scrollDateSelector.prototype.calculateCurrentActiveIndex = function(obj) {
					var that = this;

					var moveDistance = Math.round((-obj.$el.position().top) / that.itemHeight);
					var currentActiveIndex = moveDistance + that.numMarginItem;
					return currentActiveIndex;
				};

				/*用于进行数据交互*/
				scrollDateSelector.prototype.handleEvent = function() {
					var that = this;

					var currentContainer = $(that.domQuery + ' li');
					setTimeout(function() {
						currentContainer.each(function() {
							if ($(this).hasClass('list-item-active')) {
								if (option === 'single') {
									$.event.trigger("update:scrollSelector", {
										currentVal: {
											mod: 'single',
											pos: 'mid',
											index: that.currentActiveIndex
										}
									});									
									$scope.appRuntime.scrollSelectorStart = that.currentActiveIndex;									
								} else {
									if (that.params.pos === 'left') {
										$.event.trigger("update:scrollSelector", {
											currentVal: {
												mod: 'mutiple',
												pos: 'left',
												index: that.currentActiveIndex
											}
										});
										//$scope.appRuntime.scrollSelectorStart = that.currentActiveIndex;	
									}

									if (that.params.pos === 'right') {
										$.event.trigger("update:scrollSelector", {
											currentVal: {
												mod: 'mutiple',
												pos: 'right',
												index: that.currentActiveIndex
											}
										});
										//$scope.appRuntime.scrollSelectorEnd = that.currentActiveIndex;
									}
								}
							}
						});
					}, 1);

					/*持续渲染活动项*/
					var that = this;
					$scope.$on('show:modal', function() {
						that.setActiveItem(that.currentActiveIndex);
						console.log($scope.appRuntime.scrollSelectorOption);
					});

					/*处理约束*/
					//that.initModeContraint();
				};

				/*用于设定mutiple模式下条件约束*/
				scrollDateSelector.prototype.initModeContraint = function(start, end) {
					$(document).bind('update:scrollSelector', {}, function() {
						console.log(start +" "+ end);
					});
				};

				/*组件模式分类处理*/
				if (option == 'single') {
					var sdSelector = new scrollDateSelector({
						listHeight: 250,
						numItems: 5,
						numMarginItem: 2,
						flipCenterTop: -139,
						currentActiveItem: attrs.activestart !== undefined ? attrs.activestart : 0,
						domQuery: '.scroll-selector .data-list ul'
					});
				} else if (option == 'mutiple') {
					var sdSelectorStart = new scrollDateSelector({
						listHeight: 250,
						numItems: 5,
						numMarginItem: 2,
						flipCenterTop: -139,
						currentActiveItem: attrs.activestart !== undefined ? attrs.activestart : 0,
						domQuery: '.startSelector .data-list ul',
						pos: 'left'
					});

					var sdSelectorEnd = new scrollDateSelector({
						listHeight: 250,
						numItems: 5,
						numMarginItem: 2,
						flipCenterTop: -139,
						currentActiveItem: attrs.activeend !== undefined ? attrs.activeend : 0,
						domQuery: '.endSelector .data-list ul',
						pos: 'right'
					});
					
					//console.log(sdSelectorStart);

					//sdSelectorStart.initModeContraint(sdSelectorStart.currentActiveIndex, sdSelectorEnd.currentActiveIndex);
				}

			}
		}
	}
]);