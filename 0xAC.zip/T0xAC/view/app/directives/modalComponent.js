mideaACApp.directive('modalComponent', ['$compile',
	function($compile) {
		return {
			restrict: 'AE',
			replace: false,
			templateUrl: 'view/app/partials/helpers/modalComponent.html',
			link: function($scope) {

				var that = {};

				function modalComponet() {
					that = this;

					that.animationClass = { in : 'show-modal',
						out: 'hide-modal'
					};
					that.animateDelay = 450;
					that._container = $(".modal-component");
					that._contentWrapper = '.content-body';
					that._device = $scope.appConfig.isMobile ? 'mobile' : 'pc';
					that._eventCollection = {
						'pc': {
							'start': 'mousedown',
							'move': 'mousemove',
							'end': 'mouseup'
						},
						'mobile': {
							'start': 'touchstart',
							'move': 'touchmove',
							'end': 'touchend'
						}
					};

					that.init();
				}

				modalComponet.prototype.init = function() {			
					that.handleEvent();
				};
				
				modalComponet.prototype.dynamicLayout = function() {
					if($scope.component.isChangeWindSpeed || $scope.component.isChangeHumidity) {
//						$scope.component.modalHeight = 170;
						if(document.body.clientWidth > 400){
								$scope.component.modalHeight = 180;
						}else{
								$scope.component.modalHeight = 170;
						}
					} else if($scope.component.isModeControl){
						$scope.component.modalHeight = 302;
						setTimeout(function () {
							if ($scope.component.isScrollDateSelector) {
								$scope.currentDeviceInfo = $scope.acController.dataManager.getCurrentDevice().deviceInfo;
								if ($scope.currentDeviceInfo.hasReadyColdOrHot) {
									$scope.component.modalHeight = 260;
								} else {
									$scope.component.modalHeight = 210;
								}
							} else if (!$scope.component.isModeControl){
								$scope.component.modalHeight = $("modal-operation").height();
							}
						}, 100);
					} else if($scope.component.isScrollDateSelector){
						$scope.currentDeviceInfo = $scope.acController.dataManager.getCurrentDevice().deviceInfo;
						if($scope.currentDeviceInfo.hasReadyColdOrHot) {
							$scope.component.modalHeight = 260;
						} else {
							$scope.component.modalHeight = 210;
						}
					} else if ($scope.component.isUpDownNoWindFeelControl) {
						$scope.component.modalHeight = 0;
					}else if ($scope.component.isChangesTemperatureControl) {
						$scope.component.modalHeight = 210;
					} else {
						$scope.component.modalHeight = 210;
					}
				};

				modalComponet.prototype.handleEvent = function() {
					$scope.$on('close:modal', function() {
						that.lockScroll([$('.show-modal'),$('.modal-overlay'), $('body')],false);
						that.closeModal();
					});

					$scope.$on('show:modal', function() {
						that.lockScroll([$('.show-modal'),$('.modal-overlay'), $('body')],true);
						that.dynamicLayout();
						that.showModal();
					});

					$(document).on(that._eventCollection[that._device]['end'], function(event) {
						var currentTarget = $(event.target).attr('class');
						if (currentTarget === 'modal-component') {
							that.closeModal();
							$.event.trigger("close:modal:finit", [{}]);
							
							/*推进事件循环*/
							$scope.$apply();
						}		
					});
				};

				modalComponet.prototype.showModal = function() {
					that._container.fadeIn('fast');
					that._container.find(that._contentWrapper).removeClass(that.animationClass.out).addClass(that.animationClass.in);
				};

				modalComponet.prototype.closeModal = function() {
					setTimeout(function() {
						that._container.fadeOut('fast');
					}, that.animateDelay);
					that._container.find(that._contentWrapper).removeClass(that.animationClass.in).addClass(that.animationClass.out);
				};
				
				modalComponet.prototype.lockScroll = function(lockScrollList, state) {
					if(state) {
						for (var i = 0; i < lockScrollList.length; i++) {
							lockScrollList[i].unbind(that._eventCollection[that._device]['start']).bind(that._eventCollection[that._device]['start'], function(e) {
								e.preventDefault();
							})
						}
					} else {
						for (var i = 0; i < lockScrollList.length; i++) {
							lockScrollList[i].unbind(that._eventCollection[that._device]['start']).bind(that._eventCollection[that._device]['start'], function(e) {
							})
						}
					}
				};

				var mc = new modalComponet();

			}
		}
	}
]);