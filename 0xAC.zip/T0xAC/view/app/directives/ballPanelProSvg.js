mideaACApp.directive('ballPanelProSvg', ['$compile',
	function($compile) {
		return {
			restrict: 'AE',
			replace: false,
			template: '<div id="ball-panel-pro-svg"></div>',
			link: function($scope) {
				var that = {};
				function ballPanel() {
					//保存环境变量
					that = this;

					//控件设置
					that.domId = 'ball-panel-pro-svg';
					that.canvasWidth = 320;
					that.canvasHeight = 320;
					that.outerCircleRadius = 130;
					that.innerCircleRadius = 70;
					that.centerX = that.canvasWidth / 2;
					that.centerY = that.canvasHeight / 2;
					that.handle = {};
					that.device = 'pc';
					that.currentPoint = {};
					that.currentPoint.x = that.centerX;
					that.currentPoint.y = that.centerY;
					that.canvasPos = {};
					that.canvasPos = {
						'x': $('#' + that.domId).offset().top,
						'y': $('#' + that.domId).offset().left
					};
					that.totalDial = 360;
					that.centerRender = {};
					that.centerRenderPos = {
						'x': that.canvasWidth / 2,
						'y': that.canvasWidth / 2
					}
					that.currentVal = 0;
					that.dialRange = {
						'min': 17,
						'max': 30,
						'step': 1
					};

					/*启动控件*/
					that.init();
				}

				ballPanel.prototype.init = function() {
					console.log('init');
					that._dialLines = new Array();
					that.initCanvas();
					that.drawDial();
					that.interactHandle();
				}

				ballPanel.prototype.initCanvas = function() {
					that.paper = Raphael(that.domId, that.canvasWidth, that.canvasHeight);
					that.outerCircle = that.paper.circle(that.canvasWidth / 2, that.canvasHeight / 2, that.outerCircleRadius);
					that.innerCircle = that.paper.circle(that.canvasWidth / 2, that.canvasHeight / 2, that.innerCircleRadius);
					that.outerCircle.attr({
						fill: "#069eff",
						stroke: '#069eff'
					});
					that.innerCircle.attr({
						fill: "#0686FE",
						stroke: '#0686FE'
					});
				};

				ballPanel.prototype.drawDial = function() {
					var line = {};
					var unitVal = 0;
					if (that._dialLines.length == 0) {
						that._rangeDistance = that.dialRange.max - that.dialRange.min;
						for (var i = 0; i < that.totalDial; i += 3) {
							line = that.line(that.centerX + that.innerCircleRadius + 15, that.centerY, that.centerX + that.outerCircleRadius - 15, that.centerY);
							line.attr({
								stroke: '#ddd'
							});
							line.rotate(i, that.centerX, that.centerY);
							that._dialLines[i] = line;
						}
					} else {
						for (var i = 0; i < that.totalDial; i += 3) {
							unitVal = Math.round(that._rangeDistance * i / 360);
							if (that.currentVal >= unitVal) {
								that._dialLines[i].attr({
									stroke: 'blue'
								});
							} else {
								that._dialLines[i].attr({
									stroke: '#ddd'
								});
							}
						}
					}

				};

				ballPanel.prototype.drawHanel = function() {
					var line = that.line(that.centerX + that.innerCircleRadius, that.centerY, that.centerX + that.outerCircleRadius, that.centerY);
					line.attr({
						stroke: '#fff',
						'stroke-width': '3px'
					});

					/*var angle = 1;		
					setInterval(function(){
						line.rotate(angle, that.centerX, that.centerY);
					},10);*/

					return line;
				};

				ballPanel.prototype.drawCenterRender = function(content) {
					if (Object.keys(that.centerRender).length !== 0) {
						that.centerRender.remove();
					}
					that.centerRender = that.paper.text(that.centerRenderPos.x, that.centerRenderPos.y, content);
				};

				ballPanel.prototype.line = function(x1, y1, x2, y2) {
					var path = that.paper.path("M" + x1 + " " + y1 + "L " + x2 + " " + y2);
					return path;
				};

				ballPanel.prototype.interactHandle = function() {
					var eventCollection = {
						'pc': {
							'start': 'mousedown',
							'move': 'mousemove',
							'end': 'mouseup'
						},
						'mobile': {
							'start': 'touchstart',
							'move': 'touchmove',
							'end': 'touchend'
						}
					};

					that.handle = that.drawHanel();
					//that.line(that.centerX,that.centerY,that.currentPoint.x, that.currentPoint.y);

					var currentAngle = 0;
					var isStart = false;
					var interactObj = that['outerCircle'];

					interactObj[eventCollection[that.device]['move']](function(event) {
						//that.line(that.centerX, that.centerY, event.pageX, event.pageY);

						if (isStart) {
							var currentTouchPoint = {
								'x': event.pageX,
								'y': event.pageX
							}

							var lineA = {
								'x': that.currentPoint.x, //- that.centerX
								'y': that.currentPoint.y //-that.centerY
							};
							var lineB = {
								'x': event.pageX, //- that.centerX
								'y': event.pageY //-that.centerY
							};

							/*var cosAngle = (lineA.x * lineB.x + lineA.y * lineB.y) / (Math.sqrt(lineA.x * lineA.x + lineA.y + lineA.y) * Math.sqrt(lineB.x * lineB.x + lineB.y + lineB.y))
							var moveAngle = Math.acos(Math.abs(cosAngle)) * 360;*/

							/*夹角算法2*/
							/*var moveAngle = Math.abs(Raphael.angle(that.centerX, that.centerY, that.currentPoint.x, that.currentPoint.y,currentTouchPoint.x, currentTouchPoint.y));
							var moveAngle = moveAngle;*/

							deltaY = lineB.y - lineA.y;
							deltaX = lineB.x - lineA.x;
							targetAngle = Math.atan2(deltaY, deltaX) * 180 / Math.PI;
							//console.log(targetAngle);

							that.currentVal = that.calculateCore(targetAngle * 2);
							that.drawDial();
							that.drawCenterRender(that.currentVal);

							that.handle.rotate(targetAngle - currentAngle, that.centerX, that.centerY);
							currentAngle = targetAngle;
						}

					});

					interactObj[eventCollection[that.device]['start']](function(event) {
						isStart = true;
					});

					interactObj[eventCollection[that.device]['end']](function(event) {
						isStart = false;
					});

				};

				ballPanel.prototype.calculateCore = function(angle) {
					return that.dialRange.min + Math.round((angle / that.totalDial) * (that.dialRange.max - that.dialRange.min));
				};

				ballPanelObj = new ballPanel();
			}
		}
	}
]);