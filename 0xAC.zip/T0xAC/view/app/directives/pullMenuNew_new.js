mideaACApp.directive('pullMenus', ['$compile',
	function($compile) {
		return {
			restrict: 'AE',
			replace: false,
			templateUrl: 'view/app/partials/helpers/pullMenu_new.html',
			link: function($scope, element, attrs) {
				var that = {};

				function pullMenu() {
					that = this;
					/*组件配置参数*/
					that.touchZone = $("#main_model");

					that.upComponent = $('.alernate-center-render-fixed-yituoduo');
					that.centerComponent = $('#tttt');
					that.downComponent = $('.main_func');

					that.labelContainer = $('#hasFunc li p');

					that.pageLayout = {
						menuHeight: 114,
						countItem: 8,
						col: 4,
						altrenateRenderOffset: 0.6
					};
					that.animateConfig = {
						time: 300,
						timing: 'linear', //easeInQuint
						touchSenstivity: 20
					};
					that.menuClass = {
						moreFunc: 'longList',
						lessFunc: 'shortList'
					};
					that.menuModeClass = {
						'two': 'smallList',
						'three': 'normalList',
						'four': 'largeList'
					};
					that.alternateContainer = $('.alernate-center-render');
					that.lockScrollList = [$('.air-status'), $('.alernate-center-render'), $('.ball-panel-wrapper'), $('.positionFixed'), $('.timeOutPopUp'), $('.modal-component')];

					/*组件推导参数*/
					that.prevPos = {
						x: 0,
						y: 0
					};
					that.deviceVersion = $scope.appConfig.deviceVersion;
					that.device = $scope.appConfig.isMobile ? 'mobile' : 'pc';
					that.menuContainer = that.downComponent;
					//that.touchContainers = [that.downComponent, $('.status-indicator'), $('.alernate-center-render'), $('.ball-panel-touch-zone'), $('.ball-panel-wrapper')];
					that.touchContainers = [that.downComponent, that.touchZone];
					that.touchContainersCount = that.touchContainers.length;
					that._isDown = false;
					that._isUp = false;
					that._isLongMenu = true;
					that._menuMode = 3;
					that._firstRun = true;
					that._eventCollection = {
						'pc': {
							'start': 'mousedown',
							'move': 'mousemove',
							'end': 'mouseup'
						},
						'mobile': {
							'start': 'touchstart',
							'move': 'touchmove',
							'end': 'touchend'
						}
					};

					//启动
					that.init();
				}
				pullMenu.prototype.init = function(event) {
					that.lockScroll();

					that.bindEvent(that.touchContainers);

					setTimeout(function() {
						that.adapteDevice();
						that.labelContainer = $('#hasFunc li p');
					}, 100);

					function initHeight() {
						var btnImg = angular.element('#hasFunc li img'),
							setTimeDiv = angular.element('#hasFunc li .setTime');

						setTimeDiv.css('height', btnImg.height() + 'px');
						setTimeDiv.css('width', btnImg.height() + 'px');
						
					//修改start
//						that.touchZone.css('height', $(document.body).height()*0.6896 + 'px');
					//修改end

						var mainContainer = angular.element('.main_container_height'),
							mainFunc = angular.element('.main_func'),
							head = angular.element('.bg_main_White'),
							headHeight = head.outerHeight(true),
							mainFuncHeight = mainFunc.outerHeight(true),
							pullMenuDiv = angular.element('#pullMenuDiv'),
							pullMenuLi = angular.element('#hasFunc li'),
							mainFuncBottom = mainFuncHeight - parseInt(pullMenuDiv.css('margin-top'), 10) - pullMenuLi.outerHeight(true) - 5,
							mainHeight = angular.element(window).height() - headHeight - (mainFuncHeight - mainFuncBottom) + 'px';

						//						mainFunc.css('bottom', '-' + mainFuncBottom + 'px');
						//						mainContainer.css('height', mainHeight);
						//						angular.element('.ball_panel_parent').css('height', mainHeight);

					}
					setTimeout(function() {
						initHeight();
					}, 500);
					setTimeout(function() {
						initHeight();
						//判断图片是否加载完，如果没有，那么等待图片加载完毕后再次调整高度
						var timer = setInterval(function() {
							var isLoaded = checkLoaded();
							if (isLoaded) {
								clearInterval(timer);
								initHeight();
							}
						}, 50);
					}, 1500);

					//判断图片是否加载完毕
					function checkLoaded() {
						var imgArray = document.querySelectorAll(".pull-menu img");
						var loaded = true;
						for (var i = 0; i < imgArray.length; i++) {
							if (imgArray[i].complete != true)
								loaded = false
						}
						return loaded;
					}

				};

				pullMenu.prototype.bindEvent = function(touchContainers) {

					for (var i = 0; i < touchContainers.length; i++) {
						touchContainers[i].unbind(that._eventCollection[that.device]['start']).bind(that._eventCollection[that.device]['start'], function(event) {
							event.preventDefault();
							
							
							that._isDown = true;
							that._firstRun = true;
							if (that.device === 'mobile') {
								event = event.originalEvent.touches[0];
							}

							that.prevPos = {
								x: event.pageX,
								y: event.pageY
							};
							that._currentLayout = that.getLayout();
							that._currentTransform = that.getCssTransform(that.downComponent);
						});

						touchContainers[i].unbind(that._eventCollection[that.device]['end']).bind(that._eventCollection[that.device]['end'], function(event) {
							event.preventDefault();
							
							that._isDown = false;
							if (that.device === 'mobile') {
								event = event.originalEvent.touches[0];
							}

							that._currentLayout = that.getLayout();
							that._currentTransform = that.getCssTransform(that.downComponent);

							that.setEaseEffect();
							/*that.adapteDevice();*/
						});

						touchContainers[i].unbind(that._eventCollection[that.device]['move']).bind(that._eventCollection[that.device]['move'], function(event) {
							event.preventDefault();
							if (that.device === 'mobile') {
								event = event.originalEvent.touches[0];
							}

							if ((that._isDown)) {
								
								that._moveDist = event.pageY - that.prevPos.y;
								that._eleDeplacement = that._currentTransform.y + that._moveDist;
								//状态重置	
								if (that._firstRun) {
									console.log(that._currentTransform);
									that._firstRun = false;
									if ((that._currentTransform.y < 0) && !that._isUp) {
										that.downComponent.css({
											transform: "translateY(" + that._currentTransform.y + "px)"
										});
										that.alternateContainer.css({
											transform: "translateY(" + (that._currentTransform.y + 50) + "px)"
										});
										that.centerComponent.css({
											transform: "translateY(" + that._currentTransform.y + "px)"
										});
										that.upComponent.css({
											transform: "translateY(" + that._currentTransform.y + "px)"
										});
										
									} else if((that._currentTransform.y >= 0) && that._isUp) {
										that.downComponent.css({
											transform: "translateY(0px)"
										});
										that.alternateContainer.css({
											transform: "translateY(0px)"
										});
										that.centerComponent.css({
											transform: "translateY(0px)"
										});
										that.upComponent.css({
											transform: "translateY(0px)"
										});

									}
								}

								if (that._moveDist > -that.animateConfig.touchSenstivity) {
									$.event.trigger("pullMenu:before:close", [{}]);
								}

								var endStatus = that.pageLayout.menuHeight - that._currentLayout.down;
								var runPercent = (that._eleDeplacement / endStatus).toFixed(1);
								if ((that._eleDeplacement <= 0) && (Math.abs(that._eleDeplacement) < that.downComponent.height() * 0.6)) {
									console.log(that._eleDeplacement);
									that.downComponent.css({
										transform: "translateY(" + that._eleDeplacement + "px)"
									});

									that.alternateContainer.css({
										transform: "translateY(" + (that._eleDeplacement * that.pageLayout.altrenateRenderOffset) + "px)"
									});
									that.centerComponent.css({
										transform: "translateY(" + (that._eleDeplacement * 0.85) + "px)"
									});
									that.upComponent.css({
										'opacity': 1 - runPercent,
										transform: "translateY(" + (that._eleDeplacement * that.pageLayout.altrenateRenderOffset) + "px)"
									});

									//									that.labelContainer.css({
									//										'opacity': runPercent
									//									});
									if (that.downComponent.hasClass('long-pull-menu-move-up') || that.downComponent.hasClass('alternate-render-move-down')) {
										that.downComponent.removeClass('long-pull-menu-move-up').removeClass('alternate-render-move-down');
									}

									if (that.alternateContainer.hasClass('long-alternate-render-move-up') || that.alternateContainer.hasClass('alternate-render-move-down')) {
										that.alternateContainer.removeClass('long-alternate-render-move-up').removeClass('alternate-render-move-down');
									}
									if (that.centerComponent.hasClass('center-componet-render-move-up') || that.centerComponent.hasClass('alternate-render-move-down')) {
										that.centerComponent.removeClass('center-componet-render-move-up').removeClass('alternate-render-move-down');
									}
									if (that.upComponent.hasClass('long-alternate-render-move-up') || that.alternateContainer.hasClass('alternate-render-move-down')) {
										that.upComponent.removeClass('long-alternate-render-move-up').removeClass('alternate-render-move-down');
									}

								}
							}
						});
					}
				};

				pullMenu.prototype.setEaseEffect = function() {
					if (that.deviceVersion === 4) {}

					var endStatus = 0;
					var opacity = 0;
					var isOpen = false;
					var runPercent = 0;
					var percent = 0;
					var absMoveDist = Math.abs(that._moveDist);
					if (absMoveDist < 5) {
						if (that.isOpen) {
							//							that.labelContainer.css({
							//								'opacity': 1
							//							});
						}
						return;
					}
					if (that._moveDist < -that.animateConfig.touchSenstivity) {

						endStatus = that.pageLayout.menuHeight - that._currentLayout.down;
						opacity = 0;
						isOpen = true;
						that.isOpen = isOpen;
						$scope.$apply(function() {
							$scope.appRuntime.touchMoveUp = true;
						});

					} else {
						endStatus = that.pageLayout.menuHeight - that._currentLayout.down;
						opacity = 1;
						isOpen = false;
						that.isOpen = isOpen;
						$scope.$apply(function() {
							$scope.appRuntime.touchMoveUp = false;
						});
					}
					console.log("$scope.appRuntime.touchMoveUp==" + $scope.appRuntime.touchMoveUp);
					that.upComponent.stop(true, true).animate({
						'opacity': opacity
					}, {
						duration: that.animateConfig.time,
						easing: that.animateConfig.timing,
						step: function(ele, current) {
							percent = (1 - current.now).toFixed(3);

							//							that.labelContainer.css({
							//								'opacity': percent
							//							});
						},
						complete: function() {
							if (isOpen) {
								$.event.trigger("pullMenu:open", [{}]);
								//that.bindEvent([$('#ball-panel-touch-container')]);
							} else {
								$.event.trigger("pullMenu:close", [{}]);
								//$('#ball-panel-touch-container').unbind(that._eventCollection[that.device]['move']);
							}
						}
					});

					/*if(isOpen) {
						$.event.trigger("pullMenu:open", [{}]);								
					} else {
						$.event.trigger("pullMenu:close", [{}]);								
					}*/

					/*CSS3 菜单运动*/
					if ($scope.appRuntime.touchMoveUp) {

						that.upComponent.removeClass('alternate-render-move-down').addClass('long-alternate-render-move-up');
						that.downComponent.removeClass('alternate-render-move-down').addClass('long-pull-menu-move-up');
						that.alternateContainer.removeClass('alternate-render-move-down').addClass('long-alternate-render-move-up');
						that.centerComponent.removeClass('alternate-render-move-down').addClass('center-componet-render-move-up');
					
						that.alternateContainer.css({
							'transform': "translateY(-"+($scope.centerMoveHeight+ $scope.centerHeight*( 1.3 / 4.6) - 100)+"px)"
						});
						that._isUp = true;
					} else {
						that.upComponent.removeClass('long-alternate-render-move-up').addClass('alternate-render-move-down');
						that.downComponent.removeClass('long-pull-menu-move-up').addClass('alternate-render-move-down');
						that.alternateContainer.removeClass('long-alternate-render-move-up').addClass('alternate-render-move-down');
						that.centerComponent.removeClass('center-componet-render-move-up').addClass('alternate-render-move-down');
					
						that.alternateContainer.css({
							'transform': "translateY(0px)"
						});
						that._isUp = false;
					}
				};

				pullMenu.prototype.adapteDevice = function() {
					var listLength = that.downComponent.find('nav ul li').length;
					if (listLength <= that.pageLayout.countItem) {
						that.downComponent.addClass(that.menuModeClass.four);
					} else if (listLength <= that.pageLayout.countItem + 4) {
						that.downComponent.addClass(that.menuModeClass.four);
					} else {
						that.downComponent.addClass(that.menuModeClass.four);
					}
				};

				/*控件的基础函数*/
				pullMenu.prototype.getLayout = function() {
					/*用于做机型功能适配*/
					var listLength = that.downComponent.find('nav ul li').length;

					var scaleFactor = 1;
					if (listLength <= that.pageLayout.countItem) {
						that._menuMode = 2;
						scaleFactor = 0.75;
					} else if (listLength <= that.pageLayout.countItem + 4) {
						that._menuMode = 4;
					} else {
						that._menuMode = 4;

						if (that.deviceVersion === 4) {
							scaleFactor = 1.15;
						} else {
							scaleFactor = 1.20;
						}

					}

					return {
						'up': that.upComponent.height(),
						'down': that.downComponent.height() * scaleFactor
					}
				};

				pullMenu.prototype.lockScroll = function() {
					for (var i = 0; i < that.lockScrollList.length; i++) {
						that.lockScrollList[i].bind(that._eventCollection[that.device]['move'], function(e) {
							e.preventDefault();
						})
					}
				}

				pullMenu.prototype.getCssTransform = function(ele) {
					var transformMatrix = ele.css("-webkit-transform") ||
						ele.css("-moz-transform") ||
						ele.css("-ms-transform") ||
						ele.css("-o-transform") ||
						ele.css("transform");
					var matrix = transformMatrix.replace(/[^0-9\-.,]/g, '').split(',');
					//var x = matrix[12] || matrix[4]; //translate x
					var y = matrix[13] || matrix[5]; //translate y
					return {
						x: 0,
						y: parseInt(y)
					};
				}

				pullMenuInstance = new pullMenu();
			}
		}
	}
]);