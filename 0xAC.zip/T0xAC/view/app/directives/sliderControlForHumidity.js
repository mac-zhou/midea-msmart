mideaACApp.directive('sliderControlForHumidity', ['$compile',
	function($compile) {
		return {
			restrict: 'AE',
			replace: false,
			templateUrl: 'view/app/partials/helpers/sliderControlForHumidity.html',
			link: function($scope, element, attrs) {
				var that = {};

				function sliderControlForHumidity() {
					that = this;
					/*配置参数*/
					that.container = $(".wind-speed-control-slider");

					/*推导参数*/
					that._preValue = $scope.deviceStatus.setHumidityValue;
					that._curValue = $scope.deviceStatus.setHumidityValue;
                    that.isInteract = false;
					that.init();
					
				}

				sliderControlForHumidity.prototype.init = function() {
					console.log('init slider control for humidity');

					that.container.slider({
						animate: "slow",
						range: "min",
						min: 30,
						max: 90,
						step: 1,
						change: function(event, ui) {
							//console.log(ui.value);	
					   if(that.isInteract) {
	                   $.event.trigger("slider:control:for:humidity:update", [{
		               current: that._curValue
	                   }]);
	                   that.isInteract = false;
                       } 
						},
						slide: function(event, ui) {
							$scope.$apply(function() {
								$scope.deviceStatus.setHumidityValue = ui.value;
							})
						},
						start: function(event, ui) {
							that.isInteract = true;
							that._preValue = ui.value;
						},
						stop: function(event, ui) {
							that._curValue = ui.value;
							
//							if (that._preValue !== that._curValue) {
//								$.event.trigger("slider:control:for:humidity:update", [{
//									current: that._curValue
//								}]);
//							}
						}
					});

					that.dataBinding($scope.deviceStatus.setHumidityValue);
					that.eventInterface();
				}

				sliderControlForHumidity.prototype.eventInterface = function() {										
					$scope.$on("slider:control:for:humidity:init", function(event,data){
						that.container.slider("value", data.current);
					});
					
					$scope.$on("slider:control:for:humidity:disable", function(event,data){
						that.container.slider( "disable");
					});
					
					$scope.$on("slider:control:for:humidity:enable", function(event,data){
						that.container.slider( "enable");
					});
				}

				sliderControlForHumidity.prototype.dataBinding = function(value) {
					var currentValue = value !== $scope.appRuntime.defaultPlaceholder ? value : 0;
					that.container.slider("value", currentValue);
					
					$scope.$watch("deviceStatus.setHumidityValue", function(news,olds){
						if(news !== olds) {
							that.container.slider("value", news);
						}
					});
				}

				var scfh = new sliderControlForHumidity();


			}
		}
	}
]);