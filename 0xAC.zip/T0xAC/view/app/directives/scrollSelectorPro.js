mideaACApp.directive('scrollSelectorPro', ['$compile',
	function($compile) {
		return {
			restrict: 'AE',
			replace: false,
			templateUrl: 'view/app/partials/helpers/scrollSelectorPro.html',
			link: function($scope, ele, attrs) {

				var that = {};

				function scrollSelectorPro() {
					that = this;

					that.domContainer = $(".mobile-scroll-selector");

					that.currentIndex = attrs.activestart !== undefined ? attrs.activestart : -1;

					that._mobiSelectorData = [];
					
					$scope.appRuntime.scrollSelectotCurrentStatus = true;
					
					that._firstRun = 0;

					if(!$scope.appConfig.isCentralAC) {
						that.deviceStatus = $scope.deviceStatus.deviceRunningStatus !== undefined ? $scope.deviceStatus.deviceRunningStatus : true;
					} else {
						that.deviceStatus = $scope.appRuntime.deviceRunningStatus !== undefined ? parseInt($scope.appRuntime.deviceRunningStatus) : true;
					}

					that.init();
				};


				scrollSelectorPro.prototype.init = function() {

					var initData = that.initData();
					var _firstRun = 0;
					that.domContainer.mobiscroll().select({
						display: 'inline',
						showInput: false,
						group: {
							groupWheel: true,
							header: false,
							clustered: true
						},
						minWidth: 150,
						height: 30,
						rows: 5,
						data: initData,
						onChange: function() {
							that._mobiSelectorData = that.domContainer.mobiscroll('getVal', false, true);
							that.bindEvent(that._mobiSelectorData);
							
							/*PMV控件特殊处理*/
							if($scope.component.isScrollPmvSelector) {								
								$scope.$apply(function(){
									if(that._mobiSelectorData[0] == 1) {
										$scope.appRuntime.scrollSelectotCurrentStatus = true;
									} else {
										$scope.appRuntime.scrollSelectotCurrentStatus = false;
									}
								});								
							}
						},
						onPosition: function() {
							/*突破极限项目数76*/
							if(_firstRun < 2) {
								 that.domContainer.mobiscroll('setVal', that.currentIndex, true, true, true, 1);
								 _firstRun++;
							}
						},
					});

					that._mobiSelectorData = [1, that.currentIndex];
					setTimeout(function() {
						that.bindEvent(that._mobiSelectorData);
						that.watchVariable();
						that.domContainer.mobiscroll('setVal', that.currentIndex, true, true, true, 1);
					}, 100);
				}

				scrollSelectorPro.prototype.initData = function() {
					var data = [];
					var item = {};

					item = {
						text: '',
						value: $scope.appRuntime.scrollSelector.data.right[0].value,
						group: $scope.appRuntime.scrollSelector.data.right[0].label
					};
					data.push(item);

					for (var i = 0; i < $scope.appRuntime.scrollSelector.data.left.length; i++) {
						if (that.deviceStatus) {
							item = {
								text: $scope.appRuntime.scrollSelector.data.left[i].label,
								value: i,
								group: $scope.appRuntime.scrollSelector.data.right[1].label
							};
						} else {
							item = {
								text: $scope.appRuntime.scrollSelector.data.left[i].label,
								value: i,
								group: $scope.appRuntime.scrollSelector.data.right[1].labelAlias
							};
						}
						data.push(item);
					}

					return data;
				}

				scrollSelectorPro.prototype.bindEvent = function(index) {
					$.event.trigger("update:scrollSelector", {
						currentVal: {
							status: index[1] == -1 ? false : true,
							index: index[1],
						}
					});					
				}
				
				scrollSelectorPro.prototype.watchVariable = function() {
					/*PMV控件特殊处理*/
					if($scope.component.isScrollPmvSelector) {	
						$scope.$watch('appRuntime.scrollSelectotCurrentStatus', function(news, old){
							if((news !== old) && ($scope.component.isScrollPmvSelector)) {
								if((news) && (!old)){
									that.domContainer.mobiscroll('setVal', [1,6], true, true, true, 1);
									that._firstRun++;
								}
							}
						});
					}
				}

				var scp = new scrollSelectorPro();

			}
		}
	}
]);