mideaACApp.directive('simpleChart', ['$compile',
	function($compile) {
		return {
			restrict: 'AE',
			replace: false,
			template: '<div id="simple-chart"></div>',
			link: function($scope) {

				var that = {};

				function simpleChart(data) {
					that = this;

					/*图标初始化数据*/
					if (data !== undefined) {
						that.dateValue = data.dateValue;
						that.powerData = data.powerData;
					} else {
						that.dateValue = [1, 5, 10, 15, 20, 25, 31];
						that.powerData = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
							0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
							0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
						];
					}

					that.numOfDays = 31;

					/*图表画布配置*/
					that.paperWidth = 300;
					that.chartWidth = 305;
					that.chartHeight = 120;
					that.paperHeight = 100,
					that.contentHeight = 120;
					that.axisYCount = 100;
					that.lineOption = {
						stroke: '#CCCCCC',
						'stroke-width': 0.5
					};

					that.headerHeight = that.paperHeight - that.contentHeight;
					that.axisStepX = that.paperWidth / (that.powerData.length-1);
//					that.axisStepY = that.contentHeight / that.axisYCount;

					that.init();
					that.eventInterface();
				};

				simpleChart.prototype.init = function() {
					that.paper = Raphael('simple-chart', that.chartWidth, that.chartHeight);
					that.redraw();
				};

				simpleChart.prototype.redraw = function() {
					that.paper.clear();

					//powerData中最大值向上取整
					var maxPowerValue = Math.max.apply(null, that.powerData);
					var scaleValue = 0;
					var r = /^[1-9][0-9]*$/;　
					var l="";
					if (maxPowerValue <= 0.1) {
						scaleValue = 0.02;
					} else if (maxPowerValue >0.1 && maxPowerValue <= 0.5) {
						scaleValue = 0.1;
					} else if (maxPowerValue > 0.5 && maxPowerValue <= 1) {
						scaleValue = 0.2;
					} else if (maxPowerValue > 1 && maxPowerValue <= 5) {
						scaleValue = parseFloat(maxPowerValue / 5).toFixed(1);
					} else {
						scaleValue = Math.ceil(Math.ceil(maxPowerValue) / 5);
					}
					if (r.test(scaleValue)) {
						for (var i = 1; i < 6; i++) {
							that.drawLine(0, that.paperHeight / 5 * i, that.paperWidth, that.paperHeight / 5 * i, that.lineOption, that.paper);
							l = that.paper.text(7, that.paperHeight - that.paperHeight / 5 * i + 7, parseFloat(scaleValue * i).toFixed(0));
							l.attr({
								"fill": "#b2b2b2"
							});
						}
					} else {
						if (scaleValue < 0.1) {
							for (var i = 1; i < 6; i++) {
								that.drawLine(0, that.paperHeight / 5 * i, that.paperWidth, that.paperHeight / 5 * i, that.lineOption, that.paper);
								l = that.paper.text(10, that.paperHeight - that.paperHeight / 5 * i + 7, parseFloat(scaleValue * i).toFixed(2));
								l.attr({
									"fill": "#b2b2b2"
								});
							}
						} else{
							for (var i = 1; i < 6; i++) {
								that.drawLine(0, that.paperHeight / 5 * i, that.paperWidth, that.paperHeight / 5 * i, that.lineOption, that.paper);
								l = that.paper.text(7, that.paperHeight - that.paperHeight / 5 * i + 7, parseFloat(scaleValue * i).toFixed(1));
								l.attr({
									"fill": "#b2b2b2"
								});
							}
						}
						
					}

					that.axisStepY = that.paperHeight / (scaleValue * 5);


					var pen = {
						x: 0,
						y: 0
					};

					var points = new Array();
					var p = that.getCurrentMonthAndDays();
					var days = p.days;
					var months = p.month;
					var currentDay = new Date().getDate();
					var pathAttr = "M" + pen.x + "," + that.paperHeight;
					var textHeightLocation = that.paperHeight + 10;
					var nextX = 0;
					var nextY = 0;
					
					for (var i = 0; i < days; i++) {
						var option = {
							stroke: '#069eff',
							'stroke-width': 1.5,
						};
						if (i == 0) {
							if (months < 10) {
								l = that.paper.text(pen.x+7, textHeightLocation, months+".1");
							} else{
								l = that.paper.text(pen.x+9, textHeightLocation, months+".1");
							}
						} else {
							if (days == 30) {
								if ((i + 1) % 5 == 0) {
									if(i!= 29){
										l = that.paper.text(pen.x, textHeightLocation, months+"."+(i + 1));
									}
								}
								if (i == 29) {
									l = that.paper.text(pen.x-8, textHeightLocation, months+"."+(i + 1));
								}
							} else if (days == 31) {
								if ((i + 1) % 5 == 0) {
									if (i < 29) {
										l = that.paper.text(pen.x, textHeightLocation, months+"."+(i + 1));
									}
								}
								if (i == 30) {
									l = that.paper.text(pen.x-8, textHeightLocation, months+"."+days);
								}
							} else if (days == 29) {
								if ((i + 1) % 5 == 0) {
									l = that.paper.text(pen.x, textHeightLocation, months+"."+(i + 1));
								}
								if (i == 28) {
									l = that.paper.text(pen.x-8, textHeightLocation, months+"."+days);
								}
							} else if (days == 28) {
								if ((i + 1) % 5 == 0) {
									l = that.paper.text(pen.x, textHeightLocation, months+"."+(i + 1));
								}
								if (i == 27) {
									l = that.paper.text(pen.x-8, textHeightLocation, months+"."+days);
								}
							}
						}
						l.attr({
							"fill": "#b2b2b2"
						});
						pen.x += that.axisStepX;
					}
					pen.x = 0;
					for (var i = 0; i < currentDay; i++) {
						var option = {
							stroke: '#069eff',
							'stroke-width': 1.5,
						};
						//line points set
						pathAttr = pathAttr + "L" + pen.x + "," + (that.paperHeight - that.powerData[i] * that.axisStepY);
						
						nextX = pen.x - that.axisStepX;
						nextY = that.paperHeight - that.powerData[i - 1] * that.axisStepY;
						
						var l = that.drawLine(pen.x, that.paperHeight - that.powerData[i] * that.axisStepY, nextX,nextY, option, that.paper);
						l.attr({
							"stroke-linejoin": "round",
							"stroke-linecap": "round"
						});
						pen.x += that.axisStepX;
					}
					pathAttr = pathAttr + "L" + (pen.x - that.axisStepX) + "," + (that.paperHeight - that.powerData[i] * that.axisStepY) + "L" + (pen.x - that.axisStepX) + "," + that.paperHeight;
					that.paper.path(pathAttr).attr({
						"fill": "#C6E2FF",
						"stroke": "#fffff",
						"fill-opacity": "60%"
					});
					
					if(that.powerData[that.powerData.length - 1] == Math.max.apply(null, that.powerData) && that.powerData[that.powerData.length - 1] != 0){
						that.paper.circle(pen.x - that.axisStepX, that.paperHeight - that.powerData[currentDay - 1] * that.axisStepY+3, 2.5).attr({
							"fill": "white",
							"stroke": "blue"
						});
					}else{
						that.paper.circle(pen.x - that.axisStepX, that.paperHeight - that.powerData[currentDay - 1] * that.axisStepY, 2.5).attr({
							"fill": "white",
							"stroke": "blue"
						});
					}
					
						
				};

				simpleChart.prototype.drawLine = function(x1, y1, x2, y2, option, paper) {
					return paper.path("M" + x1 + " " + y1 + "L" + x2 + " " + y2).attr(option);
				};

				simpleChart.prototype.getCurrentMonthAndDays = function() {
					var returnObj = {
						month: 7,
						days: 31
					}
					var monthStr = new Date().getMonth()+1;
					var yearStr = new Date().getFullYear();
					if ("01" == monthStr) {
						returnObj.month = 1;
						returnObj.days = 31;
					} else if ("02" == monthStr) {
						returnObj.month = 2;
						returnObj.days = 28;
						var yearNum = parseInt(yearStr);
						if (0 == (yearNum % 4)) {
							returnObj.days = 29;
						}
					} else if ("03" == monthStr) {
						returnObj.month = 3;
						returnObj.days = 31;
					} else if ("04" == monthStr) {
						returnObj.month = 4;
						returnObj.days = 30;
					} else if ("05" == monthStr) {
						returnObj.month = 5;
						returnObj.days = 31;
					} else if ("06" == monthStr) {
						returnObj.month = 6;
						returnObj.days = 30;
					} else if ("07" == monthStr) {
						returnObj.month = 7;
						returnObj.days = 31;
					} else if ("08" == monthStr) {
						returnObj.month = 8;
						returnObj.days = 31;
					} else if ("09" == monthStr) {
						returnObj.month = 9;
						returnObj.days = 30;
					} else if ("10" == monthStr) {
						returnObj.month = 10;
						returnObj.days = 31;
					} else if ("11" == monthStr) {
						returnObj.month = 11;
						returnObj.days = 30;
					} else if ("12" == monthStr) {
						returnObj.month = 12;
						returnObj.days = 31;
					}
					return returnObj;
				};

				simpleChart.prototype.eventInterface = function() {
					$scope.$on('simpleChart:init:data', function(event, data) {
						//data 的格式{dateValue:array, powerData: array}
//						that.dateValue = data.dateValue;
						that.powerData = data.powerData;
						that.redraw();
					});
				};

				var sc = new simpleChart();
			}
		}
	}
]);