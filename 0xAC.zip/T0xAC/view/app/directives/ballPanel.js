mideaACApp.directive('ballPanel', ['$compile',
	function($compile) {
		return {
			restrict: 'AE',
			replace: true,
			templateUrl: 'view/app/partials/helpers/ballPanel.html',
			link: function($scope) {

				/*******************控件的初始化*********************/
				/*判断当前控制球的模式*/
				var mode = $scope.appConfig.ballPanelMode;
				//var mode = 'wind';

				/*判断是否为手机模式*/
				var isMobile = true;

				/*判断是否是高性能模式*/
				var isHeightPerformance = false;

				/*数值配置*/
				if (mode === 'temperature') {
					var step = 180;
					var upperLimit = 60;
					var lowerLimit = 20;

					/*获得当前设定温度*/
					var currentSetting = $scope.deviceStatus.temperatureInteger;

					/*获得当前室内温度值*/
					var currentDial = $scope.deviceStatus.indoorTempInteger;

					/*设定最大度数*/
					var maxContraint = 30;

					/*设定最小度数*/
					var minContraint = 17;

					/*设定数值单位*/
					$scope.appConfig.ballPanelUnit = "℃";

					/*判断是否支持小数位*/
					var supportDecimal = $scope.appConfig.supportDecimal;


				} else {
					var step = 102;
					
					/*获得当前设定温度*/
					var currentSetting = $scope.deviceStatus.windSpeedValue;

					/*获得当前室内温度值*/
					var currentDial = $scope.deviceStatus.windSpeedValue;

					/*设定最大度数*/
					var maxContraint = step;

					/*设定最小度数*/
					var minContraint = 30;

					/*设定数值单位*/
					$scope.appConfig.ballPanelUnit = "%";

					/*判断是否支持小数位*/
					var supportDecimal = false;
				}

				/*******************控件的运行核心开始*********************/
				var Dial, dial,
					__bind = function(fn, me) {
						return function() {
							return fn.apply(me, arguments);
						};
					};

				/*保存当前对象环境*/
				var that = {};
				var init = true;
				var rotateAngle = 0;

				if (mode === 'temperature') {
					if (supportDecimal) {
						currentDial *= 2;
					}
				}

				Dial = (function() {
					Dial.prototype.raf = null;

					Dial.prototype.mdown = false;

					Dial.prototype.mPos = {
						x: 0,
						y: 0
					};

					Dial.prototype.elementPosition = {
						x: 0,
						y: 0
					};

					Dial.prototype.target = 1;

					Dial.prototype.steps = step;

					Dial.prototype.radius = 150;

					Dial.prototype.maxDiff = 150;

					if (supportDecimal) {
						Dial.prototype.constraint = maxContraint * 2 / step * 360;
					} else {
						Dial.prototype.constraint = maxContraint / step * 360;
					}

					/*仪表盘默认当前值*/
					Dial.prototype.currentVal = 10;

					/*仪表盘初始化的阈值*/
					Dial.prototype.initValue = 26;

					function Dial($context) {
						that = this;
						var knobOffset;
						that.$context = $context;

						/*小数位的处理*/
						that.decimal = supportDecimal ? 0.5 : 1;

						/*绑定不同的设备事件*/
						if (!isMobile) {
							that.onMouseMove = __bind(that.onMouseMove, that);
							that.onMouseUp = __bind(that.onMouseUp, that);
							that.onMouseDown = __bind(that.onMouseDown, that);
						} else {
							that.onMouseMove = __bind(that.onTouchMove, that);
							that.onMouseUp = __bind(that.onTouchEnd, that);
							that.onMouseDown = __bind(that.onTouchEnd, that);
						}

						that.$knob = that.$context.find(".knob");
						that.$handle = that.$context.find(".handle");
						that.$progress = that.$context.find(".progress");
						that.$center = that.$context.find(".center");
						that.$textOutput = that.$center.find("span");

						/*初始化仪表盘中心数据显示*/
						//that.$textOutput.text(Dial.prototype.initValue + Dial.prototype.unit);

						that.ctx = that.$progress.get(0).getContext("2d");
						knobOffset = that.$knob.offset();
						that.elementPosition = {
							x: knobOffset.left, //+20触摸点x误差
							y: knobOffset.top //-70触摸点y误差
						};
						that.centerX = that.$progress.width() / 2;
						that.centerY = that.$progress.height() / 2;
						that.canvasSize = that.$progress.width() + 50;
						that.addEventListeners();
						that.draw();

						if (mode === 'temperature') {

							if (supportDecimal) {
								rotateAngle = currentSetting * 2 / 180 * 360;
							} else {
								rotateAngle = currentSetting / 180 * 360;
							}
							//that.init(rotateAngle);
						} else {

						}

						return;
					}

					Dial.prototype.init = function(angle) {
						that.target = angle;
						that.$knob.css({
							transform: "rotate(" + that.target + "deg)"
						});
						that.draw();
					}

					Dial.prototype.addEventListeners = function() {

						if (!isMobile) {
							that.$context.on("mousedown", that.onMouseDown);
							that.$context.on("mousemove", that.onMouseMove);
							that.$context.on("mouseup", that.onMouseUp);
						} else {
							that.$context.on("touchstart", that.onTouchStart);
							that.$context.on("touchmove", that.onTouchMove);
							that.$context.on("touchend", that.onTouchEnd);
						}

					};

					Dial.prototype.setDialPosition = function() {
						/*控制手柄小球的旋转*/
						that.$knob.css({
							transform: "rotate(" + that.target + "deg)"
						});
						that.draw();
					};

					Dial.prototype.draw = function() {
						var i, _i, _ref;
						that.$progress.get(0).height = that.canvasSize;
						that.$progress.get(0).width = that.canvasSize;
						that.ctx.save();
						that.ctx.translate(that.centerX, that.centerY);
						that.ctx.rotate((-90 * (Math.PI / 180)) - (Math.PI * 2 / that.steps));

						for (i = _i = 0, _ref = that.steps - 1; _i <= _ref; i = _i += 1) {
							that.ctx.beginPath();
							that.ctx.rotate(Math.PI * 2 / that.steps);
							that.ctx.lineWidth = 2;

							/*仪表盘刻度显示区域*/
							that.ctx.lineTo(105, 0);
							that.ctx.lineTo(135, 0);


							if (mode === 'temperature') {

								if (Math.round(i) === currentDial) {
									that.ctx.strokeStyle = "red";
								} else {
									if ((i <= Math.floor(that.currentVal)) && (i >= lowerLimit)) {
										//that.ctx.strokeStyle = "#fff";												
									} else if (((i >= currentSetting) && (i <= currentDial))) {
										that.ctx.strokeStyle = "blue"; //yellow
									} else if ((i >= that.currentVal) && (i <= currentDial)) {
										that.ctx.strokeStyle = "blue";
									} else {
										that.ctx.strokeStyle = "#ccc";
									}
								}

							} else if (mode === 'wind') {
								if (i <= Math.floor(that.currentVal)) {
									that.ctx.shadowBlur = 10;
									that.ctx.strokeStyle = "#fff";

									if (isHeightPerformance) {
										that.ctx.shadowColor = "#fff";
									}

									if (isHeightPerformance) {
										/*表盘在高数值时的变色控制*/
										if (i > (that.steps * 0.75) && that.currentVal > (that.steps * 0.75)) {
											that.ctx.strokeStyle = "#ff9306";
											that.ctx.shadowColor = "#ff9306";
										}

										/*表盘在高数值时的变色控制*/
										if (i > (that.steps * 0.88) && that.currentVal > (that.steps * 0.88)) {
											that.ctx.strokeStyle = "#ff0606";
											that.ctx.shadowColor = "#ff0606";
										}
									}
								} else {
									/*表盘刻度颜色设置*/
									that.ctx.strokeStyle = "#ccc";
									that.ctx.shadowBlur = 0;
									that.ctx.shadowColor = "#fff";
								}
							}

							that.ctx.stroke();
						}

						that.ctx.restore();
					};

					Dial.prototype.setMousePosition = function(event) {
						var atan, diff, target;
						that.mPos = {
							x: event.pageX - that.elementPosition.x,
							y: event.pageY - that.elementPosition.y
						};
						atan = Math.atan2(that.mPos.x - that.radius, that.mPos.y - that.radius);
						target = -atan / (Math.PI / 180) + 180 - 30;
						/*if (init) {
							if (mode === 'temperature') {																
								target += rotateAngle;
								console.log(rotateAngle)
							} else {

							}
							init = false;
						}*/
						diff = Math.abs(target - that.target);

						if (mode === "temperature") {
							if (diff < that.maxDiff && target < that.constraint) {
								that.target = target;
								that.currentVal = that.map(that.target, 0, 360, 0, that.steps);
								that.setDialPosition();
								that.updateOutput();
							}
						} else if (mode === "wind") { //diff < that.maxDiff
							if (target < that.constraint) {
								that.target = target;
								that.currentVal = that.map(that.target, 0, 360, 0, that.steps);
								that.setDialPosition();
								that.updateOutput();
							}
						}
					};

					/*更新仪表盘中心数据的显示*/
					Dial.prototype.updateOutput = function() {
						$.event.trigger("ballPanel:data:update", [{
							'operate': 'update',
							'currentVal': Math.round(that.currentVal) * that.decimal
						}]);
					};

					/*传统PC的操作事件处理*/
					Dial.prototype.onMouseDown = function(event) {
						that.mdown = true;
					};

					Dial.prototype.onMouseUp = function(event) {
						that.mdown = false;
					};

					Dial.prototype.onMouseMove = function(event) {
						if (that.mdown) {
							that.setMousePosition(event);
						}
					};

					/*移动设备触控事件的处理*/
					Dial.prototype.onTouchStart = function(event) {;
						that.mdown = true;
					};

					Dial.prototype.onTouchEnd = function(event) {
						that.mdown = false;
						$.event.trigger("ballPanel:data:request", [{
							'operate': 'update',
							'currentVal': Math.round(that.currentVal) * that.decimal
						}]);
						//alert('touch end');
						//console.log(that.$context);
					};

					Dial.prototype.onTouchMove = function(event) {
						//屏蔽默认行为
						event.preventDefault();

						//转化设备的触控事件
						event = event.originalEvent.touches[0];
						if (that.mdown) {
							that.setMousePosition(event);
						}
					};

					Dial.prototype.map = function(value, low1, high1, low2, high2) {
						return low2 + (high2 - low2) * (value - low1) / (high1 - low1);
					};

					return Dial;

				})(this);

				/*init for plugin*/
				this.$dial = $(".dial");
				dial = new Dial(this.$dial);


				//修复异步惰性加载中出现的bug
				setTimeout(function() {
					dial = new Dial(this.$dial);
				}, 3000);

				//用于与外部通信的事件处理
				$scope.$on('ballPanel:view:switch', function(event, message) {
					//dial = new Dial(this.$dial);
				});

			}
		}
	}
]);