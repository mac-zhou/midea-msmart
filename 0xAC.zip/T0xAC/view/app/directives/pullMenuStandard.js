mideaACApp.directive('pullMenu', ['$compile',
	function($compile) {
		return {
			restrict: 'AE',
			replace: false,
			templateUrl: 'view/app/partials/helpers/pullMenu.html',
			link: function($scope, element, attrs) {
				var that = {};

				function pullMenu() {
					that = this;

					/*组件配置参数*/
					that.upComponent = $('canvas');
					that.canvasId = 'ball-panel-pro-canvas';
					that.downComponent = $('.main_func');
					that.labelContainer = $('.func-text');
					that.touchSensitivity = 0;
					that.pageLayout = {
						currentPageHeight: $('body').height(),
						containerHeight: 420,
						menuHeight: 300,
						midLineUp: 250,
						midLineDown: 200,
						countItem: 8,
						col: 4
					};	
					
					that.deviceVersion = $scope.appConfig.deviceVersion;

					/*i5 i6*/
					that.dynamicLayoutMap = {
						twoRows: {
							menuHeight: 250
						},
						threeRows: {
							menuHeight: 320
						},
						fourRows: {
							menuHeight: 340
						},
					};
					
					/*i4*/
					if(that.deviceVersion === 4) {
						that.dynamicLayoutMap = {
							twoRows: {
								menuHeight: 200
							},
							threeRows: {
								menuHeight: 250
							},
							fourRows: {
								menuHeight: 340
							},
						};
					}

					that.device = $scope.appConfig.isMobile ? 'mobile' : 'pc';
					that.animateConfig = {
						time: 200,
						timing: 'linear'
					};
					that.menuClass = {
						moreFunc: 'longList',
						lessFunc: 'shortList'
					}
					that.alternateContainer = $('.alernate-center-render');

					that.lockScrollList = [$('.air-status'), $('.alernate-center-render'), $('.ball-panel-wrapper'), $('.positionFixed')];

					/*组件推导参数*/
					that.menuContainer = that.downComponent;
					that.touchContainers = [that.downComponent,$('.status-indicator')];
					that._isDown = false;
					that._prevPos = {
						'x': 0,
						'y': 0
					};
					that._nextPos = {
						'x': 0,
						'y': 0
					};
					that.animateEnv = {
						'upBoundary': that.pageLayout.menuHeight - that.pageLayout.currentPageHeight,
						'downBoundary': that.pageLayout.menuHeight
					};
					that._eventCollection = {
						'pc': {
							'start': 'mousedown',
							'move': 'mousemove',
							'end': 'mouseup'
						},
						'mobile': {
							'start': 'touchstart',
							'move': 'touchmove',
							'end': 'touchend'
						}
					};
					that.init();
				};
				pullMenu.prototype.init = function(event) {
					console.log('init pull menu');

					that.dynamicLayout();
					that.lockScroll();

					var defaultLayout = that.getLayout();
					that._defaultUpLayout = defaultLayout.up;
					that._defaultDownLayout = defaultLayout.down;
					$scope.appRuntime.touchMoveUp = false;

					that.bindEvent();
				};

				pullMenu.prototype.bindEvent = function() {
					
					for(var i = 0; i < that.touchContainers.length; i++){
					that.touchContainers[i].on(that._eventCollection[that.device]['start'], function(event) {
						event.preventDefault();
						that._isDown = true;
						if (that.device === 'mobile') {
							event = event.originalEvent.touches[0];
						}

						that.prevPos = {
							x: event.pageX,
							y: event.pageY
						};

						that.dynamicLayout();

						that._currentLayout = that.getLayout();
					});

					that.touchContainers[i].on(that._eventCollection[that.device]['end'], function(event) {
						event.preventDefault();
						that._isDown = false;
						if (that.device === 'mobile') {
							event = event.originalEvent.touches[0];
						}
						that.dynamicLayout();

						that._currentLayout = that.getLayout();

						that.adapteDevice();
						that.setEaseEffect();
					});

					that.touchContainers[i].on(that._eventCollection[that.device]['move'], function(event) {
						event.preventDefault();

						if (that.device === 'mobile') {
							event = event.originalEvent.touches[0];
						}

						var adapteFactor = that._meunLength <= 8 ? 0.89 : 1.2;

						if(that.deviceVersion === 4) {
							adapteFactor = that._menuLength <= 8 ? 0.68 : 0.7;
						}
						
						if ((that._isDown)) {

							that._moveDist = event.pageY - that.prevPos.y;

							var upComponentHeight = that._currentLayout.up + that._moveDist;
							var downComponentHeight = that._currentLayout.down - that._moveDist;

							//console.log(that.pageLayout.menuHeight + " " +downComponentHeight);
							if ((that.pageLayout.menuHeight > downComponentHeight) && (that._moveDist !== 0) && that._defaultDownLayout < downComponentHeight) {
								that.upComponent.css({
									height: upComponentHeight
								});
								that.downComponent.css({
									height: downComponentHeight
								});
							}
							
							if (that._moveDist < 0) {
								if (that.pageLayout.menuHeight > downComponentHeight) {
									that.alternateContainer.css({
										top: upComponentHeight * adapteFactor,
										'opacity': 1
									});
									that.upComponent.css({
										opacity: 0
									});
								}
							} else if(that._moveDist !== 0){
								if (that._defaultDownLayout < downComponentHeight) {
									that.alternateContainer.css({
										top: upComponentHeight * adapteFactor,
										'opacity': 1
									});
								}
							}
						}

					});
					
					}
				};

				pullMenu.prototype.setEaseEffect = function() {
					var moveDist = that.pageLayout.menuHeight - that._currentLayout.down;
					var adapteFactor = that._menuLength <= 8 ? 0.89 : 1.2;
					
					if(that.deviceVersion === 4) {
						adapteFactor = that._menuLength <= 8 ? 0.68 : 0.7;
					}

					if (that._moveDist < 0) {

						var upComponentHeight = that._currentLayout.up - moveDist;
						var downComponentHeight = that._currentLayout.down + moveDist;

						that.upComponent.css({
							opacity: 0
						}, that.animateConfig.time, that.animateConfig.timing);

						that.upComponent.stop(false, false).animate({
							height: upComponentHeight
						}, {
							duration: that.animateConfig.time,
							easing: that.animateConfig.timing,
							complete: function() {
								$.event.trigger("pullMenu:open", [{}]);
							},
							step: function(ele, current) {
								that.alternateContainer.css({
									top: current.now * adapteFactor,
									'opacity': 1
								});
							}
						});

						that.downComponent.stop(false, false).animate({
							height: downComponentHeight
						}, that.animateConfig.time, that.animateConfig.timing);

						$scope.$apply(function() {
							$scope.appRuntime.touchMoveUp = true;
						});

					} else {

						that.upComponent.stop(false, false).animate({
							height: that._defaultUpLayout,
						}, {
							duration: that.animateConfig.time,
							easing: that.animateConfig.timing,
							complete: function() {
								that.upComponent.css({
									opacity: 1
								});
								$.event.trigger("pullMenu:close", [{}]);
							},
							step: function(current) {
								that.alternateContainer.css({
									top: current.now * adapteFactor,
									'opacity': 1
								});
							}
						});

						that.alternateContainer.animate({
							top: '40%',
							'opacity': 1
						}, that.animateConfig.time, that.animateConfig.timing);


						that.downComponent.stop(false, false).animate({
							height: that._defaultDownLayout
						}, that.animateConfig.time, that.animateConfig.timing);

						$scope.$apply(function() {
							$scope.appRuntime.touchMoveUp = false;
						});
					}
				};

				pullMenu.prototype.getLayout = function() {
					return {
						'up': parseInt(that.upComponent.css('height').replace('px', '')),
						'down': parseInt(that.downComponent.css('height').replace('px', ''))
					}
				};

				pullMenu.prototype.adapteDevice = function() {
					var listLength = that.downComponent.find('nav ul li').length;
					if (listLength > that.pageLayout.countItem) {
						that.downComponent.removeClass(that.menuClass.lessFunc).addClass(that.menuClass.moreFunc);
					} else {
						that.downComponent.removeClass(that.menuClass.moreFunc).addClass(that.menuClass.lessFunc);
					}
				};

				pullMenu.prototype.dynamicLayout = function() {
					var listLength = that.downComponent.find('nav ul li').length;
					that._menuLength = listLength;
					if (listLength <= that.pageLayout.col * 2) {
						that.pageLayout.menuHeight = that.dynamicLayoutMap.twoRows.menuHeight;
						that.animateEnv.upBoundary = that.pageLayout.containerHeight - that.dynamicLayoutMap.twoRows.menuHeight;
					} else if (listLength <= that.pageLayout.col * 3) {
						that.pageLayout.menuHeight = that.dynamicLayoutMap.threeRows.menuHeight;
						that.animateEnv.upBoundary = that.pageLayout.containerHeight - that.dynamicLayoutMap.threeRows.menuHeight;
					} else if (listLength <= that.pageLayout.col * 4) {
						that.pageLayout.menuHeight = that.dynamicLayoutMap.fourRows.menuHeight;
						that.animateEnv.upBoundary = that.pageLayout.containerHeight - that.dynamicLayoutMap.fourRows.menuHeight;
					}
					that.animateEnv.downBoundary = that.pageLayout.menuHeight;
				}

				pullMenu.prototype.lockScroll = function() {
					for (var i = 0; i < that.lockScrollList.length; i++) {
						that.lockScrollList[i].bind(that._eventCollection[that.device]['move'], function(e) {
							e.preventDefault();
						})
					}
				}

				pullMenuInstance = new pullMenu();
			}
		}
	}
]);