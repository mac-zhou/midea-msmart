mideaACApp.directive('interactChart', ['$compile',
	function($compile) {
		return {
			templateUrl: 'view/app/partials/helpers/interactChart.html',
			link: function($scope) {

				var that = {};

				function interactChart() {
					that = this;

					/*init*/
					that.canvasWidth = 320;
					that.canvasHeight = 200;
					that._canvas = Raphael("interact-chart", that.canvasWidth, that.canvasHeight);

					that.color = "#fbc381";
					that.bgColor = "#fff5e9";
					that.shadeColor = "#fdd7ab";
					that.lineColor = "#f8931e";
					that.axisColor = "#fbc381";
					that.lineColor = "#f8931e";
					that.lineStrokeWidth = 1;

					that._background = {};

					that.values = [18, 19, 18, 22, 25, 21, 18, 30, 17];

					that.chartRangePos = {
						start: 40,
						end: 200
					};

					that._rangeMapValue = [
						20, 25, 30
					];
					that._rangeMapPos = [
						(that.chartRangePos.end - that.chartRangePos.start) * 0.2, (that.chartRangePos.end - that.chartRangePos.start) * 0.6, (that.chartRangePos.end - that.chartRangePos.start) * 1,
					];

					that.rangeX = [0, 10];
					that.rangeY = [0, 30];

					that.len = 9;

					that.posX = 50;

					that.yStep = 5;
					that.xStep = 2;

					that.animateBoundary = {
						up: 41,
						down: 205
					}

					that.controlLimit = 0;

					/*main logic*/
					/*var p = [
						["M"].concat(that.translate(0, values[0]))
					];*/

					that._X = [];
					that._Y = [];

					that._blankets = that._canvas.set();

					that._buttons = that._canvas.set();

					that._w = (that.canvasWidth - 60) / that.values.length;

					that.isDrag = -1;

					that._currentResult = [];
					for (var i = 0; i < that.values.length; i++) {
						that._currentResult[i] = that.values[i];
					}

					that.init();
				}

				interactChart.prototype.init = function() {
					
					/*普通加载*/
					that.redraw();
					
					/*测试动画加载*/
					/*setTimeout(function(){
						that.animateRedraw(100);
					},100);*/
								
					that.bindChartData();
				}

				interactChart.prototype.animateRedraw = function(time) {
					var animateValue = [0, 0, 0, 0, 0, 0, 0, 0, 0];
					var numFrame = 0;
					that._setValues = that.values;
			
					var delay = setInterval(function() {
						
						for (var i = 0; i < that.values.length; i++) {
							if (animateValue[i] < that._setValues[i]) {
								animateValue[i]+=1;
							}
						}
						that.values = animateValue;
						
						that._X = [];
						that._Y = [];
						that._blankets = that._canvas.set();
						that._buttons = that._canvas.set();
						that.redraw();

						if (numFrame > that.rangeY[1]) {
							clearInterval(delay);
						} else {
							numFrame++;
						}
						
					}, time);
				}

				interactChart.prototype.redraw = function() {
					//that.start = null;
					that._canvas.clear();
					that._sub = that._canvas.path().attr({
						stroke: "none",
						fill: [90, that.shadeColor, that.shadeColor].join("-"),
						opacity: 0
					});

					that._path = that._canvas.path().attr({
						stroke: that.lineColor,
						"stroke-width": that.lineStrokeWidth
					});

					that.interaction();
					that.drawPath();
					that.drawAxis();
				}

				interactChart.prototype.interaction = function() {
					var ii;
					for (i = 0, ii = that.values.length - 1; i < ii; i++) {
						var xy = that.translate(i, that.values[i]),
							xy1 = that.translate(i + 1, that.values[i + 1]),
							f;

						that._X[i] = xy[0];
						that._Y[i] = xy[1];

						(that._f = function(i, xy) {

							if (i !== that.controlLimit) {
								that._buttons.push(that._canvas.circle(xy[0], xy[1], 5).attr({
									fill: 'white',
									stroke: that.lineColor,
									r: 3
								}));
							} else {
								that._buttons.push(that._canvas.circle(xy[0], xy[1], 5).attr({
									fill: 'white',
									stroke: that.lineColor,
									r: 0
								}));
							}

							that._blankets.push(that._canvas.rect(xy[0]-10, 0, 30, 200).attr({
								stroke: "none",
								fill: "#000",
								opacity: 0.3
							}).drag(function(dx, dy) {
								//this.toFront();
								var start = this.start;
								var currentPoint = start.p + dy;
								//console.log("pos " + currentPoint);

								//if ((currentPoint >= that.animateBoundary.up) && (currentPoint <= that.animateBoundary.down) && (i !== that.controlLimit)) {
									that.update(start.i, currentPoint);
									var currentDial = that.calculateCurrentDial(currentPoint);
									that._currentResult[i] = currentDial;
									that.handleEvent(that._currentResult);
									//console.log(currentDial);
									//console.log((start.p + dy) + " " + currentDial +" " + i);
									//console.log(that._currentResult[0]);
								//}

							}, function(x, y) {
								this.start = {
									i: i,
									m: y,
									p: that._Y[i]
								};
							}));
							that._blankets.items[that._blankets.items.length - 1].node.style.cursor = "move";
						})(i, xy);
						if (i == ii - 1) {
							that._f(i + 1, xy1);
						}
					}
					xy = that.translate(ii, that.values[ii]);
					that._X.push(xy[0]);
					that._Y.push(xy[1]);
				}

				interactChart.prototype.drawPath = function() {
					var p = [];
					for (var j = 1, jj = that._X.length; j < jj; j++) {
						p.push(that._X[j], that._Y[j]);
					}
					p = ["M", that._X[0], that._Y[0], "L"].concat(p);
					var subaddon = "L" + (that.canvasWidth - 10) + "," + (that.canvasHeight - 10) + ",50," + (that.canvasHeight - 10) + "z";
					that._path.attr({
						path: p
					});
					that._sub.attr({
						path: p + subaddon
					});
				}

				interactChart.prototype.drawAxis = function() {
					/*绘制静态坐标系*/
					var countX = that.rangeX[1] / that.xStep;
					var countY = that.rangeY[1] / that.yStep;

					var rightBoundary = that.canvasWidth - 10;
					var currentDial = 0;
					for (var i = 1; i < countY; i++) {
						currentDial += 30; //(i / countY) * rightBoundary
						that._canvas.path("M" + that.posX + " " + (that.canvasHeight - currentDial - 10) + "L" + rightBoundary + " " + (that.canvasHeight - currentDial - 10)).attr({
							stroke: that.axisColor,
							"stroke-width": 1,
							"opacity": 0.8
						});

						/*绘制Y坐标轴*/
						if ((i !== 2) && (i !== 4)) {
							var dialValue = 0;
							switch (i) {
								case 1:
									dialValue = '20°';
									break;
								case 3:
									dialValue = '25°';
									break;
								case 5:
									dialValue = '30°';
									break;
							}
							var dialY = that._canvas.text(that.posX + 9, that.canvasHeight - currentDial - 4, dialValue);
							dialY.attr({
								fill: that.lineColor
							});
						}
					}
				}

				interactChart.prototype.update = function(i, d) {
					that._Y[i] = d;
					that.drawPath();
					that._buttons.items[i].attr({
						cy: d.toFixed(1)+50
					});
					that._blankets.items[i].attr({
						cy: d.toFixed(1)
					});
					that._canvas.safari();
				};

				interactChart.prototype.translate = function(x, y) {
					var axisY = 0;
					var startValue = 15.5;

					if ((y > that._rangeMapValue[1]) && (y <= that._rangeMapValue[2])) {
						axisY = that.chartRangePos.end - (that._rangeMapPos[2]) * (y / that._rangeMapValue[2]);
					} else if ((y > that._rangeMapValue[0]) && (y <= that._rangeMapValue[1])) {
						axisY = that.chartRangePos.end - (that._rangeMapPos[1]) * (y / that._rangeMapValue[1]);
					} else if (y <= that._rangeMapValue[0]) {
						axisY = that.chartRangePos.end - (that._rangeMapPos[0]) * ((y - startValue) / (that._rangeMapValue[0] - startValue));
					}

					return [
						that.posX + (that.canvasWidth - 60) / (that.values.length - 1) * x,
						axisY
					];
				};

				interactChart.prototype.calculateCurrentDial = function(pos) {
					var currentDialPos = that.chartRangePos.end - pos;
					var currentDialInterval = 0;
					var currentDialValue = 0;

					for (var i = 0; i < that._rangeMapPos.length; i++) {
						if ((currentDialPos < that._rangeMapPos[i + 1]) && (currentDialPos > that._rangeMapPos[i])) {
							currentDialInterval = i + 1;
						}
					}

					switch (currentDialInterval) {
						case 0:
							currentDialValue = Math.round((that.chartRangePos.end - pos) / (that._rangeMapPos[0]) * (that._rangeMapValue[0] - 17)) + 17;
							break;
						case 1:
							currentDialValue = Math.round((that.chartRangePos.end - pos - that._rangeMapPos[0]) / (that._rangeMapPos[1] - that._rangeMapPos[0]) * (that._rangeMapValue[1] - that._rangeMapValue[0])) + that._rangeMapValue[0];
							break;
						case 2:
							currentDialValue = Math.round((that.chartRangePos.end - pos - that._rangeMapPos[1]) / (that._rangeMapPos[2] - that._rangeMapPos[1]) * (that._rangeMapValue[2] - that._rangeMapValue[1])) + that._rangeMapValue[1];
							break;
					}

					//常规曲线
					//return Math.round((that.chartRangePos.end - pos) / (that.chartRangePos.end - that.chartRangePos.start) * (that.rangeY[1] - that.rangeY[0]));
					//console.log(currentDialInterval + " " + currentDialValue + " "+ that._rangeMapValue[0]);

					//非常规曲线
					return currentDialValue;
				};

				interactChart.prototype.handleEvent = function(data) {
					$.event.trigger("interactChart:data:update", [{
						'operate': 'update',
						'currentVal': data
					}]);
				};

				interactChart.prototype.bindChartData = function() {
					$scope.$on('init:interactChart', function(event, data) {
						that.values = data.current;

						/*that._X = [];
						that._Y = [];
						that._blankets = that._canvas.set();
						that._buttons = that._canvas.set();
						that.redraw();*/
						
						//alert(that.values);						
						that.animateRedraw(10);
					});
				};

				var ic = new interactChart();

			}
		}
	}
]);