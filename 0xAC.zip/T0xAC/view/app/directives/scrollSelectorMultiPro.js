mideaACApp.directive('scrollSelectorMultiPro', ['$compile',
	function($compile) {
		return {
			restrict: 'AE',
			replace: false,
			templateUrl: 'view/app/partials/helpers/scrollSelectorMultiPro.html',
			link: function($scope, ele, attrs) {

				var that = {};

				function scrollSelectorPro() {
					that = this;

					that.domContainer = $("#"+attrs.id+" .mobile-scroll-selector");

					that.currentIndex = attrs.activestart !== undefined ? attrs.activestart : -1;

					that._mobiSelectorData = -1;
					
					$scope.appRuntime.scrollSelectotCurrentStatus = true;

					that.init();
				};


				scrollSelectorPro.prototype.init = function() {

					var initData = that.initData();
					that.domContainer.mobiscroll().select({
						display: 'inline',
						showInput: false,
						minWidth: 150,
						height: 30,
						rows: 5,
						data: initData,
						onChange: function() {
							that._mobiSelectorData = that.domContainer.mobiscroll('getVal', false, true);
							that.bindEvent(that._mobiSelectorData);
						}
					});

					setTimeout(function() {
						that.bindEvent(that.currentIndex);
						that.domContainer.mobiscroll('setVal', that.currentIndex, true, true, true, 1);
					}, 100);
				}

				scrollSelectorPro.prototype.initData = function() {
					var data = [];
					var item = {};

					// item = {
					// 	text: '',
					// 	value: $scope.appRuntime.scrollSelector.data.right[0].value,
					// 	group: $scope.appRuntime.scrollSelector.data.right[0].label
					// };
					// data.push(item);

					for (var i = 0; i < $scope.appRuntime.scrollSelector.data.left.length; i++) {
						if (that.deviceStatus) {
							item = {
								text: $scope.appRuntime.scrollSelector.data.left[i].label,
								value: i,
								group: $scope.appRuntime.scrollSelector.data.right[1].label
							};
						} else {
							item = {
								text: $scope.appRuntime.scrollSelector.data.left[i].label,
								value: i,
								group: $scope.appRuntime.scrollSelector.data.right[1].labelAlias
							};
						}
						data.push(item);
					}

					return data;
				}

				scrollSelectorPro.prototype.bindEvent = function(index) {
					$.event.trigger("update:scrollSelector:"+attrs.id, {
						currentVal: {
							status: index== -1 ? false : true,
							index: index
						}
					});		
				}
				
				var scp = new scrollSelectorPro();

			}
		}
	}
]);