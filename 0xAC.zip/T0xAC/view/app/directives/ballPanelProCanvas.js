mideaACApp.directive('ballPanelProCanvas', ['$compile',
	function($compile) {
		return {
			restrict: 'AE',
			replace: false,
			template: '<div><canvas id="ball-panel-pro-canvas" width="320" height="320" style="width:270px; height:270px;"></canvas><div id="ball-panel-touch-container-wrapper"><div id="ball-panel-touch-container"></div></div></div>',
			link: function($scope) {
				var that = {};

				function ballPanel(dataSet) {
					//保存环境变量
					that = this;

					//控件设置
					/*配置参数*/
					that.domId = 'ball-panel-pro';
					that.canvasId = 'ball-panel-pro-canvas';
					//that.touchContainerId = 'ball-panel-pro-canvas';
					that.touchContainerId = 'ball-panel-touch-container';
					that.device = $scope.appConfig.isMobile ? 'mobile' : 'pc';
					that.iSHightPerformence = $scope.appConfig.isHpDevice;
					that.compressFactor = $scope.appConfig.isHpDevice ? 4 : 1;
					that.outerCircleConfig = {
						radius: 130 * that.compressFactor,
						fill: 'rgb(6,158,255)',
						stroke: 'rgb(6,158,255)',
						shadowColor: 'rgb(6,158,255)',
						shadowBlur: 0,
						opacity: 1
					};
					that.innerCircleConfig = {
						radius: 130 * 0.65 * that.compressFactor,
						fill: 'rgb(6,134,254)',
						stroke: 'rgb(6,134,254)',
						shadowColor: 'rgb(6,134,254)',
						shadowBlur: 0,
						opacity: 1
					};
					that.dialSpacing = 15;
					that.dialConfig = {
						spacing: ((130 * that.compressFactor - 130 * that.compressFactor * 0.65) * (1 - 0.43)) / 2,
						fill: 'rgb(221,221,221)',
						stroke: 'rgb(221,221,221)',
						opacity: 0.5,
						alterOverFill: 'rgb(255,255,0)',
						alterOverStroke: 'rgb(255,255,0)',
						alterOverOpacity: 0.5,
						alterBelowFill: 'rgb(255,255,255)',
						alterBelowStroke: 'rgb(255,255,255)',
						alterBelowOpacity: 1,
						alterCurrentFill: 'rgb(255,255,0)',
						alterCurrentStroke: 'rgb(255,255,0)',
						alterCurrentOpacity: 0.5,
						lineWidth: 1.5 * that.compressFactor
					};
					that.dialRange = {
						'min': 17,
						'max': 24.5,
						'step': $scope.appConfig.isHpDevice ? 2 : 3.5
					};
					that.handleConfig = {
						'stickWidth': 3 * that.compressFactor,
						'stickFill': '#fff',
						'stickStroke': '#fff',
						'ballWidth': 5 * that.compressFactor,
						'ballFill': '#fff',
						'ballStroke': '#fff',
						'shadowColor': '#ddd',
						'shadowBlur': 10,
						'opacity': 1
					};
					that.centerRenderConfig = {
						fontFamilyNum: 'Arial',
						fontFamilyText: 'Microsoft yahei',
						fontSizeNum: '45',
						fontSizeText: '18',
						fontWeightNum: 'bolder',
						fontWeightText: 'normal',
						stroke: '#fff',
						fill: '#fff',
						textLength: 16,
						opacity: 1
					};
					that.deactiveStyle = {
						innerCircleColor: 'rgb(179,179,179)',
						outerCircleColor: 'rgb(204,204,204)',
						dialColor: 'rgb(221,221,221)',
						dialOpacity: 0.8,
						stickOpacity: 0.5
					};
					that.unit = '°';
					that.defaultModeText = '制热运行';
					that.currentMode = 'cold';
					that.currentRealValue = dataSet !== undefined ? dataSet.current : 17; //17
					that.currentConfigValue = dataSet !== undefined ? dataSet.config : 17.1;; //17.1
					that.hasCenterRender = false;
					that.status = dataSet !== undefined ? dataSet.status : true;
					that.deviceStatus = true;
					that.pullMenuStatus = false;
					that.adjustAngle = 19 / 30 * Math.PI;
					that.endAngle = 11 / 30 * Math.PI;
					that.hasDecimal = $scope.appConfig.supportDecimal;
					that.controlInterval = {
						down: 17,
						up: 30
					}

					/*推导参数*/
					$('#' + that.canvasId)[0].width = $('#' + that.canvasId).width() * that.compressFactor;
					$('#' + that.canvasId)[0].height = $('#' + that.canvasId).height() * that.compressFactor;
					that.touchContainer = $('#' + that.touchContainerId);
					that.touchContainerWrapper = $('#' + that.touchContainerId).parent();
					that.canvasWidth = $('#' + that.canvasId).attr('width');
					that.canvasHeight = $('#' + that.canvasId).attr('height');
					that.centerX = that.canvasWidth / 2;
					that.centerY = that.canvasHeight / 2;
					that.currentVal = that.currentConfigValue;
					that.currentPoint = {
						x: that.centerX,
						y: that.centerY
					};
					if ($scope.appConfig.firstRunBallPanel) {
						$scope.appConfig.firstRunBallPanel = false;
						that.canvasPos = {
							'x': $('#' + that.canvasId).offset().left * that.compressFactor,
							'y': $('#' + that.canvasId).offset().top * that.compressFactor
						};
						
						/*应对高延迟情况下的动画阻塞*/
						setTimeout(function(){
							that.canvasPos = {
								'x': $('#' + that.canvasId).offset().left* that.compressFactor,
								'y': $('#' + that.canvasId).offset().top * that.compressFactor
							};
							$scope.appRuntime.canvasPos = that.canvasPos;
						}, 5000);
						
						$scope.appRuntime.canvasPos = that.canvasPos;
					} else {
						that.canvasPos = $scope.appRuntime.canvasPos;
					}
					that.totalDial = 360;
					that.totalDialPI = 2 * Math.PI;
					that.centerRenderPos = {
						'x': that.canvasWidth / 2,
						'y': that.canvasHeight / 2
					};
					that._eventCollection = {
						'pc': {
							'start': 'mousedown',
							'move': 'mousemove',
							'end': 'mouseup'
						},
						'mobile': {
							'start': 'touchstart',
							'move': 'touchmove',
							'end': 'touchend'
						}
					};

					/*启动控件*/
					that.init();
				}

				/*控制球核心功能component*/
				ballPanel.prototype.init = function() {
					console.log('init');

					that._particles = new Array();
					that._colorChangeDelay = 0;

					that._defaultOuterCircleConfig = that.clone(that.outerCircleConfig);
					that._defaultInnerCircleConfig = that.clone(that.innerCircleConfig);
					that._defaultDialConfig = that.clone(that.dialConfig);
					that._defaultHandleConfig = that.clone(that.handleConfig);
					
					if(!that.status) {
						that.outerCircleConfig.fill = that.deactiveStyle.outerCircleColor;
						that.outerCircleConfig.stroke = that.deactiveStyle.outerCircleColor;
						that.outerCircleConfig.shadowColor = that.deactiveStyle.outerCircleColor;

						that.innerCircleConfig.fill = that.deactiveStyle.innerCircleColor;
						that.innerCircleConfig.shadowColor = that.deactiveStyle.innerCircleColor;						

						that.dialConfig.opacity = that.deactiveStyle.dialOpacity;
						that.handleConfig.opacity = that.deactiveStyle.stickOpacity;
						
						that.currentConfigValue = that.currentRealValue;
						
						$.event.trigger("homePage:apperance:change", [{
							status: false
						}]);
					} else {
						that.outerCircleConfig = that.clone(that._defaultOuterCircleConfig);

						that.innerCircleConfig = that.clone(that._defaultInnerCircleConfig);

						that.dialConfig = that.clone(that._defaultDialConfig);

						that.handleConfig = that.clone(that._defaultHandleConfig);
						
						$.event.trigger("homePage:apperance:change", [{
							status: true
						}]);
					}

					that.redrawBallPanel(false);

					that.interactHandle();

					that.eventInterface();
				}

				ballPanel.prototype.initCanvas = function() {
					that._canvas = document.getElementById(that.canvasId);
					that._context = that._canvas.getContext("2d");

					that.drawCircle();
				};

				ballPanel.prototype.drawCircle = function() {
					that.save(function() {
						that._outerCircle = that.renderCircle({
							centerX: that.centerX,
							centerY: that.centerY,
							radius: that.outerCircleConfig.radius,
							fill: that.outerCircleConfig.fill,
							stroke: that.outerCircleConfig.stroke,
							opacity: that.outerCircleConfig.opacity
						}, 'out');
					});

				};

				ballPanel.prototype.drawDial = function() {
					that._initCurrentDial = 0;

					var limit = that.inverseCalculateCore(that.currentRealValue);
					var set = that.inverseCalculateCore(that.currentConfigValue);
					var currentAngle = that.normalizedAngle(that._currentAngle);

					/*动态调整坐标系*/
					if ((currentAngle >= 0) && (currentAngle < Math.PI * 0.5)) {
						currentAngle = currentAngle + Math.PI * 2
					}
					
					/*取值限制*/
					if(limit < that.inverseCalculateCore(that.controlInterval.down)) {
						limit = 1.571;
					}
					if(limit > that.inverseCalculateCore(that.controlInterval.up)) {
						limit = 7.819;
					}

					//console.log(currentAngle + " " + limit);					
					//console.log("real "+limit+" "+that.currentRealValue);
					//console.log("set "+set+" "+that.currentConfigValue);					

					for (var ii = 0; ii < that.totalDial; ii += that.dialRange.step) {
						var i = ii / 360 * Math.PI * 2;

						/*动态调整坐标系*/
						if ((i >= 0) && (i < Math.PI * 0.5)) {
							i = i + Math.PI * 2
						}

						var fillStyle = that.dialConfig.fill,
							strokeStyle = that.dialConfig.stroke,
							lineWidth = that.dialConfig.lineWidth;

						if ((i < limit) && (i > currentAngle)) {
							that.save(function() {
								that._context.globalAlpha = that.dialConfig.alterBelowOpacity;
								that.renderLine({
									fillStyle: that.dialConfig.alterBelowFill,
									strokeStyle: that.dialConfig.alterBelowStroke,
									lineWidth: that.dialConfig.lineWidth,
									start: {
										x: that.innerCircleConfig.radius + that.dialConfig.spacing,
										y: 0
									},
									end: {
										x: that.outerCircleConfig.radius - that.dialConfig.spacing,
										y: 0
									},
								}, function() {
									that._context.translate(that.centerX, that.centerY);
									that._context.rotate(i);
								});
							});
						} else if (((i >= limit) && (i < currentAngle))) {
							that.save(function() {
								that._context.globalAlpha = that.dialConfig.alterOverOpacity;
								that.renderLine({
									fillStyle: that.dialConfig.alterOverFill,
									strokeStyle: that.dialConfig.alterOverStroke,
									lineWidth: that.dialConfig.lineWidth,
									start: {
										x: that.innerCircleConfig.radius + that.dialConfig.spacing,
										y: 0
									},
									end: {
										x: that.outerCircleConfig.radius - that.dialConfig.spacing,
										y: 0
									},
								}, function() {
									that._context.translate(that.centerX, that.centerY);
									that._context.rotate(i);
								});
							});
						} else {
							that.save(function() {
								that._context.globalAlpha = that.dialConfig.opacity;
								that.renderLine({
									fillStyle: fillStyle,
									strokeStyle: strokeStyle,
									lineWidth: lineWidth,
									start: {
										x: that.innerCircleConfig.radius + that.dialConfig.spacing,
										y: 0
									},
									end: {
										x: that.outerCircleConfig.radius - that.dialConfig.spacing,
										y: 0
									},
								}, function() {
									that._context.translate(that.centerX, that.centerY);
									that._context.rotate(i);
								});
							});
						}

						/*当前温度分割线*/
						//console.log(i + " " + limit);
						if ((i.toFixed(2) == limit.toFixed(2)) && (that._initCurrentDial == 0)) {
							that._initCurrentDial++;
													
							that.save(function() {
								that._context.globalAlpha = that.dialConfig.opacity;
								that.renderLine({
									fillStyle: that.dialConfig.alterCurrentFill,
									strokeStyle: that.dialConfig.alterCurrentStroke,
									lineWidth: lineWidth * 2,
									start: {
										x: that.innerCircleConfig.radius + that.dialConfig.spacing,
										y: 0
									},
									end: {
										x: that.outerCircleConfig.radius - that.dialConfig.spacing,
										y: 0
									},
								}, function() {
									that._context.translate(that.centerX, that.centerY);
									that._context.rotate(i);
								});
							});

						    /*运动限制和坐标调整*/
                            if((that.currentRealValue < that.controlInterval.down) || (that.currentRealValue > that.controlInterval.up)) {
                            	that._realTempPos = 1.571;
                            } else {
                            	that._realTempPos = i;
                            }
								
							that.drawTooltips(that._realTempPos);
						}
					}
				};

				ballPanel.prototype.drawHanel = function(angle) {
					that.save(function() {
						that._context.globalAlpha = that.handleConfig.opacity;
						that.renderLine({
							fillStyle: that.handleConfig.stickFill,
							strokeStyle: that.handleConfig.stickStroke,
							lineWidth: that.handleConfig.stickWidth,
							start: {
								x: that.innerCircleConfig.radius,
								y: 0
							},
							end: {
								x: that.outerCircleConfig.radius,
								y: 0
							},
						}, function() {
							that._context.translate(that.centerX, that.centerY);
							that._context.rotate(angle);
						});

						that.renderCircle({
							centerX: that.outerCircleConfig.radius,
							centerY: 0,
							radius: that.handleConfig.ballWidth,
							fill: that.handleConfig.ballFill
						}, 'ball');
					});
					
					/*转动外置手柄*/
					that.addExternalHandel(angle);

				};

				ballPanel.prototype.drawCenterRender = function(contents) {
					var contentStringA = contents.num.toString();
					var contentStringB = contents.text.toString();
					that.save(function() {
						that.renderText({
							content: contentStringA + that.unit,
							fontSize: that.centerRenderConfig.fontSizeNum,
							fontFamily: that.centerRenderConfig.fontFamilyNum,
							fontWeight: that.centerRenderConfig.fontWeightNum,
							fillStyle: that.centerRenderConfig.fill,
							strokeStyle: that.centerRenderConfig.stroke,
							left: that.centerRenderPos.x - 1.6 * that.centerRenderConfig.textLength,
							top: that.centerRenderPos.y + that.centerRenderConfig.textLength - 10
						});
					});

					that.save(function() {
						that.renderText({
							content: contentStringB,
							fontSize: that.centerRenderConfig.fontSizeText,
							fontFamily: that.centerRenderConfig.fontFamilyText,
							fontWeight: that.centerRenderConfig.fontWeightText,
							fillStyle: that.centerRenderConfig.fill,
							strokeStyle: that.centerRenderConfig.stroke,
							left: that.centerRenderPos.x - 1.1 * that.centerRenderConfig.textLength,
							top: that.centerRenderPos.y + that.centerRenderConfig.textLength + 15
						});
					});

				};

				ballPanel.prototype.drawTooltips = function(i) {
					var rotateAngle = 0;
					var rotateDirection = 1;

					/*var adapteFactor = 0;					
					if((i>0.5*Math.PI)&&(i<1.5*Math.PI)) {
						adapteFactor = -35;
					} else {
						adapteFactor = -35;
					}
					console.log(adapteFactor);*/

					if (i > Math.PI) {
						rotateAngle = i - 2 * Math.PI;
					} else if (i > 0.5 * Math.PI) {
						rotateAngle = Math.PI - i;
						rotateDirection = -1;
					}

					that._currentRealPos = {
						x: (that.outerCircleConfig.radius + that.outerCircleConfig.radius * Math.cos(rotateAngle) * rotateDirection) / that.compressFactor,
						y: (that.centerY + that.outerCircleConfig.radius * Math.sin(rotateAngle)) / that.compressFactor
					}

					$.event.trigger("ballPanel:tooltips:position", [{
						pos: that._currentRealPos
					}]);
				}

				ballPanel.prototype.interactHandle = function() {
					var lineA = {
						'x': 0,
						'y': 0
					};
					that._isStart = false;

					that.touchContainer.unbind(that._eventCollection[that.device]['move']).bind(that._eventCollection[that.device]['move'], function(event) {
						event.preventDefault();
						event.stopPropagation();
						if (that.device === 'mobile') {
							event = event.originalEvent.touches[0];
						}
						if (that._isStart) {
							var lineB = {
								'x': event.pageX * (that.compressFactor) - that.centerX - that.canvasPos.x,
								'y': event.pageY * (that.compressFactor) - that.centerY - that.canvasPos.y
							};

							var deltaY = lineB.y - lineA.y;
							var deltaX = lineB.x - lineA.x;
							var targetAngle = Math.atan2(deltaY, deltaX);
							that._currentAngle = targetAngle;

							var normalAngle = that.normalizedAngle(that._currentAngle);

							if (((normalAngle > that.adjustAngle) && (normalAngle < 2 * Math.PI)) || ((normalAngle > 0) && (normalAngle < that.endAngle))) {
								that.currentVal = that.calculateCore(targetAngle);
								$scope.appRuntime.currentVal = that.currentVal;
								that.clear();

								that.drawCircle();
								that.drawDial();
								that.drawHanel(targetAngle);

								if (that.hasCenterRender) {
									that.drawCenterRender({
										num: that.currentVal,
										text: that.defaultModeText
									});
								} else {
									$.event.trigger("ballPanel:data:update", [{
										num: that.currentVal,
										text: that.currentModeText == undefined ? that.defaultModeText : that.currentModeText
									}]);
								}								
							}
						}
					});

					that.touchContainer.unbind(that._eventCollection[that.device]['start']).bind(that._eventCollection[that.device]['start'], function(event) {
						event.preventDefault();
						event.stopPropagation();
						that._isStart = true;
						that._prevVal = that.currentVal;

						$.event.trigger("ballPanel:interact:touching:on", [{}]);
					});

					that.touchContainer.unbind(that._eventCollection[that.device]['end']).bind(that._eventCollection[that.device]['end'], function(event) {
						event.preventDefault();
						event.stopPropagation();
						that._isStart = false;

						if (that._prevVal === that.currentVal) {
							$.event.trigger("ballPanel:interact:value:change:none", [{}]);
						} else {
							$.event.trigger("ballPanel:interact:value:change:has", [{}]);
							$.event.trigger("ballPanel:data:request", [{
								currentVal: that.currentVal
							}]);
						}

						that._prevVal = that.currentVal;

						$.event.trigger("ballPanel:interact:touchend", [{}]);
						setTimeout(function() {
							$.event.trigger("ballPanel:interact:reset", [{}]);
						}, 5000);

						$.event.trigger("ballPanel:interact:touching:off", [{}]);

						/*setTimeout(function() {
							$scope.$apply(function() {
								$scope.appRuntime.touchEventCount += 1;
								$.event.trigger("ballPanel:data:request", [{
									currentVal: that.currentVal
								}]);
							});
						}, 1000);*/
					});

				};

				ballPanel.prototype.disable = function() {
					that.touchContainer.unbind();

					that.touchContainer.unbind(that._eventCollection[that.device]['start']).bind(that._eventCollection[that.device]['start'], function(event) {
						event.preventDefault();
						if ((!that.status) && (!that.pullMenuStatus)) {
							$.event.trigger("ballPanel:status:close", [{}]);
						}
					});
				};

				ballPanel.prototype.calculateCore = function(angle) {
					var value = 0;
					angle = that.normalizedAngle(angle) - that.adjustAngle;
					angle = that.normalizedAngle(angle);

					if (that.hasDecimal) {
						angle = 180 / Math.PI * angle * 2 * 2;
						value = that.dialRange.min + Math.round((angle / that.totalDial) * (that.dialRange.max - that.dialRange.min)) * 0.5;
					} else {
						angle = 180 / Math.PI * angle * 2;
						value = that.dialRange.min + Math.round((angle / that.totalDial) * (that.dialRange.max - that.dialRange.min));
					}
					return value;
				};

				ballPanel.prototype.inverseCalculateCore = function(value) {
					var angle = 0;

					if (value <= that.dialRange.max) {
						angle = (value - that.dialRange.min) / (that.dialRange.max - that.dialRange.min) * Math.PI + that.adjustAngle;
					} else {
						angle = (value - that.dialRange.min) / (that.dialRange.max - that.dialRange.min) * Math.PI + that.adjustAngle;
					}

					//angle = angle > 6.283 ? 6.23 : angle;

					return angle;
				};

				ballPanel.prototype.normalizedAngle = function(angle) {
					var normalAngle = 0;
					if (angle >= 0) {
						normalAngle = angle;
					} else {
						normalAngle = 2 * Math.PI + angle;
					}
					return normalAngle;
				};

				ballPanel.prototype.eventInterface = function() {
					$scope.$on('update::ballPanel', function(event, message) {

						that.currentRealValue = message.tempReal;
						that.currentConfigValue = message.tempConfig;
						that.currentModeText = message.mode;
						that.deviceStatus = message.status;

						if (message.mode === 4) {
							that.currentMode = 'heat';
						} else {
							that.currentMode = 'cold'
						}

						if ((!that._isStart) && (!$scope.appRuntime.isTouchOpenClose)) {
							that.redrawBallPanel(true);
						}

					});

					$(document).bind('pullMenu:redraw', {}, function(event, data) {
						that.redrawBallPanel();
					});

					$(document).bind('pullMenu:open', {}, function(event, data) {
						that.pullMenuStatus = true;
					});

					$(document).bind('pullMenu:close', {}, function(event, data) {
						that.pullMenuStatus = false;
					});

					$scope.$on('ballPanel:active', function() {
						that.status = true;
						that.interactHandle();
					});

					$scope.$on('ballPanel:deactive', function() {
						that.status = false;
						that.disable();
					});

					$scope.$on('ballPanel:change:appearance:disable', function(event, data) {
						
						//alert(data.tempReal+"---off---"+data.current)

						if (data.mode === 4) {
							that.currentMode = 'heat';
						} else {
							that.currentMode = 'cold'
						}
						that.currentRealValue = data.tempReal;
						that.currentConfigValue = data.tempReal;
						that.deviceStatus = data.status;
						
						if(that.currentRealValue < that.controlInterval.down) {
							that.currentConfigValue = that.controlInterval.down;
						}	
						if(that.currentRealValue > that.controlInterval.up) {
							that.currentConfigValue = that.controlInterval.up;
						}

						that.outerCircleConfig.fill = that.deactiveStyle.outerCircleColor;
						that.outerCircleConfig.stroke = that.deactiveStyle.outerCircleColor;
						that.outerCircleConfig.shadowColor = that.deactiveStyle.outerCircleColor;

						that.innerCircleConfig.fill = that.deactiveStyle.innerCircleColor;
						that.innerCircleConfig.shadowColor = that.deactiveStyle.innerCircleColor;

						/*that.dialConfig.alterBelowFill = that.deactiveStyle.dialColor;
						that.dialConfig.alterBelowStroke = that.deactiveStyle.dialColor;
						that.dialConfig.alterOverFill = that.deactiveStyle.dialColor;
						that.dialConfig.alterOverStroke = that.deactiveStyle.dialColor;*/

						that.dialConfig.opacity = that.deactiveStyle.dialOpacity;
						that.handleConfig.opacity = that.deactiveStyle.stickOpacity;

						that.clear();
						that.redrawBallPanel(true);
						that.currentConfigValue = data.current;
					});

					$scope.$on('ballPanel:change:appearance:enable', function(event, data) {

						//alert(data.tempReal+"---on---"+data.current);
						
						if (data.mode === 4) {
							that.currentMode = 'heat';
						} else {
							that.currentMode = 'cold'
						}

						that.currentRealValue = data.tempReal;
						that.currentConfigValue = data.current;
						that.deviceStatus = data.status;
					
						that.outerCircleConfig = that.clone(that._defaultOuterCircleConfig);

						that.innerCircleConfig = that.clone(that._defaultInnerCircleConfig);

						that.dialConfig = that.clone(that._defaultDialConfig);

						that.handleConfig = that.clone(that._defaultHandleConfig);
						
						that.clear();
						that.redrawBallPanel(true);

					});

					$scope.$on('trigger::open::close::animation', function(event, data) {
						that.currentRealValue = data.tempReal;
						that.currentConfigValue = data.tempConfig;
						
						/*运动限制*/
						var realTemp = that.currentRealValue;
						if(that.currentRealValue < that.controlInterval.down) {
							realTemp = that.controlInterval.down;
						}	
						if(that.currentRealValue > that.controlInterval.up) {
							realTemp = that.controlInterval.up;
						}
						
						if (data.status) {
							//alert(that.currentRealValue+" "+that.currentConfigValueCache);
							
							that.outerCircleConfig = that.clone(that._defaultOuterCircleConfig);

							that.innerCircleConfig = that.clone(that._defaultInnerCircleConfig);
	
							that.dialConfig = that.clone(that._defaultDialConfig);
	
							that.handleConfig = that.clone(that._defaultHandleConfig);
							
							/*that.status = true;
							that.interactHandle();*/
							
							$.event.trigger("homePage:apperance:change", [{
								status: true
							}]);
							
							that.animateDrawing(realTemp, that.currentConfigValue, 2, 0.5);
						} else {
							
							that.outerCircleConfig.fill = that.deactiveStyle.outerCircleColor;
							that.outerCircleConfig.stroke = that.deactiveStyle.outerCircleColor;
							that.outerCircleConfig.shadowColor = that.deactiveStyle.outerCircleColor;
	
							that.innerCircleConfig.fill = that.deactiveStyle.innerCircleColor;
							that.innerCircleConfig.shadowColor = that.deactiveStyle.innerCircleColor;
	
							/*that.dialConfig.alterBelowFill = that.deactiveStyle.dialColor;
							that.dialConfig.alterBelowStroke = that.deactiveStyle.dialColor;
							that.dialConfig.alterOverFill = that.deactiveStyle.dialColor;
							that.dialConfig.alterOverStroke = that.deactiveStyle.dialColor;*/
	
							that.dialConfig.opacity = that.deactiveStyle.dialOpacity;
							that.handleConfig.opacity = that.deactiveStyle.stickOpacity;
							
							/*that.status = false;
							that.disable();*/
							
							$.event.trigger("homePage:apperance:change", [{
								status: false
							}]);
														
							that.animateDrawing(that.currentConfigValue, realTemp, 2, 0.5);
						}
					})

				};

				ballPanel.prototype.fadeColorEffect = function(startColor, endColor, currentFrame, totalFrames) {
					startColor = startColor.replace('rgb(', "").replace(')', "").split(',');
					endColor = endColor.replace('rgb(', "").replace(')', "").split(',');

					var currentColor = {
						r: startColor[0] * (1 - currentFrame / totalFrames) + endColor[0] * currentFrame / totalFrames,
						g: startColor[1] * (1 - currentFrame / totalFrames) + endColor[1] * currentFrame / totalFrames,
						b: startColor[2] * (1 - currentFrame / totalFrames) + endColor[2] * currentFrame / totalFrames
					};

					return "rgb(" + currentColor.r.toFixed(0) + "," + currentColor.g.toFixed(0) + "," + currentColor.b.toFixed(0) + ")";
				};

				ballPanel.prototype.animateOpenClose = function(status, currentFrame, totalFrames) {

					if (status) {
						that.dialConfig.opacity = that._defaultDialConfig.opacity;
						that.handleConfig.opacity = that._defaultHandleConfig.opacity;

						that.outerCircleConfig.fill = that.fadeColorEffect(that.outerCircleConfig.fill, that._defaultOuterCircleConfig.fill, currentFrame, totalFrames);;
						that.outerCircleConfig.stroke = that.fadeColorEffect(that.outerCircleConfig.stroke, that._defaultOuterCircleConfig.stroke, currentFrame, totalFrames);

						that.dialConfig.alterBelowFill = that.fadeColorEffect(that.dialConfig.alterBelowFill, that._defaultDialConfig.alterBelowFill, currentFrame, totalFrames);
						that.dialConfig.alterBelowStroke = that.fadeColorEffect(that.dialConfig.alterBelowStroke, that._defaultDialConfig.alterBelowStroke, currentFrame, totalFrames);
						that.dialConfig.alterOverFill = that.fadeColorEffect(that.dialConfig.alterOverFill, that._defaultDialConfig.alterOverFill, currentFrame, totalFrames);
						that.dialConfig.alterOverStroke = that.fadeColorEffect(that.dialConfig.alterOverStroke, that._defaultDialConfig.alterOverStroke, currentFrame, totalFrames);
						that.dialConfig.alterCurrentFill = that.fadeColorEffect(that.dialConfig.alterCurrentFill, that._defaultDialConfig.alterCurrentFill, currentFrame, totalFrames);
						that.dialConfig.alterCurrentStroke = that.fadeColorEffect(that.dialConfig.alterCurrentStroke, that._defaultDialConfig.alterCurrentStroke, currentFrame, totalFrames);

					} else {

						that.outerCircleConfig.fill = that.fadeColorEffect(that.outerCircleConfig.fill, that.deactiveStyle.outerCircleColor, currentFrame, totalFrames);;
						that.outerCircleConfig.stroke = that.fadeColorEffect(that.outerCircleConfig.stroke, that.deactiveStyle.outerCircleColor, currentFrame, totalFrames);
						that.outerCircleConfig.shadowColor = that.fadeColorEffect(that.outerCircleConfig.shadowColor, that.deactiveStyle.outerCircleColor, currentFrame, totalFrames);

						that.dialConfig.alterBelowFill = that.fadeColorEffect(that.dialConfig.alterBelowFill, that.deactiveStyle.dialColor, currentFrame, totalFrames);
						that.dialConfig.alterBelowStroke = that.fadeColorEffect(that.dialConfig.alterBelowStroke, that.deactiveStyle.dialColor, currentFrame, totalFrames);
						that.dialConfig.alterOverFill = that.fadeColorEffect(that.dialConfig.alterOverFill, that.deactiveStyle.dialColor, currentFrame, totalFrames);
						that.dialConfig.alterOverStroke = that.fadeColorEffect(that.dialConfig.alterOverStroke, that.deactiveStyle.dialColor, currentFrame, totalFrames);
						that.dialConfig.alterCurrentFill = that.fadeColorEffect(that.dialConfig.alterCurrentFill, that.deactiveStyle.dialColor, currentFrame, totalFrames);
						that.dialConfig.alterCurrentStroke = that.fadeColorEffect(that.dialConfig.alterCurrentStroke, that.deactiveStyle.dialColor, currentFrame, totalFrames);

						that.dialConfig.opacity = that.deactiveStyle.dialOpacity;
						that.handleConfig.opacity = that.deactiveStyle.stickOpacity;
					}
				};

				ballPanel.prototype.redrawBallPanel = function(clear) {
					if (clear) {
						that.clear();
					}

					/*模式切换时 控制球颜色翻转  制冷：2 制热：4*/
					if (that.deviceStatus) {
						//暂时屏蔽 有待确认和改进
						//that.switchColor(that.currentMode);
					}

					that.initCanvas();

					if (that.hasCenterRender) {
						that.drawCenterRender({
							num: that.currentConfigValue,
							text: that.currentModeText == undefined ? that.defaultModeText : that.currentModeText,
						});
					} else {
						$.event.trigger("ballPanel:data:update", [{
							num: that.currentConfigValue,
							text: that.currentModeText == undefined ? that.defaultModeText : that.currentModeText
						}]);
					}

					that._currentAngle = that.inverseCalculateCore(that.currentConfigValue);
					that.drawDial();
					that._Handle = that.drawHanel(that._currentAngle);													
				};

				ballPanel.prototype.animateDrawing = function(start, end, speed, stepDist) {
					var currentFrame = 0;
					var totalFrames = 10;
					var step = start;
					that.currentConfigValue = start;

					that.redrawBallPanel(true);
					
					var delay = setInterval(function() {
						if (step.toFixed(1) === end.toFixed(1)) {
							clearInterval(delay);
							$scope.$apply(function(){
								$scope.appRuntime.isTouchOpenClose = false;
							});
						}

						if (step === start) {
							that.redrawBallPanel(false);
						} else {
							that.redrawBallPanel(true);
						}
						if (start > end) {
							step -= stepDist;
							//that.animateOpenClose(false, currentFrame, totalFrames);
						} else {
							step += stepDist;
							//that.animateOpenClose(true, currentFrame, totalFrames);
						}

                        if(currentFrame < totalFrames) {
							currentFrame += 1;
						}

						that.currentConfigValue = step;
					}, speed);
				};

				ballPanel.prototype.switchColor = function(mode) {
					if (mode === 'cold') {
						that.dialConfig.alterOverFill = that._defaultDialConfig.alterOverFill;
						that.dialConfig.alterOverStroke = that._defaultDialConfig.alterOverStroke;

						that.dialConfig.alterBelowFill = that._defaultDialConfig.alterBelowFill;
						that.dialConfig.alterBelowStroke = that._defaultDialConfig.alterBelowStroke;

						that.dialConfig.alterOverOpacity = that._defaultDialConfig.alterOverOpacity;
						that.dialConfig.alterBelowOpacity = that._defaultDialConfig.alterBelowOpacity;
					} else if (mode === 'heat') {
						that.dialConfig.alterOverFill = that._defaultDialConfig.alterBelowFill;
						that.dialConfig.alterOverStroke = that._defaultDialConfig.alterBelowStroke;

						that.dialConfig.alterBelowFill = that._defaultDialConfig.alterOverFill;
						that.dialConfig.alterBelowStroke = that._defaultDialConfig.alterOverStroke;

						that.dialConfig.alterOverOpacity = that._defaultDialConfig.alterBelowOpacity;
						that.dialConfig.alterBelowOpacity = that._defaultDialConfig.alterOverOpacity;
					}
				};
				
				ballPanel.prototype.addExternalHandel = function(angle) {
					that.touchContainerWrapper.css({
						transform: "rotate(" + angle*180/Math.PI + "deg)"
					});
				}

				/*扩展功能--呼吸功能*/
				ballPanel.prototype.respiration = function() {
					var outerCircleRadius = that.outerCircleConfig.radius;
					var innerCircleRadius = that.innerCircleConfig.radius;
					var animateCurrentTime = 0;
					var animateMaxtTime = 1000;
					var animateSpeed = 100;
					var moveStep = 20;
					var easeFunc = 'easeOutQuad';
					var animteLoop = setInterval(function() {
						/*ease方案*/
						if (animateCurrentTime < animateMaxtTime) {
							animateCurrentTime += animateSpeed;
							that.outerCircleConfig.radius = that.ease(animateCurrentTime, outerCircleRadius, moveStep, animateMaxtTime, easeFunc);
							that.innerCircleConfig.radius = that.ease(animateCurrentTime, innerCircleRadius, moveStep, animateMaxtTime, easeFunc);
							that.redrawBallPanel(true);
						} else {
							outerCircleRadius += moveStep;
							innerCircleRadius += moveStep;
							moveStep = -moveStep;
							animateCurrentTime = 0;
						}
					}, animateSpeed);

					return animteLoop;
				};

				ballPanel.prototype.ease = function(currentTime, startPoint, moveDist, duration, easeFunc) {
					return $.easing[easeFunc](0, currentTime, startPoint, moveDist, duration);
				};

				/*扩展功能--粒子效果*/
				ballPanel.prototype.animateParticles = function() {
					that.drawParticles();

					var innerRadius = that.particleZoneConfig('in').innerRadius;
					var outerRadius = that.particleZoneConfig('in').outerRadius;

					var step = 1;
					var animateParticlesLoop = setInterval(function() {
						for (var i = 0; i < that._particles.length; i++) {
							var randomPosX = that.randomNum(0, that.canvasWidth);
							var randomPosY = that.randomNum(0, that.canvasHeight);
							var posX = that._particles[i].get('left');
							var posY = that._particles[i].get('top');
							if (that.isVertexInZone(posX, posY, outerRadius) || (!that.isVertexInZone(posX, posY, innerRadius))) {
								that._particles[i].set('left', that._particles[i].get('left') + step);
								that._particles[i].set('top', that._particles[i].get('top') + step);
							} else {
								//i--;
								step -= step;
							}

						}
						//console.log(posX);
						that._canvas.renderAll();
					}, 1000000);

					return animateParticlesLoop;
				};

				ballPanel.prototype.drawParticles = function() {
					that.density = 100;
					var innerRadius = that.particleZoneConfig('in').innerRadius;
					var outerRadius = that.particleZoneConfig('in').outerRadius;

					if (that._particles.length === 0) {
						for (var i = 0; i < that.density; i++) {
							var randomPosX = that.randomNum(0, that.canvasWidth);
							var randomPosY = that.randomNum(0, that.canvasHeight);
							if (that.isVertexInZone(randomPosX, randomPosY, outerRadius) && (!that.isVertexInZone(randomPosX, randomPosY, innerRadius))) {
								var particle = that.drawParticle(randomPosX, randomPosY, 'circle');
								that._particles.push(particle);
							} else {
								i--;
							}
						}
					}
					return that._particles;
				};

				ballPanel.prototype.drawParticle = function(x, y, shapeMode) {
					var particle = {};
					switch (shapeMode) {
						case 'circle':
							particle = new fabric.Circle({
								selectable: false,
								radius: 3,
								fill: '#fff',
								opacity: 0.5,
								left: x,
								top: y,
							});
							that._canvas.add(particle);
							break;
						case 'rect':
							particle = new fabric.Rect({
								width: 10,
								height: 10,
								stroke: '#fff',
								fill: '#fff',
								opacity: 0.5,
								left: x,
								top: y,
								selectable: false
							});
							that._canvas.add(particle);
							break;
						case 'image':
							/*解决方案一  -- 图片动画*/
							/*var snowStateA = 'http://www.wearewebstars.dk/codepen/img/s1.png';
							var snowStateB = 'http://www.wearewebstars.dk/codepen/img/s2.png';
							var snowStateC = 'http://www.wearewebstars.dk/codepen/img/s3.png';
							fabric.Image.fromURL(snowStateC, function(img) {
								that._canvas.add(img);
							}); */
							break;
					}

					return particle;
				};

				ballPanel.prototype.particleZoneConfig = function(state) {
					var zone = {};
					switch (state) {
						case 'in':
							zone = {
								innerRadius: that.outerCircleConfig.radius,
								outerRadius: that.outerCircleConfig.radius + 20
							};
							break;
						case 'out':
							zone = {
								innerRadius: 0,
								outerRadius: that.innerCircleConfig.radius
							};
							break;
					}
					return zone;
				};

				ballPanel.prototype.randomNum = function(start, end) {
					return Math.random() * (end - start) + start;
				};

				ballPanel.prototype.verticesDist = function(x1, y1, x2, y2) {
					return Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
				};

				ballPanel.prototype.isVertexInZone = function(x, y, radius) {
					var dist = that.verticesDist(x, y, that.centerX, that.centerY);
					if (dist <= radius) {
						return true;
					} else {
						return false;
					}
				};

				/*H5 封装函数*/
				ballPanel.prototype.renderCircle = function(params, status) {

					that._context.fillStyle = params.fill;

					if (status == "out") {
						that._context.globalAlpha = params.opacity;
						that._context.strokeStyle = params.stroke;
						that._context.lineWidth = that.outerCircleConfig.radius - that.innerCircleConfig.radius;

						that._context.beginPath();
						that._context.arc(params.centerX, params.centerY, params.radius - that._context.lineWidth * 0.5, that.adjustAngle, that.endAngle, false);
						that._context.stroke();

						that._context.globalAlpha = params.opacity * 0.3;
						that._context.beginPath();
						that._context.arc(params.centerX, params.centerY, params.radius - that._context.lineWidth * 0.5, that.adjustAngle, that.endAngle, true);
						that._context.stroke();
					}

					if (status == "ball") {
						that._context.globalAlpha = params.opacity;
						that._context.beginPath();
						var circleIn = that._context.arc(params.centerX, params.centerY, params.radius, 0, Math.PI * 2, true);
						that._context.closePath();
						that._context.fill();
					}

					return circleIn;
				};

				ballPanel.prototype.renderLine = function(params, func) {
					that._context.fillStyle = params.fillStyle;
					that._context.strokeStyle = params.strokeStyle;
					that._context.lineWidth = params.lineWidth;
					that._context.beginPath();

					func();

					that._context.moveTo(params.start.x, params.start.y);
					that._context.lineTo(params.end.x, params.end.y);

					that._context.closePath();
					that._context.stroke();
					that._context.fill();
				};

				ballPanel.prototype.save = function(func) {
					that._context.save();
					func();
					that._context.restore();
				};

				ballPanel.prototype.clear = function() {
					that._context.clearRect(0, 0, that.canvasWidth, that.canvasHeight);
				};

				ballPanel.prototype.renderText = function(params) {
					that._context.font = params.fontWeight + " " + params.fontSize + "px " + params.fontFamily;
					that._context.fillStyle = params.fillStyle;
					that._context.strokeStyle = params.strokeStyle;
					that._context.fillText(params.content, params.left, params.top);
				};

				/*JS原生封装函数*/
				/*深度复制对象 仅限一层树*/
				ballPanel.prototype.clone = function(oldObj) {
					var clone = {};
					for (var i in oldObj) {
						clone[i] = oldObj[i];
					}
					return clone;
				};
				
				/*数据延迟加载解决方案*/
				if(($scope.appConfig.pageLoadState !== undefined) && ($scope.appConfig.pageLoadState !== 'in')){
						new ballPanel();
				} else {
					setTimeout(function(){
						new ballPanel({current: $scope.deviceStatus.indoorTempInteger, config: $scope.appRuntime.currentConfigTemp, status: $scope.deviceStatus.deviceRunningStatus});
						if(($scope.deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind) || (!$scope.deviceStatus.deviceRunningStatus)) {
							$scope.$broadcast('ballPanel:deactive');
						}
					}, 1000);
				}
				//var respiration = ballPanel.respiration();
				//var animateParticles = ballPanel.animateParticles();

			}
		}
	}
]);