mideaACApp.directive('tagsEdit', ['$compile',
	function($compile) {
		return {
			link: function($scope, element, attrs) {

				(function initJqueryPlugin() {
					//这里可以初始化你需要的jquery插件

					$('#alternateFunc,#hasFunc').sortable({
						revert: true,
						connectWith: "#alternateFunc,#hasFunc"
					});

					/*var currentObj = document.getElementById(attrs.id);
					if (attrs.id === 'hasFunc') {
						if ($scope.appConfig.isMobile) {
							var hammertime = new Hammer(currentObj);
							hammertime.on('press', function(e) {
								//var hasFunc = $(e.target).parent();
								//$(e.target).parent().remove();
								//console.log($('#alternateFunc'));
								//$('#alternateFunc').appendChild(hasFunc.html());
							});
					}*/

				})($);

			}
		}
	}
]);