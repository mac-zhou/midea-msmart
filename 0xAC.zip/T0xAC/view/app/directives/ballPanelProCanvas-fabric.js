mideaACApp.directive('ballPanelProCanvas', ['$compile',
	function($compile) {
		return {
			restrict: 'AE',
			replace: false,
			template: '<canvas id="ball-panel-pro-canvas" width="320" height="300"></canvas>',
			link: function($scope) {
				var that = {};

				function ballPanel() {
					//保存环境变量
					that = this;

					//控件设置
					/*配置参数*/
					that.domId = 'ball-panel-pro';
					that.canvasId = 'ball-panel-pro-canvas';
					that.device = 'pc';
					that.iSHightPerformence = false;
					that.outerCircleConfig = {
						radius: 130,
						fill: '#069eff'
					};
					that.innerCircleConfig = {
						radius: 70,
						fill: '#0686FE'
					};
					that.dialSpacing = 15;
					that.dialConfig = {
						spacing: 15,
						fill: '#ddd',
						stroke: '#ddd',
						opacity: 0.5,
						alterFill: 'red',
						alterStroke: 'red',
						alterOpacity: 0.5
					}
					that.dialRange = {
						'min': 17,
						'max': 30,
						'step': 1
					};
					that.handleConfig = {
						'stickWidth': 3,
						'stickFill': '#fff',
						'stickStroke': '#fff',
						'ballWidth': 4,
						'ballFill': '#fff',
						'ballStroke': '#fff'
					};
					that.centerRenderConfig = {
						fontFamily: 'Microsoft yahei',
						fontSize: '18',
						stroke: '#fff',
						fill: '#fff',
						textLength: 9
					}

					/*推导参数*/
					that.canvasWidth = $('#' + that.canvasId).attr('width');
					that.canvasHeight = $('#' + that.canvasId).attr('height');
					that.centerX = that.canvasWidth / 2;
					that.centerY = that.canvasHeight / 2;
					that.currentVal = 0;
					that.currentPoint = {
						x: that.centerX,
						y: that.centerY
					};
					that.canvasPos = {
						'x': $('#' + that.canvasId).offset().top,
						'y': $('#' + that.canvasId).offset().left
					};
					that.totalDial = 360;
					that.totalDialPI = 2 * Math.PI;
					that.centerRenderPos = {
						'x': that.canvasWidth / 2,
						'y': that.canvasHeight / 2
					};

					/*启动控件*/
					that.init();
				}

				ballPanel.prototype.init = function() {
					console.log('init');

					that._particles = new Array();

					that._dialLines = new Array();
					that.initCanvas();
					that.drawDial();
					that.drawCenterRender(0);
					that._Handle = that.drawHanel();
					that.interactHandle();

					/*呼吸动画*/
					//that.resperation();
				}

				ballPanel.prototype.redrawPanel = function() {
					that._dialLines = new Array();
					that.initCanvas();
					that.drawDial();
				}

				ballPanel.prototype.initCanvas = function() {

					that._canvas = new fabric.Canvas(that.canvasId, {
						selection: false,
					});
					that._outerCircle = new fabric.Circle({
						selectable: false,
						radius: that.outerCircleConfig.radius,
						fill: that.outerCircleConfig.fill,
						left: (that.canvasWidth - that.outerCircleConfig.radius * 2) / 2,
						top: (that.canvasHeight - that.outerCircleConfig.radius * 2) / 2,
					});

					that._innerouterCircle = new fabric.Circle({
						selectable: false,
						radius: that.innerCircleConfig.radius,
						fill: that.innerCircleConfig.fill,
						left: (that.canvasWidth - that.innerCircleConfig.radius * 2) / 2,
						top: (that.canvasHeight - that.innerCircleConfig.radius * 2) / 2,
					});

					that._canvas.add(that._outerCircle, that._innerouterCircle);
				};

				ballPanel.prototype.drawDial = function() {
					var line = {};
					var unitVal = 0;
					if (that._dialLines.length == 0) {
						that._rangeDistance = that.dialRange.max - that.dialRange.min;
						for (var i = 0; i < that.totalDialPI; i += 0.1) {
							var line = that.rotateLine(that.centerX + that.innerCircleConfig.radius + that.dialConfig.spacing, that.centerY, that.centerX + that.outerCircleConfig.radius - that.dialConfig.spacing, that.centerY, i);
							line.set({
								fill: that.dialConfig.fill,
								stroke: that.dialConfig.stroke,
								opacity: that.dialConfig.opacity,
								angle: 0,
								selectable: false
							});
							var lineUnion = {
								obj: line,
								value: that.calculateCore(i * 180 / Math.PI * 2)
							};
							that._dialLines.push(lineUnion);
							that._canvas.add(line);
						}
					} else {
						for (var i = 0; i < that._dialLines.length; i++) {
							unitVal = Math.round(that._rangeDistance * i / 360);
							if (that.currentVal >= that._dialLines[i].value) {
								that._dialLines[i].obj.set('stroke', that.dialConfig.alterStroke);
								that._dialLines[i].obj.set('fill', that.dialConfig.alterFill);
								that._dialLines[i].obj.set('opacity', that.dialConfig.opacity);
							} else {
								that._dialLines[i].obj.set('stroke', that.dialConfig.stroke);
								that._dialLines[i].obj.set('fill', that.dialConfig.fill);
								that._dialLines[i].obj.set('opacity', that.dialConfig.opacity);
							}
						}
					}

				};

				ballPanel.prototype.drawHanel = function() {
					/*var stick = that.line(that.centerX+that.innerCircleConfig.radius, that.centerY, that.centerX + that.outerCircleConfig.radius, that.centerY);
					stick.set({
						fill: that.handleConfig.stickFill,
						stroke: that.handleConfig.stickStroke,
						strokeWidth: that.handleConfig.stickWidth,
						selectable: false
					});*/

					var ball = new fabric.Circle({
						selectable: false,
						radius: that.handleConfig.ballWidth,
						fill: that.handleConfig.ballFill,
						stroke: that.handleConfig.ballStroke,
						left: that.canvasWidth / 2 + that.outerCircleConfig.radius - that.handleConfig.ballWidth / 2,
						top: that.canvasHeight / 2 - that.handleConfig.ballWidth / 2
					});
					that._canvas.add(ball);
					//that._canvas.add(stick);
					var handel = {
						//stick: stick,
						ball: ball
					}
					return handel;
				};

				ballPanel.prototype.drawCenterRender = function(content) {
					if (that._centerRender !== undefined) {
						that._canvas.remove(that._centerRender);
					}
					var contentString = content.toString();
					that._centerRender = new fabric.Text(contentString, {
						left: that.centerRenderPos.x - that.centerRenderConfig.textLength,
						top: that.centerRenderPos.y - that.centerRenderConfig.textLength,
						fontFamily: that.centerRenderConfig.fontFamily,
						fontSize: that.centerRenderConfig.fontSize,
						stroke: that.centerRenderConfig.stroke,
						fill: that.centerRenderConfig.fill
					});
					that._canvas.add(that._centerRender);
				};

				ballPanel.prototype.line = function(x1, y1, x2, y2) {
					var path = new fabric.Path('M ' + x1 + ' ' + y1 + ' L ' + x2 + ' ' + y2);
					return path;
				};

				ballPanel.prototype.interactHandle = function() {
					/*var eventCollection = {
						'pc': {
							'start': 'mousedown',
							'move': 'mousemove',
							'end': 'mouseup'
						},
						'mobile': {
							'start': 'touchstart',
							'move': 'touchmove',
							'end': 'touchend'
						}
					};*/

					var lineA = {
						'x': that.currentPoint.x,
						'y': that.currentPoint.y
					};
					that._isStart = false;

					that._canvas.on('touch:drag', function(event) {
						if (that._isStart) {
							var pointer = that._canvas.getPointer(event.e);
							var lineB = {
								'x': pointer.x,
								'y': pointer.y
							};

							/*夹角算法2*/
							//var cosAngle = (lineA.x * lineB.x + lineA.y * lineB.y) / (Math.sqrt(lineA.x * lineA.x + lineA.y + lineA.y) * Math.sqrt(lineB.x * lineB.x + lineB.y + lineB.y))
							//var moveAngle = Math.acos(Math.abs(cosAngle)) * 360;
							/*var moveAngle = Math.abs(Raphael.angle(that.centerX, that.centerY, that.currentPoint.x, that.currentPoint.y,currentTouchPoint.x, currentTouchPoint.y));
							var moveAngle = moveAngle;*/

							var deltaY = lineB.y - lineA.y;
							var deltaX = lineB.x - lineA.x;
							var targetAngle = Math.atan2(deltaY, deltaX);

							that.currentVal = that.calculateCore(targetAngle * 180 / Math.PI * 2);
							//that.drawDial();
							that.drawCenterRender(that.currentVal);

							/*stick ball animation 方案1*/
							that._canvas.remove(that._Handle.ball);
							/*that._canvas.remove(that._Handle.stick);							
							that._Handle.stick = that.rotateLine(that.centerX + that.innerCircleConfig.radius, that.centerY, that.centerX + that.outerCircleConfig.radius, that.centerY, targetAngle);
							that._Handle.stick.set({
								fill: that.handleConfig.stickFill,
								stroke: that.handleConfig.stickStroke,
								opacity: 1,
								strokeWidth: that.handleConfig.stickWidth,
								selectable: false
							});*/
							that._Handle.ball = that.rotateBall(that.centerX + that.outerCircleConfig.radius, that.centerY, targetAngle);
							that._Handle.ball.set({
								selectable: false,
								radius: that.handleConfig.ballWidth,
								fill: that.handleConfig.ballFill,
								stroke: that.handleConfig.ballStroke,
							});
							that._canvas.add( /*that._Handle.stick, */ that._Handle.ball);

							/*stick ball animation 方案2*/
							/*that._canvas.contextContainer.__proto__.transalte(this.centerX, this.centerY);
							console.log(that._canvas.contextContainer.__proto__);
							that._Handle.stick.translateToOriginPoint(new fabric.Point(that.centerX-100, that.centerY),'left','left');
							that._Handle.stick.rotate(targetAngle / Math.PI * 360);
							that._Handle.stick.set('angle', targetAngle / Math.PI * 180);*/

							if (that.iSHightPerformence) {
								that._canvas.renderAll();
							}

							/*动画效果增强*/
							that.richAnimation();
						}
					});

					that._canvas.on('mouse:down', function(event) {
						that._isStart = true;
					});

					that._canvas.on('mouse:up', function(event) {
						that._isStart = false;
					});

				};

				ballPanel.prototype.calculateCore = function(angle) {
					return that.dialRange.min + Math.round((angle / that.totalDial) * (that.dialRange.max - that.dialRange.min));
				};

				ballPanel.prototype.rotateLine = function(x1, y1, x2, y2, angle) {
					var p1 = fabric.util.rotatePoint(new fabric.Point(x1, y1), new fabric.Point(that.centerX, that.centerY), angle);
					var p2 = fabric.util.rotatePoint(new fabric.Point(x2, y2), new fabric.Point(that.centerX, that.centerY), angle);
					var line = that.line(p1.x, p1.y, p2.x, p2.y);
					return line;
				};

				ballPanel.prototype.rotateBall = function(x, y, angle) {
					var point = fabric.util.rotatePoint(new fabric.Point(x, y), new fabric.Point(that.centerX, that.centerY), angle);
					var ball = new fabric.Circle({
						left: point.x - that.handleConfig.ballWidth / 2,
						top: point.y - that.handleConfig.ballWidth / 2
					});
					return ball;
				};

				ballPanel.prototype.richAnimation = function() {};

				ballPanel.prototype.respiration = function() {
					var outerCircleRadius = that.outerCircleConfig.radius;
					var innerCircleRadius = that.innerCircleConfig.radius;
					var animateCurrentTime = 0;
					var animateMaxtTime = 1000;
					var animateSpeed = 100;
					var moveStep = 20;
					var easeFunc = 'easeInOutBack';
					var animteLoop = setInterval(function() {
						/*ease方案*/
						if (animateCurrentTime < animateMaxtTime) {
							animateCurrentTime += animateSpeed;
							that.outerCircleConfig.radius = that.ease(animateCurrentTime, outerCircleRadius, moveStep, animateMaxtTime, easeFunc);
							that.innerCircleConfig.radius = that.ease(animateCurrentTime, innerCircleRadius, moveStep, animateMaxtTime, easeFunc);
							that.redrawPanel();
						} else {
							outerCircleRadius += moveStep;
							innerCircleRadius += moveStep;
							moveStep = -moveStep;
							animateCurrentTime = 0;
						}
					}, animateSpeed);

					return animteLoop;
				};

				ballPanel.prototype.animateParticles = function() {
					that.drawParticles();

					var innerRadius = that.particleZoneConfig('in').innerRadius;
					var outerRadius = that.particleZoneConfig('in').outerRadius;

					var step = 1;
					var animateParticlesLoop = setInterval(function() {
						for (var i = 0; i < that._particles.length; i++) {
							var randomPosX = that.randomNum(0, that.canvasWidth);
							var randomPosY = that.randomNum(0, that.canvasHeight);
							var posX = that._particles[i].get('left');
							var posY = that._particles[i].get('top');
							if (that.isVertexInZone(posX, posY, outerRadius) || (!that.isVertexInZone(posX, posY, innerRadius))) {
								that._particles[i].set('left', that._particles[i].get('left') + step);
								that._particles[i].set('top', that._particles[i].get('top') + step);
							} else {
								//i--;
								step -= step;
							}

						}
						//console.log(posX);
						that._canvas.renderAll();
					}, 1000000);

					return animateParticlesLoop;
				};

				ballPanel.prototype.drawParticles = function() {
					that.density = 100;
					var innerRadius = that.particleZoneConfig('in').innerRadius;
					var outerRadius = that.particleZoneConfig('in').outerRadius;

					if (that._particles.length === 0) {
						for (var i = 0; i < that.density; i++) {
							var randomPosX = that.randomNum(0, that.canvasWidth);
							var randomPosY = that.randomNum(0, that.canvasHeight);
							if (that.isVertexInZone(randomPosX, randomPosY, outerRadius) && (!that.isVertexInZone(randomPosX, randomPosY, innerRadius))) {
								var particle = that.drawParticle(randomPosX, randomPosY, 'circle');
								that._particles.push(particle);
							} else {
								i--;
							}
						}
					}
					return that._particles;
				};

				ballPanel.prototype.drawParticle = function(x, y, shapeMode) {
					var particle = {};
					switch (shapeMode) {
						case 'circle':
							particle = new fabric.Circle({
								selectable: false,
								radius: 3,
								fill: '#fff',
								opacity: 0.5,
								left: x,
								top: y,
							});
							that._canvas.add(particle);
							break;
						case 'rect':
							particle = new fabric.Rect({
								width: 10,
								height: 10,
								stroke: '#fff',
								fill: '#fff',
								opacity: 0.5,
								left: x,
								top: y,
								selectable: false
							});
							that._canvas.add(particle);
							break;
						case 'image':
							/*解决方案一  -- 图片动画*/
							/*var snowStateA = 'http://www.wearewebstars.dk/codepen/img/s1.png';
							var snowStateB = 'http://www.wearewebstars.dk/codepen/img/s2.png';
							var snowStateC = 'http://www.wearewebstars.dk/codepen/img/s3.png';
							fabric.Image.fromURL(snowStateC, function(img) {
								that._canvas.add(img);
							}); */
							break;
					}

					return particle;
				};

				ballPanel.prototype.particleZoneConfig = function(state) {
					var zone = {};
					switch (state) {
						case 'in':
							zone = {
								innerRadius: that.outerCircleConfig.radius,
								outerRadius: that.outerCircleConfig.radius + 20
							};
							break;
						case 'out':
							zone = {
								innerRadius: 0,
								outerRadius: that.innerCircleConfig.radius
							};
							break;
					}
					return zone;
				};

				ballPanel.prototype.randomNum = function(start, end) {
					return Math.random() * (end - start) + start;
				};

				ballPanel.prototype.verticesDist = function(x1, y1, x2, y2) {
					return Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
				};

				ballPanel.prototype.isVertexInZone = function(x, y, radius) {
					var dist = that.verticesDist(x, y, that.centerX, that.centerY);
					if (dist <= radius) {
						return true;
					} else {
						return false;
					}
				};

				ballPanel.prototype.ease = function(currentTime, startPoint, moveDist, duration, easeFunc) {
					return fabric['util']['ease'][easeFunc](currentTime, startPoint, moveDist, duration);
				};

				var ballPanel = new ballPanel();
				//var respiration = ballPanel.respiration();
				//var animateParticles = ballPanel.animateParticles();
			}
		}
	}
]);