mideaACApp.directive('uiToggleSwitch', ['$compile',
	function($compile) {
		return {
			restrict: 'AE',
			replace: false,
			templateUrl: 'view/app/partials/helpers/uiToggleSwitch.html',
			link: function($scope, element, attrs) {

				var that = {};

				function uiToggleSwitch() {
					that = this;
					
					that.domContainer = $('.mui-switch');
					that.device = $scope.appConfig.isMobile ? 'mobile' : 'pc';
					that.theme = {
						off: '.mui-switch',
						on: 'mui-active',
						dragging: 'mui-dragging'
					};
					that.currentStatus = false;
					
					//组件泛化
					that.componentId = attrs.id !== undefined ? attrs.id+"::" : ""; 				
					that.uiToggleSwitchId = attrs.id !== undefined ? "#"+attrs.id : "";
					
					that._eventCollection = {
						'pc': {
							'start': 'mousedown',
							'move': 'mousemove',
							'end': 'mouseup'
						},
						'mobile': {
							'start': 'touchstart',
							'move': 'touchmove',
							'end': 'touchend'
						}
					};
					
					that.init();
				}

				uiToggleSwitch.prototype.init = function() {
					setTimeout(function(){
						//组件泛化
						that.domContainer = $(that.uiToggleSwitchId + " .mui-switch");
						
						that.componentActions();
						that.bindData();
						that.eventInterface();
					}, 10);				
				}
				
				uiToggleSwitch.prototype.componentActions = function() {
					that.domContainer.unbind(that._eventCollection[that.device]['start']).bind(that._eventCollection[that.device]['start'], function() {
						that.domContainer.addClass(that.theme.dragging);
					});
					that.domContainer.unbind(that._eventCollection[that.device]['end']).bind(that._eventCollection[that.device]['end'], function(event) {
						if (!that.domContainer.hasClass(that.theme.on)) {
							that.domContainer.addClass(that.theme.on).removeClass(that.theme.dragging);
							that.currentStatus = true;
						} else {
							that.domContainer.removeClass(that.theme.on).removeClass(that.theme.dragging);
							that.currentStatus = false;
						}
						$.event.trigger(that.componentId+"update::toggle::switch", [{
							currentVal: that.currentStatus
						}]);
					});
				}
				
				uiToggleSwitch.prototype.bindData = function() {					
					if(that.currentStatus) {
						that.domContainer.addClass(that.theme.on).removeClass(that.theme.dragging);
					} else {
						that.domContainer.removeClass(that.theme.on).removeClass(that.theme.dragging);						
					}
				}
				
				uiToggleSwitch.prototype.eventInterface = function() {
					$scope.$on(that.componentId+'init::toggle::switch',function(event, data){
						that.currentStatus = data.currentVal;
						if(that.currentStatus) {
							that.domContainer.addClass(that.theme.on).removeClass(that.theme.dragging);
						} else {
							that.domContainer.removeClass(that.theme.on).removeClass(that.theme.dragging);						
						}
					});
				}
				
				var uts = new uiToggleSwitch();

			}
		}
	}
]);