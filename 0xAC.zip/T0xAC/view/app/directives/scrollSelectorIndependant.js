mideaACApp.directive('scrollSelector', ['$compile',
	function($compile) {
		return {
			restrict: 'AE',
			replace: false,
			templateUrl: 'view/app/partials/helpers/scrollSelector.html',
			link: function($scope, ele, attrs) {
				/*声明和定义组件类*/
				var that = {};

				/*插件模式*/
				var option = attrs.option !== undefined ? attrs.option : 'single';
				var pos = attrs.pos !== undefined ? attrs.pos : 'left';
				var defaultActiveItem = attrs.active;

				function scrollDateSelector(params) {
					that = this;
					that.params = params;
					that.listHeight = params.listHeight !== undefined ? params.listHeight : 250;
					that.numItems = params.numItems !== undefined ? params.numItems : 5;
					that.itemHeight = that.listHeight / that.numItems;
					that.numMarginItem = params.numMarginItem !== undefined ? params.numMarginItem : 2;
					that.currentActiveIndex = that.params.currentActiveItem;
					that.domQuery = params.domQuery !== undefined ? params.domQuery : '.scroll-date-selector .time-list ul';
					that.flipCenterTop = params.flipCenterTop !== undefined ? params.flipCenterTop : '63';

					if (params.listHeight !== undefined) {
						$(that.domQuery).parent().css({
							height: params.listHeight
						});
					}

					if (params.flipCenterTop !== undefined) {
						$(that.domQuery).parent().parent().find('.flip-center').css({
							top: params.flipCenterTop + 'px'
						});
					}

					that.init();
				};

				/*组件初始化*/
				scrollDateSelector.prototype.init = function() {

					that.setActiveItem(that.currentActiveIndex);

					that._scrollContainer = $(that.domQuery).pep({
						axis: "y",
						easeDuration: 500,
						useCSSTranslation: false,
						startPos: that.setCurrentPos(that.params.currentActiveItem),
						drag: function(ev, obj) {
							that.setEffect(ev, obj);
						},
						stop: function(ev, obj) {
							that.outOfBounds(ev, obj);
							that.setEffect(ev, obj);
						},
						rest: function(ev, obj) {
							that.outOfBounds(ev, obj);
							that.itemAlignement(ev, obj);
						}
					});
					that.handleEvent();
				};

				/*设置当前活动项的坐标*/
				scrollDateSelector.prototype.setCurrentPos = function(itemIndex) {
					var pos = {};
					if (itemIndex < that.numMarginItem) {
						itemIndex = itemIndex === 0 ? that.numMarginItem : itemIndex;
						var pos = {
							'left': 0,
							'top': that.itemHeight * (itemIndex)
						}
					} else {
						var pos = {
							'left': 0,
							'top': -that.itemHeight * (itemIndex - that.numMarginItem)
						}
					}
					return pos;
				};

				/*激活当前活动项*/
				scrollDateSelector.prototype.setActiveItem = function(index) {
					setTimeout(function() {
						$(that.domQuery + " li:eq(" + index + ")").removeClass('list-item-deactive').addClass('list-item-active');
						$(that.domQuery + " li:not(:eq(" + index + "))").removeClass('list-item-active').addClass('list-item-deactive');
					}, 100);
				}

				/*用于边界检测*/
				scrollDateSelector.prototype.outOfBounds = function(ev, obj) {
					/*
					 * A obj.$el.outerHeight() 子容器的高度
					 * B obj.$el.parent().outerHeight() 父容器的高度
					 * A>B and if pos = A-B then has collision
					 */
					var currentItemMargin = that.numMarginItem * that.itemHeight;

					if (-obj.$el.position().top > (obj.$el.outerHeight() - obj.$el.parent().outerHeight() + currentItemMargin)) {
						obj.$el.css({
							top: -obj.$el.outerHeight() + obj.$el.parent().outerHeight() - currentItemMargin
						})
					}

					if (obj.$el.position().top > currentItemMargin) {
						setTimeout(function() {
							obj.$el.css({
								top: currentItemMargin
							});
						}, 0);
						that.setActiveItem(0);
					}

				};

				/*用于平滑对齐*/
				scrollDateSelector.prototype.itemAlignement = function(ev, obj) {
					var delay = 500;
					setTimeout(function() {
						obj.$el.css({
							top: -Math.round((-obj.$el.position().top) / that.itemHeight) * that.itemHeight
						});
						that.setEffect(ev, obj);
					}, delay);

					setTimeout(function() {
						that.handleEvent();
					}, delay + 1);
				};

				/*用于设置运动过程中list项目的效果*/
				scrollDateSelector.prototype.setEffect = function(ev, obj) {
					that.currentActiveIndex = that.calculateCurrentActiveIndex(obj);
					that.setActiveItem(that.currentActiveIndex);
				};

				/*获得当前激活的坐标*/
				scrollDateSelector.prototype.calculateCurrentActiveIndex = function(obj) {
					var moveDistance = Math.round((-obj.$el.position().top) / that.itemHeight);
					var currentActiveIndex = moveDistance + that.numMarginItem;
					return currentActiveIndex;
				};

				/*用于进行数据交互*/
				scrollDateSelector.prototype.handleEvent = function() {
					var currentContainer = $(that.domQuery + ' li');
					//setTimeout(function() {
					currentContainer.each(function() {
						if ($(this).hasClass('list-item-active')) {
							if (option === 'single') {
								$.event.trigger("update:scrollSelector", [{
									currentVal: $(this).attr('data-container')
								}]);
							} else {
								if (pos === 'left') {
									$.event.trigger("update:scrollSelector", {
										currentVal: {
											left: $(this).attr('data-container'),
											index: that.currentActiveIndex
										}
									});
								}

								if (pos === 'right') {
									$.event.trigger("update:scrollSelector", {
										currentVal: {
											right: $(this).attr('data-container'),
											index: that.currentActiveIndex
										}
									});
								}
							}
						}
					});
					//}, 1);

					/*持续渲染活动项*/
					$scope.$on('show:modal', function() {
						that.setActiveItem(that.currentActiveIndex);
					});

					/*处理约束*/
					that.initModeContraint();
				};

				/*用于设定mutiple模式下条件约束*/
				scrollDateSelector.prototype.initModeContraint = function() {
					if (option == 'mutiple') {
						$scope.$on('reachContraint::scrollSelector', function(event, data) {
							console.log('reach ' + data.adapteIndex);
						});
					}
				};

				/*组件模式分类处理*/
				if (option == 'single') {
					var sdSelector = new scrollDateSelector({
						listHeight: 250,
						numItems: 5,
						numMarginItem: 2,
						flipCenterTop: -123,
						currentActiveItem: defaultActiveItem !== undefined ? defaultActiveItem : 0,
						domQuery: '.scroll-selector .data-list ul'
					});
				} else if (option == 'mutiple') {
					var sdSelector = new scrollDateSelector({
						listHeight: 250,
						numItems: 5,
						numMarginItem: 2,
						flipCenterTop: -123,
						currentActiveItem: defaultActiveItem !== undefined ? defaultActiveItem : 0,
						domQuery: '.' + pos + ' .scroll-selector .data-list ul'
					});

				}

			}
		}
	}
]);