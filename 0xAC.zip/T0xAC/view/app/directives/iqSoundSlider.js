mideaACApp.directive('iqSoundPlayerSliderControl', ['$compile',
	function($compile) {
		return {
			restrict: 'AE',
			replace: false,
			templateUrl: 'view/app/partials/helpers/iqSoundPlayerSliderControl.html',
			link: function($scope, element, attrs) {
				console.log(element);
				var that = {};

				function slideControl() {
					that = this;
					/*配置参数*/
					that.container = $(".iq-sound-control-slider");

					/*推导参数*/
//					that._preValue = $scope.deviceStatus.windSpeedValue;
//					that._curValue = $scope.deviceStatus.windSpeedValue;
                    that.isInteract = false;
					that.init();
				}

				slideControl.prototype.init = function() {
					console.log('init slider control');

					that.container.slider({
						animate: "slow",
						range: "min",
						min: 0,
						max: 5,
						step: 1,
						change: function(event, ui) {
							//console.log(ui.value);	
						if(that.isInteract) {
                         $.event.trigger("slider:control:for:soundValue:update", [{
                         current: that._curValue
                         }]);
                         that.isInteract = false;
                         } 		
						},
						slide: function(event, ui) {
							$scope.$apply(function() {
//								$scope.deviceStatus.windSpeedValue = ui.value;
							})
						},
						start: function(event, ui) {
							that.isInteract = true;
							that._preValue = ui.value;
						},
						stop: function(event, ui) {
							that._curValue = ui.value;
							
//							if (that._preValue !== that._curValue) {
//								$.event.trigger("slider:control:for:soundValue:update", [{
//									current: that._curValue
//								}]);
//							}
						}
					});

					that.dataBinding($scope.acController.dataManager.getVolumeState().manualAdjustment);
					that.eventInterface();
				}

				slideControl.prototype.eventInterface = function() {										
					$scope.$on("slider:control:for:soundValue:init", function(event,data){
						that.container.slider("value", data.current);
					});
					
					$scope.$on("slider:control:for:soundValue:disable", function(event,data){
						that.container.slider( "disable");
					});
					
					$scope.$on("slider:control:for:soundValue:enable", function(event,data){
						that.container.slider( "enable");
					});
					
				}

				slideControl.prototype.dataBinding = function(value) {
					var currentValue = value !== $scope.appRuntime.defaultPlaceholder ? value : 0;
					that.container.slider("value", currentValue);
					
					$scope.$watch("deviceVolumeStatus.manualAdjustment", function(news,olds){
						if(news !== olds) {
							that.container.slider("value", news);
							/*if(news > 100){
								$scope.$broadcast('init::toggle::switch',{'currentVal': true});
								that.container.slider( "disable");
							} else {
								$scope.$broadcast('init::toggle::switch',{'currentVal': false});
							}*/
						}
					});
				}

				var sc = new slideControl();


			}
		}
	}
]);