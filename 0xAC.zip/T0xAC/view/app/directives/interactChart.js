mideaACApp.directive('interactChart', ['$compile',
    function ($compile) {
        return {
            templateUrl: 'view/app/partials/helpers/interactChart.html',
            link: function ($scope, element, attrs) {

                var that = {};

                function interactChart() {
                    that = this;

                    /*配置参数*/
                    that.canvasId = 'interact-chart';
                    that.rangeX = [0, 10];
                    that.rangeY = [0, 30];
                    that.yStep = 5;
                    that.xStep = 2;
                    that.device = $scope.appConfig.isMobile ? 'mobile' : 'pc';
                    that.iSHightPerformence = $scope.appConfig.isHpDevice;
                    that.compressFactor = $scope.appConfig.isHpDevice ? 6 : 3;
                    that.isInteractable = attrs.interact == undefined ? true : false;
                    that.initData = attrs.sets;
                    that.chartConfig = {
                        left: 0 * that.compressFactor,
                        top: 30 * that.compressFactor,
                        width: $('#' + that.canvasId).width() * that.compressFactor * (1 - 0.02),
                        height: $('#' + that.canvasId).height() * that.compressFactor,
                        offset: $('#' + that.canvasId).height() / 6 * that.compressFactor,
                        paddingBottom: 5 * that.compressFactor,
                        paddingRight: 0.02,
                        lineHeight: 0 * that.compressFactor,
                        shadeFill: "rgba(248,147,30, 0.5)",
                        bgFill: "#fef4e8"
                    };
                    that.chartAxisY = {
                        fontSize: 10 * that.compressFactor,
                        fontWeight: 20 * that.compressFactor,
                        fontFamily: 'Microsoft yahei',
                        fontFill: "#f8931e",
                        fontStroke: "#f8931e",
                        offset: 10 * that.compressFactor,
                        lineFill: "#f8931e",
                        lineStroke: "#f8931e",
                        lineHeight: 0.5 * that.compressFactor,
                        opacity: 0.5
                    };
                    that.chartButton = {
                        width: 5 * that.compressFactor,
                        fill: "#fff",
                        stroke: "#f8931e",
                        lineWidth: 2 * that.compressFactor,
                        touchOffset: 20 * that.compressFactor
                    };
                    that.touchContainer = $("#" + that.canvasId);
                    that.values = [30, 17, 23, 22, 25, 21, 18, 29, 21];
                    that.chartRangePos = {
                        start: 0,
                        end: that.chartConfig.height
                    };
                    that._rangeMapValue = [
                        20, 25, 30
                    ];
                    that._rangeMapPos = [
                        (that.chartRangePos.end - that.chartRangePos.start) * 1 / 6, (that.chartRangePos.end - that.chartRangePos.start) * 3 / 6, (that.chartRangePos.end - that.chartRangePos.start) * 5 / 6,
                    ];

                    /*推导参数*/
                    $('#' + that.canvasId)[0].width = $('#' + that.canvasId).width() * that.compressFactor;
                    $('#' + that.canvasId)[0].height = $('#' + that.canvasId).height() * that.compressFactor;
                    that.canvasWidth = $('#' + that.canvasId).attr('width');
                    that.canvasHeight = $('#' + that.canvasId).attr('height');
                    that.centerX = that.canvasWidth / 2;
                    that.centerY = that.canvasHeight / 2;
                    that._eventCollection = {
                        'pc': {
                            'start': 'mousedown',
                            'move': 'mousemove',
                            'end': 'mouseup'
                        },
                        'mobile': {
                            'start': 'touchstart',
                            'move': 'touchmove',
                            'end': 'touchend'
                        }
                    };
                    that._isStart = false;
                    that._prevPos = {
                        x: 0,
                        y: 0
                    };
                    that._buttons = [];
                    that.canvasPos = {
                        'x': $('#' + that.canvasId).offset().left * that.compressFactor,
                        'y': $('#' + that.canvasId).offset().top * that.compressFactor
                    };

                    /*init*/
                    //setTimeout(function () {
                    that.init();
                    //}, 1000);
                }

                interactChart.prototype.init = function () {
                    that.bindChartData();

                    that._canvas = document.getElementById(that.canvasId);
                    that._context = that._canvas.getContext("2d");
                    var sleepData = new Array();
                    sleepData = that.initData.split(",");
                    for (var i = 0; i < sleepData.length; i++) {
                        sleepData[i] = sleepData[i].replace("\"", "").replace("\"", "");
                    }

                    sleepData[0] = sleepData[0].substring(1, 3);
                    sleepData[sleepData.length - 1] = sleepData[sleepData.length - 1].substring(0, 2);
                    if (that.initData.length !== 0) {
                        that.values = sleepData;
//						alert(that.values);
                    }

//					if($scope.appCache.pullMenuData.length !== 0) {
//						that.values = $scope.appCache.pullMenuData;
//					}

                    /*普通加载*/
                    that.redraw();
                };

                interactChart.prototype.animateRedraw = function (time) {
                    var animateValue = [0, 0, 0, 0, 0, 0, 0, 0, 0];
                    var numFrame = 0;
                    that._setValues = that.values;

                    var delay = setInterval(function () {

                        for (var i = 0; i < that.values.length; i++) {
                            if (animateValue[i] < that._setValues[i]) {
                                animateValue[i] += 1;
                            }
                        }
                        that.values = animateValue;

                        that.clear();
                        that.redraw();

                        if (numFrame > that.rangeY[1]) {
                            clearInterval(delay);
                        } else {
                            numFrame++;
                        }

                    }, time);
                };

                interactChart.prototype.redraw = function () {

                    //that.clear();
                    that.drawBackGround();
                    that.drawAxis();
                    that.drawPath();

                    if (that.isInteractable) {
                        that.interaction();
                    }
//					that.interaction();
                    if (navigator.userAgent.toLowerCase().indexOf('android') > -1) {
                        that._canvas.style.display = "";
                    }
                };

                interactChart.prototype.interaction = function () {
                    var currentVal = 0;
                    var zone = 0;

                    that.touchContainer.unbind(that._eventCollection[that.device]['start']).bind(that._eventCollection[that.device]['start'], function (event) {
                        event.preventDefault();
                        if (that.device === 'mobile') {
                            event = event.originalEvent.touches[0];
                        }

                        that._isStart = true;

                        that._prevPos = {
                            x: event.pageX,
                            y: event.pageY
                        }
                    });

                    that.touchContainer.unbind(that._eventCollection[that.device]['move']).bind(that._eventCollection[that.device]['move'], function (event) {
                        event.preventDefault();
                        if (that.device === 'mobile') {
                            event = event.originalEvent.touches[0];
                        }

                        if (that._isStart) {
                            that._moveDist = {
                                x: event.pageX - that._prevPos.x,
                                y: event.pageY - that._prevPos.y
                            }
                            zone = that.getTouchZone(that._prevPos.x);
                            currentVal = that.values[zone];
                            currentVal -= that._moveDist.y * that.compressFactor / (that.chartConfig.height);
                            if ((currentVal >= 17) && (currentVal <= 30) && (zone !== 0)) {
                                currentVal = currentVal.toFixed(1);
                                that.values[zone] = currentVal;
                                if (navigator.userAgent.toLowerCase().indexOf('android') > -1) {
                                    that._canvas.style.display = "none";
                                }
                                that.clear();
                                that.redraw();
                            }
                        }
                    });

                    that.touchContainer.unbind(that._eventCollection[that.device]['end']).bind(that._eventCollection[that.device]['end'], function (event) {
                        event.preventDefault();
                        that._isStart = false;

                        that.handleEvent(that.values);
                        console.log(that.values);
                    });
                };

                interactChart.prototype.drawPath = function () {
                    var countX = that.rangeX[1] / that.xStep;
                    var countY = that.rangeY[1] / that.yStep;
                    var currentDial = {
                        x: 0,
                        y: 0
                    };
                    var axisStep = {
                        x: that.chartConfig.width / (that.values.length - 1),
                        y: that.chartConfig.height / countY
                    };
                    var currentPoints = [];
                    that._buttons = [];

                    that.save(function () {
                        for (var i = 0; i <= that.values.length; i++) {
                            currentPointStart = {
                                x: currentDial.x,
                                y: that.translate(that.values[i], axisStep.y) - that.chartConfig.paddingBottom
                            };

                            currentPointEnd = {
                                x: currentDial.x + axisStep.x,
                                y: that.translate(that.values[i + 1], axisStep.y) - that.chartConfig.paddingBottom
                            };

                            that._buttons.push(currentPointEnd);

                            if (i < that.values.length - 1) {
                                /*方案1 阴影绘制  -- 一次性绘制*/
                                that.renderLine({
                                    fillStyle: that.chartAxisY.lineFill,
                                    strokeStyle: that.chartAxisY.lineStroke,
                                    lineWidth: that.chartButton.lineWidth,
                                    start: {
                                        x: currentPointStart.x,
                                        y: currentPointStart.y
                                    },
                                    end: {
                                        x: currentPointEnd.x,
                                        y: currentPointEnd.y
                                    }
                                }, function () {
                                });

                                /*阴影绘制  -- 缓存点*/
                                currentPoints.push({
                                    start: {
                                        x: currentPointStart.x,
                                        y: currentPointStart.y
                                    },
                                    end: {
                                        x: currentPointEnd.x,
                                        y: currentPointEnd.y
                                    }
                                });
                            }
                            currentDial.x += axisStep.x;
                        }
                    });

                    that.save(function () {
                        /*阴影绘制  -- 一次性绘图*/
                        that.rendershade({
                            fillStyle: that.chartConfig.shadeFill,
                            strokeStyle: that.chartAxisY.lineStroke,
                            lineWidth: that.chartConfig.lineHeight,
                            points: currentPoints
                        });

                        /*圆球绘制*/
                        currentDial = {
                            x: 0,
                            y: 0
                        };

                        for (var i = 0; i < that.values.length; i++) {
                            currentPointStart = {
                                x: currentDial.x,
                                y: that.translate(that.values[i], axisStep.y) - that.chartConfig.paddingBottom
                            };

                            currentPointEnd = {
                                x: currentDial.x + axisStep.x,
                                y: that.translate(that.values[i + 1], axisStep.y) - that.chartConfig.paddingBottom
                            };

                            that.renderCircle({
                                centerX: currentPointEnd.x,
                                centerY: currentPointEnd.y,
                                radius: that.chartButton.width,
                                fill: that.chartButton.fill,
                                stroke: that.chartButton.stroke,
                                lineWidth: that.chartButton.lineWidth
                            });

                            currentDial.x += axisStep.x;
                        }
                    });

                };

                interactChart.prototype.drawAxis = function () {
                    /*绘制静态坐标系*/
                    var countX = that.rangeX[1] / that.xStep;
                    var countY = that.rangeY[1] / that.yStep;

                    var rightBoundary = that.chartConfig.width;
                    var currentDial = 0;
                    var axisStep = that.chartConfig.height / countY;

                    // 适配横坐标间距
                    var ulWidth = $('.interact-chart-axis').width(),
                        liPadding = (ulWidth - 17 * 4) / 4;
                    $('.interact-chart-axis li:not(:last-child)').css('padding-right', liPadding);

                    that.save(function () {
                        for (var i = 1; i < countY; i++) {
                            currentDial += axisStep;

                            that.renderLineDashed({
                                fillStyle: that.chartAxisY.lineFill,
                                strokeStyle: that.chartAxisY.lineStroke,
                                lineWidth: that.chartAxisY.lineHeight,
                                opacity: that.chartAxisY.opacity,
                                start: {
                                    x: that.chartConfig.left,
                                    y: that.canvasHeight - currentDial - that.chartConfig.paddingBottom
                                },
                                end: {
                                    x: rightBoundary,
                                    y: that.canvasHeight - currentDial - that.chartConfig.paddingBottom
                                }
                            }, function () {
                            });

                            if ((i !== 2) && (i !== 4)) {
                                var dialValue = 0;
                                switch (i) {
                                    case 1:
                                        dialValue = '20°';
                                        break;
                                    case 3:
                                        dialValue = '25°';
                                        break;
                                    case 5:
                                        dialValue = '30°';
                                        break;
                                }

                                that.renderText({
                                    content: dialValue,
                                    fontSize: that.chartAxisY.fontSize,
                                    fontFamily: that.chartAxisY.fontFamily,
                                    fontWeight: that.chartAxisY.fontWeight,
                                    fillStyle: that.chartAxisY.fontFill,
                                    strokeStyle: that.chartAxisY.fontStroke,
                                    left: that.chartConfig.left,
                                    top: that.canvasHeight - currentDial + that.chartAxisY.offset - that.chartConfig.paddingBottom
                                });
                            }
                        }
                    });

                };

                interactChart.prototype.drawBackGround = function () {
                    that.save(function () {
                        that._context.rect(0, that.chartConfig.top - 5, that.chartConfig.width, that.chartConfig.height);
                        that._context.fillStyle = that.chartConfig.bgFill;
                        that._context.fill();
                    });
                };

                interactChart.prototype.canvasCompress = function (value) {
                    return value * that.compressFactor;
                };

                interactChart.prototype.getTouchZone = function (value) {
                    var index = 0;
                    value = that.canvasCompress(value) + that.canvasPos.x;

                    //console.log("--------------------------------------");
                    for (var i = 0; i < that._buttons.length; i++) {
                        //console.log("dial:"+ that._buttons[i].x + " current:" + value);
                        if ((value >= that._buttons[i].x) && (value <= (that._buttons[i + 1].x) + that.chartButton.touchOffset)) {
                            index = i + 1;
                            break;
                        }
                    }

                    return index;
                };

                interactChart.prototype.update = function (i, d) {
                };

                interactChart.prototype.translate = function (value, chartOffset) {
                    var axisY = 0;
                    var startValue = 0;

                    if ((value > that._rangeMapValue[1]) && (value <= that._rangeMapValue[2])) {
                        axisY = (that.chartRangePos.end - that._rangeMapPos[1]) - ((value - that._rangeMapValue[1]) / 5) * chartOffset * 2;
                    } else if ((value > that._rangeMapValue[0]) && (value <= that._rangeMapValue[1])) {
                        axisY = (that.chartRangePos.end - that._rangeMapPos[0]) - ((value - that._rangeMapValue[0]) / 5) * chartOffset * 2;
                    } else if (value <= that._rangeMapValue[0]) {
                        axisY = that.chartRangePos.end - ((value - 17) / 3) * chartOffset;
                    }

                    return axisY;
                };

                interactChart.prototype.handleEvent = function (data) {
                    $.event.trigger("interactChart:data:update", [{
                        'operate': 'update',
                        'currentVal': data
                    }]);
                };

                interactChart.prototype.bindChartData = function () {
                    // $scope.$on('init:interactChart', function(event, data) {
                    // 	alert("init:interactChart");
                    // 	that.values = data.current;
                    // 	//that.clear();
                    // 	//that.redraw();
                    // 	that.animateRedraw(30);
                    // });

                    $(document).unbind('init:interactChart').bind('init:interactChart', {}, function (event, data) {
                        that.values = data.current;
                        that.clear();
                        that.redraw();
                        // that.animateRedraw(30);
                    });
                };

                /*H5 封装函数*/
                interactChart.prototype.renderCircle = function (params) {
                    that._context.fillStyle = params.fill;
                    that._context.globalAlpha = params.opacity;
                    that._context.lineWidth = params.lineWidth;
                    that._context.beginPath();
                    var circleIn = that._context.arc(params.centerX, params.centerY, params.radius, 0, Math.PI * 2, true);
                    that._context.closePath();
                    that._context.fill();
                    that._context.stroke();

                    return circleIn;
                };

                interactChart.prototype.renderLine = function (params, func) {
                    that._context.globalAlpha = params.opacity;
                    that._context.fillStyle = params.fillStyle;
                    that._context.strokeStyle = params.strokeStyle;
                    that._context.lineWidth = params.lineWidth;
                    that._context.beginPath();

                    that._context.moveTo(params.start.x, params.start.y);
                    that._context.lineTo(params.end.x, params.end.y);

                    func();

                    that._context.closePath();
                    that._context.stroke();
                    that._context.fill();
                };

                interactChart.prototype.renderLineDashed = function (params, func) {
                    that._context.globalAlpha = params.opacity;
                    that._context.fillStyle = params.fillStyle;
                    that._context.strokeStyle = params.strokeStyle;
                    that._context.lineWidth = params.lineWidth;
                    that._context.beginPath();

                    that._context.dashedLine(params.start.x, params.start.y, params.end.x, params.end.y, 4);

                    func();

                    that._context.closePath();
                    that._context.stroke();
                    that._context.fill();
                };

                interactChart.prototype.rendershade = function (params) {

                    that._context.fillStyle = params.fillStyle;
                    that._context.strokeStyle = params.strokeStyle;
                    that._context.lineWidth = params.lineWidth;
                    that._context.beginPath();

                    for (var i = 0; i < params.points.length; i++) {
                        if (i === 0) {
                            that._context.moveTo(params.points[i].start.x, params.points[i].start.y);
                        }
                        that._context.lineTo(params.points[i].end.x, params.points[i].end.y);
                    }

                    that._context.lineTo(params.points[params.points.length - 1].end.x, that.chartConfig.height);
                    that._context.lineTo(params.points[0].start.x, that.chartConfig.height);
                    that._context.lineTo(params.points[0].start.x, params.points[0].start.y);

                    that._context.closePath();
                    that._context.stroke();
                    that._context.fill();

                };

                interactChart.prototype.save = function (func) {
                    that._context.save();
                    func();
                    that._context.restore();
                };

                interactChart.prototype.clear = function () {
                    that._context.clearRect(0, 0, that.canvasWidth, that.canvasHeight);
                };

                interactChart.prototype.renderText = function (params) {
                    that._context.globalAlpha = 1;
                    that._context.font = params.fontSize + "px " + params.fontFamily + " ";
                    that._context.fillStyle = params.fillStyle;
                    that._context.strokeStyle = params.strokeStyle;
                    that._context.fillText(params.content, params.left, params.top);
                };

                /*prototype扩展画布底层*/
                CanvasRenderingContext2D.prototype.dashedLine = function (x1, y1, x2, y2, dashLen) {
                    if (dashLen == undefined) dashLen = 2;
                    this.moveTo(x1, y1);

                    var dX = x2 - x1;
                    var dY = y2 - y1;
                    var dashes = Math.floor(Math.sqrt(dX * dX + dY * dY) / dashLen);
                    var dashX = dX / dashes;
                    var dashY = dY / dashes;

                    var q = 0;
                    while (q++ < dashes) {
                        x1 += dashX;
                        y1 += dashY;
                        this[q % 2 == 0 ? 'moveTo' : 'lineTo'](x1, y1);
                    }
                    this[q % 2 == 0 ? 'moveTo' : 'lineTo'](x2, y2);
                };

                var ic = new interactChart();

            }
        }
    }
]);