mideaACApp.service('coreHelper', function($http, $q, $location) {

	/*路由跳转方案*/
	this.redirectPage = function($scope, page, state) {
		$scope.appConfig.pageLoadState = state;
		
		if ($scope.appConfig.loadMode == 'lazy') {		
			//按操作状态动态控制转场效果
			if (state === 'in') {
				$scope.appConfig.pageRenderClass = $scope.appConfig.pageInEffect;

			} else if (state === 'out') {
				$scope.appConfig.pageRenderClass = $scope.appConfig.pageOutEffect;

			} else {
				$scope.appConfig.pageRenderClass = $scope.appConfig.pageInEffect;

			}

			//页面切换时 body回滚到页面顶部
			$("body").scrollTop(0);

			//路由处理
			$location.path("/" + page);

			//发送更新事件
			$scope.$broadcast('base:update-plugin');

		} else {
			$scope.appConfig.currentPage = page;
		}
	};

	/*函数延迟执行*/
	this.delayExecute = function(func, time) {
		setTimeout(function() {
			func();
		}, time);
	};
	
	/*模态对话框*/
	this.modalBox = function (modal, templateUrl, size, windowClass,controller) {
        modalDialog = modal.open({
            templateUrl: templateUrl,
            size: size,
            windowClass: windowClass,
            controller: controller
        });
        return modalDialog;
    };

	/*框架性能测试*/
	this.testPerformence = function($scope) {
		$scope.messages = new Array('Cras justo odio', 'Dapibus ac facilisis in', 'Morbi leo risus');
		$scope.messagesOut = new Array();
		var messageIndex = $scope.messages.length - 1;
		for (var i = 0; i < 100; i++) {
			$scope.messagesOut.push($scope.messages[Math.floor(Math.random() * messageIndex + 1)]);
		}
		console.log($scope.messagesOut);
	}

	/*主机接口测试*/
	this.testAcApi = function($scope) {
		$scope.acController = new mdSmart.ACController();
		$scope.acController.requestDeviceStatus();
	}
	this.testUtil = function($scope) {
		$scope.acController.initVideUrl();
		console.log(status);
	}
	
	this.detectHpDevice = function() {
		var browserMeta = navigator.userAgent;

		if (browserMeta.indexOf('Windows') > -1) {
			return true;
		}

		if (browserMeta.indexOf('iPod') > -1) {
			return false;
		}

		if (browserMeta.indexOf('iPhone') > -1) {
			if (browserMeta.match(/OS [6-9]_\d[_\d]* like Mac OS X/i)) {
				return true;
			} else {
				return false;
			}
		}

		if (browserMeta.toLowerCase().indexOf('android') > -1) {
			return true;
		}
	}

	this.detectDevice = function() {
		var browserMeta = navigator.userAgent;
		if (browserMeta.indexOf('Windows') > -1) {
			return false;
		} else {
			return true;
		}
	};

	this.isAndroid = function () {
        var browserMeta = navigator.userAgent;
        if (browserMeta.toLowerCase().indexOf('android') > -1) {
            return true;
        } else {
        	return false;
		}
    };
	
	this.getDeviceVersion = function() {
	    if(navigator.userAgent.match(/iPhone/i)) {
			if(window.screen.height == (960 / 2)) {
				return 4;
			}
			if(window.screen.height == (1136 / 2)) {
				return 5;
			}			 
	    } else {
	    	return -1;
	    }
	}
	
	this.lockScroll = function($scope,lockScrollList, state) {
		var _device = $scope.appConfig.isMobile ? 'mobile' : 'pc';
		var _eventCollection = {
			'pc': {
				'start': 'mousedown',
				'move': 'mousemove',
				'end': 'mouseup'
			},
			'mobile': {
				'start': 'touchstart',
				'move': 'touchmove',
				'end': 'touchend'
			}
		};
		if(state) {
			for (var i = 0; i < lockScrollList.length; i++) {
				lockScrollList[i].unbind(_eventCollection[_device]['start']).bind(_eventCollection[_device]['start'], function(e) {
					e.preventDefault();
				})
			}
		} else {
			for (var i = 0; i < lockScrollList.length; i++) {
				lockScrollList[i].unbind(_eventCollection[_device]['start']).bind(_eventCollection[_device]['start'], function(e) {
				})
			}
		}
	};
	
	this.clone = function(original) {
		var clone = {};
		for (var i in original) {
			if(typeof original[i] === 'object') {
				clone[i] =this.clone(original[i]);
			} else {
				clone[i] = original[i];
			}
		}
		return clone;
	};

	//网络工具
	 this.getResultData = function(message) {
		var errMainCode = 0;
		var errMainMesg = "";
		var errSubCode = 0;
		var errSubMesg = "";

		var jsonResult = JSON.parse(message);
		errMainCode = jsonResult.errorCode;

		if(errMainCode == undefined || errMainCode == null) {
			errMainCode = jsonResult.errCode;
		}
		if(errMainCode != 0 && errMainCode != "0") //	 有主类型错误
		{
			errMainMesg = jsonResult.msg;
			if(errMainMesg == undefined || errMainMesg == null) {
				errMainMesg = jsonResult.errMessage;
			}
			var errTxt = "ERR[" + errMainCode + "]:" + errMainMesg;
			this.showErrorAlert(errTxt);
			return null;
		} else //	主框架无错误
		{
			//	主框架里的返回值
			var resultData = JSON.parse(JSON.stringify(jsonResult.result)); //{"returnData":{"errCode":"1", ....}}
			//	管家平台返回数据

			var returnData = JSON.parse(JSON.stringify(resultData.returnData)); //{"errCode":"1", ....}

			errSubCode = returnData.errCode;

			if(errSubCode == null || errSubCode.length == 0) {
				this.showErrorAlert("格式不正确:" + message);
				return null;
			}
			//	判断管家平台返回是否有错误
			if(errSubCode != 0 && errSubCode != "0") //	 有子类型错误
			{
				errSubMesg = returnData.errMsg;
				var errTxt = "ERR[" + errSubCode + "]:" + errSubMesg;
				this.showErrorAlert(errTxt);
				return null;
			} else {
				return returnData.result;
			}
		}
		return null;
	}

	 this.getCommandResult = function(message) {
		var errMainCode = 0;
		var errMainMesg = "";
		var errSubCode = 0;
		var errSubMesg = "";

		var jsonResult = JSON.parse(message);

		errMainCode = jsonResult.errorCode;
		//	alertDebugText(errMainCode);

		if(errMainCode == undefined || errMainCode == null) {
			errMainCode = jsonResult.errCode;
		}
		if(errMainCode != 0 && errMainCode != "0") //	 有主类型错误
		{
			errMainMesg = jsonResult.msg;
			if(errMainMesg == undefined || errMainMesg == null) {
				errMainMesg = jsonResult.errMessage;
			}
			var errTxt = "ERR[" + errMainCode + "]:" + errMainMesg;
			this.showErrorAlert(errTxt);
			return false;
		} else //	主框架无错误
		{
			//	主框架里的返回值
			var resultData = JSON.parse(JSON.stringify(jsonResult.result)); //{"returnData":{"errCode":"1", ....}}
			//	管家平台返回数据

			var returnData = JSON.parse(JSON.stringify(resultData.returnData)); //{"errCode":"1", ....}

			errSubCode = returnData.errCode;
			//	判断管家平台返回是否有错误
			if(errSubCode != 0 && errSubCode != "0") //	 有主类型错误
			{
				errSubMesg = returnData.errMsg;
				var errTxt = "ERR[" + errSubCode + "]:" + errSubMesg;
				this.showErrorAlert(errTxt);
				return false;
			} else {
				return true;
			}
		}
		return false;
	}

	 this.getLocalTime = function(nS) {
		var newDate = new Date();
		newDate.setTime(nS);
		
		var year = newDate.getFullYear();
		var month = (newDate.getMonth()+1) < 10 ? "0"+(newDate.getMonth()+1) : (newDate.getMonth()+1);
		var day = newDate.getDate() < 10 ? "0"+newDate.getDate() : newDate.getDate();
		
		//return newDate.toLocaleDateString();
		return year+"年"+month+"月"+day+"日";
	}

	 this.showErrorAlert = function(txt) {
		var functionParamers = {
			title: "提示",
			message: txt,
			btnText: "确定"
		};
		//bridge.showAlert(functionParamers);
	}

	 this.isEmpty = function(value) {
		return(Array.isArray(value) && value.length === 0) || (Object.prototype.isPrototypeOf(value) && Object.keys(value).length === 0);
	}
});