mideaACApp.service('staticData', function($http, $q, $rootScope) {

	/*icon 的图标数据*/
	this.getIconResource = function() {
		return {
			openCloseSrc: {
				off: "./view/public/images/ac_button_switch.png",
				on: "./view/public/images/ac_button_switch.png"
			},
			upDownSwipeSrc: {
				off: "./view/public/images/ac_control_luffing.png",
				on: "./view/public/images/ac_control_luffing_on.png"
			},
			upSwipeSrc: {
				off: "./view/public/images/ac_control_up.png",
				on: "./view/public/images/ac_control_up_on.png"
			},
			downSwipeSrc: {
				off: "./view/public/images/ac_control_down.png",
				on: "./view/public/images/ac_control_down_on.png"
			},
			leftRightSwipeSrc: {
				off: "./view/public/images/ac_control_swing.png",
				on: "./view/public/images/ac_control_swing_on.png"
			},
			swipeSrc: {
				off: "./view/public/images/ac_control_swing.png",
				on: "./view/public/images/ac_control_swing_on.png"
			},
			ecoSrc: {
				off: "./view/public/images/ac_control_eco.png",
				on: "./view/public/images/ac_control_eco_on.png"
			},
			keepWarmSrc: {
				off: "./view/public/images/ac_control_baowen.png",
				on: "./view/public/images/ac_control_baowen_on.png"
			},
			sleepSrc: {
				off: "./view/public/images/ac_control_sleep.png",
				on: "./view/public/images/ac_control_sleep_on.png"
			},
			timerSrc: {
				off: "./view/public/images/ac_control_timer.png",
				on: "./view/public/images/ac_control_timer_on.png"
			},
			timerOpenSrc: {
				off: "./view/public/images/ac_control_timer.png",
				on: "./view/public/images/ac_control_timer_on.png"
			},
			noWindFeelSrc: {
				off: "./view/public/images/ac_control_naturalflow.png",
				on: "./view/public/images/ac_control_naturalflow_on.png"
			},
			preColdSrc: {
				off: "./view/public/images/ac_control_prepare.png",
				on: "./view/public/images/ac_control_prepare_on.png"
			},
			electricHeatSrc: {
				off: "./view/public/images/ac_control_heat.png",
				on: "./view/public/images/ac_control_heat_on.png"
			},
			natureWindSrc: {
				off: "./view/public/images/ac_control_naturalwind.png",
				on: "./view/public/images/ac_control_naturalwind_on.png"
			},
			purifySrc: {
				off: "./view/public/images/ac_control_purify.png",
				on: "./view/public/images/ac_control_purify_on.png"
			},
			childrenPreventColdSrc: {
				off: "./view/public/images/ac_control_angel.png",
				on: "./view/public/images/ac_control_angel_on.png"
			},
			drySrc: {
				off: "./view/public/images/ac_control_dry.png",
				on: "./view/public/images/ac_control_dry_on.png"
			},
			savingElectricSrc: {
				off: "./view/public/images/ac_control_save.png",
				on: "./view/public/images/ac_control_save_on.png"
			},
			pmvSrc: {
				off: "./view/public/images/ac_control_pmv.png",
				on: "./view/public/images/ac_control_pmv_on.png"
			},
			strongForceSrc: {
				off: "./view/public/images/ac_control_turbo.png",
				on: "./view/public/images/ac_control_turbo_on.png"
			},
			selfCleaningSrc: {
				off: "./view/public/images/ac_control_clean.png",
				on: "./view/public/images/ac_control_clean_on.png"
			},
			coldHotSwitchSrc: {
				off: "./view/public/images/ac_control_comfort.png",
				on: "./view/public/images/ac_control_comfort_on.png"
			},
			comfortDrySrc: {
				off: "./view/public/images/ac_control_comforpumping_@3x.png",
				on: "./view/public/images/ac_control_comforpumping_on_@3x.png"
			},
			manualDrySrc: {
				off: "./view/public/images/ac_control_humidifier.png",
				on: "./view/public/images/ac_control_humidifier_on.png"
			},
			preventStraightLineWindSrc: {
				off: "./view/public/images/ac_button_prevent_straight_line_wind.png",
				on: "./view/public/images/ac_button_prevent_straight_line_wind_on.png"
			},
			windBlowingSwitchSrc: {
				off: "./view/public/images/ac_button_wind_blowing.png",
				on: "./view/public/images/ac_button_wind_blowing_on.png"
			},
			childrenPreventWindSrc: {
				off: "./view/public/images/ac_button_childrenPreventWind.png",
				on: "./view/public/images/ac_button_childrenPreventWind_on.png"
			},
			upDownNoWindFeelSrc: {//上下无风感总按钮
				off: "./view/public/images/ac_control_naturalflow.png",
				on: "./view/public/images/ac_control_naturalflow_on.png"
			},
			upDownNoWindFeelYBSrc: {//上下无风感总按钮
				off: "./view/public/images/off-2/ac_control_naturalflowYB.png",
				on: "./view/public/images/on-2/ac_control_naturalflowYB_on.png"
			},
			downNoWindFeelSrc: {//上下无风感按钮
				off: "./view/public/images/ac_button_upNoWindFeel.png",
				on: "./view/public/images/ac_button_upNoWindFeel_on.png"
			},
			upNoWindFeelSrc: {//下无风感按钮
				off: "./view/public/images/ac_button_downNoWindFeel.png",
				on: "./view/public/images/ac_button_downNoWindFeel_on.png"
			},
			changesTemperatureSrc: {//知冷暖
				off: "./view/public/images/changesTemperature_off.png",
				on: "./view/public/images/changesTemperature_on.png"
			},
			windFeelFA100Src: {//无风感
				off: "./view/public/images/ac_control_naturalflow.png",
				on: "./view/public/images/ac_control_naturalflow_on.png"
			},
			straightBlowSrc: {//防直吹
				off: "./view/public/images/ac_control_naturalflow.png",
				on: "./view/public/images/ac_button_upNoWindFeel_on.png"
			},
			softWindFeelSwitchSrc: {//微风感
				off: "./view/public/images/ac_control_naturalflow.png",
				on: "./view/public/images/ac_button_upNoWindFeel_on.png"
			},
			windFeelingFA100SwitchSrc: {//无风感
				off: "./view/public/images/ac_control_naturalflow.png",
				on: "./view/public/images/ac_button_upNoWindFeel_on.png"
			}
		};
	};

	/*定时器的数据*/
	this.getTimerData = function() {
		if(_dm_.getDeviceType() == "1TO1"){
			return {
			data: {
				left: [{
					value: '0,30',
					label: '0.5小时'
				}, {
					value: '1,0',
					label: '1小时'
				},  {
					value: '1,30',
					label: '1.5小时'
				}, {
					value: '2,0',
					label: '2小时'
				}, {
					value: '2,30',
					label: '2.5小时'
				}, {
					value: '3,0',
					label: '3小时'
				}, {
					value: '3,30',
					label: '3.5小时'
				}, {
					value: '4,0',
					label: '4小时'
				}, {
					value: '4,30',
					label: '4.5小时'
				}, {
					value: '5,0',
					label: '5小时'
				}, {
					value: '5,30',
					label: '5.5小时'
				}, {
					value: '6,0',
					label: '6小时'
				}, {
					value: '6,30',
					label: '6.5小时'
				}, {
					value: '7,0',
					label: '7小时'
				}, {
					value: '7,30',
					label: '7.5小时'
				}, {
					value: '8,0',
					label: '8小时'
				}, {
					value: '8,30',
					label: '8.5小时'
				}, {
					value: '9,0',
					label: '9小时'
				}, {
					value: '9,30',
					label: '9.5小时'
				}, {
					value: '10,0',
					label: '10小时'
				},  {
					value: '11,0',
					label: '11小时'
				}, {
					value: '12,0',
					label: '12小时'
				},  {
					value: '13,0',
					label: '13小时'
				},  {
					value: '14,0',
					label: '14小时'
				},  {
					value: '15,0',
					label: '15小时'
				},  {
					value: '16,0',
					label: '16小时'
				},  {
					value: '17,0',
					label: '17小时'
				},  {
					value: '18,0',
					label: '18小时'
				},  {
					value: '19,0',
					label: '19小时'
				},  {
					value: '20,0',
					label: '20小时'
				},  {
					value: '21,0',
					label: '21小时'
				},  {
					value: '22,0',
					label: '22小时'
				},  {
					value: '23,0',
					label: '23小时'
				},  {
					value: '24,0',
					label: '24小时'
				}],
				right: [{
					value: '-1',
					label: '关闭定时'
				}, {
					value: '1',
					label: '定时关机',
					labelAlias: '定时开机'
				}]
			}
		};
		}else{
			return {
			data: {
				left: [{
					value: '0,30',
					label: '0.5小时'
				}, {
					value: '1,0',
					label: '1小时'
				},  {
					value: '1,30',
					label: '1.5小时'
				}, {
					value: '2,0',
					label: '2小时'
				}, {
					value: '2,30',
					label: '2.5小时'
				}, {
					value: '3,0',
					label: '3小时'
				}, {
					value: '3,30',
					label: '3.5小时'
				}, {
					value: '4,0',
					label: '4小时'
				}, {
					value: '4,30',
					label: '4.5小时'
				}, {
					value: '5,0',
					label: '5小时'
				}, {
					value: '5,30',
					label: '5.5小时'
				}, {
					value: '6,0',
					label: '6小时'
				}, {
					value: '6,30',
					label: '6.5小时'
				}, {
					value: '7,0',
					label: '7小时'
				}, {
					value: '7,30',
					label: '7.5小时'
				}, {
					value: '8,0',
					label: '8小时'
				}, {
					value: '8,30',
					label: '8.5小时'
				}, {
					value: '9,0',
					label: '9小时'
				}, {
					value: '9,30',
					label: '9.5小时'
				}, {
					value: '10,0',
					label: '10小时'
				}, {
					value: '10,30',
					label: '10.5小时'
				}, {
					value: '11,0',
					label: '11小时'
				}, {
					value: '11,30',
					label: '11.5小时'
				}, {
					value: '12,0',
					label: '12小时'
				}, {
					value: '12,30',
					label: '12.5小时'
				}, {
					value: '13,0',
					label: '13小时'
				}, {
					value: '13,30',
					label: '13.5小时'
				}, {
					value: '14,0',
					label: '14小时'
				}, {
					value: '14,30',
					label: '14.5小时'
				}, {
					value: '15,0',
					label: '15小时'
				}, {
					value: '15,30',
					label: '15.5小时'
				}, {
					value: '16,0',
					label: '16小时'
				}, {
					value: '16,30',
					label: '16.5小时'
				}, {
					value: '17,0',
					label: '17小时'
				}, {
					value: '17,30',
					label: '17.5小时'
				}, {
					value: '18,0',
					label: '18小时'
				}, {
					value: '18,30',
					label: '18.5小时'
				}, {
					value: '19,0',
					label: '19小时'
				}, {
					value: '19,30',
					label: '19.5小时'
				}, {
					value: '20,0',
					label: '20小时'
				}, {
					value: '20,30',
					label: '20.5小时'
				}, {
					value: '21,0',
					label: '21小时'
				}, {
					value: '21,30',
					label: '21.5小时'
				}, {
					value: '22,0',
					label: '22小时'
				}, {
					value: '22,30',
					label: '22.5小时'
				}, {
					value: '23,0',
					label: '23小时'
				}, {
					value: '23,30',
					label: '23.5小时'
				}, {
					value: '24,0',
					label: '24小时'
				}],
				right: [{
					value: '-1',
					label: '关闭定时'
				}, {
					value: '1',
					label: '定时关机',
					labelAlias: '定时开机'
				}]
			}
		};
		}
		
	};

	/*pmv的数据*/
	this.getPmvData = function() {
		return {
			data: {
				left: [{
					value: '-3',
					label: '-3'
				}, {
					value: '-2.5',
					label: '-2.5'
				}, {
					value: '-2',
					label: '-2'
				}, {
					value: '-1.5',
					label: '-1.5'
				}, {
					value: '-1',
					label: '-1'
				}, {
					value: '-0.5',
					label: '-0.5'
				}, {
					value: '0',
					label: '0'
				}, {
					value: '0.5',
					label: '0.5'
				}, {
					value: '1',
					label: '1'
				}, {
					value: '1.5',
					label: '1.5'
				}, {
					value: '2',
					label: '2'
				}, {
					value: '2.5',
					label: '2.5'
				}, {
					value: '3',
					label: '3'
				}],
				right: [{
					value: '-1',
					label: '关闭'
				}, {
					value: '1',
					label: 'PMV运行',
					labelAlias: 'PMV运行'
				}]
			}
		};
	};

	/*敏感度的数据*/
	this.getSensitivityData = function() {
		return {
			data: {
				left: [{
					value: '2',
					label: '低'
				}, {
					value: '1',
					label: '中'
				}, {
					value: '0',
					label: '高'
				}]
			}
		};
	};

	/*制冷区间的温度范围*/
	this.getCpcColdIntervalData = function() {
		return {
			data: {
				left: [{
					value: '17',
					label: '17°C'
				}, {
					value: '17.5',
					label: '17.5°C'
				}, {
					value: '18',
					label: '18°C'
				}, {
					value: '18.5',
					label: '18.5°C'
				}, {
					value: '19',
					label: '19°C'
				}, {
					value: '19.5',
					label: '19.5°C'
				}, {
					value: '20',
					label: '20°C'
				}, {
					value: '20.5',
					label: '20.5°C'
				}, {
					value: '21',
					label: '21°C'
				}, {
					value: '21.5',
					label: '21.5°C'
				}, {
					value: '22',
					label: '22°C'
				}, {
					value: '22.5',
					label: '22.5°C'
				}, {
					value: '23',
					label: '23°C'
				}, {
					value: '23.5',
					label: '23.5°C'
				}, {
					value: '24',
					label: '24°C'
				}, {
					value: '24.5',
					label: '24.5°C'
				}, {
					value: '25',
					label: '25°C'
				}, {
					value: '25.5',
					label: '25.5°C'
				}, {
					value: '26',
					label: '26°C'
				}, {
					value: '26.5',
					label: '26.5°C'
				}, {
					value: '27',
					label: '27°C'
				}, {
					value: '27.5',
					label: '27.5°C'
				}, {
					value: '28',
					label: '28°C'
				}, {
					value: '28.5',
					label: '28.5°C'
				}, {
					value: '29',
					label: '29°C'
				}, {
					value: '29.5',
					label: '29.5°C'
				}, {
					value: '30',
					label: '30°C'
				}],
				right: [{
					value: '17',
					label: '17°C'
				}, {
					value: '17.5',
					label: '17.5°C'
				}, {
					value: '18',
					label: '18°C'
				}, {
					value: '18.5',
					label: '18.5°C'
				}, {
					value: '19',
					label: '19°C'
				}, {
					value: '19.5',
					label: '19.5°C'
				}, {
					value: '20',
					label: '20°C'
				}, {
					value: '20.5',
					label: '20.5°C'
				}, {
					value: '21',
					label: '21°C'
				}, {
					value: '21.5',
					label: '21.5°C'
				}, {
					value: '22',
					label: '22°C'
				}, {
					value: '22.5',
					label: '22.5°C'
				}, {
					value: '23',
					label: '23°C'
				}, {
					value: '23.5',
					label: '23.5°C'
				}, {
					value: '24',
					label: '24°C'
				}, {
					value: '24.5',
					label: '24.5°C'
				}, {
					value: '25',
					label: '25°C'
				}, {
					value: '25.5',
					label: '25.5°C'
				}, {
					value: '26',
					label: '26°C'
				}, {
					value: '26.5',
					label: '26.5°C'
				}, {
					value: '27',
					label: '27°C'
				}, {
					value: '27.5',
					label: '27.5°C'
				}, {
					value: '28',
					label: '28°C'
				}, {
					value: '28.5',
					label: '28.5°C'
				}, {
					value: '29',
					label: '29°C'
				}, {
					value: '29.5',
					label: '29.5°C'
				}, {
					value: '30',
					label: '30°C'
				}]
			}
		};
	};

	/*制热区间的温度范围*/
	this.getCpcHeatIntervalData = function() {
		return {
			data: {
				left: [{
					value: '17',
					label: '17°C'
				}, {
					value: '17.5',
					label: '17.5°C'
				}, {
					value: '18',
					label: '18°C'
				}, {
					value: '18.5',
					label: '18.5°C'
				}, {
					value: '19',
					label: '19°C'
				}, {
					value: '19.5',
					label: '19.5°C'
				}, {
					value: '20',
					label: '20°C'
				}, {
					value: '20.5',
					label: '20.5°C'
				}, {
					value: '21',
					label: '21°C'
				}, {
					value: '21.5',
					label: '21.5°C'
				}, {
					value: '22',
					label: '22°C'
				}, {
					value: '22.5',
					label: '22.5°C'
				}, {
					value: '23',
					label: '23°C'
				}, {
					value: '23.5',
					label: '23.5°C'
				}, {
					value: '24',
					label: '24°C'
				}, {
					value: '24.5',
					label: '24.5°C'
				}, {
					value: '25',
					label: '25°C'
				}, {
					value: '25.5',
					label: '25.5°C'
				}, {
					value: '26',
					label: '26°C'
				}, {
					value: '26.5',
					label: '26.5°C'
				}, {
					value: '27',
					label: '27°C'
				}, {
					value: '27.5',
					label: '27.5°C'
				}, {
					value: '28',
					label: '28°C'
				}, {
					value: '28.5',
					label: '28.5°C'
				}, {
					value: '29',
					label: '29°C'
				}, {
					value: '29.5',
					label: '29.5°C'
				}, {
					value: '30',
					label: '30°C'
				}],
				right: [{
					value: '17',
					label: '17°C'
				}, {
					value: '17.5',
					label: '17.5°C'
				}, {
					value: '18',
					label: '18°C'
				}, {
					value: '18.5',
					label: '18.5°C'
				}, {
					value: '19',
					label: '19°C'
				}, {
					value: '19.5',
					label: '19.5°C'
				}, {
					value: '20',
					label: '20°C'
				}, {
					value: '20.5',
					label: '20.5°C'
				}, {
					value: '21',
					label: '21°C'
				}, {
					value: '21.5',
					label: '21.5°C'
				}, {
					value: '22',
					label: '22°C'
				}, {
					value: '22.5',
					label: '22.5°C'
				}, {
					value: '23',
					label: '23°C'
				}, {
					value: '23.5',
					label: '23.5°C'
				}, {
					value: '24',
					label: '24°C'
				}, {
					value: '24.5',
					label: '24.5°C'
				}, {
					value: '25',
					label: '25°C'
				}, {
					value: '25.5',
					label: '25.5°C'
				}, {
					value: '26',
					label: '26°C'
				}, {
					value: '26.5',
					label: '26.5°C'
				}, {
					value: '27',
					label: '27°C'
				}, {
					value: '27.5',
					label: '27.5°C'
				}, {
					value: '28',
					label: '28°C'
				}, {
					value: '28.5',
					label: '28.5°C'
				}, {
					value: '29',
					label: '29°C'
				}, {
					value: '29.5',
					label: '29.5°C'
				}, {
					value: '30',
					label: '30°C'
				}]
			}
		};
	};

	/*制冷区间 发现踢被子后升温*/
	this.getCpcColdTemperateRiseData = function() {
		return {
			data: {
				left: [{
					value: '0',
					label: '0'
				}, {
					value: '0.5',
					label: '0.5'
				}, {
					value: '1',
					label: '1'
				}, {
					value: '1.5',
					label: '1.5'
				}, {
					value: '2',
					label: '2'
				}, {
					value: '2.5',
					label: '2.5'
				}, {
					value: '3',
					label: '3'
				}, {
					value: '3.5',
					label: '3.5'
				}, {
					value: '4',
					label: '4'
				}, {
					value: '4.5',
					label: '4.5'
				}, {
					value: '5',
					label: '5'
				}, {
					value: '5.5',
					label: '5.5'
				}, {
					value: '6',
					label: '6'
				}]
			}
		};
	};

	/*制热区间 发现踢被子后升温*/
	this.getCpcHeatTemperateRiseData = function() {
		return {
			data: {
				left: [{
					value: '0',
					label: '0'
				}, {
					value: '0.5',
					label: '0.5'
				}, {
					value: '1',
					label: '1'
				}, {
					value: '1.5',
					label: '1.5'
				}, {
					value: '2',
					label: '2'
				}, {
					value: '2.5',
					label: '2.5'
				}, {
					value: '3',
					label: '3'
				}, {
					value: '3.5',
					label: '3.5'
				}, {
					value: '4',
					label: '4'
				}, {
					value: '4.5',
					label: '4.5'
				}, {
					value: '5',
					label: '5'
				}, {
					value: '5.5',
					label: '5.5'
				}, {
					value: '6',
					label: '6'
				}]
			}
		};
	}
	
	/*模式的数据*/
	this.getModeData = function() {
		return {
			data: {
				left: [{
					value: '1',
					label: '自动'
				}, {
					value: '2',
					label: '制冷'
				}, {
					value: '3',
					label: '抽湿'
				}, {
					value: '4',
					label: '制热'
				}, {
					value: '5',
					label: '送风'
				}]
			}
		};
	};

});