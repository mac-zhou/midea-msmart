mideaACApp.service('deviceCommand', function($http, $q, $rootScope) {
	this.todo = function() {
		//todo
		console.log('deviceCommand');
	};
});