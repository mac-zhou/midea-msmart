mideaACApp.service('deviceRequest', function($http, $q, $rootScope) {
	this.todo = function() {
		//todo
	};
});