
function receiveUploadMsgIsPermit() {
	var isPermit = true;

	var SNStr = bridge.getCurrentDevSN();
	var promptStr = localStorage.getItem("ACMsgSync" + SNStr);
	if ("false" == promptStr) {
		isPermit = false;
	}

	return isPermit;
}

function setReceiveUploadMsgIsPermit() {
	var SNStr = bridge.getCurrentDevSN();
	var localTimeoutId = localStorage.getItem("acMsgSyncTimeoutId" + SNStr);
	clearTimeout(localTimeoutId);

	var delayId = localStorage.getItem("acMsgSyncDelayId" + SNStr);
	clearTimeout(delayId);

	var acMsgSyncDelayId = setTimeout(function() {
		localStorage.setItem("ACMsgSync" + SNStr, "true");
	}, 2000);
	localStorage.setItem("acMsgSyncDelayId" + SNStr, acMsgSyncDelayId);

}

function setReceiveUploadIsUnallowed() {
	var SNStr = bridge.getCurrentDevSN();
	localStorage.setItem("ACMsgSync" + SNStr, "false");

	var localTimeoutId = localStorage.getItem("acMsgSyncTimeoutId" + SNStr);
	clearTimeout(localTimeoutId);

	var acMsgSyncDelayId = localStorage.getItem("acMsgSyncDelayId" + SNStr);
	clearTimeout(acMsgSyncDelayId);

	var acMsgSyncTimeoutId = setTimeout(function() {
		localStorage.setItem("ACMsgSync" + SNStr, "true");
	}, 4500);
	localStorage.setItem("acMsgSyncTimeoutId" + SNStr, acMsgSyncTimeoutId);
}




function receiveUploadMsgIsPermitCard() {
	var isPermit = true;

	var SNStr = bridge.getCurrentDevSN();
	var promptStr = localStorage.getItem("ACMsgSyncCard" + SNStr);
	if ("false" == promptStr) {
		isPermit = false;
	}

	return isPermit;
}

function setReceiveUploadMsgIsPermitCard() {
	var SNStr = bridge.getCurrentDevSN();
	var localTimeoutId = localStorage.getItem("acMsgSyncTimeoutIdCard" + SNStr);
	clearTimeout(localTimeoutId);

	var delayId = localStorage.getItem("acMsgSyncDelayIdCard" + SNStr);
	clearTimeout(delayId);

	var acMsgSyncDelayId = setTimeout(function() {
		localStorage.setItem("ACMsgSyncCard" + SNStr, "true");
	}, 2000);
	localStorage.setItem("acMsgSyncDelayIdCard" + SNStr, acMsgSyncDelayId);

}

function setReceiveUploadIsUnallowedCard() {
	var SNStr = bridge.getCurrentDevSN();
	localStorage.setItem("ACMsgSyncCard" + SNStr, "false");

	var localTimeoutId = localStorage.getItem("acMsgSyncTimeoutIdCard" + SNStr);
	clearTimeout(localTimeoutId);

	var acMsgSyncDelayId = localStorage.getItem("acMsgSyncDelayIdCard" + SNStr);
	clearTimeout(acMsgSyncDelayId);

	var acMsgSyncTimeoutId = setTimeout(function() {
		localStorage.setItem("ACMsgSyncCard" + SNStr, "true");
	}, 4500);
	localStorage.setItem("acMsgSyncTimeoutIdCard" + SNStr, acMsgSyncTimeoutId);

}