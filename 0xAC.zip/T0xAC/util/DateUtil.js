Date.prototype.Format = function(fmt)   
{ //author: meizz   
  var o = {   
    "M+" : this.getMonth()+1,                 //月份   
    "d+" : this.getDate(),                    //日   
    "h+" : this.getHours(),                   //小时   
    "m+" : this.getMinutes(),                 //分   
    "s+" : this.getSeconds(),                 //秒   
    "q+" : Math.floor((this.getMonth()+3)/3), //季度   
    "S"  : this.getMilliseconds()             //毫秒   
  };   
  if(/(y+)/.test(fmt))   
    fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));   
  for(var k in o)   
    if(new RegExp("("+ k +")").test(fmt))   
  fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));   
  return fmt;   
} 

/**
 * @return {Object} 获取当前月及当前月的天数{month:7,days:31}
 */
function getCurrentMonthAndDays() {
	var returnObj = {
		month:7,
		days:31
	}
	var yearMonthStr = new Date().Format("yyyy-MM-dd");
	var yearStr = yearMonthStr.split("-")[0];
	var monthStr = yearMonthStr.split("-")[1];
	if ("01" == monthStr) {
		returnObj.month = 1;
		returnObj.days = 31;
	} else if ("02" == monthStr) {
		returnObj.month = 2;
		returnObj.days = 28;
		var yearNum = parseInt(yearStr);
		if (0 == (yearNum % 4)) {
			returnObj.days = 29;
		}
	} else if ("03" == monthStr) {
		returnObj.month = 3;
		returnObj.days = 31;
	} else if ("04" == monthStr) {
		returnObj.month = 4;
		returnObj.days = 30;
	} else if ("05" == monthStr) {
		returnObj.month = 5;
		returnObj.days = 31;
	} else if ("06" == monthStr) {
		returnObj.month = 6;
		returnObj.days = 30;
	} else if ("07" == monthStr) {
		returnObj.month = 7;
		returnObj.days = 31;
	} else if ("08" == monthStr) {
		returnObj.month = 8;
		returnObj.days = 31;
	} else if ("09" == monthStr) {
		returnObj.month = 9;
		returnObj.days = 30;
	} else if ("10" == monthStr) {
		returnObj.month = 10;
		returnObj.days = 31;
	} else if ("11" == monthStr) {
		returnObj.month = 11;
		returnObj.days = 30;
	} else if ("12" == monthStr) {
		returnObj.month = 12;
		returnObj.days = 31;
	} 
	return returnObj;
}
