//针对主应用对于请求失败时，乱弹请求失败请重试的问题，对方法进行override ，不再弹出提示 add by yuxg 20150818
bridge.popupTimeOut = function() {

}