/**
 * @author yuxg
 * @file 资源引用文件，考虑javascript引入方式问题，统一放到这个文件里面进入
 * 
 */

//定义命名空间
var mdSmart = mdSmart || {};

/**
 * 引入依赖文件
 */

document.write('<script src="./view/js/i18n/zh.js"><\/script>');
document.write('<script src="./view/js/i18n/en.js"><\/script>');

document.write('<script src="./util/DateUtil.js"><\/script>');

document.write('<script src="../base/iosbridge.js"><\/script>');
document.write('<script src="../base/base.js"><\/script>');

document.write('<script src="./util/IncompatibleUtil.js"><\/script>');
document.write('<script src="./util/ControllerPanelUtil.js"><\/script>');

document.write('<script src="./view/js/AC_MSG.js"><\/script>');

document.write('<script src="./manager/Manager.js"><\/script>');
document.write('<script src="./controller/Controller.js"><\/script>');

