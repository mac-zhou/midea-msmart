/**
 * @author yuxg
 * @file
 * Controller.js文件，定义了mdSmart.ACController，用于界面交互的请求，回调处理,对底层逻辑进行封装
 */

mdSmart.ACController = function() {

	//初始化manager对象
	var _dataManager = new mdSmart.ACDataManager();
	this.dataManager = _dataManager;
	var that = this;
	var selfCleanProcessing = false;
	var acGlobalDeviceSn = null;

	//msg0xAC对象具有请求控制，状态保存，协议解析
	var _dataParse = new mdSmart.msg0xAC();
	this.dataManager.setDataStorage(_dataParse);

	(function init() {
		networkDelay = setTimeout(function() {
		}, 12000);
		//绑定监听器，监听家电上传，通知界面刷新
		$(document).bind('recieveMessage', {}, function (event, message) {
			var isPermit = receiveUploadMsgIsPermit();
			if (isPermit) {
				var isNewProtocolData = isNewProtocol(message);
				if (isNewProtocolData) {
					processNewProtocolUpdateDataAndNotifyRefreshView(message);					
				} else if (!selfCleanProcessing) {
					processModeDataAndNotifyRefreshView(message);
				}
			}
		});

		_dataManager.initDeviceInfo();
		_dataManager.initPromptToneFromLocal();

		setTimeout(function() {
			initPrepareColdOrHeat();
//			initSelfCleaningStatus();
		}, 500);

		setTimeout(function() {
			initSecurityStatus();
		}, 500)

		setTimeout(function() {
			acGlobalDeviceSn = bridge.getCurrentDevSN();
		});
	}());

	//旧协议相关请求，控制

	/**
	 * 请求设备的状态信息,请求完毕进行数据处理，然后回调刷新界面
	 * 进行请求的同步问题管理,
	 */
	this.requestDeviceStatus = function() {
		_dataParse.setSetByte4(0x00);
		var cmdBytes = _dataParse.cmdRequestStatus();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processModeDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 返回卡片页面
	 */
	this.controlGoback = function() {
		bridge.goBack();
	}

	this.showLoading = function() {
		that.lockScroll([$('.loadingWrapper')], true);
		$(".loadingWrapper").css({
			"height": $(document).height(),
			"display": "block"
		});
	var appElement = document.querySelector('[ng-controller=BootController]');
    	var $scope = angular.element(appElement).scope();
		networkDelay = setTimeout(function() {
			that.hideLoading();
			$scope.timeoutPopUp("网络超时，请重试");
			$scope.$apply();
		}, 12000);
	}

	this.hideLoading = function() {
		that.lockScroll([$('.loadingWrapper')], false);
		clearTimeout(networkDelay);
		$(".loadingWrapper").css({
			"display": "none"
		});
	}
	
	this.lockScroll = function(lockScrollList, state) {
		var _device = 'mobile';
		var _eventCollection = {
			'pc': {
				'start': 'mousedown',
				'move': 'mousemove',
				'end': 'mouseup'
			},
			'mobile': {
				'start': 'touchstart',
				'move': 'touchmove',
				'end': 'touchend'
			}
		};
		if(state) {
			for (var i = 0; i < lockScrollList.length; i++) {
				lockScrollList[i].unbind(_eventCollection[_device]['start']).bind(_eventCollection[_device]['start'], function(e) {
					e.preventDefault();
				})
			}
		} else {
			for (var i = 0; i < lockScrollList.length; i++) {
				lockScrollList[i].unbind(_eventCollection[_device]['start']).bind(_eventCollection[_device]['start'], function(e) {
				})
			}
		}
	};

	/**
	 * 开关机操作
	 * @param isOpen：true开机，false关机
	 */
	this.controlDeviceOnAndOff = function(isOpen) {
		that.showLoading();
		if(isOpen) {
			var currentBody = _dataParse.getCurrentBody();
			_dataParse.setMobileTimerInfoSwitch(0x01);
			_dataParse.setTimerOpenSwitch(0x00);
			_dataParse.setTimerOpenAbsoluteHour(0x7f);
			_dataParse.setTimerCloseAbsoluteHour(0x7f);
			_dataParse.setTimerOpenAbsoluteMinute(0x00);
			_dataParse.setRunningState(0x01);
			_dataParse.setPMVFunction(0);
			_dataParse.setComfortWindVH(0x00);
			_dataParse.setComfortWindDownState(0x00);
			_dataParse.setKeepWarmSwitch(0);
			_dataParse.setWindBlowingSwitch(0);
			if(currentBody[2] == 0)
				_dataParse.setSetTemperate(0x4a);
			if(currentBody[3] == 128)
				_dataParse.setNoPolarWindSpeedValue(0x65);
			if(currentBody[2] == 10)
				_dataParse.setSetMode(0x01);
			var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
			setOpenDeviceHelperStatueWithRunMode(deviceStatus.runningMode);
			var cmdBytes = _dataParse.cmdControl(0);
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				processModeDataAndNotifyRefreshView(messageBack);
			}, function(message) {
				processOperateFailCallBack(message);
			});
		} else {
			_dataParse.setPowerSavingSwitch(0x00);
			_dataParse.setMobileTimerInfoSwitch(0x01);
			_dataParse.setTimerCloseSwitch(0x00);
			_dataParse.setTimerCloseAbsoluteHour(0x7f);
			_dataParse.setTimerCloseAbsoluteMinute(0x00);
			_dataParse.setRunningState(0x00);
			_dataParse.setPurifyingFunction(0x00);
			_dataParse.setPreventingCold(0x00);
			_dataParse.setNaturalWindFunctionSwitch(0x00);
			_dataParse.setPMVFunction(0);
			_dataParse.setKeepWarmSwitch(0);
			_dataParse.setWindBlowingSwitch(0);
			var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
			var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
			_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
			_dataParse.setComfortWindVH(0x00);
			_dataParse.setComfortWindDownState(0x00);

			switch(deviceStatus.runningMode) {
				case 1: //自动模式
					{
						_dataParse.setNoPolarWindSpeedValue(101);
						break;
					}
				case 2: //制冷模式
					{
						_dataParse.setNoPolarWindSpeedValue(102);
						break;
					}
				case 3: //抽湿模式
					{
						_dataParse.setNoPolarWindSpeedValue(101);
						break;
					}
				case 4: //制热模式
					{
						_dataParse.setNoPolarWindSpeedValue(102);
						break;
					}
				case 5: //送风模式
					{
						_dataParse.setNoPolarWindSpeedValue(102);
						break;
					}
			}
            _dataParse.setElectricHeatingButtonPressFlg(0);
			var cmdBytes = _dataParse.cmdControl(0);
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				processModeDataAndNotifyRefreshView(messageBack);
			}, function(message) {
				processOperateFailCallBack(message);
			});
		}
		if(_dataManager.getCurrentDevice().deviceInfo.hasFilterScreen){
			that.filterDirtyPluggingStatus();
		}
	}

	//控制舒适抽湿
	this.controlComfortDry = function(isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		if(isOpen) {
			_dataParse.setSetMode(6);
			_dataParse.setHumidity(101);
			_dataParse.setNoPolarWindSpeedValue(102);
		} else {
			_dataParse.setSetMode(3);
			_dataParse.setNoPolarWindSpeedValue(101);
			_dataParse.setHumidity(0);
		}
		_dataParse.setPowerSavingSwitch(0x00);
		_dataParse.setEOCFunctionSwitch(0);
		_dataParse.setMobileTimerInfoSwitch(0x00);
		_dataParse.setNaturalWindFunctionSwitch(0x00);
		_dataParse.setPMVFunction(0);
		_dataParse.setPreventingCold(0x00);
		_dataParse.setElectricHeatingButtonPressFlg(0);
		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	//控制手动抽湿
	this.controlManualDry = function(isOpen, setHumidityValue) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;

		if(isOpen) {
			_dataParse.setSetMode(6);
			_dataParse.setHumidity(setHumidityValue);
			_dataParse.setNoPolarWindSpeedValue(102);
		} else {
			_dataParse.setSetMode(3);
			_dataParse.setNoPolarWindSpeedValue(101);
			_dataParse.setHumidity(0);
		}
		_dataParse.setPowerSavingSwitch(0x00);
		_dataParse.setEOCFunctionSwitch(0);
		_dataParse.setMobileTimerInfoSwitch(0x00);
		_dataParse.setNaturalWindFunctionSwitch(0x00);
		_dataParse.setPMVFunction(0);
		_dataParse.setPreventingCold(0x00);
		_dataParse.setElectricHeatingButtonPressFlg(0);
		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 切换模式，循环往复切换运行模式：自动，制冷，抽湿，制热，送风
	 * 切换模式，关闭ECO、自然风、PMV、小天使
	 */
	this.controlSwitchMode = function(modeIndex) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		if(modeIndex == undefined) {
			var runMode = deviceStatus.runningMode + 1;
			_dataParse.setWindBlowingSwitch(0);
			if(runMode > 5) {
				if(runMode >= 7) {
					runMode = 2;
				} else {
					runMode = 1;
				}
			}
		} else {
			var runMode = modeIndex;
		}
		_dataParse.setPowerSavingSwitch(0x00);
		_dataParse.setMobileTimerInfoSwitch(0x00);
		_dataParse.setEOCFunctionSwitch(0);
		_dataParse.setNaturalWindFunctionSwitch(0x00);
		_dataParse.setPMVFunction(0);
		_dataParse.setPreventingCold(0x00);
		_dataParse.setKeepWarmSwitch(0);
		_dataParse.setElectricHeatingButtonPressFlg(0);
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var acDeviceType = _dataManager.getCurrentDevice().deviceInfo.deviceType;
		switch(runMode) {
			case "1": //自动模式
				{
					_dataParse.setNoPolarWindSpeedValue(101);
					_dataParse.setElectricHeatingButtonPressFlg(0);
					_dataParse.setElectricAuxiliaryHeat(1);
					_dataParse.setSetMode(runMode);
					if(mdSmart.ACDataManager.ACDeviceType.FA100== acDeviceType){
					_dataManager.getCurrentDevice().deviceStatus.windAvoidStatus=false;
					_dataManager.getCurrentDevice().deviceStatus.isWindBlow=false;	
					}				
					break;
				}
			case "2": //制冷模式
				{
					_dataParse.setNoPolarWindSpeedValue(102);
					_dataParse.setSetMode(runMode);
					if(mdSmart.ACDataManager.ACDeviceType.FA100== acDeviceType){
					_dataManager.getCurrentDevice().deviceStatus.windAvoidStatus=false;
					_dataManager.getCurrentDevice().deviceStatus.isWindBlow=false;
					}
					break;
				}
			case "3": //抽湿模式
				{
					_dataParse.setNoPolarWindSpeedValue(101);
					_dataParse.setHumidity(0);
					_dataParse.setSetMode(runMode);
					if(mdSmart.ACDataManager.ACDeviceType.FA100== acDeviceType){
					_dataManager.getCurrentDevice().deviceStatus.windAvoidStatus=false;
					_dataManager.getCurrentDevice().deviceStatus.isWindBlow=false;
					}
					break;
				}
			case "4": //制热模式
				{
					_dataParse.setNoPolarWindSpeedValue(102);
					_dataParse.setElectricHeatingButtonPressFlg(0);
					_dataParse.setElectricAuxiliaryHeat(1);
					_dataParse.setSetMode(runMode);
					if(mdSmart.ACDataManager.ACDeviceType.FA100== acDeviceType){
					_dataManager.getCurrentDevice().deviceStatus.windAvoidStatus=false;
					_dataManager.getCurrentDevice().deviceStatus.isWindBlow=false;
					}
					break;
				}
			case "5": //送风模式
				{
					_dataParse.setNoPolarWindSpeedValue(102);
					_dataParse.setSetMode(runMode);
					if(mdSmart.ACDataManager.ACDeviceType.FA100== acDeviceType){
					_dataManager.getCurrentDevice().deviceStatus.windAvoidStatus=false;
					_dataManager.getCurrentDevice().deviceStatus.isWindBlow=false;
					}
					break;
				}
		}

		var cmdBytes = _dataParse.cmdControl(0);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processModeDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 设置温度,参数：整数，小数
	 * @param integerNum:整数，范围17到30值，
	 * decimalNum:小数{0,0.5}
	 */
	this.controlSetTemperature = function(integerNum, decimalNum) {
		that.showLoading();
		if((17 <= integerNum && integerNum <= 30) && (0 == decimalNum || 0.5 == decimalNum)) {
			_dataParse.setPMVFunction(0);
			_dataParse.setMobileTimerInfoSwitch(0x00);
			var decimal = decimalNum == 0.5 ? 1 : 0;
			_dataParse.setSetTemperate(integerNum - 16, decimal);
			_dataParse.setSetTemperate18B(0x00);
			_dataParse.setElectricHeatingButtonPressFlg(0);
			var cmdBytes = _dataParse.cmdControl(0);
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				processDataAndNotifyRefreshView(messageBack);
			}, function(message) {
				processOperateFailCallBack(message);
			});
		}
	}

	/**
	 * 定时功能打开，或者关闭
	 * @param isOn:true 定时开机，false定时关机,hh小时，mm分钟
	 */
	this.controlSetTimerDeviceOnOff = function(isOn, hh, mm) {
		that.showLoading();
		var deviceIsOpen = _dataManager.getCurrentDevice().deviceStatus.deviceRunningStatus;
		 _dataParse.setElectricHeatingButtonPressFlg(0);
		if(deviceIsOpen) { //当前状态开机
			if(isOn) { //定时关机打开
				_dataParse.setMobileTimerInfoSwitch(0x01);
				_dataParse.setTimerCloseSwitch(0x01);
				var settingHours = (hh * 4) + (mm / 15);
				var settingMinutes = 15 - mm % 15;
				_dataParse.setTimerCloseAbsoluteHour(settingHours);
				_dataParse.setTimerCloseAbsoluteMinute(settingMinutes);
				var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
				var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
				_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
				var cmdBytes = _dataParse.cmdControl();
				var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
					processDataAndNotifyRefreshView(messageBack);
				}, function(message) {
					processOperateFailCallBack(message);
				});
			} else { //定时关机关闭
				_dataParse.setMobileTimerInfoSwitch(0x01);
				_dataParse.setTimerCloseSwitch(0x00);
				_dataParse.setTimerCloseAbsoluteHour(0x7f);
				_dataParse.setTimerCloseAbsoluteMinute(0x00);
				var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
				var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
				_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
				var cmdBytes = _dataParse.cmdControl();
				var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
					processDataAndNotifyRefreshView(messageBack);
				}, function(message) {
					processOperateFailCallBack(message);
				});
			}
		} else {
			if(isOn) { //定时开机打开
				_dataParse.setMobileTimerInfoSwitch(0x01);
				_dataParse.setTimerOpenSwitch(0x01);

				var settingHours = (hh * 4) + (mm / 15);
				var settingMinutes = 15 - (mm % 15);
				_dataParse.setTimerOpenAbsoluteHour(settingHours);
				_dataParse.setTimerOpenAbsoluteMinute(settingMinutes);

				var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
				var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
				_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
				var cmdBytes = _dataParse.cmdControl();
				var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
					processDataAndNotifyRefreshView(messageBack);
				}, function(message) {
					processOperateFailCallBack(message);
				});
			} else { //定时开机关闭
				_dataParse.setMobileTimerInfoSwitch(0x01);
				_dataParse.setTimerOpenSwitch(0x00);
				_dataParse.setTimerOpenAbsoluteHour(0x7f);
				_dataParse.setTimerOpenAbsoluteMinute(0x00);
				var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
				var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
				_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
				var cmdBytes = _dataParse.cmdControl();
				var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
					processDataAndNotifyRefreshView(messageBack);
				}, function(message) {
					processOperateFailCallBack(message);
				});
			}
		}
	}

	/**
	 * 设置风速
	 * @param windValue：1~100,101自动风
	 */
	this.controlSetWindSpeedValue = function(windValue) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		 _dataParse.setElectricHeatingButtonPressFlg(0);
		if(windValue < 1) {
			windValue = 1;
		} else if(windValue > 102) {
			windValue = 102;
		}
		_dataParse.setPowerSavingSwitch(0x00);
		_dataParse.setMobileTimerInfoSwitch(0x00);
		_dataParse.setNoPolarWindSpeedValue(windValue);
		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
		notifyRefreshIntelViewStatus();
	}

	/**
	 * ECO功能切换
	 * @param isOpen:true 打开ECO,false关闭ECO
	 * 仅制冷模式有效，开启Eco（默认26度，自动风）后关闭舒睡、自然风
	 */
	this.controlSwitchECO = function(isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		if(isOpen) {
			_dataParse.setEOCFunctionSwitch(1);
			_dataParse.setSetTemperate(10, 0x00);
			_dataParse.setNoPolarWindSpeedValue(102);
			_dataParse.setNaturalWindFunctionSwitch(0x00);
			_dataParse.setSleepFunctionSwitch(0);
			_dataParse.setSleepModeSwitch(0);
			_dataParse.setPMVFunction(0);
			_dataParse.setKeepWarmSwitch(0);
		} else {
			_dataParse.setEOCFunctionSwitch(0);
		}
		_dataParse.setEnergySavingSwitch(1);
		_dataParse.setMobileTimerInfoSwitch(0);
		_dataParse.setElectricHeatingButtonPressFlg(0);

//		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
//		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}
	
	/*	 
	 * 保温功能切换
	 */
	this.controlKeepWarm = function (isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		if (isOpen) {
			_dataParse.setKeepWarmSwitch(1);
			_dataParse.setSetTemperate(11, 0x00);
			_dataParse.setNoPolarWindSpeedValue(102);
			_dataParse.setNaturalWindFunctionSwitch(0x00);
			_dataParse.setSleepFunctionSwitch(0);
			_dataParse.setSleepModeSwitch(0);
			_dataParse.setPMVFunction(0);
			_dataParse.setEOCFunctionSwitch(0);
			_dataParse.setStrongSwitch(0);
			_dataParse.setPowerSavingSwitch(0);
			_dataParse.setPMVFunction(0);
		} else {
			_dataParse.setKeepWarmSwitch(0);
		}
		_dataParse.setMobileTimerInfoSwitch(0);
        _dataParse.setElectricHeatingButtonPressFlg(0);
//		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
//		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function (message) {
			processOperateFailCallBack(message);
		});
	}
	/*	 
	 * 以色列功能切换
	 */
	this.controlShabbat = function (isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		if (isOpen) {
			_dataParse.setShabbatSwitch(1);

		} else {
			_dataParse.setShabbatSwitch(0);
		}
		_dataParse.setMobileTimerInfoSwitch(0);
//		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
//		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function (message) {
			processOperateFailCallBack(message);
		});
	}
	/*	 
	 * 清除尘满时间
	 */
	this.controlScavengingFlowerRunningTime = function (isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		if (isOpen) {
			_dataParse.setScavengingFlowerRunningTimeSwitch(1);

		} else {
			_dataParse.setScavengingFlowerRunningTimeSwitch(0);
		}
		_dataParse.setMobileTimerInfoSwitch(0);
        _dataParse.setElectricHeatingButtonPressFlg(0);
//		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
//		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function (message) {
			processOperateFailCallBack(message);
		});
	}
	
		/**
	 * 旧协议防直吹功能切换
	 */
	this.controlWindBlowing = function (isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		if (isOpen) {
			if((deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool) ||
			(deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind)){
			_dataParse.setNoPolarWindSpeedValue(20);	
			}else{
			_dataParse.setNoPolarWindSpeedValue(102);	
			}
			_dataParse.setWindBlowingSwitch(1);
//			_dataParse.setRunningState(0x01);
			//关闭上下摆风
			_dataParse.setComfortWind0x3LV(0x00);
			_dataParse.setComfortWind0x3RV(0x00);
				 //关闭左右摆风
		     _dataParse.setComfortWind0x3LH(0x00);
		     _dataParse.setComfortWind0x3RH(0x00);
		     _dataParse.setNaturalWindFunctionSwitch(0);
		} else {
			_dataParse.setWindBlowingSwitch(0);
		}
		    _dataParse.setMobileTimerInfoSwitch(0);
            _dataParse.setElectricHeatingButtonPressFlg(0);
		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function (message) {
			processOperateFailCallBack(message);
		});
	}
	//FA100防直吹
	this.controlNoWindFeelModalClose = function(open) {
//		if(hasNoWindFeelModal) {
		that.showLoading();
		var deviceStatus = _dataManager.getDeviceWindBlowingStatus().windBlowing;
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x43;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度	
		if(open){
		itemsBytes[3] = 2;	
		_dataParse.setPreventingCold(0x00);
		}else{
		itemsBytes[3] = 1;		
		}
		    _dataParse.setMobileTimerInfoSwitch(0);
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
//		}
	}
	//FA100微风感
	this.controlBreezeFeels = function(open) {
//		if(hasNoWindFeelModal) {
		that.showLoading();
		var deviceStatus = _dataManager.getDeviceWindBlowingStatus().softWindFeel;
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x43;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度	
		if(open){
		itemsBytes[3] = 3;	
		_dataParse.setComfortWind0x3LV(0x00);
		_dataParse.setComfortWind0x3RV(0x00);
		_dataParse.setPreventingCold(0x00);
		}else{
		itemsBytes[3] = 1;		
		}
		    _dataParse.setMobileTimerInfoSwitch(0);
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
//		}
	}
	//FA100无风感
	this.controlWindFeelingFA100 = function(open) {
//		if(hasNoWindFeelModal) {
		that.showLoading();
		var deviceStatus = _dataManager.getDeviceWindBlowingStatus().windFeelingFA100;
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x43;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度	
		if(open){
		itemsBytes[3] = 4;
		_dataParse.setKeepWarmSwitch(0x00);
		_dataParse.setEOCFunctionSwitch(0x00);
		_dataParse.setPreventingCold(0x00);
		}else{
		itemsBytes[3] = 1;		
		}
		    _dataParse.setMobileTimerInfoSwitch(0);
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
//		}
	}
	//新防直吹控制
	this.controlWindBlowingnew = function(isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getDeviceWindBlowingStatus().windBlowing;
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x42;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(isOpen) {
			itemsBytes[3] = 2;			
		} else {
			itemsBytes[3] = 1;
		}
		if (isOpen) {
			if((_dataManager.getCurrentDevice().deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool) ||
			(_dataManager.getCurrentDevice().deviceStatus.runningMode == mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind)){
			_dataParse.setNoPolarWindSpeedValue(1);	
			}
			//关闭上下摆风
			_dataParse.setComfortWind0x3LV(0x00);
			_dataParse.setComfortWind0x3RV(0x00);
		    _dataParse.setNaturalWindFunctionSwitch(0);
		} 
		    _dataParse.setMobileTimerInfoSwitch(0);

		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	//新防直吹功能查询
		this.requestWindBlowingnewValue = function() {
		var hasWindBlowing = _dataManager.getCurrentDevice().deviceInfo.hasWindBlowing;
//		if(hasWindBlowing) {
			var tmpCheckTypeCount = 1; //查询属性个数
			var tmpValue = [];
			tmpValue[0] = 0x00; //高位  
			tmpValue[1] = 0x42; //低位

			var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
//			alert("查询："+cmdBytes);
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
//				alert("返回："+messageBack);
				processNewProtocolDataAndNotifyRefreshView(messageBack);
			}, function(message) {});
//		}
	}
		//FA100无风感
	this.requestWindBlowingnewValueFA100 = function() {
			var tmpCheckTypeCount = 1; //查询属性个数
			var tmpValue = [];
			tmpValue[0] = 0x00; //高位  
			tmpValue[1] = 0x43; //低位

			var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				processNewProtocolDataAndNotifyRefreshView(messageBack);
			}, function(message) {});
	}
	
	/**
	 * 自然风功能切换
	 * @param isOpen:true 开发自然风，false关闭自然风
	 * 仅在制冷和送风模式下有效，开启自然风后默认开启上下风、左右风
	 */
	this.controlSwitchNatureWind = function(isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		if(isOpen) {
			_dataParse.setNaturalWindFunctionSwitch(1);
			_dataParse.setComfortWind0x3LV(0x01);
			_dataParse.setComfortWind0x3LH(0x01);
			_dataParse.setComfortWind0x3RH(0x01);
			_dataParse.setComfortWind0x3RV(0x01);
			_dataParse.setRuiFengSwitch(0x00);
			_dataParse.setEOCFunctionSwitch(0x00);
			_dataParse.setIModeRecovery(0x00);
			_dataParse.setPreventingCold(0x00);
			_dataParse.setPMVFunction(0);
			_dataParse.setKeepWarmSwitch(0);
			_dataParse.setWindBlowingSwitch(0);
		} else {
			_dataParse.setNaturalWindFunctionSwitch(0);
		}
		_dataParse.setElectricHeatingButtonPressFlg(0);
		_dataParse.setMobileTimerInfoSwitch(0);

		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 上下摆风功能切换
	 * @param isOpen:true上下摆风打开，false上下摆风关闭
	 */
	this.controlSwitchUpDownWind = function(isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		if(isOpen) {
			_dataParse.setComfortWind0x3LV(0x01);
			_dataParse.setComfortWind0x3RV(0x01);
			_dataParse.setWindBlowingSwitch(0);
		} else {
			_dataParse.setComfortWind0x3LV(0x00);
			_dataParse.setComfortWind0x3RV(0x00);
		}
		if((_dataManager.getCurrentDevice().deviceStatus.upNoWindFeel) && (_dataManager.getCurrentDevice().deviceStatus.downNoWindFeel)) {
				_dataParse.setComfortWindDownState(0x00);
			}
		_dataParse.setWindBlowingSwitch(0);
		_dataParse.setMobileTimerInfoSwitch(0x00);
		_dataParse.setElectricHeatingButtonPressFlg(0);

		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});

	}

	/**
	 * 上摆风功能切换
	 * @param isOpen:true 上摆风打开，false下摆风关闭
	 */
	this.controlSwitchUpSwipeWind = function(isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		if(isOpen) {
			_dataParse.setComfortWind0x3LH(0x01);
			_dataParse.setComfortWind0x3RH(0x01);
			_dataParse.setWindBlowingSwitch(0);
		} else {
			_dataParse.setComfortWind0x3LH(0x00);
			_dataParse.setComfortWind0x3RH(0x00);
		}
		_dataParse.setWindBlowingSwitch(0);
		_dataParse.setComfortWindDownControl(0x01);
		_dataParse.setMobileTimerInfoSwitch(0x00);
		_dataParse.setElectricHeatingButtonPressFlg(0);

		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 下摆风功能切换
	 * @param isOpen:true 下摆风开打，false下摆风关闭
	 */
	this.controlSwitchDownSwipeWind = function(isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		if(isOpen) {
			_dataParse.setComfortWindDownState(0x01);
			_dataParse.setWindBlowingSwitch(0);
		} else {
			_dataParse.setComfortWindDownState(0x00);
		}
		_dataParse.setComfortWindDownControl(0x01);
		_dataParse.setMobileTimerInfoSwitch(0x00);
		_dataParse.setElectricHeatingButtonPressFlg(0);

		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 左右摆风功能切换
	 * @param isOpen:true 左右摆风打开，false左右摆风关闭
	 */
	this.controlSwitchLeftRightWind = function(isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		if(isOpen) {
			_dataParse.setComfortWind0x3LH(0x01);
			_dataParse.setComfortWind0x3RH(0x01);
            _dataParse.setWindBlowingSwitch(0);
			//YB301
			if(_dataManager.getCurrentDevice().deviceInfo.hasUpDownNoWindFeel) {
				_dataParse.setComfortWindDownState(0x01);
			}
			if((_dataManager.getCurrentDevice().deviceStatus.upNoWindFeel) && !(_dataManager.getCurrentDevice().deviceStatus.downNoWindFeel)) {
				_dataParse.setComfortWind0x3LH(0x00);
				_dataParse.setComfortWind0x3RH(0x00);
				_dataParse.setComfortWindDownState(0x01);
			}
			if(!(_dataManager.getCurrentDevice().deviceStatus.upNoWindFeel) && (_dataManager.getCurrentDevice().deviceStatus.downNoWindFeel)) {
				_dataParse.setComfortWind0x3LH(0x01);
				_dataParse.setComfortWind0x3RH(0x01);
				_dataParse.setComfortWindDownState(0x00);
			}
			if(!(_dataManager.getCurrentDevice().deviceStatus.upNoWindFeel) && !(_dataManager.getCurrentDevice().deviceStatus.downNoWindFeel)) {
				_dataParse.setComfortWind0x3LH(0x01);
				_dataParse.setComfortWind0x3RH(0x01);
				_dataParse.setComfortWindDownState(0x01);
			}
		} else {
			_dataParse.setComfortWind0x3LH(0x00);
			_dataParse.setComfortWind0x3RH(0x00);
			_dataParse.setComfortWindDownState(0x00);
		}
		_dataParse.setMobileTimerInfoSwitch(0x00);
		_dataParse.setElectricHeatingButtonPressFlg(0);

		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			if(isOpen) {
				if(deviceStatus.upNoWindFeel && deviceStatus.downNoWindFeel) {
					//上无风感、下无风感同时开启时开启左右风，关闭上下无风感
					deviceStatus.upNoWindFeel = false;
					deviceStatus.downNoWindFeel = false;
					deviceStatus.noWindFeel = false;
				}
			}
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 摆风功能切换
	 * @param isOpen:true 摆风打开，false 摆风关闭
	 */
	this.controlSwitchWind = function(isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		if(isOpen) {
			_dataParse.setComfortWind0x3LH(0x01);
			_dataParse.setComfortWind0x3RH(0x01);
			_dataParse.setComfortWindDownState(0x01);
		} else {
			_dataParse.setComfortWind0x3LH(0x00);
			_dataParse.setComfortWind0x3RH(0x00);
			_dataParse.setComfortWindDownState(0x00);
		}
		_dataParse.setMobileTimerInfoSwitch(0x00);
		_dataParse.setElectricHeatingButtonPressFlg(0);
		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 干燥功能切换
	 * @param isOpen:true 干燥功能开发，false干燥功能关闭
	 * 干燥在制热、自动、送风模式下无效
	 */
	this.controlSwitchDry = function(isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		if(isOpen) {
			_dataParse.setDry(1);
		} else {
			_dataParse.setDry(0);
		}
		_dataParse.setMobileTimerInfoSwitch(0x00);
		_dataParse.setElectricHeatingButtonPressFlg(0);

		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 电辅热功能切换
	 * @param isOpen:true 电辅热功能打开，false干燥功能关闭
	 * 仅在自动、制热模式有效
	 */
	this.controlSwitchElecHeatHelper = function(isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		if(isOpen) {
			_dataParse.setElectricAuxiliaryHeat(1);
		} else {
			_dataParse.setElectricAuxiliaryHeat(0);
		}
		_dataParse.setMobileTimerInfoSwitch(0x00);
		_dataParse.setElectricHeatingButtonPressFlg(1);

		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * PMV 功能切换
	 * @param pmvValue值，ACPMVMode枚举，1~13,-111为关闭
	 */
	this.controlSwitchPMV = function(pmvValue) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		var realPMVValue = 0;
		if(mdSmart.ACDataManager.ACPMVMode.PMVModeClose == pmvValue) {
			realPMVValue = 0;
		} else {
			realPMVValue = (pmvValue * 2) + 7;
		}
		_dataParse.setMobileTimerInfoSwitch(0x00);
		_dataParse.setPMVFunction(realPMVValue);
		if(realPMVValue != 0) {
			//关闭ECO
			_dataParse.setEOCFunctionSwitch(0x00);
			//关闭强劲
			_dataParse.setStrongSwitch(0x00);
			//关闭自然风
			_dataParse.setNaturalWindFunctionSwitch(0x00);
			//关闭睿风
			_dataParse.setRuiFengSwitch(0x00);
			//关闭I模式
			_dataParse.setIModeRecovery(0x00);
			//关闭儿童睡眠
			_dataParse.setChildrenSleepMode(0x00);
			//关闭舒睡
			_dataParse.setSleepModeSwitch(0x00);
			//关闭保温
			_dataParse.setKeepWarmSwitch(0x00);
		}
            _dataParse.setElectricHeatingButtonPressFlg(0);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 屏显功能切换
	 * @param isOpen:true 屏显功能打开，false屏显功能关闭
	 */
	this.controlSwitchScreenDisplay = function(isOpen) {
		that.showLoading();
		var cmdBytes = _dataParse.cmdChangeDisplay();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 防着凉功能切换，用于控制智慧眼功能是否打开
	 * @param isOpen:true 防着凉功能打开，false防着凉功能关闭
	 * 仅在制冷、制热、自动模式有效，开启防着凉后关闭舒睡
	 */
	this.controlSwitchPreventCold = function(isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		if(isOpen) {
			_dataParse.setPreventingCold(1);
			_dataParse.setSleepFunctionSwitch(0);
			_dataParse.setSleepModeSwitch(0);
		} else {
			_dataParse.setPreventingCold(0);
		}
		_dataParse.setMobileTimerInfoSwitch(0x00);

		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 *更新儿童防着凉踢被子参数信息，制热灵敏度，制冷灵敏度，制热上限，制热下限，制冷上限，制冷下限等
	 */
	this.controlSetPreventColdParameter = function() {
		that.showLoading();
		var preventColdStatus = _dataManager.getPreventColdParameterModify();
		var itemsNum = 6;
		var itemsBytes = [];

		//制冷灵敏度
		itemsBytes[0] = 0x10;
		itemsBytes[1] = 0x04;
		itemsBytes[2] = 1; //属性长度
		if(0 == preventColdStatus.beColdSensitivity) {
			itemsBytes[3] = 100;
		} else if(1 == preventColdStatus.beColdSensitivity) {
			itemsBytes[3] = 50;
		} else if(2 == preventColdStatus.beColdSensitivity) {
			itemsBytes[3] = 1;
		}
		//制热灵敏度
		itemsBytes[4] = 0x11;
		itemsBytes[5] = 0x04;
		itemsBytes[6] = 1; //属性长度
		if(0 == preventColdStatus.beHeatSensitivity) {
			itemsBytes[7] = 100;
		} else if(1 == preventColdStatus.beHeatSensitivity) {
			itemsBytes[7] = 50;
		} else if(2 == preventColdStatus.beHeatSensitivity) {
			itemsBytes[7] = 1;
		}
		//制冷补偿
		itemsBytes[8] = 0x12;
		itemsBytes[9] = 0x04;
		itemsBytes[10] = 1; //属性长度
		itemsBytes[11] = preventColdStatus.beColdTemperateRise * 2;
		//制热补偿
		itemsBytes[12] = 0x13;
		itemsBytes[13] = 0x04;
		itemsBytes[14] = 1; //属性长度
		itemsBytes[15] = preventColdStatus.beHeatTemperateRise * 2;
		//制冷上下限
		itemsBytes[16] = 0x1b;
		itemsBytes[17] = 0x04;
		itemsBytes[18] = 2; //属性长度
		itemsBytes[19] = preventColdStatus.beColdMin * 2;
		itemsBytes[20] = preventColdStatus.beColdMax * 2;
		//制热上下限
		itemsBytes[21] = 0x1c;
		itemsBytes[22] = 0x04;
		itemsBytes[23] = 2; //属性长度
		itemsBytes[24] = preventColdStatus.beHeatMin * 2;
		itemsBytes[25] = preventColdStatus.beHeatMax * 2;
        _dataParse.setElectricHeatingButtonPressFlg(0);
		//发送指令设置儿童踢被子的参数信息，回调后更新界面
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			_dataManager.resetCachePreventCold();
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 空气净化
	 * @param isOpen:true空气净化功能打开，false空气净化功能关闭
	 */
	this.controlSwitchAirPure = function(isOpen) {
		that.showLoading();
		if(isOpen) {
			_dataParse.setMobileTimerInfoSwitch(0x00);
			_dataParse.setPurifyingFunction(0x01);
		} else {
			_dataParse.setMobileTimerInfoSwitch(0x00);
			_dataParse.setPurifyingFunction(0x00);
		}
		_dataParse.setElectricHeatingButtonPressFlg(0);
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 省电开关控制
	 * @param isOpen:true 省电功能开启，false省电空能关闭
	 */
	this.controlSwitchSavingElectric = function(isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		if(isOpen) {
			_dataParse.setMobileTimerInfoSwitch(0x00);
			_dataParse.setSleepFunctionSwitch(0);
			_dataParse.setSleepModeSwitch(0);
			_dataParse.setPowerSavingSwitch(0x01);
			_dataParse.setNoPolarWindSpeedValue(102);
			_dataParse.setKeepWarmSwitch(0);
		} else {
			_dataParse.setMobileTimerInfoSwitch(0x00);
			_dataParse.setPowerSavingSwitch(0x00);
		}
		_dataParse.setElectricHeatingButtonPressFlg(0);
		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 智能除湿
	 * @param isOpen:true智能除湿打开，false智能除湿关闭
	 */
	this.controlSmartRemoveWet = function(isOpen) {
		_dataParse.setMobileTimerInfoSwitch(0x00);
		_dataParse.setNoPolarWindSpeedValue(102);
		_dataParse.setEOCFunctionSwitch(0x00);
		_dataParse.setHumidity(101);
		_dataParse.setSetMode(6);
		_dataParse.setElectricHeatingButtonPressFlg(0);

		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 手动除湿
	 * @param humidityValue:湿度范围30~90
	 */
	this.controlManualRemoveWet = function(humidityValue) {
		if(humidityValue < 30) {
			humidityValue = 30;
		} else if(humidityValue > 90) {
			humidityValue = 90;
		}
		_dataParse.setMobileTimerInfoSwitch(0x00);
		_dataParse.setNoPolarWindSpeedValue(102);
		_dataParse.setEOCFunctionSwitch(0x00);
		_dataParse.setHumidity(humidityValue);
		_dataParse.setSetMode(6);
		_dataParse.setElectricHeatingButtonPressFlg(0);

		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 睡眠曲线开关控制
	 * @param isOpen:true 睡眠曲线开，false睡眠曲线关
	 */
	this.controlSwitchSleep = function(isOpen) {
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
//		if(!deviceStatus.deviceRunningStatus) {
//			//alert("关机下舒睡不可用");
//			var functionParamers = {
//				title: "提示",
//				message: "关机下舒睡不可用!",
//				btnText: "确定"
//			};
//			bridge.showAlert(functionParamers);
//			return false;
//		}
//
//		if(deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool &&
//			deviceStatus.runningMode != mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat) {
//			//alert("舒睡只在制冷，制热模式下有效!");
//			var functionParamers = {
//				title: "提示",
//				message: "舒睡只在制冷，制热模式下有效!",
//				btnText: "确定"
//			};
//			bridge.showAlert(functionParamers);
//			return false;
//		}

		var applianceId = bridge.getCurrentApplianceID();
		var runMode = _dataManager.getCurrentDevice().deviceStatus.runningMode;
		var functionParamers;
		var sleepObj = undefined;
		var sleepStatus = _dataManager.getSleepMode();
		var sleepType = 0;

		if(0 == sleepStatus.selectSleepType) {
			sleepType = 6;
			sleepObj = sleepStatus.sleepCurveRecommend;
		} else if(1 == sleepStatus.selectSleepType) {
			sleepType = 4;
			sleepObj = sleepStatus.sleepCurveCustom;
		} else if(2 == sleepStatus.selectSleepType) {
			sleepType = 5;
			sleepObj = sleepStatus.sleepCurveInteligent;
		}
		var sleepHourValue = [];
		sleepHourValue[0] = sleepObj.firstHour;
		sleepHourValue[1] = sleepObj.secondHour;
		sleepHourValue[2] = sleepObj.thirdHour;
		sleepHourValue[3] = sleepObj.forthHour;
		sleepHourValue[4] = sleepObj.fifthHour;
		sleepHourValue[5] = sleepObj.sixthtHour;
		sleepHourValue[6] = sleepObj.seventhHour;
		sleepHourValue[7] = sleepObj.eighthHour;
		sleepHourValue[8] = sleepObj.ninthHour;
		sleepHourValue[9] = sleepObj.tenthHour;

		if(isOpen) {
			var functionParamers = {
				queryStrings: {
					"serviceUrl": "/sleepCurve/startSleepCurve"
				},
				transmitData: {
					"applianceId": applianceId,
					"type": sleepType,
					"mode": runMode,
					"value0": sleepObj.firstHour,
					"value1": sleepObj.secondHour,
					"value2": sleepObj.thirdHour,
					"value3": sleepObj.forthHour,
					"value4": sleepObj.fifthHour,
					"value5": sleepObj.sixthtHour,
					"value6": sleepObj.seventhHour,
					"value7": sleepObj.eighthHour,
					"value8": sleepObj.ninthHour,
					"value9": sleepObj.tenthHour,
				}
			};
			var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
				var jsonString = JSON.stringify(messageBack);
				var jsonData = JSON.parse(jsonString);
				var errflag = jsonData.errorCode;
				if(errflag == 0) {
					var returnData = jsonData.result.returnData;
					var errMsg = returnData.errMsg;
					var errCode = returnData.errCode;
					if(errCode == 0) {
						setTimeout(function() {
							setLocalSleepStatus(3);
						}, 0);
					}
				}
			});
		} else {
			sleepModeValue = 0;
			var functionParamers = {
				queryStrings: {
					"serviceUrl": "/sleepCurve/closeSleepCurve"
				},
				transmitData: {
					"userId": "0",
					"familyId": "0",
					"applianceId": applianceId
				},
			};
			var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
				var jsonString = JSON.stringify(messageBack);
				var jsonData = JSON.parse(jsonString);
				var errflag = jsonData.errorCode;
				if(errflag == 0) {
					var returnData = jsonData.result.returnData;
					var errMsg = returnData.errMsg;
					var errCode = returnData.errCode;
					if(errCode == 0) {
						setTimeout(function() {
							setLocalSleepStatus(0);
						}, 0);
					}
				}
			});
		}
	}

	/**
	 *发送数据到家电，控制舒睡开关
	 * @param {Object} sleepModeValue  0：关 ， 3:开
	 */
	function setLocalSleepStatus(sleepModeValue) {
		that.showLoading();
		var sleepObj = undefined;
		var sleepStatus = _dataManager.getSleepMode();
		if(0 == sleepStatus.selectSleepType) {
			sleepObj = sleepStatus.sleepCurveRecommend;
		} else if(1 == sleepStatus.selectSleepType) {
			sleepObj = sleepStatus.sleepCurveCustom;
		} else if(2 == sleepStatus.selectSleepType) {
			sleepObj = sleepStatus.sleepCurveInteligent;
		}
		var sleepHourValue = [];
		sleepHourValue[0] = sleepObj.firstHour - 17;
		sleepHourValue[1] = sleepObj.secondHour - 17;
		sleepHourValue[2] = sleepObj.thirdHour - 17;
		sleepHourValue[3] = sleepObj.forthHour - 17;
		sleepHourValue[4] = sleepObj.fifthHour - 17;
		sleepHourValue[5] = sleepObj.sixthtHour - 17;
		sleepHourValue[6] = sleepObj.seventhHour - 17;
		sleepHourValue[7] = sleepObj.eighthHour - 17;
		sleepHourValue[8] = sleepObj.ninthHour - 17;
		sleepHourValue[9] = sleepObj.tenthHour - 17;

		_dataParse.setLocationSleepMode(sleepModeValue, sleepHourValue);
		_dataParse.setElectricHeatingButtonPressFlg(0);
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);

		if(sleepModeValue == 3) {
			var cmdBytes = _dataParse.cmdControl(9);
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				_dataParse.setLocationSleepMode(sleepModeValue, sleepHourValue);
				setTimeout(function() {
					var cmdBytesOpen = _dataParse.cmdControl();
					var cmdId = bridge.startCmdProcess(cmdBytesOpen, function(messageBack) {
						processDataAndNotifyRefreshSleepView(messageBack);
					}, function(message) {
						processOperateFailCallBack(message);
					});
				}, 0);
			}, function(message) {
				processOperateFailCallBack(message);
			});
		} else {
			var cmdBytesClose = _dataParse.cmdControl();
			var cmdId = bridge.startCmdProcess(cmdBytesClose, function(messageBack) {
				processDataAndNotifyRefreshSleepView(messageBack);
			}, function(message) {
				processOperateFailCallBack(message);
			});
		}
	}

	/**
	 * 强劲功能切换
	 * @param isOpen:true 强劲功能打开,false强劲功能关闭
	 */
	this.controlSwitchTubro = function(isOpen) {
		that.showLoading();
		if(isOpen) {
			_dataParse.setMobileTimerInfoSwitch(0x00);
			_dataParse.setStrongSwitch(0x01);
		} else {
			_dataParse.setMobileTimerInfoSwitch(0x00);
			_dataParse.setStrongSwitch(0x00);
		}
		_dataParse.setElectricHeatingButtonPressFlg(0);
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		var temperate = temperatureTranslation(deviceStatus.temperatureInteger, deviceStatus.temperatureDecimal);
		_dataParse.setSetTemperate(temperate.integerTemp, temperate.decimalTemp);
		var cmdBytes = _dataParse.cmdControl();
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}
	/*
	 * yuyin获取版本更新说明
	 */
	this.requestYuyinVersionContent = function() {
		var version = _dataManager.getYuyinVersion().yuyinUpdateVersion;
		//		    alert(version);
		var applianceId = bridge.getCurrentApplianceID();
		var functionParamers = {
			queryStrings: {
				"serviceUrl": "/OTA/queryUpdateContent"
			},
			transmitData: {
				"version": version,
			},
		};
		var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			//TODO数据解析，绑定数据
			var jsonData = JSON.parse(jsonString);
			var errflag = jsonData.errorCode;
			//			alert(jsonString);
			if(errflag == 0) {
				var returnData = jsonData.result.returnData.result;
				//				alert(returnData.content);
				var errMsg = jsonData.result.returnData.errMsg;
				var errCode = jsonData.result.returnData.errCode;
				if(errCode == 0) {
					//					alert("returnData.content"+returnData.content);
					_dataManager.deviceYuyinVersionContent(returnData.content);
					yuyinbanbensmStatus();

				}
			}
		});
	}

	/*
	 * yuyin查询设备OTA信息
	 */
	this.getYuyinVersion = function() {
		var applianceId = bridge.getCurrentApplianceID();
		var functionParamers = {
			queryStrings: {
				"serviceUrl": "/OTA/queryOtaInfo"
			},
			transmitData: {
				"applianceId": applianceId, //applianceId
			},
		};
		var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			//TODO数据解析，绑定数据
			var jsonData = JSON.parse(jsonString);
			var errflag = jsonData.errorCode;
			//			alert(jsonString);
			if(errflag == 0) {
				var returnData = jsonData.result.returnData.result;
				var errMsg = jsonData.result.returnData.errMsg;
				var errCode = jsonData.result.returnData.errCode;
				//				alert(errCode);
				if(errCode == 0) {
					//					alert("ddd"+returnData.nowVersion);

					//	 var description = ""; 
					//	 for(var i in returnData){   
					//	        var property=obj[i];   
					//	        description+=i+" = "+property+"\n";  
					//	    }   
					//	    alert(description);
					_dataManager.deviceYuyinStatus(returnData.status);
					_dataManager.deviceYuyinCompany(returnData.company);
					_dataManager.updateYuyinVersionCurrentVersion(returnData.nowVersion);
					_dataManager.updateYuyinVersion(returnData.updateVersion);
					_dataManager.downloadRateYuyinVersionProgress(returnData.downloadRate);
					_dataManager.updateRateYuyinVersionProgress(returnData.updateRate);
					yuyinUpdateStatus();
				} else {
					var functionParamers = {
						title: "提示",
						message: "网络超时-1, 请退出后重新查询 " + errCode,
						btnText: "确定"
					};
					//bridge.showAlert(functionParamers);

					$.event.trigger("getDeviceVersionTimeOut", {});
				}
			} else {
				var functionParamers = {
					title: "提示",
					message: "网络超时-2, 请退出后重新查询 " + errflag,
					btnText: "确定"
				};
				//bridge.showAlert(functionParamers);
				$.event.trigger("getDeviceVersionTimeOut", {});
			}
		});
	}
	/*
	 * yuyin开始升级
	 */
	this.startUpdateYuyinVersion = function() {
		var applianceId = bridge.getCurrentApplianceID();
		var functionParamers = {
			queryStrings: {
				"serviceUrl": "/OTA/startUpdate"
			},
			transmitData: {
				"applianceId": applianceId, //applianceId
			},
		};
		var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			//TODO数据解析，绑定数据
			var jsonData = JSON.parse(jsonString);
			var errflag = jsonData.errorCode;
			//				alert(jsonString);
			if(errflag == 0) {
				var returnData = jsonData.result.returnData;
				var errMsg = returnData.errMsg;
				var errCode = returnData.errCode;

				if(errCode == 0) {
					//					_dataManager.updateWifiVersionCurrentVersion(ver);
					//						wifiUpdateStatus();
					that.getYuyinVersion();
				} else {
					var functionParamers = {
						title: "提示",
						message: "网络超时-1, 请退出后重新升级 " + errCode,
						btnText: "确定"
					};
					bridge.showAlert(functionParamers);
				}
			} else {
				var functionParamers = {
					title: "提示",
					message: "网络超时-2, 请退出后重新升级 " + errflag,
					btnText: "确定"
				};
				bridge.showAlert(functionParamers);
			}
		});
	}

	/**
	 * 请求电量的相关数据信息
	 */
	this.requestElectricQuantityStatus = function() {
		requestRealTimePower();
		//			window.setTimeout(function() {
		//				requestElectQuantityToday();
		//			}, 500);
		window.setTimeout(function() {
			requestEcoRunningStatus();
		}, 1000);
		window.setTimeout(function() {
			requestElectQuantity4Week();
		}, 2000);
		window.setTimeout(function() {
			requestElectQuantity4Month();
		}, 3000);

	}
	// 请求今日电量

	function requestElectQuantityToday() {
		var elecQtyObj = _dataManager.getElectricQuantity();
		var applianceId = bridge.getCurrentApplianceID();
		var timeStr = new Date().Format("yyyy-MM-dd");
		if("" == elecQtyObj.elecQty.currentWeekElecQty.totalElecQty) {
			var functionParamers = {
				queryStrings: {
					"serviceUrl": "/electricity/queryDayElec"
				},
				transmitData: {
					"applianceId": applianceId
				}
			};
			var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
				var jsonString = JSON.stringify(messageBack);
				//TODO数据解析，绑定数据
				var jsonData = JSON.parse(jsonString);
				var errflag = jsonData.errorCode;
				//数据解析,更新videoUrl对象
				if(errflag == 0) {
					var returnData = jsonData.result.returnData;
					var errMsg = returnData.errMsg;
					var errCode = returnData.errCode;
					if(errCode == 0 && undefined != returnData.result && undefined != returnData.result.elecValue) {
						var electTodayValue = returnData.result.elecValue;
						elecQtyObj.todayElecQty = electTodayValue.toFixed(2);
					}
				}
				notifyRefreshElecView();
			});

		}
	}

	//请求本月电量
	function requestElectQuantity4Month() {
		var elecQtyObj = _dataManager.getElectricQuantity();
		var applianceId = bridge.getCurrentApplianceID();
		var timeStr = new Date().Format("yyyy-MM-dd");
		var currentDay = new Date().getDate();
		if("" == elecQtyObj.elecQty.currentMonthElecQty.totalElecQty) {
			var functionParamers = {
				queryStrings: {
					"serviceUrl": "/electricity/queryElec"
				},
				transmitData: {
					"applianceId": applianceId,
					"type": 2,
					"date": timeStr
				}
			};
			var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
				var jsonString = JSON.stringify(messageBack);
				var jsonData = JSON.parse(jsonString);
				var errflag = jsonData.errorCode;
				//数据解析,更新videoUrl对象
				if(errflag == 0) {
					var returnData = jsonData.result.returnData;
					var errMsg = returnData.errMsg;
					var errCode = returnData.errCode;
					if(errCode == 0 && undefined != returnData.result && undefined != returnData.result.elecDetails) {
						var elecDetails = returnData.result.elecDetails;
						var totalElecQty = 0;
						elecQtyObj.elecQty.currentMonthElecQty.totalElecQty = parseFloat(returnData.result.totalValue).toFixed(2);
						var electTodayValue = elecDetails[currentDay - 1].value;
						elecQtyObj.todayElecQty = electTodayValue.toFixed(2);
						//						totalElecQty = totalElecQty + elecDetails[0].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.one = elecDetails[0].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.two = elecDetails[1].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.three = elecDetails[2].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.four = elecDetails[3].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.five = elecDetails[4].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.six = elecDetails[5].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.seven = elecDetails[6].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.eight = elecDetails[7].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.nine = elecDetails[8].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.ten = elecDetails[9].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.eleven = elecDetails[10].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.twelve = elecDetails[11].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.thirteen = elecDetails[12].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.fourteen = elecDetails[13].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.fifteen = elecDetails[14].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.sixteen = elecDetails[15].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.seventeen = elecDetails[16].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.eighteen = elecDetails[17].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.nineteen = elecDetails[18].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.twenty = elecDetails[19].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.twentyOne = elecDetails[20].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.twentyTwo = elecDetails[21].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.twentyThree = elecDetails[22].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.twentyFour = elecDetails[23].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.twentyFive = elecDetails[24].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.twentySix = elecDetails[25].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.twentySeven = elecDetails[26].value;
						elecQtyObj.elecQty.currentMonthElecQty.details.twentyEight = elecDetails[27].value;

						if(elecDetails.length >= 29) {
							if(elecDetails[28].value != null || elecDetails[28].value != undefined) {
								elecQtyObj.elecQty.currentMonthElecQty.details.twentyNine = elecDetails[28].value;
							} else {
								elecQtyObj.elecQty.currentMonthElecQty.details.twentyNine = 0;
							}
						}
						if(elecDetails.length >= 30) {
							if(elecDetails[29].value != null || elecDetails[29].value != undefined) {
								elecQtyObj.elecQty.currentMonthElecQty.details.thirty = elecDetails[29].value;
							} else {
								elecQtyObj.elecQty.currentMonthElecQty.details.thirty = 0;
							}
						}
						if(elecDetails.length == 31) {
							if(elecDetails[30].value != null || elecDetails[30].value != undefined) {
								elecQtyObj.elecQty.currentMonthElecQty.details.thirtyOne = elecDetails[30].value;
							} else {
								elecQtyObj.elecQty.currentMonthElecQty.details.thirtyOne = 0;
							}
						}
					}
				}
				notifyRefreshMonthElecView()

			});
		}
	}

	// 请求本周电量
	function requestElectQuantity4Week() {
		var elecQtyObj = _dataManager.getElectricQuantity();
		var applianceId = bridge.getCurrentApplianceID();
		var timeStr = new Date().Format("yyyy-MM-dd");
		if("" == elecQtyObj.elecQty.currentWeekElecQty.totalElecQty) {
			var functionParamers = {
				queryStrings: {
					"serviceUrl": "/electricity/queryElec"
				},
				transmitData: {
					"applianceId": applianceId,
					"type": 1,
					"date": timeStr
				}
			};
			var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
				var jsonString = JSON.stringify(messageBack);
				//TODO数据解析，绑定数据
				var jsonData = JSON.parse(jsonString);
				var errflag = jsonData.errorCode;
				//数据解析,更新videoUrl对象
				if(errflag == 0) {
					var returnData = jsonData.result.returnData;
					var errMsg = returnData.errMsg;
					var errCode = returnData.errCode;
					if(errCode == 0 && undefined != returnData.result && undefined != returnData.result.elecDetails) {
						var elecDetails = returnData.result.elecDetails;
						elecQtyObj.elecQty.currentWeekElecQty.details.one = elecDetails[0].value;
						elecQtyObj.elecQty.currentWeekElecQty.details.two = elecDetails[1].value;
						elecQtyObj.elecQty.currentWeekElecQty.details.three = elecDetails[2].value;
						elecQtyObj.elecQty.currentWeekElecQty.details.four = elecDetails[3].value;
						elecQtyObj.elecQty.currentWeekElecQty.details.five = elecDetails[4].value;
						elecQtyObj.elecQty.currentWeekElecQty.details.six = elecDetails[5].value;
						elecQtyObj.elecQty.currentWeekElecQty.details.seven = elecDetails[6].value;
						var totalEleQyt = elecDetails[0].value + elecDetails[1].value + elecDetails[2].value + elecDetails[3].value + elecDetails[4].value + elecDetails[5].value + elecDetails[6].value;
						elecQtyObj.elecQty.currentWeekElecQty.totalElecQty = totalEleQyt.toFixed(2);
					}
				}
				notifyRefreshElecView();
			});

		}
	}

	function requestRealTimePower() {
		var elecQtyObj = _dataManager.getElectricQuantity();
		var applianceId = bridge.getCurrentApplianceID();
		var timeStr = new Date().Format("yyyy-MM-dd");
		//请求实时功率，累计电量
		var cmdBytes = _dataParse.cmdCheckStatus(0);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			//TODO 修改elecQtyObj属性
			checkRecData = messageBack;
			if(checkRecData[10] == 0xC1) {
				var tt = makeformatTime(checkRecData[24], checkRecData[25], checkRecData[26], checkRecData[27], 0);
				checkRecData[10] = 0x00;
				elecQtyObj.realTimePower.runTime = tt;
				tt = makeformatTime(checkRecData[19], checkRecData[20], checkRecData[21], checkRecData[22], 0);
				elecQtyObj.realTimePower.totalRunTime = tt;

			}

		});

		cmdBytes = _dataParse.cmdCheckStatus(4);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			//TODO 修改elecQtyObj属性
			checkRecData = messageBack;
			if((checkRecData[10] == 0xC1) && (checkRecData[13] == 0x44)) {
				tt = makeformatPower(checkRecData[22], checkRecData[23], checkRecData[24], checkRecData[25], 1);
				elecQtyObj.realTimePower.runElecQty = tt;
				tt = makeformatPower(checkRecData[14], checkRecData[15], checkRecData[16], checkRecData[17], 1);
				elecQtyObj.elecQty.totalElecQty = tt;
				elecQtyObj.realTimePower.totalRunElecQty = tt;
				tt = makeformatPower(checkRecData[26], checkRecData[27], checkRecData[28], 0, 0);
				elecQtyObj.realTimePower.power = tt;
			}
			checkRecData[10] = 0x00;
			notifyRefreshElecView();

		});
	}

	function requestEcoRunningStatus() {
		var elecQtyObj = _dataManager.getElectricQuantity();
		var applianceId = bridge.getCurrentApplianceID();
		var timeStr = new Date().Format("yyyy-MM-dd");
		// 请求ECO运行信息
		if("" == elecQtyObj.ecoRunningStatus.EcoTime) {
			var tmpCheckTypeCount = 2; //查询属性个数
			var tmpValue = [];

			tmpValue[0] = 0x00; //高位  属性：ECO运行时间
			tmpValue[1] = 0x1e //低位

			tmpValue[2] = 0x00; //高位  属性：ECO运行电量
			tmpValue[3] = 0x1f; //低位

			var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				processNewProtocolDataAndNotifyRefreshView(messageBack);
				notifyRefreshElecView();
			});
		}
	}

	//新协议相关请求，控制

	/**
	 * 预冷预热
	 * @param isOpen:true 预冷预热功能打开，false预冷预热功能关闭
	 */
	this.controlSwitchPreColdHeat = function(isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x01;
		itemsBytes[1] = 0x02;
		itemsBytes[2] = 1; //属性长度
		if(isOpen) {
			itemsBytes[3] = 1;
		} else {
			itemsBytes[3] = 0;
		}
		_dataParse.setElectricHeatingButtonPressFlg(0);

		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 无风感功能切换
	 * @param isOpen:true 无风感功能打开，false 无风感功能关闭
	 * 无风感仅在制冷模式下有效
	 */
	this.controlSwitchNoWindFeel = function(isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getCurrentDevice().deviceStatus;
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x18;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(isOpen) {
			itemsBytes[3] = 1;
		} else {
			itemsBytes[3] = 0;
		}
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}
	
	this.requestNoWindFeelStatus = function() {		
			var tmpCheckTypeCount = 1; //查询属性个数
			var tmpValue = [];
			tmpValue[0] = 0x00; //高位  
			tmpValue[1] = 0x18; //低位

			var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				processNewProtocolDataAndNotifyRefreshView(messageBack);
			}, function(message) {});
		}

	/**
	 * 上下无风感功能切换
	 * @param {Boolean} upIsOpen:true 上无风感功能打开，false 上无风感功能关闭
	 * @param {Boolean} downIsOpen:true 上无风感功能打开，false 上无风感功能关闭
	 * 上下无风感仅在制冷模式下有效
	 */
	this.controlSwitchUpDownNoWindFeel = function(upIsOpen, downIsOpen) {
		var v = upIsOpen && downIsOpen ? 1 :
			upIsOpen && !downIsOpen ? 2 :
			!upIsOpen && downIsOpen ? 3 :
			0;
		if((upIsOpen || downIsOpen) == 1) {
			_dataParse.setNoPolarWindSpeedValue(102);
		}
		controlNewProtocalSingleProperty(0x18, 0x00, [v], function(data) {
			if(v == 1) {
				//上无风感、下无风感同时开启时，关闭左右风
				_dataManager.getCurrentDevice().deviceStatus.leftRighProducetWindStatus = false;
				_dataParse.setComfortWind0x3LH(0x00);
		        _dataParse.setComfortWind0x3RH(0x00);
		        _dataParse.setComfortWindDownState(0x00);
			}
			if(v == 2){
			_dataParse.setComfortWind0x3LH(0x00);
			_dataParse.setComfortWind0x3RH(0x00);
			}
            if(v == 3){
			_dataParse.setComfortWindDownState(0x00);
			}
		}, null);
	}

	/**
	 * 上下无风感查询
	 */
	this.requestUpDownNoWindFeelStatus = function() {
		var hasUpDownNoWindFeel = _dataManager.getCurrentDevice().deviceInfo.hasUpDownNoWindFeel;
		var hasNoWindFeel = _dataManager.getCurrentDevice().deviceInfo.hasNoWindFeel;
		if(hasUpDownNoWindFeel || hasNoWindFeel) {
			var tmpValue = [];
			tmpValue[0] = 0x00; //高位  
			tmpValue[1] = 0x18; //低位
			// tmpValue[0] = 0x00; //高位  
			// tmpValue[1] = 0x3D; //低位
			// tmpValue[2] = 0x00; //高位  
			// tmpValue[3] = 0x3E; //低位
			requestNewProtocalProperties(tmpValue, function(data) {
				processNewProtocolDataAndNotifyRefreshView(data);
			}, null);
		}
	}
	
	
	//自清洁控制
	this.controlSelfCleaning = function(isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getDeviceCleaningStatus().selfCleaning;
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x39;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(isOpen) {
			itemsBytes[3] = 1;
		} else {
			itemsBytes[3] = 0;
		}

		_dataParse.setEOCFunctionSwitch(0x00);
		_dataParse.setMobileTimerInfoSwitch(0x01);
		_dataParse.setTimerCloseSwitch(0x00);
		_dataParse.setTimerCloseAbsoluteHour(0x7f);
		_dataParse.setTimerCloseAbsoluteMinute(0x00);
		_dataParse.setPurifyingFunction(0x00);
		_dataParse.setNaturalWindFunctionSwitch(0x00);
		_dataParse.setComfortWind0x3LV(0x00);
		_dataParse.setComfortWind0x3RV(0x00);
		_dataParse.setComfortWind0x3LH(0x00);
		_dataParse.setComfortWind0x3RH(0x00);
		_dataParse.setKeepWarmSwitch(0x00);
		_dataParse.setPreventingCold(0x00);
		_dataParse.setWindBlowingSwitch(0x00);
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			selfCleanProcessing = true;
			//屏蔽10秒旧协议的上报，阻止错误的界面状态刷新
			setTimeout(function() {
				selfCleanProcessing = false;
			}, 10000);
			processNewProtocolDataAndNotifyRefreshView(messageBack);

		}, function(message) {
			processOperateFailCallBack(message);
		});
	}
	this.selfCleaningdeviceStatus = function() {
		_dataParse.setRunningState(0x00);
	}
	//自清洁	
//	function initSelfCleaningStatus() {
//		var hasSelfCleaning = _dataManager.getCurrentDevice().deviceInfo.hasSelfCleaning;
//		if(hasSelfCleaning) { //有自清洁
//			requestSelfCleaningValue();
//		}
//	}
	//自清洁功能查询
	this.requestSelfCleaningValue = function() {
		var hasSelfCleaning = _dataManager.getCurrentDevice().deviceInfo.hasSelfCleaning;
		if(hasSelfCleaning) {
			var tmpCheckTypeCount = 1; //查询属性个数
			var tmpValue = [];
			tmpValue[0] = 0x00; //高位  
			tmpValue[1] = 0x39; //低位

			var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				processNewProtocolDataAndNotifyRefreshView(messageBack);
			}, function(message) {});
		}
	}
	//风避人功能查询
	this.requestAvoidValue = function() {
		var hasChangesTemperature = _dataManager.getCurrentDevice().deviceInfo.hasChangesTemperature;
		if(hasChangesTemperature) {
			var tmpCheckTypeCount = 1; //查询属性个数
			var tmpValue = [];
			tmpValue[0] = 0x00; //高位  
			tmpValue[1] = 0x33; //低位

			var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				processNewProtocolDataAndNotifyRefreshView(messageBack);
			}, function(message) {});
		}
	}
	/**
	 * 请求室内湿度值
	 */
	this.requestHumidityValue = function() {
		var acDeviceType = _dataManager.getCurrentDevice().deviceInfo.deviceType;
		if(mdSmart.ACDataManager.ACDeviceType.KHB1 != acDeviceType &&
			mdSmart.ACDataManager.ACDeviceType.TAB12 != acDeviceType &&
			mdSmart.ACDataManager.ACDeviceType.TAB3 != acDeviceType &&
			mdSmart.ACDataManager.ACDeviceType.YB200 != acDeviceType &&
			mdSmart.ACDataManager.ACDeviceType.IQ100 != acDeviceType &&
			mdSmart.ACDataManager.ACDeviceType.IQ300 != acDeviceType&&
			mdSmart.ACDataManager.ACDeviceType.FA100 != acDeviceType&&
		    mdSmart.ACDataManager.ACDeviceType.FA200 != acDeviceType) { //KHB1	TA
			return false;
		}
		var tmpCheckTypeCount = 1; //查询属性个数
		var tmpValue = [];
		//室内湿度
		tmpValue[0] = 0x00; //高位  
		tmpValue[1] = 0x15; //低位

		var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processHumidityValueRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 请求儿童防着凉设置状态
	 */
	this.requestPreventColdDeviceStatus = function() {

		var acDeviceType = _dataManager.getCurrentDevice().deviceInfo.deviceType;
		if(mdSmart.ACDataManager.ACDeviceType.WEA != acDeviceType) { //儿童空调
			return false;
		}

		var tmpCheckTypeCount = 6; //查询属性个数
		var tmpValue = [];
		//制冷踢被子灵敏度
		tmpValue[0] = 0x04; //高位  
		tmpValue[1] = 0x10; //低位
		//制热踢被子灵敏度
		tmpValue[2] = 0x04; //高位	
		tmpValue[3] = 0x11;
		//制冷温度补偿值
		tmpValue[4] = 0x04; //高位 
		tmpValue[5] = 0x12;
		//制热温度补偿值
		tmpValue[6] = 0x04; //高位 
		tmpValue[7] = 0x13;
		//制冷上下限
		tmpValue[8] = 0x04; //高位 
		tmpValue[9] = 0x1b;
		//制热上下限
		tmpValue[10] = 0x04; //高位 
		tmpValue[11] = 0x1c;

		var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			_dataManager.resetCachePreventCold();
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}
		/**
	 * 请求专属功能设置状态
	 */
	this.requestExclusiveModeStatus = function() {
//		that.showLoading();
		var tmpCheckTypeCount = 1; //查询属性个数
		var tmpValue = [];
		//手势识别状态
		tmpValue[0] = 0x00; //高位 
		tmpValue[1] = 0x45;

		var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyRefreshIntelViewStatus();
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}
	//家人个数
	this.requestRequestFamilyStatus = function() {
		var tmpCheckTypeCount = 1; //查询属性个数
		var tmpValue = [];
		//手势识别状态
		tmpValue[0] = 0x00; //高位 
		tmpValue[1] = 0x44;
		
        var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyRefreshIntelViewStatus();
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}
	
	//查询PM2.5
	this.requestPMStatus = function() {
		var tmpCheckTypeCount = 1; //查询属性个数
		var tmpValue = [];
		//手势识别状态
		tmpValue[0] = 0x02; //高位 
		tmpValue[1] = 0x0B;
		
        var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyRefreshPMStatus();
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 请求安防功能设置状态
	 */
	this.requestSafeInvadeStatus = function() {

		var tmpCheckTypeCount = 1; //查询属性个数
		var tmpValue = [];
		//安防功能状态
		tmpValue[0] = 0x00; //高位  
		tmpValue[1] = 0x29; //低位
		//		//安防入侵
		//		tmpValue[2] = 0x00; //高位	
		//		tmpValue[3] = 0x2a;
		//		//入侵功能状态
		//		tmpValue[4] = 0x00; //高位 
		//		tmpValue[5] = 0x2c;
		//		//入侵录像状态
		//		tmpValue[6] = 0x00; //高位 
		//		tmpValue[7] = 0x2d;
		//		//人脸识别状态
		//		tmpValue[8] = 0x00; //高位 
		//		tmpValue[9] = 0x2e;
		//		//红外补光状态
		//		tmpValue[10] = 0x00; //高位 
		//		tmpValue[11] = 0x2f;
		//		//远程视频状态
		//		tmpValue[12] = 0x00; //高位 
		//		tmpValue[13] = 0x35;

		var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
			notifyRefreshIntrusionViewStatus();
		});
	}

	/**
	 * 安防功能切换
	 * @param isOpen:true 安防功能打开，false 安防功能关闭
	 */
	this.controlSecurityStatus = function(isOpen) {
		that.showLoading();
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x29;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(isOpen) {
			itemsBytes[3] = 1;
		} else {
			itemsBytes[3] = 0;
		}
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyRefreshIntrusionViewStatus();
		}, function(message) {
			processOperateFailCallBack(message);
			notifyRefreshIntrusionViewStatus();
		});
	}

	/**
	 * 入侵功能切换
	 * @param isOpen:true 入侵功能打开，false 入侵功能关闭
	 */
	this.controlIntrusionStatus = function(isOpen) {
		that.showLoading();
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x2c;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(isOpen) {
			itemsBytes[3] = 1;
		} else {
			itemsBytes[3] = 0;
		}
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 入侵录像功能切换
	 * @param isOpen:true 入侵录像功能打开，false 入侵录像功能关闭
	 */
	this.controlIntrusionVideoStatus = function(isOpen) {
		that.showLoading();
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x2d;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(isOpen) {
			itemsBytes[3] = 1;
		} else {
			itemsBytes[3] = 0;
		}
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 人脸识别功能切换
	 * @param isOpen:true 人脸识别功能打开，false 人脸识别功能关闭
	 */
	this.controlFaceRecognitionStatus = function(isOpen) {
		that.showLoading();
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x2e;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(isOpen) {
			itemsBytes[3] = 1;
		} else {
			itemsBytes[3] = 0;
		}
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 红外补光功能切换
	 * @param 1－－100:true 红外补光功能打开，0 红外补光功能关闭
	 */
	this.controlInfraredLightStatus = function(isOpen) {
		that.showLoading();
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x2f;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(isOpen) {
			itemsBytes[3] = 1;
		} else {
			itemsBytes[3] = 0;
		}
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 远程视频功能切换
	 * @param 1－－100:true 红外补光功能打开，0 红外补光功能关闭
	 */
	this.controlRemoteVideoStatus = function(isOpen) {
		that.showLoading();
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x35;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(isOpen) {
			itemsBytes[3] = 1;
		} else {
			itemsBytes[3] = 0;
		}
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 请求智能控制功能设置状态
	 */
	this.requestIntelligentControlStatus = function() {

		var tmpCheckTypeCount = 6; //查询属性个数
		var tmpValue = [];
		//无人节能状态
		tmpValue[0] = 0x00; //高位  
		tmpValue[1] = 0x30; //低位
		//智能控制状态
		tmpValue[2] = 0x00; //高位	
		tmpValue[3] = 0x31;
		//风向设定状态
		tmpValue[4] = 0x00; //高位 
		tmpValue[5] = 0x32;
		//智能风速状态
		tmpValue[6] = 0x00; //高位 
		tmpValue[7] = 0x33;
		//手势识别状态
		tmpValue[8] = 0x00; //高位 
		tmpValue[9] = 0x34;
		//手势开关机
		tmpValue[10] = 0x00; //高位 
		tmpValue[11] = 0x35;

		var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			_dataManager.newProtocolDataProcess(messageBack);
			notifyRefreshIntelViewStatus();
			notifyRefreshGestureRecognitionViewStatus();
			//			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}
	/**
	 * 请求风吹人风避人功能设置状态
	 */
	this.requestWindBlowWindCloseControlStatus = function() {
		var tmpCheckTypeCount = 1; //查询属性个数
		var tmpValue = [];
		//风向设定状态
		tmpValue[0] = 0x00; //高位 
		tmpValue[1] = 0x32;

		var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			_dataManager.newProtocolDataProcess(messageBack);
			notifyRefreshIntelViewStatus();
			notifyRefreshGestureRecognitionViewStatus();
			//			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 请求手势识别功能设置状态
	 */
	this.requestGestureControlStatus = function() {

		var tmpCheckTypeCount = 1; //查询属性个数
		var tmpValue = [];
		//手势识别状态
		tmpValue[0] = 0x00; //高位 
		tmpValue[1] = 0x34;

		var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 智能控制功能切换
	 * @param true 智能控制功能打开，false 智能控制功能关闭
	 */
	this.controlIntelligentStatus = function(isOpen) {
		that.showLoading();
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x31;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(isOpen) {
			itemsBytes[3] = 1;
		} else {
			itemsBytes[3] = 0;
		}
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			if(isOpen) {
				//关闭自然风
				_dataParse.setNaturalWindFunctionSwitch(0x00);
				//关闭上下摆风
				_dataParse.setComfortWind0x3LV(0x00);
				_dataParse.setComfortWind0x3RV(0x00);
				//关闭左右摆风
				_dataParse.setComfortWind0x3LH(0x00);
				_dataParse.setComfortWind0x3RH(0x00);
			}
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
			notifyRefreshIntelViewStatus();
		});
	}

	/**
	 * 无人节能功能切换
	 * @param true 无人节能功能打开，false 无人节能功能关闭
	 */
	this.controlEnergySavingStatus = function(isOpen, value1, value2, value3, value4, value5) {
		that.showLoading();
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x30;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 6; //属性长度
		if(isOpen) {
			itemsBytes[3] = 1;
		} else {
			itemsBytes[3] = 0;
		}
		itemsBytes[4] = value1;
		itemsBytes[5] = value2;
		itemsBytes[6] = value3;
		itemsBytes[7] = value4;
		itemsBytes[8] = value5;
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
			notifyRefreshIntelViewStatus();
		});
	}

	/**
	 * 风向设定功能切换
	 * @param 0 关闭 1 风吹人  2 风避人
	 */
	this.controlWindDirectionStatus = function(windDirectionValue) {
		that.showLoading();
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x32;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		itemsBytes[3] = windDirectionValue;
	
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
		if(windDirectionValue==1){
		_dataParse.setComfortWindDownState(0x01);
		_dataParse.setComfortWind0x3LH(0x01);
		_dataParse.setComfortWind0x3RH(0x01);
		_dataParse.setComfortWind0x3LV(0x01);
		_dataParse.setComfortWind0x3RV(0x01);
		_dataParse.setComfortWindDownControl(0x01);
		_dataParse.setKeepWarmSwitch(0x00);
		_dataParse.setPreventingCold(0x00);
		}
		if(windDirectionValue==2){
		_dataParse.setComfortWind0x3LH(0x00);
		_dataParse.setComfortWind0x3RH(0x00);
		_dataParse.setComfortWind0x3LV(0x00);
		_dataParse.setComfortWind0x3RV(0x00);
		_dataParse.setComfortWindDownState(0x00);
		_dataParse.setComfortWindDownControl(0x00);
		}
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyRefreshIntelViewStatus();
		}, function(message) {
			processOperateFailCallBack(message);
			notifyRefreshIntelViewStatus();
		});
	}
	/**
	 * 风向设定功能切换
	 * @param 0 关闭 1 风吹人 
	 */
	this.controlWindDirectionStatusOpenForFA100 = function(isOpen) {
		that.showLoading();
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x32;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(isOpen) {
			itemsBytes[3] = 1;
		_dataParse.setKeepWarmSwitch(0);
		_dataParse.setComfortWind0x3LH(0x01);
		_dataParse.setComfortWind0x3RH(0x01);
		_dataParse.setComfortWind0x3LV(0x01);
		_dataParse.setComfortWind0x3RV(0x01);
		_dataParse.setNaturalWindFunctionSwitch(0x00);
		_dataParse.setPreventingCold(0x00);
		_dataParse.setWindBlowingSwitch(0);
		} else {
			itemsBytes[3] = 0;
		}
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyRefreshIntelViewStatus();
		}, function(message) {
			processOperateFailCallBack(message);
			notifyRefreshIntelViewStatus();
		});
	}
	
	/**
	 * 风向设定功能切换
	 * @param 0 关闭 1 风避人
	 */
	this.controlWindDirectionStatuscloseForFA100 = function(isOpen) {
		that.showLoading();
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x33;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(isOpen) {
			itemsBytes[3] = 1;
		_dataParse.setKeepWarmSwitch(0);
		_dataParse.setPreventingCold(0);
		_dataParse.setComfortWind0x3LH(0x00);
		_dataParse.setComfortWind0x3RH(0x00);
		_dataParse.setComfortWind0x3LV(0x00);
		_dataParse.setComfortWind0x3RV(0x00);
		_dataParse.setNaturalWindFunctionSwitch(0x00);
		_dataParse.setWindBlowingSwitch(0);
		} else {
			itemsBytes[3] = 0;
		}
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyRefreshIntelViewStatus();
		}, function(message) {
			processOperateFailCallBack(message);
			notifyRefreshIntelViewStatus();
		});
	}

	/**
	 * 智能风速调节功能切换(不吹人功能)
	 * @param 0 关闭 1 开启
	 */
	this.controlWindSpeedStatus = function(isOpen) {
		that.showLoading();
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x33;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(isOpen) {
			itemsBytes[3] = 1;
		_dataParse.setComfortWindDownState(0x01);
		_dataParse.setComfortWind0x3LH(0x01);
		_dataParse.setComfortWind0x3RH(0x01);
		_dataParse.setComfortWind0x3LV(0x01);
		_dataParse.setComfortWind0x3RV(0x01);
		_dataParse.setComfortWindDownControl(0x01);
		_dataParse.setKeepWarmSwitch(0x00);
		_dataParse.setPreventingCold(0x00);
		} else {
			itemsBytes[3] = 0;
		}
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyRefreshIntelViewStatus();
			if(isOpen) { //新旧协议状态同步
				//关闭上下摆风
//				_dataParse.setComfortWind0x3LV(0x00);
//				_dataParse.setComfortWind0x3RV(0x00);
				// //关闭左右摆风
				// _dataParse.setComfortWind0x3LH(0x00);
				// _dataParse.setComfortWind0x3RH(0x00);
			}
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}
		/**
	 * 智能风感设定功能切换
	 * @param 关闭(风吹人／风避人／智慧风) 开启 默认开风吹人
	 */
	this.controlSmartWindFeelingStatus = function(windDirectionValue) {
		that.showLoading();
		var itemsNum = 2;
		var itemsBytes = [];
		itemsBytes[0] = 0x32;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(windDirectionValue){
		itemsBytes[3] = 1;
		_dataParse.setComfortWindDownState(0x01);
		_dataParse.setComfortWind0x3LH(0x01);
		_dataParse.setComfortWind0x3RH(0x01);
		_dataParse.setComfortWind0x3LV(0x01);
		_dataParse.setComfortWind0x3RV(0x01);
		_dataParse.setComfortWindDownControl(0x01);
		}else{
		itemsBytes[3] = 0;	
		}		
		itemsBytes[4] = 0x33;
		itemsBytes[5] = 0x00;
		itemsBytes[6] = 1; //属性长度
	    itemsBytes[7] = 0;
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyRefreshIntelViewStatus();
		}, function(message) {
			processOperateFailCallBack(message);
			notifyRefreshIntelViewStatus();
		});
	}
	/**
	 * 不吹人功能查询(不吹人功能)
	 */
	this.requestWindSpeedStatus = function() {
		var hasPreventStraightLineWind = _dataManager.getCurrentDevice().deviceInfo.hasPreventStraightLineWind;
		if(hasPreventStraightLineWind) {
			var tmpCheckTypeCount = 1; //查询属性个数
			var tmpValue = [];
			tmpValue[0] = 0x00; //高位  
			tmpValue[1] = 0x33; //低位

			var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				processNewProtocolDataAndNotifyRefreshView(messageBack);
			}, function(message) {});
		}
	}

	/**
	 * 手势识别功能切换
	 * @param 0 关闭 1 开启
	 */
	this.controlGestureRecognitionStatus = function(isOnOff, isDirection) {
		that.showLoading();
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x34;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 2; //属性长度
		itemsBytes[3] = isOnOff;
		itemsBytes[4] = isDirection;
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
			notifyRefreshGestureRecognitionViewStatus();
		});
	}
	/**
	 * 专属功能切换
	 * @param 0 关闭 1 开启
	 */
	this.controlExclusiveModeStatus = function(isOpen) {
		that.showLoading();
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x45;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(isOpen) {
			itemsBytes[3] = 1;
		} else {
			itemsBytes[3] = 0;
		}
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyRefreshIntelViewStatus();
		}, function(message) {
			processOperateFailCallBack(message);
			notifyRefreshGestureRecognitionViewStatus();
		});
	}

	//停止基准校准
	this.stopCalibrationState = function() {
		var cmdValue = []; //属性命令
		cmdValue[0] = 0x01;
		cmdValue[1] = 0x04;
		var msgValueLength = 1; //属性长度
		var msgValue = [];
		msgValue[0] = 0;
		var cmdBytes = _dataParse.cmdNewVer(cmdValue, msgValueLength, msgValue);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			var queryFirstResult = messageBack;
			that.queryCalibrationState();
			//			that.queryCalibrationValue()
			//			if (queryFirstResult[14] == 0) {
			//				processStopCalibration();
			//			} else {
			//				that.initQueryStrongPreventState();
			//			}
		});
	}

	// 开启基准校准
	this.startCalibrationState = function() {
		var cmdValue = []; //属性命令
		cmdValue[0] = 0x01;
		cmdValue[1] = 0x04;
		var msgValueLength = 1; //属性长度
		var msgValue = [];
		msgValue[0] = 2;
		var cmdBytes = _dataParse.cmdNewVer(cmdValue, msgValueLength, msgValue);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			var queryFirstResult = messageBack;
			if(queryFirstResult[14] == 0) {
				var cmdValue = []; //属性命令
				cmdValue[0] = 0x04;
				cmdValue[1] = 0x08;
				var tmpCheckTypeCount = 1; //属性长度

				var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, cmdValue);

				var cmdID = bridge.startCmdProcess(cmdBytes, function(messageBack) {
					if(messageBack[14] == 0) {
						processCalibrationData(messageBack);
					}
				});
			} else {
				processCalibrationDataAfterFail();
			}
		}, function(errCode) {
			if(errCode == '-1') {
				processCalibrationDataAfterFail();
			}
		});
	};

	/**
	 * 基准校准结果查询
	 */
	this.queryCalibrationValue = function() {
		var cmdValue = []; //属性命令
		cmdValue[0] = 0x04;
		cmdValue[1] = 0x02;
		cmdValue[2] = 0x04;
		cmdValue[3] = 0x03;
		cmdValue[4] = 0x04;
		cmdValue[5] = 0x04;
		cmdValue[6] = 0x04;
		cmdValue[7] = 0x05;
		cmdValue[8] = 0x04;
		cmdValue[9] = 0x07;
		var tmpCheckTypeCount = 5; //属性长度

		var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, cmdValue);

		var cmdID = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			//			var ifGetResult = ifGetDataResult(messageBack);
			//			if (ifGetResult) {
			processCalibrationData(messageBack);
			//			} else{
			//				that.queryCalibrationValue();
			//			}
		}, function(errCode) {
			if(errCode == -1) {
				that.queryCalibrationValue();
			}
		});
	}

	/**
	 * 基准校准查询
	 */
	this.queryCalibrationState = function() {
		//按钮处理方法
		if(_dataManager.getCalibration.queryState == 0) {
			return false;
		}

		var cmdValue = []; //属性命令
		cmdValue[0] = 0x04;
		cmdValue[1] = 0x06;
		var msgValueLength = 1; //属性长度
		var cmdBytes = _dataParse.cmdNewVerForCheck(msgValueLength, cmdValue);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			var queryFirstResult = messageBack;
			if(queryFirstResult[14] == 0 && queryFirstResult[16] == 1) {
				that.queryCalibrationValue();
			} else {
				that.queryCalibrationState();
			}
		}, function(errCode) {
			if(errCode == -1) {
				that.queryCalibrationState();
			}
		});
	}

	//停止强力防霉
	this.stopStrongPreventState = function() {
		var cmdValue = []; //属性命令
		cmdValue[0] = 0x01;
		cmdValue[1] = 0x04;
		var msgValueLength = 1; //属性长度
		var msgValue = [];
		msgValue[0] = 0;
		var cmdBytes = _dataParse.cmdNewVer(cmdValue, msgValueLength, msgValue);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			var queryFirstResult = messageBack;
			that.queryStrongPreventState();
			//			that.queryStrongPreventValue();
			//			if (queryFirstResult[14] == 0) {
			//				processStopStrongPrevent();
			//			} else {
			//				that.initQueryStrongPreventState();
			//			}
		});
	}

	// 开启强力防霉
	this.startStrongPreventState = function() {
		var cmdValue = []; //属性命令
		cmdValue[0] = 0x01;
		cmdValue[1] = 0x04;
		var msgValueLength = 1; //属性长度
		var msgValue = [];
		msgValue[0] = 1;
		var cmdBytes = _dataParse.cmdNewVer(cmdValue, msgValueLength, msgValue);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			setTimeout(function() {
				var queryFirstResult = messageBack;
				if(queryFirstResult[14] == 0) {
					var cmdValue = []; //属性命令
					cmdValue[0] = 0x04;
					cmdValue[1] = 0x08;
					var tmpCheckTypeCount = 1; //属性长度

					var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, cmdValue);

					var cmdID = bridge.startCmdProcess(cmdBytes, function(messageBack) {
						if(messageBack[14] == 0) {
							processStrongPreventData(messageBack);
						}
					});
				} else {
					processStrongPreventDataAfterFail();
				}
			}, 1000);
		}, function(errCode) {
			if(errCode == "-1") {
				processStrongPreventDataAfterFail();
			}
		});
	};

	/**
	 * 强力防霉结果查询
	 */
	this.queryStrongPreventValue = function() {
		//0406屏蔽
		//		if (_dataManager.getStrongPrevent().queryState == 0) {
		//			return false;
		//		}

		var cmdValue = []; //属性命令
		cmdValue[0] = 0x04;
		cmdValue[1] = 0x02;
		cmdValue[2] = 0x04;
		cmdValue[3] = 0x03;
		cmdValue[4] = 0x04;
		cmdValue[5] = 0x04;
		cmdValue[6] = 0x04;
		cmdValue[7] = 0x05;
		cmdValue[8] = 0x04;
		cmdValue[9] = 0x07;
		var tmpCheckTypeCount = 5; //属性长度

		var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, cmdValue);

		var cmdID = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			//			var ifGetResult = ifGetDataResult(messageBack);
			//			if (ifGetResult) {
			processStrongPreventData(messageBack);
			//			} else{
			//				that.queryStrongPreventValue();
			//			}
		}, function(errCode) {
			if(errCode == -1) {
				that.queryStrongPreventValue();
			}
		});
	}
	/**
	 * 防冷风控制
	 */
	this.controlColdWindStatus = function(isOpen) {
		that.showLoading();
		// var deviceStatus = _dataManager.getDeviceColdWindStatus();
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x3a;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		itemsBytes[3] = isOpen ? 1 : 0; // deviceStatus.coldWind;

		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
//			    alert("flfkongz==="+cmdBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
//			 	    alert("flf return==="+messageBack);
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyControlColdWindStatus();
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}
	/**
	 * 天气播报控制
	 */
	this.controlWeatherReportStatus = function(isOpen) {
		that.showLoading();
		var deviceStatus = _dataManager.getDeviceWeatherReportStatus().weatherReport;
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x3b;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(isOpen) {
			itemsBytes[3] = 0;
		} else {
			itemsBytes[3] = 1;
		}

		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		//	    alert("tqbbkongz==="+cmdBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			// 	    alert("tqbb return==="+messageBack);
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyControlWeatherReportStatus();
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	/**
	 * 定时天气播报控制
	 */
	this.controlTimingWeatherStatus = function() {
		that.showLoading();
		var timingWeatherReportState = _dataManager.getTimingWeatherReportState();
		var itemsNum = 1;
		var itemsBytes = [];
		itemsBytes[0] = 0x3c;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 7; //属性长度
		itemsBytes[3] = timingWeatherReportState.timingWeatherReportSwitch;
		itemsBytes[4] = 0xff;
		itemsBytes[5] = 0xff;
		itemsBytes[6] = 0xff;
		itemsBytes[7] = 0xff;
		itemsBytes[8] = 0xff;
		itemsBytes[9] = 0xff;

		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		//	    alert("dsbbbbb==="+cmdBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			// 	    alert("dsbbbb return==="+messageBack);
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyControlTimingWeatherStatus();
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}
	/**
	 * 语音控制
	 */
	this.controlVoiceStatus = function() {
		that.showLoading();
		var voiceCurrentStatus = _dataManager.getVoiceState();
		var itemsNum = 1;
		var itemsBytes = [];
		itemsBytes[0] = 0x20;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 20; //属性长度
		itemsBytes[3] = voiceCurrentStatus.voiceBroadcastStatus;
		itemsBytes[4] = 0xff;
		itemsBytes[5] = voiceCurrentStatus.toneStatus;
		itemsBytes[6] = voiceCurrentStatus.voiceTimeLength;
		itemsBytes[7] = 0xff;
		itemsBytes[8] = 0xff;
		itemsBytes[9] = 0xff;
		itemsBytes[10] = 0xff;
		itemsBytes[11] = 0xff;

		itemsBytes[12] = 0xff;
		itemsBytes[13] = 0xff;
		itemsBytes[14] = 0xff;
		itemsBytes[15] = 0xff;
		itemsBytes[16] = 0xff;
		itemsBytes[17] = 0xff;
		itemsBytes[18] = 0xff;
		itemsBytes[19] = 0xff;
		itemsBytes[20] = 0xff;
		itemsBytes[21] = 0xff;
		itemsBytes[22] = 0xff;

		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		//	    alert("bbbbb==="+cmdBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			// 	    alert("bbbb return==="+messageBack);
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyControlVoiceStatus();
		}, function(message) {
			processOperateFailCallBack(message);
			//			notifyControlVoiceStatus();
		});
	}

	/**
	 * 音量控制
	 */
	this.controlVolumeStatus = function(soundValue) {
		that.showLoading();
		var volumeStatus = _dataManager.getVolumeState();
		var itemsNum = 1;
		var itemsBytes = [];
		itemsBytes[0] = 0x24;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 4; //属性长度
		itemsBytes[3] = volumeStatus.volumeControlType;
		itemsBytes[4] = volumeStatus.manualAdjustment * 20;
		itemsBytes[5] = 20;
		itemsBytes[6] = 80;
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		//	    alert("eeee==="+cmdBytes+"\n aaaa=="+itemsBytes[4]);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			//	    alert("eeee return==="+messageBack);
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyControlVoiceStatus();
		}, function(message) {
			processOperateFailCallBack(message);

		});
	}
	
	/**
	 * 冷热感控制
	 */
	this.controlColdHotStatusForFA100 = function(coldHotSwitch) {
		that.showLoading();
		var ColdHotStatus = _dataManager.getColdHotState();
		//  	alert(ColdHotStatus);
		var itemsNum = 2;
		var itemsBytes = [];
		itemsBytes[0] = 0x21;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 8; //属性长度	
		itemsBytes[3] = coldHotSwitch;
		itemsBytes[4] = ColdHotStatus.coldHotStall;
		itemsBytes[5] = 0xff;
		itemsBytes[6] = 0xff;
		itemsBytes[7] = 0xff;
		itemsBytes[8] = 0xff;
		itemsBytes[9] = 0xff;
		itemsBytes[10] = 0xff;
		itemsBytes[11] = 0x32;
		itemsBytes[12] = 0x00;
		itemsBytes[13] = 1; //属性长度
		itemsBytes[14] = 0;
		if(ColdHotStatus.coldHotSwitch==0) {
			_dataParse.setRunningState(0x01);
			//		_dataParse.setSetMode(0x01);
			_dataParse.setSetTemperate(10, 0x00);
			_dataManager.getCurrentDevice().deviceStatus.temperatureInteger = 26;
			_dataManager.getCurrentDevice().deviceStatus.temperatureDecimal = 0;
			_dataParse.setPreventingCold(0x00);
			_dataManager.getDeviceCleaningStatus().selfCleaning=false;
			_dataManager.getCurrentDevice().deviceStatus.selfCleaningStatus=false;
			_dataParse.setKeepWarmSwitch(0x00);
			_dataParse.setEOCFunctionSwitch(0x00);
		}
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
//		console.log("知冷暖"+cmdBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
//			console.log("知冷暖返回"+messageBack);
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyControlColdHotStatus();
			notifyRefreshIntelViewStatus();
		}, function(message) {
			processOperateFailCallBack(message);
			notifyControlColdHotStatus();
			notifyRefreshIntelViewStatus();
		});
	}
	/**
	 * 冷热感控制
	 */
	this.controlColdHotStatus = function(coldHotSwitch) {
		that.showLoading();
		var ColdHotStatus = _dataManager.getColdHotState();
		//  	alert(ColdHotStatus);
		var itemsNum = 1;
		var itemsBytes = [];
		itemsBytes[0] = 0x21;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 8; //属性长度	
		itemsBytes[3] = coldHotSwitch;
		itemsBytes[4] = ColdHotStatus.coldHotStall;
		itemsBytes[5] = 0xff;
		itemsBytes[6] = 0xff;
		itemsBytes[7] = 0xff;
		itemsBytes[8] = 0xff;
		itemsBytes[9] = 0xff;
		itemsBytes[10] = 0xff;
		if(ColdHotStatus.coldHotSwitch == 0) {
			_dataParse.setRunningState(0x01);
			//		_dataParse.setSetMode(0x01);
			_dataParse.setSetTemperate(10, 0x00);
			_dataManager.getCurrentDevice().deviceStatus.temperatureInteger = 26;
			_dataManager.getCurrentDevice().deviceStatus.temperatureDecimal = 0;
		}
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyControlColdHotStatus();
		}, function(message) {
			processOperateFailCallBack(message);
			notifyControlColdHotStatus();
		});
	}
	this.controlColdHotStatus1 = function() {
		that.showLoading();
		var ColdHotStatus = _dataManager.getColdHotState();
		var itemsNum = 1;
		var itemsBytes = [];
		itemsBytes[0] = 0x21;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 8; //属性长度	
		itemsBytes[3] = ColdHotStatus.coldHotSwitch;
		itemsBytes[4] = ColdHotStatus.coldHotStall;
		itemsBytes[5] = 0xff;
		itemsBytes[6] = 0xff;
		itemsBytes[7] = 0xff;
		itemsBytes[8] = 0xff;
		itemsBytes[9] = 0xff;
		itemsBytes[10] = 0xff;

		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		//	    alert("eeee==="+cmdBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			// 	    alert("eeee return==="+messageBack);
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyControlColdHotStatus();
		}, function(message) {
			processOperateFailCallBack(message);
			notifyControlColdHotStatus();
		});
	}

	/**
	 * 强力防霉查询
	 */
	this.queryStrongPreventState = function() {
		//按钮处理方法
		if(_dataManager.getStrongPrevent().queryState == 0) {
			return false;
		}

		var cmdValue = []; //属性命令
		cmdValue[0] = 0x04;
		cmdValue[1] = 0x06;
		var msgValueLength = 1; //属性长度
		var cmdBytes = _dataParse.cmdNewVerForCheck(msgValueLength, cmdValue);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			var queryFirstResult = messageBack;
			if(queryFirstResult[14] == 0 && queryFirstResult[16] == 1) {
				that.queryStrongPreventValue();
			} else {
				that.queryStrongPreventState();
			}
		}, function(errCode) {
			if(errCode == -1) {
				that.queryStrongPreventState();
			}
		});
	}

	function initSecurityStatus() {
		var hasSecutiry = _dataManager.getCurrentDevice().deviceInfo.hasSafeInvade;
		if(hasSecutiry) {
			var tmpCheckTypeCount = 1; //查询属性个数
			var tmpValue = [];
			//安防功能状态
			tmpValue[0] = 0x00; //高位  
			tmpValue[1] = 0x29; //低位

			var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				processNewProtocolDataAndNotifyRefreshView(messageBack);
			}, function(message) {

			});
		};
	}

	function initPrepareColdOrHeat() {
		var hasReadColdOrHot = _dataManager.getCurrentDevice().deviceInfo.hasReadyColdOrHot;
		if(hasReadColdOrHot) { //有预冷预热
			requestPrepareColdOrHeatStatus();
		}
	}

	function requestPrepareColdOrHeatStatus() {
		var tmpCheckTypeCount = 1; //查询属性个数
		var tmpValue = [];
		//预冷预热
		tmpValue[0] = 0x02; //高位  
		tmpValue[1] = 0x01; //低位

		var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			//			processOperateFailCallBack(message);
		});
	}
	//语音功能查询
	this.initVoiceStatus = function() {
		var hasVoice = _dataManager.getCurrentDevice().deviceInfo.hasVoice;
		if(hasVoice) {
			var tmpCheckTypeCount = 2; //查询属性个数
			var tmpValue = [];
			//语音功能状态
			tmpValue[0] = 0x00; //高位  
			tmpValue[1] = 0x20; //低位
			//音量功能状态
			tmpValue[2] = 0x00; //高位  
			tmpValue[3] = 0x24; //低位
			var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
			//			alert("yuyin"+cmdBytes);
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				//				alert("fyuyin"+messageBack);
				processNewProtocolDataAndNotifyRefreshView(messageBack);
				notifyControlVoiceStatus();
			}, function(message) {
				notifyControlVoiceStatus();
			});
		}
	}

	function initColdeHotStatus() {
		var hasColdHot = _dataManager.getCurrentDevice().deviceInfo.hasColdHot;
		if(hasColdHot) { //有冷热
			requestInitColdeHotStatus();
		}
	}
	//冷热感功能查询
	this.requestInitColdeHotStatus = function() {
		var hasColdHoty = _dataManager.getCurrentDevice().deviceInfo.hasColdHot;
		//		alert(ColdeHot);
		if(hasColdHoty) {
			var tmpCheckTypeCount = 1; //查询属性个数
			var tmpValue = [];
			//冷热感功能状态
			tmpValue[0] = 0x00; //高位  
			tmpValue[1] = 0x21; //低位

			var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				processNewProtocolDataAndNotifyRefreshView(messageBack);
				notifyControlColdHotStatus();
			}, function(message) {
				notifyControlColdHotStatus();
			});
		}
	}
	//冷热感功能查询
	this.requestInitColdeHotStatusForFA100 = function() {
		var hasColdHoty = _dataManager.getCurrentDevice().deviceInfo.hasColdHot;
		//		alert(ColdeHot);
			var tmpCheckTypeCount = 1; //查询属性个数
			var tmpValue = [];
			//冷热感功能状态
			tmpValue[0] = 0x00; //高位  
			tmpValue[1] = 0x21; //低位

			var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				processNewProtocolDataAndNotifyRefreshView(messageBack);
				notifyControlColdHotStatus();
			}, function(message) {
				notifyControlColdHotStatus();
			});
	}
	this.requestWristbandStatus = function() {
		var tmpCheckTypeCount = 2; //查询属性个数
		var tmpValue = [];
		tmpValue[0] = 0x05; //高位  
		tmpValue[1] = 0x07; //低位

		tmpValue[2] = 0x05; //高位  
		tmpValue[3] = 0x08; //低位

		var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {

		});
	}
		//过滤网校准控制
	this.controlScreenCalibration = function() {
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x0A;
		itemsBytes[1] = 0x04;
		itemsBytes[2] = 1; //属性长度
		itemsBytes[3] = 1;

		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			refreshscreenCalibrationStatus();
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}
	//过滤网校准查询
	this.screenCalibrationStatus = function() {
			var tmpCheckTypeCount = 1; //查询属性个数
			var tmpValue = [];
			//语音功能状态
			tmpValue[0] = 0x04; //高位  
			tmpValue[1] = 0x0A; //低位
			var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
//			alert("查"+cmdBytes);
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
//			alert("返"+messageBack);	
				processNewProtocolDataAndNotifyRefreshView(messageBack);
				refreshscreenCalibrationStatus();
			}, function(message) {
				
			});
	}
	
	
	//过滤网脏堵检测传感器查询
	this.filterDirtyPluggingStatus = function() {
			var tmpCheckTypeCount = 1; //查询属性个数
			var tmpValue = [];
			//语音功能状态
			tmpValue[0] = 0x04; //高位  
			tmpValue[1] = 0x09; //低位
			var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				processNewProtocolDataAndNotifyRefreshView(messageBack);
			}, function(message) {
				
			});
	}
	
	//防冷风查询、天气播报、定时天气播报
	this.initColdWindStatus = function() {
		var hasUpDownNoWindFeel = _dataManager.getCurrentDevice().deviceInfo.hasUpDownNoWindFeel;
		if(hasUpDownNoWindFeel) {
		var tmpCheckTypeCount = 3; //查询属性个数
		var tmpValue = [];
		//防冷风查询
		tmpValue[0] = 0x00;
		tmpValue[1] = 0x3a;
		//天气播报
		tmpValue[2] = 0x00;
		tmpValue[3] = 0x3b;
		//定时天气播报
		tmpValue[4] = 0x00;
		tmpValue[5] = 0x3c;
		var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyControlColdWindStatus();
			notifyControlWeatherReportStatus();
			notifyControlTimingWeatherStatus();
		}, function(message) {
			notifyControlColdWindStatus();
			notifyControlWeatherReportStatus();
			notifyControlTimingWeatherStatus();
		});
		}
	}

	//服务器相关请求，控制

	/**
	 * 获取美粉圈，售后，商城url
	 */
	this.requestExternalUrl = function() {

		var mideaUrl = _dataManager.getMideaStoreUrl();
		if(undefined != mideaUrl && "" != mideaUrl && null != mideaUrl) {
			return false;
		}
		var functionParamers = {
			queryStrings: {
				"serviceUrl": "/appliance/getOurterUrlInfo"
			},
			transmitData: {
				"userId": 0,
				"familyId": 0,
				"roomId": "1",
			},
		};
		var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
			var mideaStoreUrlKey = "shopUrl";
			var mideaAfterSaleUrlKey = "afterSaleUrl";
			var mideaFansUrlKey = "mideaFansUrl"
			var jsonString = JSON.stringify(messageBack);
			var resultEnv = resultDataParse(jsonString);
			if(null != resultEnv) {
				for(var i = 0; i < resultEnv.length; i++) {
					var rItem = resultEnv[i];
					var urlKey = rItem.key;
					if(mideaStoreUrlKey == rItem.key) {
						_dataManager.setMideaStoreUrl(rItem.val);
						continue;
					}
					if(mideaAfterSaleUrlKey == rItem.key) {
						_dataManager.setMideaAfterSaleUrl(rItem.val);
						continue;
					}
					if(mideaFansUrlKey == rItem.key) {
						_dataManager.setMideaFanUrl(rItem.val);
						continue;
					}
				}
				//				notifyObtainExternalUrl();
			}
		});
	}

	/**
	 * 请求视频播放地址URL链接
	 */
	this.requestVideoUrl = function() {

		var productInstructionUrl = _dataManager.getInstructionsUrls().ProductInstruction;
		if(undefined != productInstructionUrl && "" != productInstructionUrl && null != productInstructionUrl) {
			return false;
		}
		var productModel = "";
		var devSN = bridge.getCurrentDevSN(); //获取家电SN
		if("" != devSN) {
			if('32' == devSN.length) {
				productModel = devSN.substring(12, 17);
			} else {
				productModel = devSN.substring(6, 11);
			}
		}
		var functionParamers = {
			queryStrings: {
				"serviceUrl": "/appliance/getApplianceAllVideoURL"
			},
			transmitData: {
				"applianceModel": productModel,
				"type": 1
			}
		};

		var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			var jsonData = JSON.parse(jsonString);
			var errflag = jsonData.errorCode;
			//数据解析,更新videoUrl对象
			if(errflag == 0) {
				var returnData = jsonData.result.returnData;
				var errMsg = returnData.errMsg;
				var errCode = returnData.errCode;
				var reponsevideoUrl = {
					ProductInstruction: "",
					DailyUse: "",
					CleanMaintain: "",
					ContactUs: "",
					WifiControl: "",
					IntactTotal: ""
				}
				if(errCode == 0) {
					result = returnData.result;
					for(var i in result) {
						var videoUrlObj = result[i];
						if("0" == videoUrlObj.videoType) {
							reponsevideoUrl.IntactTotal = videoUrlObj.videoURL;
						} else if("1" == videoUrlObj.videoType) {
							reponsevideoUrl.ProductInstruction = videoUrlObj.videoURL;
						} else if("2" == videoUrlObj.videoType) {
							reponsevideoUrl.DailyUse = videoUrlObj.videoURL;
						} else if("3" == videoUrlObj.videoType) {
							reponsevideoUrl.CleanMaintain = videoUrlObj.videoURL;
						} else if("4" == videoUrlObj.videoType) {
							reponsevideoUrl.ContactUs = videoUrlObj.videoURL;
						} else if("5" == videoUrlObj.videoType) {
							reponsevideoUrl.WifiControl = videoUrlObj.videoURL;
						}
					}
					_dataManager.updateInstructionURL(reponsevideoUrl);
					notifyObtainVideoUrl();
				}
			}
		});
	}

	/**
	 * 请求FAQ 内容
	 */
	this.requestFAQContent = function() {

		var FAQContent = _dataManager.getFAQContent();
		if(undefined != FAQContent && "" != FAQContent && {} != FAQContent && null != FAQContent) {
			return false;
		}

		var functionParamer = {
			queryStrings: {
				"serviceUrl": "/appliance/getApplianceKnowledge"
			},
			transmitData: {
				"type": "1", //  type:1  空调
				"applianceModel": "", //  applianceModel   五位数机型产码
				"quesType": "2", //  quesType:1  使用技巧    2  常见问题    3  故障代码
				"keyword": "" //  keyword  搜索关键字
			}
		};
		var cmdId = bridge.requestDataTransmit(functionParamer, function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			var jsonData = JSON.parse(jsonString);
			var errflag = jsonData.errorCode;
			var result = "";
			if(errflag == 0) {
				var returnData = jsonData.result.returnData;
				var errMsg = returnData.errMsg;
				var errCode = returnData.errCode;
				if(errCode != 0) {} else {
					result = returnData.result;
				}
			} else {

			}
			if(result != "") {
				//TODO更新数据
				_dataManager.setFAQContent(result);
				//				notifyObtainProblemDetailContent();
			} else {

			}
		});
	}

	/**
	 * 请求儿童防着凉APNS状态
	 */
	this.requestPreventColdAPNSRemindStatus = function() {
		var acDeviceType = _dataManager.getCurrentDevice().deviceInfo.deviceType;
//		if(mdSmart.ACDataManager.ACDeviceType.WEA != acDeviceType) { //儿童空调
//			return false;
//		}

		var applianceId = bridge.getCurrentApplianceID();
		var functionParamers = {
			queryStrings: {
				"serviceUrl": "/wisdomEye/getRemindStatus"
			},
			transmitData: {
				"applianceId": parseInt(applianceId)
			},
		};
		var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			var jsonData = JSON.parse(jsonString);
			var errflag = jsonData.errorCode;
			var result = "";
			if(errflag == 0) {
				var returnData = jsonData.result.returnData;
				var errMsg = returnData.errMsg;
				var errCode = returnData.errCode;
				if(errCode == 0) {
					childKick = returnData.result.status;
					if(2 == childKick) { //2 表示开启，1表示关闭
						_dataManager.setPreventColdAPNSRemind(true);
					} else {
						_dataManager.setPreventColdAPNSRemind(false);
					}
				}
			}
			notifyRefreshPreventColdViewStatus();
		}, function(message) {
			processOperateFailCallBack(message);
			notifyRefreshPreventColdViewStatus();
		});
	}

	/**
	 * 请求阶梯降温状态
	 */
	this.requestLadderControlStatus = function() {
		var applianceId = bridge.getCurrentApplianceID();
		var functionParamers = {
			queryStrings: {
				"serviceUrl": "/ladderTempControl/querryLadderTempControl"
			},
			transmitData: {
				"applianceId": parseInt(applianceId)
			},
		};
		var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			var jsonData = JSON.parse(jsonString);
			var errflag = jsonData.errorCode;
			var result = "";
			if(errflag == 0) {
				var returnData = jsonData.result.returnData;
				var errCode = returnData.errCode;
				if(errCode == 0) {
					result = returnData.result.func;
					if(1 == result) { //1 表示开启
						_dataManager.setLadderControlStatus(true);
						_dataParse.setSleepModeSwitch(0);
						_dataParse.setPMVFunction(0);
						_dataManager.closeCurrentDevicePMV();
						_dataParse.setNaturalWindFunctionSwitch(0);
						_dataParse.setEOCFunctionSwitch(0);
						_dataManager.closeNoWindFeelECONaturalWind();
					} else {
						_dataManager.setLadderControlStatus(false);
					}
					notifyRefreshLadderControlStatus();
				}
			}
		}, function(message) {
			processOperateFailCallBack(message);
			notifyRefreshLadderControlStatus();
		});
	}

	/**
	 * 阶梯降温功能切换
	 * @param {Boolean} isOpen true:打开，false：关闭
	 */
	this.controlLadderControlStatus = function(isOpen) {
		that.showLoading();
		var queryStr = undefined;
		var applianceId = bridge.getCurrentApplianceID();
		var functionParamers = undefined;
		var setTemp = _dataManager.getCurrentDevice().deviceStatus.temperatureInteger +
			_dataManager.getCurrentDevice().deviceStatus.temperatureDecimal;
		if(isOpen) {
			functionParamers = {
				queryStrings: {
					"serviceUrl": "/ladderTempControl/startLadderTempControl"
				},
				transmitData: {
					"applianceId": applianceId,
					"temp": Number(setTemp),
					"flag": ""
				}
			};
		} else {
			functionParamers = {
				queryStrings: {
					"serviceUrl": "/ladderTempControl/closeLadderTempControl"
				},
				transmitData: {
					"applianceId": applianceId
				}
			};
		}
		var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			clearTimeout(networkDelay);
			that.hideLoading();
			var jsonData = JSON.parse(jsonString);
			var errflag = jsonData.errorCode;
			var result = "";
			if(errflag == 0) {
				var returnData = jsonData.result.returnData;
				var errCode = returnData.errCode;
				if(errCode == 0) {
					if(isOpen) { //2 表示开启，1表示关闭
						_dataManager.setLadderControlStatus(true);
						_dataParse.setSleepModeSwitch(0);
						_dataParse.setPMVFunction(0);
						_dataManager.closeCurrentDevicePMV();
						_dataParse.setNaturalWindFunctionSwitch(0);
						_dataParse.setEOCFunctionSwitch(0);
						_dataManager.closeNoWindFeelECONaturalWind();
						_dataParse.setKeepWarmSwitch(0);
						_dataParse.setPreventingCold(0);
						_dataManager.getDeviceWindAvoidStatus().windAvoid=false;
						_dataManager.getCurrentDevice().deviceStatus.windAvoidStatus=false;
						_dataManager.getColdHotState().coldHotSwitch=false;
					} else {
						_dataManager.setLadderControlStatus(false);
					}
					notifyRefreshLadderControlStatus();
				}
			}
		}, function(message) {
			processOperateFailCallBack(message);
			notifyRefreshLadderControlStatus();
		});
	}

	/**
	 * 请求入侵消息推送状态
	 */
	this.requestIntrusionRemindStatus = function() {
		var acDeviceType = _dataManager.getCurrentDevice().deviceInfo.deviceType;

		var applianceId = bridge.getCurrentApplianceID();
		var functionParamers = {
			queryStrings: {
				"serviceUrl": "/infraredSensor/queryIntrusion"
			},
			transmitData: {
				"applianceId": parseInt(applianceId)
			},
		};
		var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			var jsonData = JSON.parse(jsonString);
			var errflag = jsonData.errorCode;

			if(errflag == 0) {
				var returnData = jsonData.result.returnData;
				var errCode = returnData.errCode;
				if(errCode == 0) {
					intrusionStatus = returnData.result.status;
					if(2 == intrusionStatus) { //2 表示开启，1表示关闭
						_dataManager.setIntrusionRemind(true);
					} else {
						_dataManager.setIntrusionRemind(false);
					}
				}
			}
			notifyRefreshIntrusionViewStatus();
		}, function(message) {
			processOperateFailCallBack(message);
			notifyRefreshIntrusionViewStatus();
		});
	}

	/**
	 * 初始化
	 */
	this.initSleepCurve = function() {
		var deviceInfo = _dataManager.getCurrentDevice().deviceInfo;
		if(deviceInfo.hasSleepCurve) {
			requestSleepCurve();
		}
	}

	function requestSleepCurve() {
		var applianceId = bridge.getCurrentApplianceID();
		var runMode = _dataManager.getCurrentDevice().deviceStatus.runningMode;
		if(mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool == runMode) {
			runMode = mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool;
		} else {
			runMode = mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat;
		}
		var tempInteger = _dataManager.getCurrentDevice().deviceStatus.temperatureInteger;
		var tempDecimal = _dataManager.getCurrentDevice().deviceStatus.temperatureDecimal;
		var realTemperate = tempInteger + tempDecimal;

		var functionParamers = {
			queryStrings: {
				"serviceUrl": "/sleepCurve/getOffsetCurveStatus"
			},
			transmitData: {
				"applianceId": applianceId,
				"mode": runMode,
				"temp": realTemperate
			},
		};
		var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			if(jsonString != undefined) {
				dealSleepStatus(jsonString);
			}
			notifyRefreshSleepView();
		}, function(message) {
			processOperateFailCallBack(message);
			notifyRefreshSleepView();
		});
	}

	/*
	 * 收到服务器返回数据后处理
	 */
	function dealSleepStatus(jsonstring) {
		var jsonData = JSON.parse(jsonstring);
		var errflag = jsonData.errorCode;
		var result = undefined;
		var tmpStatus = undefined;
		var tmpType = undefined;

		if(errflag == 0) {
			var returnData = jsonData.result.returnData;
			var errMsg = returnData.errMsg;
			var errCode = returnData.errCode;
			if(errCode == 0) {

				for(var i = 0; i < returnData.result.length; i++) {
					tmpStatus = returnData.result[i].status;
					tmpType = returnData.result[i].type;

					if(tmpType == 4) { //自定义曲线
						if(tmpStatus == 2) {
							_dataManager.updateSleepMode(1, returnData.result[i], true);
						} else if(tmpStatus == 1) {
							_dataManager.updateSleepMode(1, returnData.result[i], false);
						}

					} else if(tmpType == 6) { //推荐曲线曲线
						if(tmpStatus == 2) {
							_dataManager.updateSleepMode(0, returnData.result[i], true);
						} else if(tmpStatus == 1) {
							_dataManager.updateSleepMode(0, returnData.result[i], false);
						}
					}
				}
			}
		}
	}

	/**
	 * 设备体检
	 */
	this.controlDeviceCheck = function() {
		//TODO体检过程中通知刷新体检进度信息，体检完成通知刷新体检结束状态信息
		startDeviceCheck();
	}

	//获取上一次体检结果
	this.getDeviceIntelCheckInfo = function() {
		requestDeviceCheckScore();
	}

	//开始体检
	function startDeviceCheck() {
		var checkScoreObj = _dataManager.getDeviceCheckFinishStatus();
		var applianceId = bridge.getCurrentApplianceID();
		var functionParamers = {
			queryStrings: {
				"serviceUrl": "/acCheck/startACCheck"
			},
			transmitData: {
				"applianceId": applianceId
			}
		}
		var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			//TODO数据解析，绑定数据
			var jsonData = JSON.parse(jsonString);
			var errflag = jsonData.errorCode;
			//数据解析,更新videoUrl对象
			if(errflag == 0) {
				var returnData = jsonData.result.returnData;
				var errMsg = returnData.errMsg;
				var errCode = returnData.errCode;
				if(errCode == 0) {
					var returnScore = returnData.result.score;
					checkScoreObj.score = returnScore.score;
					checkScoreObj.scoreLevel = returnScore.scoreLevel;
					if(0 == returnScore.checkStatus) {
						checkScoreObj.checkParameters = "异常";
						checkScoreObj.scanProcess = "体检异常，请及时排除";
					} else {
						checkScoreObj.checkParameters = "正常";
						checkScoreObj.scanProcess = "体检正常，请继续保持";
					}
					checkScoreObj.checkFaultNum = returnScore.faultNum + "个故障";
					checkScoreObj.checkFaultDetail = [];
					if(returnScore.faultList.length > 0) {
						for(var errSum = 0; errSum < returnScore.faultList.length; errSum++) {
							//							checkScoreObj.checkFaultDetail[errSum] = returnScore.faultList[errSum].errCode + ":" + returnScore.faultList[errSum].errMsg;
							checkScoreObj.checkFaultDetail[errSum] = returnScore.faultList[errSum].errMsg;
						}
					} else {
						checkScoreObj.checkFaultDetail = [];
					}
					//			通知更新界面
					notifyRefreshIntelCheckView("queryLastCheckInfo");
				}
			}
		}, function(errCode) {
			if(errCode == '-1') {
				notifyRefreshIntelCheckView("queryLastCheckInfo");
			}
		});
	}

	// 获取体检分数
	function requestDeviceCheckScore() {
		var checkScoreObj = _dataManager.getDeviceCheckFinishStatus();
		var applianceId = bridge.getCurrentApplianceID();
		var functionParamers = {
			queryStrings: {
				"serviceUrl": "/acCheck/getACCheckScore"
			},
			transmitData: {
				"applianceId": applianceId
			},
		};
		var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			//TODO数据解析，绑定数据
			var jsonData = JSON.parse(jsonString);
			var errflag = jsonData.errorCode;
			//数据解析,更新videoUrl对象
			if(errflag == 0) {
				var returnData = jsonData.result.returnData;
				var errMsg = returnData.errMsg;
				var errCode = returnData.errCode;
				if(errCode == 0 && undefined != returnData.result) {
					checkScoreObj.score = returnData.result.score;
					checkScoreObj.scoreLevel = returnData.result.scoreLevel;
					if(0 == returnData.result.checkStatus) {
						checkScoreObj.checkParameters = "异常";
					} else {
						checkScoreObj.checkParameters = "正常";
					}
					checkScoreObj.checkFaultNum = returnData.result.faultNum + "个故障";
					checkScoreObj.scanProcess = "上次体检时间：" + returnData.result.lastCheckTime;
					
					checkScoreObj.checkNum = returnData.result.checkNum;
					
					if(returnData.result.faultList.length > 0) {
						for(var errSum = 0; errSum < returnData.result.faultList.length; errSum++) {
							//							checkScoreObj.checkFaultDetail[errSum] = returnData.result.faultList[errSum].errCode + ":" + returnData.result.faultList[errSum].errMsg;
							checkScoreObj.checkFaultDetail[errSum] = returnData.result.faultList[errSum].errMsg;
						}
					} else {
						checkScoreObj.checkFaultDetail = [];
					}

					//			通知更新界面
					notifyRefreshIntelCheckView("queryLastCheckInfo");
				}
			}
		}, function(errCode) {
			if(errCode == '-1') {
				notifyRefreshIntelCheckView("queryLastCheckInfo");
			}
		});

	}

	/**
	 * 取消设备体检
	 */
	this.cancelDeviceCheck = function() {

	}

	/**
	 * 通过年，月获取用电记录，格式为yyyymm,例如201506,返回值：6月的当前用电记录
	 * requestDate = {year:"",month:""}
	 */
	this.requestElectricQuantityRecordByDate = function(requestDate) {
		//TODO 请求服务器成功通知界面那数据更新界面,如果本地有，就通知取数据，如果没有就请求服务器，然后更新本地，再通知界面刷新
	}

	/**
	 * 请求打开美的商城网页
	 */
	this.requestOpenMideaStore = function() {
		var requestUrl = _dataManager.getMideaStoreUrl();
		bridge.openWeb(requestUrl);
	}

	/**
	 * 请求打开美粉圈网页
	 */
	this.requestOpenMideaFan = function() {
		var requestUrl = _dataManager.getMideaFanUrl();
		bridge.openWeb(requestUrl);
	}

	/**
	 * 请求打开美的售后网页
	 */
	this.requestOpenMideaAfterSale = function() {
		var requestUrl = _dataManager.getMideaAfterSaleUrl();
		bridge.openWeb(requestUrl);
	}

	/**
	 * 防着凉APNS推送提醒功能切换，用于在检测到踢被子后，是否推送消息给手机
	 * @param {Boolean} isOpen true:打开，false：关闭
	 */
	this.controlSwitchPreventColdAPNSRemind = function(isOpen) {
		that.showLoading();
		var queryStr = undefined;
		var applianceId = bridge.getCurrentApplianceID();
		if(isOpen) {
			queryStr = "/wisdomEye/startRemind";
		} else {
			queryStr = "/wisdomEye/closeRemind";
		}
		var functionParamers = {
			queryStrings: {
				"serviceUrl": queryStr
			},
			transmitData: {
				"applianceId": parseInt(applianceId)
			},
		};

		var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
			clearTimeout(networkDelay);
			that.hideLoading();
			var jsonString = JSON.stringify(messageBack);
			var jsonData = JSON.parse(jsonString);
			var errflag = jsonData.errorCode;
			if(errflag == 0) {
				var returnData = jsonData.result.returnData;
				var errCode = returnData.errCode;
				if(errCode == 0) {
					var returnSatus = returnData.switcher;
					if(2 == returnSatus) {
						_dataManager.setPreventColdAPNSRemind(true);
					} else if(1 == returnSatus) {
						_dataManager.setPreventColdAPNSRemind(false);
					}
				} else {
					notifyRefreshPreventColdViewStatus();
				}
			} else {
				notifyRefreshPreventColdViewStatus();
			}
		}, function(message) {
			processOperateFailCallBack(message);
			notifyRefreshPreventColdViewStatus();
		});
	}

	/**
	 * 入侵信息推送提醒功能切换，用于入侵后，是否推送消息给手机
	 * @param {Boolean} isOpen true:打开，false：关闭
	 */
	this.controlSwitchIntrusionRemind = function(isOpen) {
		that.showLoading();
		var queryStr = undefined;
		var applianceId = bridge.getCurrentApplianceID();
		if(isOpen) {
			queryStr = "/infraredSensor/startIntrusion";
		} else {
			queryStr = "/infraredSensor/closeIntrusion";
		}
		var functionParamers = {
			queryStrings: {
				"serviceUrl": queryStr
			},
			transmitData: {
				"applianceId": parseInt(applianceId)
			},
		};
		var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
			that.hideLoading();
			clearTimeout(networkDelay);
			var jsonString = JSON.stringify(messageBack);
			var jsonData = JSON.parse(jsonString);
			var errflag = jsonData.errorCode;
			if(errflag == 0) {
				var returnData = jsonData.result.returnData;
				var errCode = returnData.errCode;
				if(errCode == 0) {
					if(isOpen) {
						_dataManager.setIntrusionRemind(true);
					} else {
						_dataManager.setIntrusionRemind(false);
					}
				} else {
					notifyRefreshIntrusionViewStatus();
				}
			} else {
				notifyRefreshIntrusionViewStatus();
			}
		}, function(message) {
			processOperateFailCallBack(message);
			notifyRefreshIntrusionViewStatus();
		});
	}
		//注册人脸
	this.controlJumpIntoFaceRegistered = function() {
		 sn = bridge.getCurrentDevSN();
			bridge.commandInterface("shareYB200Face",{"SN":"md"+sn});	
	}

	//播放视频监控
	this.controlVideoPlay = function() {
		      this.controlSwitchReportVideo(true);
      if (_dm_.getDeviceType() == "YB100") {
			sn = bridge.getCurrentDevSN();
			bridge.commandInterface("showYB200Video",{"SN": ("md"+sn)});
			return;
		}
		var sn = acGlobalDeviceSn;
		if (sn.length != 32) {
			sn = bridge.getCurrentDevSN();
			if (sn.length != 32) {
				return;
			} else {
				acGlobalDeviceSn = sn;
			}
		}
		// var functionParamers = {
		// 	title: "提示",
		// 	message: sn.substring(6,29),
		// 	btnText: "确定"
		// };
		// bridge.showAlert(functionParamers);
		// return ;
		this.getDeviceCameraSdk(sn, function (online) {
			switch (online) {
				case 1:
				case 4:
					bridge.commandInterface("showYB200Video",{"SN":"device_" + sn});
					break;
				case 2:
						setTimeout(function() {
			bridge.jumpOtherPlugin = function(cmdParamers) {
				var param = {};
				if(cmdParamers != undefined) {
					param.cmdParamers = cmdParamers;
				}
				var p = JSON.stringify(param);
				bridge.po._execObjcMethod('jumpOtherPlugin', p);
			};
			bridge.jumpOtherPlugin("showYB200Video");
		}, 0);
//					bridge.commandInterface("showYB200Video",{"SN":sn});
					break;
				case 3:
					var functionParamers = {
						title: "提示",
						message: "摄像头离线",
						btnText: "确定"
					};
					bridge.showAlert(functionParamers);
					break;
				default:
					break;
			}
		});

//		setTimeout(function() {
//			bridge.jumpOtherPlugin = function(cmdParamers) {
//				var param = {};
//				if(cmdParamers != undefined) {
//					param.cmdParamers = cmdParamers;
//				}
//				var p = JSON.stringify(param);
//				bridge.po._execObjcMethod('jumpOtherPlugin', p);
//			};
//			bridge.jumpOtherPlugin("showYB200Video");
//		}, 0);
		}
	/****** YB视频SDK判断 ******/
	var allowsVideoRequest = true;
	this.getDeviceCameraSdk = function (sn, callback) {
		that.showLoading();
		bridge.getUserInfo(function(userInfo) {
			if (allowsVideoRequest) {
				allowsVideoRequest = false;
				setTimeout(function(){ allowsVideoRequest = true; }, 500);
				that.hideLoading();
				var userId = userInfo.userId,
					familyId = userInfo.familyId;
				// var sn = bridge.getCurrentDevSN();
				var functionParamers = {
					queryStrings: {
						"serviceUrl": "/p2p/getUserOnline"
					},
					transmitData: {
						"deviceId": sn,
						"userId": userId,
						"familyId": familyId
					},
				};
				that.showLoading();
				setTimeout(function() {
					var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
						that.hideLoading();
						// var jsonString = JSON.stringify(messageBack);
						var errorCode = messageBack.errorCode;
						if(errorCode == 0) {
							var returnData = messageBack.result.returnData;
							var errflag = returnData.errCode;
							if(errflag == 0) {
								var online = returnData.result.online;
								callback(online);
							} else {
								processOperateFailCallBack("-1");
							}
						} else {
							processOperateFailCallBack("-1");
						}
					}, function(message) {
						processOperateFailCallBack(message);
					});
				}, 0);
			}
		});
	}
	/****** YB视频判断结束 ******/
	/**
	 * 视频功能切换
	 * @param {Boolean} isOpen true:打开，false：关闭
	 */
	this.controlSwitchReportVideo = function(isOpen) {
		var applianceId = bridge.getCurrentApplianceID();
		var userId = undefined;
		//获取用户信息，调试完成后要将该功能移到控制页面
		var cmdId = bridge.getUserInfo(function(userInfo) {
			if(userInfo == null) {
				bridge.logToIOS("获取用户信息失败");
				setTimeout(function() {
					alert('获取用户信息失败')
				}, 100);
			} else {
				currentUserInfo = userInfo;
				userId = parseInt(currentUserInfo.userId)

				var opType = undefined;
				if(isOpen) {
					opType = 2;
				} else {
					opType = 1;
				}

				var functionParamers = {
					queryStrings: {
						"serviceUrl": "/video/reportVideo"
					},
					transmitData: {
						"userId": userId,
						"applianceId": parseInt(applianceId),
						"opType": opType
					}
				};
				var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
					var jsonString = JSON.stringify(messageBack);
					var jsonData = JSON.parse(jsonString);
					var errorCode = jsonData.errorCode;
					if(errorCode == 0) {
						var returnData = jsonData.result.returnData;
						var errflag = returnData.errCode;
						if(errflag == 0) {

						} else {
							processOperateFailCallBack("-1");
						}
					} else {
						processOperateFailCallBack("-1");
					}
				}, function(message) {
					processOperateFailCallBack(message);
				});
			}
		});

	}

	/****** 自学习接口 ******/
	/**
	 * 查询自学习状态
	 * @param {Boolean} 2 true:打开，1 false：关闭
	 */
	this.querySwitchSelfLearningStatus = function() {
		var selfLearningObj = _dataManager.getSelfLearning();
		var applianceId = bridge.getCurrentApplianceID();

		var functionParamers = {
			queryStrings: {
				"serviceUrl": "/selfLearning/selfLearningExecuting"
			},
			transmitData: {
				"applianceId": parseInt(applianceId),
				//				"applianceId": 111111,
				"opType": 3
			},
		};
		setTimeout(function() {
			setTimeout(function() {
				clearTimeout(networkDelay);
				that.hideLoading();
			}, 10000);
			var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
				var jsonString = JSON.stringify(messageBack);
				var jsonData = JSON.parse(jsonString);
				var errorCode = jsonData.errorCode;
				if(errorCode == 0) {
					var returnData = jsonData.result.returnData;
					var errflag = returnData.errCode;
					if(errflag == 0) {
						var status = returnData.result.status;
						if(status == 2) {
							selfLearningObj.selfLearningStatus = true;
						} else {
							selfLearningObj.selfLearningStatus = false;
						}
						notifyRefreshSelfLearningViewStatus();
					} else {
						// processOperateFailCallBack("-1");
					}
				} else {
					// processOperateFailCallBack("-1");
				}
			}, function(message) {
				processOperateFailCallBack(message);
			});
		}, 0);
	}

	/**
	 * 查询自学习时间段
	 * @param {Boolean} slotStart:开始时间段，slotStop：结束
	 */
	this.querySwitchSelfLearningTimeSlot = function() {
		var selfLearningObj = _dataManager.getSelfLearning();
		var applianceId = bridge.getCurrentApplianceID();
		var functionParamers = {
			queryStrings: {
				"serviceUrl": "/selfLearning/selfLearningTimeSlot"
			},
			transmitData: {
				"applianceId": parseInt(applianceId),
				"opType": 2
			},
		};
		setTimeout(function() {
			var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
				var jsonString = JSON.stringify(messageBack);
				var jsonData = JSON.parse(jsonString);
				var errorCode = jsonData.errorCode;
				if(errorCode == 0) {
					var returnData = jsonData.result.returnData;
					var errflag = returnData.errCode;
					if(errflag == 0) {
						selfLearningObj.selfLearningSlotStart = returnData.result.slotStart;
						selfLearningObj.selfLearningSlotStop = returnData.result.slotStop;
						notifyRefreshSelfLearningViewStatus();
					} else {
						// processOperateFailCallBack("-1");
					}
				} else {
					// processOperateFailCallBack("-1");
				}
			}, function(message) {
				processOperateFailCallBack(message);
			});
		}, 1);
	}

	/**
	 * 查询自学习结果曲线(3天曲线，现在改为只用今天的)
	 * @param {Boolean}
	 */
	this.querySelfLearningCurve = function() {
		var selfLearningObj = _dataManager.getSelfLearning();
		var applianceId = bridge.getCurrentApplianceID();
		var functionParamers = {
			queryStrings: {
				"serviceUrl": "/selfLearning/getSelfLearningCurve"
			},
			transmitData: {
				"applianceId": parseInt(applianceId)
			},
		};
		setTimeout(function() {
			var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
				var jsonString = JSON.stringify(messageBack);
				var jsonData = JSON.parse(jsonString);
				//			alert("queryCurve="+jsonString);
				var errorCode = jsonData.errorCode;
				if(errorCode == 0) {
					var returnData = jsonData.result.returnData;
					var errflag = returnData.errCode;
					if(errflag == 0) {
						selfLearningObj.selfLearningCurve = returnData.result.list;
						selfLearningObj.selfLearningSlotStart = returnData.result.startTime;
						selfLearningObj.selfLearningSlotStop = returnData.result.stopTime;
						notifyRefreshSelfLearningViewCurve();
					} else {
						// processOperateFailCallBack("-1");
					}
				} else {
					// processOperateFailCallBack("-1");
				}
				clearTimeout(networkDelay);
				that.hideLoading();
			}, function(message) {
				clearTimeout(networkDelay);
				processOperateFailCallBack(message);
				that.hideLoading();
			});
		}, 0);
	}

	/**
	 * 查询自学习用户操作值(10天数据)
	 * @param {Boolean}
	 */
	this.querySelfLearningValueList = function() {
		bridge.logToIOS("initqueryValue=" + (new Date()));
		var selfLearningObj = _dataManager.getSelfLearning();
		var applianceId = bridge.getCurrentApplianceID();
		var functionParamers = {
			queryStrings: {
				"serviceUrl": "/selfLearning/getLearningValueList"
			},
			transmitData: {
				"applianceId": parseInt(applianceId)
				//				"applianceId": 111111
			},
		};
		setTimeout(function() {
			that.showLoading();
			setTimeout(function() {
				clearTimeout(networkDelay);
				that.hideLoading();
			}, 10000);
			var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {

				bridge.logToIOS("initqueryValueReceive=" + (new Date()));
				var jsonString = JSON.stringify(messageBack);
				var jsonData = JSON.parse(jsonString);
				//			alert("ValueList="+jsonString);
				var errorCode = jsonData.errorCode;
				if(errorCode == 0) {
					var returnData = jsonData.result.returnData;
					var errflag = returnData.errCode;
					if(errflag == 0) {
						selfLearningObj.selfLearningValueList = returnData.result.list;
						notifyRefreshSelfLearningViewValueList();
					} else {
						// processOperateFailCallBack("-1");
					}
				} else {
					// processOperateFailCallBack("-1");
				}
				clearTimeout(networkDelay);
				that.hideLoading();
			}, function(message) {
				clearTimeout(networkDelay);
				processOperateFailCallBack(message);
				that.hideLoading();
			});
		}, 0);
	}

	/**
	 * 是否开启自学习
	 * @param {Boolean} isOpen true:打开，false：关闭
	 */
	this.controlSwitchSelfLearningStatus = function(isOpen) {
		var selfLearningObj = _dataManager.getSelfLearning();
		var applianceId = bridge.getCurrentApplianceID();
		var opType = undefined;
		if(isOpen) {
			opType = 2;
		} else {
			opType = 1;
		}

		var functionParamers = {
			queryStrings: {
				"serviceUrl": "/selfLearning/selfLearningExecuting"
			},
			transmitData: {
				"applianceId": parseInt(applianceId),
				//				"applianceId": 111111,
				"opType": opType
			},
		};
		setTimeout(function() {
			var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
				var jsonString = JSON.stringify(messageBack);
				var jsonData = JSON.parse(jsonString);
				var errorCode = jsonData.errorCode;
				if(errorCode == 0) {
					var returnData = jsonData.result.returnData;
					var errflag = returnData.errCode;
					if(errflag == 0) {
						if(isOpen) {
							selfLearningObj.selfLearningStatus = true;
						} else {
							selfLearningObj.selfLearningStatus = false;
						}
						notifyRefreshSelfLearningViewStatus();
					} else {
						processOperateFailCallBack("-1");
					}
				} else {
					processOperateFailCallBack("-1");
				}
			}, function(message) {
				processOperateFailCallBack(message);
			});
		}, 0);
	}
	/**
	 * 设置自学习时间段
	 * @param {Boolean} slotStart:开始时间段，slotStop：结束
	 */
	this.controlSwitchSelfLearningTimeSlot = function(slotStart, slotStop) {
		var selfLearningObj = _dataManager.getSelfLearning();
		var applianceId = bridge.getCurrentApplianceID();
		var functionParamers = {
			queryStrings: {
				"serviceUrl": "/selfLearning/selfLearningTimeSlot"
			},
			transmitData: {
				"applianceId": parseInt(applianceId),
				//				"applianceId": 111111,
				"opType": 1,
				"slotStart": slotStart,
				"slotStop": slotStop
			},
		};
		setTimeout(function() {
			var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
				var jsonString = JSON.stringify(messageBack);
				var jsonData = JSON.parse(jsonString);
				var errorCode = jsonData.errorCode;
				if(errorCode == 0) {
					var returnData = jsonData.result.returnData;
					var errflag = returnData.errCode;
					if(errflag == 0) {
						selfLearningObj.selfLearningSlotStart = slotStart;
						selfLearningObj.selfLearningSlotStop = slotStop;
						notifyRefreshSelfLearningViewStatus();
					} else {
						processOperateFailCallBack("-1");
					}
				} else {
					processOperateFailCallBack("-1");
				}
			}, function(message) {
				processOperateFailCallBack(message);
			});
		}, 0);
	}

	/****** 自学习结束 ******/

	//回家自动开机
	this.controlAutoOn = function(isOpen) {
		that.showLoading();
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x07;
		itemsBytes[1] = 0x05;
		itemsBytes[2] = 1; //属性长度
		if(isOpen) {
			itemsBytes[3] = 1;
		} else {
			itemsBytes[3] = 0;
		}
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyRefreshMyWristbandViewStatus();
		}, function(message) {
			processOperateFailCallBack(message);
			notifyRefreshMyWristbandViewStatus();
		});
	}

	//离家自动关机
	this.controlAutoOff = function(isOpen) {
		that.showLoading();
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x08;
		itemsBytes[1] = 0x05;
		itemsBytes[2] = 1; //属性长度
		if(isOpen) {
			itemsBytes[3] = 1;
		} else {
			itemsBytes[3] = 0;
		}
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			processNewProtocolDataAndNotifyRefreshView(messageBack);
			notifyRefreshMyWristbandViewStatus();
		}, function(message) {
			processOperateFailCallBack(message);
			notifyRefreshMyWristbandViewStatus();
		});
	}

	//获取小米运动睡眠曲线
	this.getMiSportSleepData = function(accessToken, AppID, AppKey, AppSecret) {
		var tmpTime = (new Date()).valueOf();
		var applianceId = bridge.getCurrentApplianceID();
		var runMode = _dataManager.getCurrentDevice().deviceStatus.runningMode;
		if(mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool == runMode) {
			runMode = mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool;
		} else {
			runMode = mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat;
		}

		var tmpquerystring = "appid=" + AppID +
			"&access_token=" + accessToken +
			"&call_id=" + tmpTime +
			"&l=english&third_appid" + AppKey +
			"&third_appsecret=" + AppSecret +
			"&v=1.0";
		var functionParamers = {
			queryStrings: {
				"serviceUrl": "/sleepCurve/getBraceletSleepCurve"
			},
			transmitData: {
				"applianceId": applianceId,
				"mode": runMode,
				"querystring": tmpquerystring
			}
		};
		//   		 alert("get sleepdata is "+JSON.stringify(functionParamers));
		var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			//			 alert("sleepdata is "+jsonString);
			var jsonData = JSON.parse(jsonString);
			var errorCode = jsonData.errorCode;
			if(errorCode == 0) {
				var returnData = jsonData.result.returnData;
				var errflag = returnData.errCode;
				if(errflag == 0) {

					for(var i = 0; i < returnData.result.length; i++) {
						tmpStatus = returnData.result[i].status;
						tmpType = returnData.result[i].type;
						if(tmpType == 5) {
							if(tmpStatus == 2) {
								_dataManager.updateSleepMode(2, returnData.result[i], true);
							} else if(tmpStatus == 1) {
								_dataManager.updateSleepMode(2, returnData.result[i], false);
							}
						}
					}

				} else {
					processOperateFailCallBack("-1");
				}
			} else {
				processOperateFailCallBack("-1");
			}
			notifyRefreshInteligentSleepView();
		}, function(message) {
			// processOperateFailCallBack(message);
		});
		// 		notifyRedirectMyWristbandView();			 					
	}

	this.getMiSportData = function(accessToken, AppID, AppKey, AppSecret) {
		//保存token至服务器,可选!!!!!!!!!!!
		// this.bindTokenToSer(accessToken);

		var tmpTime = (new Date()).valueOf();
		var tmpquerystring = "appid=" + AppID +
			"&access_token=" + accessToken +
			"&call_id=" + tmpTime +
			"&l=english&third_appid=" + AppKey +
			"&third_appsecret=" + AppSecret +
			"&v=1.0";

		var functionParamers = {
			queryStrings: {
				"serviceUrl": "/miBracelet/getUserData"
			},
			transmitData: {
				"querystring": tmpquerystring
			}
		};

		//alert("request="+JSON.stringify(functionParamers));
		var cmdId = bridge.requestDataTransmit(functionParamers, function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			//			 alert("requestDataTransmit"+jsonString);
			var jsonData = JSON.parse(jsonString);
			var errorCode = jsonData.errorCode;
			if(errorCode == 0) {
				var returnData = jsonData.result.returnData;
				var errflag = returnData.errCode;
				if(errflag == 0) {
					notifyRedirectMyWristbandView();
					var wristbandResultString = JSON.stringify(returnData.result);
					wristbandResultString = wristbandResultString.replace('[', '');
					wristbandResultString = wristbandResultString.replace(']', '');
					if(wristbandResultString != "") {
						var wristbandResult = JSON.parse(wristbandResultString);
						var wristbandObj = _dataManager.getWristbandStatus();
						wristbandObj.wristbandDate = wristbandResult.date;
						wristbandObj.wristbandConsumption = wristbandResult.calorie;
						wristbandObj.wristbandSteps = wristbandResult.step;
						wristbandObj.wristbandWalkTime = wristbandResult.walkTime;
						wristbandObj.wristbandRunDistance = wristbandResult.runDistance;
						wristbandObj.wristbandDayDistance = wristbandResult.walkDistance;
					}
					notifyRefreshMyWristbandView();
				} else {
					if(errflag == "-20002" || errflag == "-20000") {
						this.loginMi();
					} else {
						notifyRedirectMyWristbandView();
					}
				}
			} else {
				notifyRedirectMyWristbandView();
			}
		}, function(message) {
			notifyRedirectMyWristbandView();
		});
	}

	//搜索小米手环
	this.searchWristbandList = function() {
		var wristbandObj = _dataManager.getWristbandStatus();
		wristbandObj.wristbandList = [];
		wristbandObj.wristbandNameList = [];
		bridge.MiScan("", function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			//			alert("searchWristbandList"+jsonString);
			var wristbandSearchList = JSON.parse(jsonString);
			var tempStr = undefined;
			var secondTempStr = undefined;
			var tempItem = {};
			for(var i = 0; i < wristbandSearchList.length; i++) {
				tempItem = {}
				tempStr = wristbandSearchList[i].firstName;
				if(tempStr != undefined) {
					if(tempStr.indexOf('MI') != -1 || tempStr.indexOf('mi' == -1)) {
						tempItem.firstMac = wristbandSearchList[i].firstMac;
						tempItem.firstName = wristbandSearchList[i].firstName
						wristbandObj.wristbandList[i] = tempItem;
					} else {
						secondTempStr = wristbandSearchList[i].secondName;
						if(secondTempStr.indexOf('MI') != -1 || secondTempStr.indexOf('mi') != -1) {
							tempItem.firstMac = wristbandSearchList[i].firstMac;
							tempItem.firstName = wristbandSearchList[i].secondName
							wristbandObj.wristbandList[i] = tempItem;
						}
					}
				} else {
					secondTempStr = wristbandSearchList[i].secondName;
					if(secondTempStr != undefined) {
						if(secondTempStr.indexOf('MI') != -1 || secondTempStr.indexOf('mi') != -1) {
							tempItem.firstMac = wristbandSearchList[i].firstMac;
							tempItem.firstName = wristbandSearchList[i].secondName
							wristbandObj.wristbandList[i] = tempItem;
						}
					}
				}

			}
			notifyRefreshAddWristbandView();
		});
	}

	//绑定小米手环
	this.bindWristbandData = function(wristbandMAC) {
		var wristbandFirstMac = wristbandMAC.firstMac
		var SNStr = bridge.getCurrentDevSN();
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x02;
		itemsBytes[1] = 0x05;
		itemsBytes[2] = 6; //属性长度
		var j = 3;

		var wristbandMacData = new Array();

		var wristbandObj = _dataManager.getWristbandStatus();

		//注意换成选中的设备,转换后mac地址通过逗号分割!
		// wristbandMAC = "C8:0F:10:0C:06:E7";
		wristbandMacData = wristbandFirstMac.split(":");
		//mac地址低位在前，高位在后 字符串转16进制
		for(var i = wristbandMacData.length - 1; i >= 0; i--) {
			itemsBytes[j++] = parseInt(wristbandMacData[i], 16);
		};

		//生成空调绑定协议指令
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);

		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {

			//要判断绑定成功????????????????????????????????????
			var jsonString = JSON.stringify(messageBack);
			var tmpList = JSON.parse(jsonString);
			//如果空调绑定成功，保存mac地址
			if((parseInt(tmpList[12], 16) == 2) && (parseInt(tmpList[13], 16) == 5) && (parseInt(tmpList[14], 16) == 0)) {
				localStorage.setItem("mac" + SNStr, wristbandMacData);
				notiryRefreshDelWristbandViewStatus();
			} else {
				alert('绑定失败，请重试。')
			}
		});
	}

	//判断本地是否有保存小米手环信息，接口需返回属性个数
	this.searchBindWristbandData = function() {
		bridge.MiMenu("", function(messageBack) {});
	}

	//调用登录接口
	this.loginMi = function() {
		var SNStr = bridge.getCurrentDevSN();
		bridge.MiLogin("", function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			var tmpList = JSON.parse(jsonString);
			var accessToken = tmpList.accessToken;
			var AppID = tmpList.AppID;
			var AppKey = tmpList.AppKey;
			var AppSecret = tmpList.AppSecret;
			localStorage.setItem("accessToken" + SNStr, tmpList.accessToken);
			localStorage.setItem("AppID" + SNStr, tmpList.AppID);
			localStorage.setItem("AppKey" + SNStr, tmpList.AppKey);
			localStorage.setItem("AppSecret" + SNStr, tmpList.AppSecret);

			this.getMiSportData(accessToken, AppID, AppKey, AppSecret);
			this.getMiSportSleepData(accessToken, AppID, AppKey, AppSecret);
		});
	}

	//删除小米手环
	this.delWristbandData = function() {
		var SNStr = bridge.getCurrentDevSN();
		var itemsNum = 1;
		var itemsBytes = [];
		itemsBytes[0] = 0x02;
		itemsBytes[1] = 0x05;
		itemsBytes[2] = 6; //属性长度
		var j = 3;
		var wristbandMacData = new Array();
		//mac址址清0
		for(var i = 6; i >= 0; i--) {
			itemsBytes[j++] = 0;
			wristbandMacData[i] = 0;
		};

		//生成空调绑定协议指令
		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			//要判删除定成功????????????????????????????????????
			var jsonString = JSON.stringify(messageBack);
			var tmpList = JSON.parse(jsonString);

			//如果空调绑定成功，保存mac地址
			if((parseInt(tmpList[12], 16) == 2) && (parseInt(tmpList[13], 16) == 5) && (parseInt(tmpList[14], 16) == 0)) {
				//将保存mac置为undefined

				localStorage.setItem("mac" + SNStr, undefined);
				notiryRefreshDelWristbandViewStatus();
			} else {
				processOperateFailCallBack("-1");
			}
		});

	}

	//提前查询小米睡眠曲线、小米运动数据
	this.queryMyWristInfo = function() {
		var SNStr = bridge.getCurrentDevSN();
		var tmpMac = localStorage.getItem("mac" + SNStr);
		if((tmpMac == "undefined") || (tmpMac == null)) {

		} else {
			var accessToken = localStorage.getItem('accessToken' + SNStr);
			var AppID = localStorage.getItem('AppID' + SNStr);
			var AppKey = localStorage.getItem('AppKey' + SNStr);
			var AppSecret = localStorage.getItem('AppSecret' + SNStr);

			if((accessToken == undefined) || (accessToken == null) ||
				(AppID == undefined) || (AppID == null) ||
				(AppKey == undefined) || (AppKey == null) ||
				(AppSecret == undefined) || (AppSecret == null)
			) {

			} else {
				this.getMiSportSleepData(accessToken, AppID, AppKey, AppSecret);
			}
		}
	}

	//判断本地是否有保存小米手环信息，接口需返回属性个数
	this.ifHasBindWristbandData = function() {
		var SNStr = bridge.getCurrentDevSN();
		var tmpMac = localStorage.getItem("mac" + SNStr);
		if((tmpMac == "undefined") || (tmpMac == null)) {
			//进入添加手环界面
			notifyRedirectAddWristbandView();
		} else {
			var accessToken = localStorage.getItem('accessToken' + SNStr);
			var AppID = localStorage.getItem('AppID' + SNStr);
			var AppKey = localStorage.getItem('AppKey' + SNStr);
			var AppSecret = localStorage.getItem('AppSecret' + SNStr);
			if((accessToken == undefined) || (accessToken == null) ||
				(AppID == undefined) || (AppID == null) ||
				(AppKey == undefined) || (AppKey == null) ||
				(AppSecret == undefined) || (AppSecret == null)
			) {
				this.loginMi();
			} else {
				this.getMiSportData(accessToken, AppID, AppKey, AppSecret);
				this.getMiSportSleepData(accessToken, AppID, AppKey, AppSecret);
			}
		}
	}

	//蓝牙版本查询
	this.getBluetoothVersion = function() {
		var tmpCheckTypeCount = 3; //查询属性个数
		var tmpValue = [];
		tmpValue[0] = 0x05; //高位  
		tmpValue[1] = 0x04; //低位
		tmpValue[2] = 0x05; //高位  
		tmpValue[3] = 0x14; //低位
		tmpValue[4] = 0x05; //高位  
		tmpValue[5] = 0x03; //低位

		var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			notifyRefreshUpgradeViewStatus(messageBack);
			var SNStr = bridge.getCurrentDevSN();
			var ifClickUpdate = localStorage.getItem('ifClickBluetoothUpdate' + SNStr);
			if(ifClickUpdate == "true") {
				that.queryBluetoothUpgradeProgress();
			} else {
				notifyRefreshUpgradeViewProgress();
				notifyRefreshBluetoothMode();
			}
		}, function(message) {
			processOperateFailCallBack(message);
		});
	}

	//设置蓝牙模块模式  1:从机模式（升级过程中）     2:主机模式
	this.setBluetoothMode = function(bluetoothMode) {
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x03;
		itemsBytes[1] = 0x05;
		itemsBytes[2] = 1; //属性长度
		itemsBytes[3] = bluetoothMode;

		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			var tmpList = JSON.parse(jsonString);
			if(bluetoothMode == 1) {
				//由于家电返回错误，此处无法判断
				//				if ((parseInt(tmpList[12],16) == 3) && (parseInt(tmpList[13],16) == 5) 
				//				&& (parseInt(tmpList[14],16) == 0) && (parseInt(tmpList[16],16) == 1)){
				//					
				//					_dataManager.getDeviceBluetoothStatus().currentBluetoothMode = "1";
				//					notifyRefreshBluetoothMode();
				//				} else {
				//					_dataManager.getDeviceBluetoothStatus().currentBluetoothMode = "2";
				//				}

				_dataManager.getDeviceBluetoothStatus().currentBluetoothMode = "1";
				notifyRefreshBluetoothMode();
			} else if(bluetoothMode == 2) {
				//设置主机模式
				//				if ((parseInt(tmpList[12],16) == 3) && (parseInt(tmpList[13],16) == 5) 
				//				&& (parseInt(tmpList[14],16) == 0) && (parseInt(tmpList[16],16) == 2)){
				//					_dataManager.getDeviceBluetoothStatus().currentBluetoothMode = "2";
				//				} else {
				//					_dataManager.getDeviceBluetoothStatus().currentBluetoothMode = "1";
				//				}

				_dataManager.getDeviceBluetoothStatus().currentBluetoothMode = "2";
				notifyRefreshUpgradeViewProgress();
			}
		}, function(message) {
			if(bluetoothMode == 1) {
				//升级失败
				_dataManager.getDeviceBluetoothStatus().bluetoothNewestVersionProgress = -1;
				notifyRefreshUpgradeViewProgress();
			}
		});
	}

	//获取蓝牙模块MAC地址
	this.getBluetoothMac = function() {
		var deviceBluetoothStatus = _dataManager.getDeviceBluetoothStatus();
		deviceBluetoothStatus.bluetoothMacList = [];
		bridge.MiScan("", function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			var wristbandSearchList = JSON.parse(jsonString);
			var tempStr = undefined;
			var secondTempStr = undefined;
			var tempItem = {};
			for(var i = 0; i < wristbandSearchList.length; i++) {
				tempItem = {}
				tempStr = wristbandSearchList[i].firstName;
				if(tempStr != undefined) {
					if(tempStr.indexOf('MI') != -1 || tempStr.indexOf('mi' == -1)) {
						deviceBluetoothStatus.bluetoothMacList[i] = wristbandSearchList[i].firstMac;
					} else {
						secondTempStr = wristbandSearchList[i].secondName;
						if(secondTempStr.indexOf('MI') != -1 || secondTempStr.indexOf('mi') != -1) {
							deviceBluetoothStatus.bluetoothMacList[i] = wristbandSearchList[i].firstMac;
						}
					}
				} else {
					secondTempStr = wristbandSearchList[i].secondName;
					if(secondTempStr != undefined) {
						if(secondTempStr.indexOf('MI') != -1 || secondTempStr.indexOf('mi') != -1) {
							deviceBluetoothStatus.bluetoothMacList[i] = wristbandSearchList[i].firstMac;
						}
					}
				}
			}
			//通知界面更新MAC地址列表
			notifyRefreshBluetoothUpgradeView();
		});
	}

	//蓝牙版本升级
	this.updateBluetoothSoftVersion = function(bluetoothMAC) {
		//		alert("updateBluetoothSoftVersion");
		var applianceId = bridge.getCurrentApplianceID();
		//		var deviceBluetoothMAC = _dataManager.getDeviceBluetoothStatus().bluetoothMac;
		//		var deviceBluetoothMAC = "88:0F:10:C0:23:BC";			//0298
		//		var deviceBluetoothMAC = "E8:B8:52:5B:8E:86";			
		var deviceBluetoothMAC = bluetoothMAC;
		var upgradeFile = "./MI04-v0.0.1.7-20160218.fw";
		var functionParamers = {
			deviceBluetoothMAC: deviceBluetoothMAC,
			upgradeFile: upgradeFile
		};
		//		alert("updateBluetoothSoftVersion=="+JSON.stringify(functionParamers));
		bridge.FirmwareUpdate(functionParamers, function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			//			alert("FirmwareUpdate messageBack ="+jsonString);
			var tmpList = JSON.parse(jsonString);
			var updateResult = tmpList.result;
			if(updateResult == "YES") {
				_dataManager.getDeviceBluetoothStatus().bluetoothNewestVersionProgress = 1;
				notifyRefreshUpgradeViewProgress();
			} else {
				//升级失败
				_dataManager.getDeviceBluetoothStatus().bluetoothNewestVersionProgress = -1;
				notifyRefreshUpgradeViewProgress();
			}
		}, function(message) {
			//升级失败
			_dataManager.getDeviceBluetoothStatus().bluetoothNewestVersionProgress = -1;
			notifyRefreshUpgradeViewProgress();
		});
	}

	//查询蓝牙升级进度
	this.queryBluetoothUpgradeProgress = function() {
		bridge.MiUpgradeProgress('', function(messageBack) {
			var jsonString = JSON.stringify(messageBack);
			//			alert("queryBluetoothUpgradeProgress==="+jsonString);
			var tmpList = JSON.parse(jsonString);
			var updateResult = tmpList.result;
			if(updateResult == "YES") {
				//查询进度成功
				var progressValue = tmpList.progress;
				_dataManager.getDeviceBluetoothStatus().bluetoothUpgradeProgressValue = progressValue;
				if(progressValue < 100) {
					_dataManager.getDeviceBluetoothStatus().bluetoothNewestVersionProgress = 1;
				} else {
					_dataManager.getDeviceBluetoothStatus().bluetoothNewestVersionProgress = 2;
					that.setBluetoothMode(2);
				}
			} else if(updateResult == "NO") {
				//升级失败
				_dataManager.getDeviceBluetoothStatus().bluetoothNewestVersionProgress = -1;
			}
			notifyRefreshUpgradeViewProgress();
		}, function(message) {
			that.queryBluetoothUpgradeProgress();
		});
	}

	//通知方法列表

	/**
	 * 处理返回的数据，并通知界面刷新
	 * @param {Object} dataSource
	 */
	function processDataAndNotifyRefreshView(dataSource) {
		clearTimeout(networkDelay);
		that.hideLoading();
		setReceiveUploadMsgIsPermit(); //设置家电上传可用 add by yuxg 20150826

		var receiveMessageBody = dataSource.slice(10, dataSource.length - 1);
		if(!(receiveMessageBody[0] == 0xC0 || receiveMessageBody[0] == 0xA0 || receiveMessageBody[0] == 0xA1)) {
			return false;
		}
		var faultValueByte = receiveMessageBody[1];
		var faultValue = faultValueByte >> 7;

		if(receiveMessageBody[0] == 0xA0 && (faultValue != 0)) {
			return false;
		}

		var processData = _dataParse.parseMessageForView(dataSource);
		_dataManager.updateDeviceStatus(processData.status);
		_dataManager.updateDeviceStatusOfSpecial(dataSource);

		$.event.trigger("updateViewMessage", {});
	}

	function processDataAndNotifyRefreshSleepView(dataSource) {
		clearTimeout(networkDelay);
		that.hideLoading();
		var processData = _dataParse.parseMessageForView(dataSource);
		_dataManager.updateDeviceStatus(processData.status);
		_dataManager.updateDeviceStatusOfSpecial(dataSource);

		$.event.trigger("updateViewMessage", {});
		$.event.trigger("refreshSleepStatus", {});
		$.event.trigger("updateSleepCurveStatus", {});
		// notifyRefreshSleepView();
	}

	function isNewProtocol(dataSource) {
		var receiveMessageBody = dataSource.slice(10, dataSource.length - 1);
		var receiveMessageBody_new = dataSource.slice(9, dataSource.length - 1);
		var isNewProtocol = false;
		if((receiveMessageBody[0] == 0xB5) || (receiveMessageBody[0] == 0xB4)) {
			isNewProtocol = true;
		}
		//05、C0的主动上传判断
//		if((receiveMessageBody_new[0] == 0x05) || (receiveMessageBody_new[1] == 0xC0)) {
//			isNewProtocol = true;
//		}		
		return isNewProtocol;
	}

	function processModeDataAndNotifyRefreshView(dataSource) {
		clearTimeout(networkDelay);
		that.hideLoading();
		setReceiveUploadMsgIsPermit();

		var receiveMessageBody = dataSource.slice(10, dataSource.length - 1);
		if(!(receiveMessageBody[0] == 0xC0 || receiveMessageBody[0] == 0xA0 || receiveMessageBody[0] == 0xA1)) {
			return false;
		}
		var faultValueByte = receiveMessageBody[1];
		var faultValue = faultValueByte >> 7;
		if(receiveMessageBody[0] == 0xA0 && (faultValue != 0)) {
			return false;
		}

		var processData = _dataParse.parseMessageForView(dataSource);
		_dataManager.updateDeviceStatus(processData.status);
		_dataManager.updateDeviceStatusOfSpecial(dataSource);

		$.event.trigger("updateViewMessage", {});

		$.event.trigger("updateModeViewMessage", {});
	}

	function processStrongPreventDataAfterFail() {
		$.event.trigger("updateStrongPreventViewMessageAfterFail", {});
	}

	function processStrongPreventData(dataSource) {
		_dataManager.newProtocolStrongPreventDataProcess(dataSource);
		$.event.trigger("updateStrongPreventViewMessage", {});
	}

	function processCalibrationDataAfterFail() {
		$.event.trigger("updateCalibrationViewMessageAfterFail", {});
	}

	function processCalibrationData(dataSource) {
		_dataManager.newProtocolCalibrationDataProcess(dataSource);
		$.event.trigger("updateCalibrationViewMessage", {});
	}

	function processStopStrongPrevent() {
		_dataManager.stopStrongPrevent();
		$.event.trigger("updateStrongPreventViewMessage", {});
	}

	function processStopCalibration() {
		_dataManager.stopCalibration();
		$.event.trigger("updateCalibrationViewMessage", {});
	}

	function processNewProtocolDataAndNotifyRefreshView(dataSource) {
		clearTimeout(networkDelay);
		that.hideLoading();
		_dataManager.newProtocolDataProcess(dataSource);
		$.event.trigger("updateViewMessage", {});
	}

	function processNewProtocolUpdateDataAndNotifyRefreshView(dataSource) {
		setReceiveUploadMsgIsPermit();
		_dataManager.newProtocolUploadDataProcess(dataSource);
		$.event.trigger("updateViewMessage", {});
		$.event.trigger("refreshIntelViewStatus", {});
		$.event.trigger("refreshGestureRecognitionViewStatus", {});
		$.event.trigger("refreshIntrusionViewStatus", {});
		$.event.trigger("refreshControlVoiceStatus", {});
		$.event.trigger("refreshControlColdHotStatus", {});
		$.event.trigger("refreshControlColdWindStatus", {});
		$.event.trigger("refreshControlWeatherReportStatus", {});
		$.event.trigger("refreshControlTimingWeatherStatus", {});
		$.event.trigger("refreshFilterDirtyPluggingStatus", {});
		$.event.trigger("refreshPMStatus", {});		
	}

	function processHumidityValueRefreshView(dataSource) {
		_dataManager.newProtocolDataProcess(dataSource);
		$.event.trigger("updateHumidityMessage", {});
	}
	
	/**
	 *通知刷新软件更新
	 */
	function refreshscreenCalibrationStatus(){
		$.event.trigger("refreshScreenCalibrationStatus", {});
	}
	function yuyinUpdateStatus() {
		$.event.trigger("refreshYuyinUpdateStatus", {});
	}

	function yuyinbanbensmStatus() {
		$.event.trigger("refreshYuyinbanbensmStatus", {});
	}
	/**
	 *通知刷新儿童防着凉控制界面，包括有APNS推送设置状态更新，防着凉参数设置更新
	 */
	function notifyRefreshPreventColdViewStatus() {
		$.event.trigger("refreshPreventColdViewStatus", {});
	}
	//语音控制界面更新
	function notifyControlVoiceStatus() {
		$.event.trigger("refreshControlVoiceStatus", {});
	}
	//冷热感控制界面更新
	function notifyControlColdHotStatus() {
		$.event.trigger("refreshControlColdHotStatus", {});
	}
	//定时天气播报控制界面更新
	function notifyControlTimingWeatherStatus() {
		$.event.trigger("refreshControlTimingWeatherStatus", {});
	}
	//防冷风控制界面更新
	function notifyControlColdWindStatus() {
		$.event.trigger("refreshControlColdWindStatus", {});
	}
	//天气播报控制界面更新
	function notifyControlWeatherReportStatus() {
		$.event.trigger("refreshControlWeatherReportStatus", {});
	}
	//安防控制界面更新
	function notifyRefreshIntrusionViewStatus() {
		$.event.trigger("refreshIntrusionViewStatus", {});
	}
	//智能控制界面更新
	function notifyRefreshIntelViewStatus() {
		$.event.trigger("refreshIntelViewStatus", {});
	}
	//MP2.5界面更新
	function notifyRefreshPMStatus() {
		$.event.trigger("refreshPMStatus", {});
	}
	//手势识别更新
	function notifyRefreshGestureRecognitionViewStatus() {
		$.event.trigger("refreshGestureRecognitionViewStatus", {});
	}
	function notifyRefreshLadderControlStatus() {
		$.event.trigger("refreshLadderControlStatus", {});
	}

	function notifyObtainExternalUrl() {
		$.event.trigger("obtainExternalUrl", {});
	}

	function notifyObtainVideoUrl() {
		$.event.trigger("obtainVideoUrl", {});
	}

	function notifyObtainProblemDetailContent() {
		$.event.trigger("obtainProblemDetailContent", {});
	}

	function notifyRefreshElecView() {
		$.event.trigger("refreshElecView", {});
	}

	function notifyRefreshMonthElecView() {
		$.event.trigger("refreshMonthElecView", {});
	}

	function notifyRefreshSleepView() {
		$.event.trigger("refreshSleepView", {});
	}

	function notifyRefreshInteligentSleepView() {
		$.event.trigger("refreshSleepInteligentView", {});
	}

	function notifyRefreshIntelCheckView(queryType) {
		//		if ("queryLastCheckInfo" == queryType) {
		$.event.trigger("refreshIntelCheckView", {});
		//		} else {
		//			$.event.trigger("refreshCurrentIntelCheckView", {});
		//		}
	}

	function processOperateFailCallBack(message) {
		clearTimeout(networkDelay);
		that.hideLoading();
		if(-1 == message) {
			$.event.trigger("notifyOperateFail", {});
		}
	}
	//通知添加手环界面
	function notifyRefreshAddWristbandView() {
		$.event.trigger("refreshAddWristbandViewStatus", {});
	}

	//通知我的手环界面
	function notifyRefreshMyWristbandViewStatus() {
		$.event.trigger("refreshMyWristbandViewStatus", {});
	}

	//通知删除小米手环
	function notiryRefreshDelWristbandViewStatus() {
		$.event.trigger("refreshDelWristbandSuccess", {});
	}

	//跳转到添加手环界面
	function notifyRedirectAddWristbandView() {
		$.event.trigger("refreshRedirectAddWristbandView", {});
	}

	//跳转到我的手环界面
	function notifyRedirectMyWristbandView() {
		$.event.trigger("redirectMyWristbandView", {});
	}
	//更新我的手环界面数据
	function notifyRefreshMyWristbandView() {
		$.event.trigger("refreshMyWristbandView", {});
	}

	//更新MAC地址列表
	function notifyRefreshBluetoothUpgradeView() {
		$.event.trigger("refreshBluetoothMacView", {});
	}

	//更新版本信息
	function notifyRefreshUpgradeViewStatus(dataSource) {
		_dataManager.newProtocolDataProcess(dataSource);
	}

	//更新升级过程界面
	function notifyRefreshUpgradeViewProgress() {
		$.event.trigger("refreshUpgradeProgress", {});
	}

	//根据当前模式更新界面显示
	function notifyRefreshBluetoothMode() {
		$.event.trigger("refreshBluetoothMode", {});
	}

	//更新自学习界面
	function notifyRefreshSelfLearningViewStatus() {
		$.event.trigger("refreshSelfLearningViewStatus", {});
	}

	function notifyRefreshSelfLearningViewCurve() {
		$.event.trigger("refreshSelfLearningViewCurve", {});
	}

	function notifyRefreshSelfLearningViewValueList() {
		$.event.trigger("refreshSelfLearningViewValueList", {});
	}

	//辅助方法列表

	/**
	 * 请求外部资源数据解析
	 *  {"errorCode":0, "result":{"returnData":{"errCode":"1", ....}}}
	 */
	function resultDataParse(message) {
		var errMainCode = 0;
		var errMainMesg = "";
		var errSubCode = 0;
		var errSubMesg = "";

		var jsonResult = JSON.parse(message);
		errMainCode = jsonResult.errorCode;
		if(errMainCode == undefined || errMainCode == null) {
			errMainCode = jsonResult.errCode;
		}
		if(errMainCode != 0 && errMainCode != "0") { //	 有主类型错误
			errMainMesg = jsonResult.msg;
			if(errMainMesg == undefined || errMainMesg == null) {
				errMainMesg = jsonResult.errMessage;
			}
			return null;
		} else { //	主框架无错误
			//	主框架里的返回值
			var resultData = JSON.parse(JSON.stringify(jsonResult.result)); //{"returnData":{"errCode":"1", ....}}
			var returnData = JSON.parse(JSON.stringify(resultData.returnData)); //{"errCode":"1", ....}
			errSubCode = returnData.errCode;
			if(errSubCode == null || errSubCode.length == 0) {
				return null;
			}
			if(errSubCode != 0 && errSubCode != "0") { //	 有子类型错误
				errSubMesg = returnData.errMsg;
				return null;
			} else {
				return returnData.result;
			}
		}
		return null;
	}

	/**
	 * 开机设置设备的一些辅助功能状态
	 * @param {Enumerator} runningMode 当前设备运行状态
	 */
	function setOpenDeviceHelperStatueWithRunMode(runningMode) {
		switch(runningMode) {
			case mdSmart.ACDataManager.ACRunMode.RunModeAuto:
				{
					_dataParse.setNoPolarWindSpeedValue(101);
					_dataParse.setElectricHeatingButtonPressFlg(0);
					_dataParse.setElectricAuxiliaryHeat(1);
					break;
				}
			case mdSmart.ACDataManager.ACRunMode.RunModeRemoveWet:
				{
					_dataParse.setNoPolarWindSpeedValue(101);
					break;
				}
			case mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind:
				{
					_dataParse.setNoPolarWindSpeedValue(102);
					break;
				}
			case mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool:
				{
					_dataParse.setNoPolarWindSpeedValue(102);
					break;
				}
			case mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat:
				{
					_dataParse.setNoPolarWindSpeedValue(102);
					_dataParse.setElectricHeatingButtonPressFlg(0);
					_dataParse.setElectricAuxiliaryHeat(1);
					break;
				}
		}
	}

	/**
	 * 前条件：参数要满足参数要求
	 * 后条件：根据用户可见温度转化为设备识别的温度
	 * @param {Number} temperateInteger 用户认识的温度 17~30
	 * @param {Number} temperateDecimal 用户认识的小数 0，0.5
	 * @return{Object} temperature 返回家电设备认识的温度 整数1~14，小数0，1
	 */
	function temperatureTranslation(temperateInteger, temperateDecimal) {
		var integerNum = 1;
		var decimalNum = 0;
		if((17 <= temperateInteger && temperateInteger <= 30) && (0 == temperateDecimal || 0.5 == temperateDecimal)) {
			integerNum = temperateInteger - 16;
			decimalNum = temperateDecimal == 0.5 ? 1 : 0;
		}
		var temperature = {
			integerTemp: integerNum,
			decimalTemp: decimalNum
		}
		return temperature
	}

	/**
	 * @param {Object} p1
	 * @param {Object} p2
	 * @param {Object} p3
	 * @param {Object} p4
	 * @param {Object} p5
	 */
	function makeformatTime(p1, p2, p3, p4, p5) {
		var tp1, tp2, tp3, tp4, tp5;
		var tday = 0;
		var thour = 0;
		var tmin = 0;
		var result = 0;
		if(p1 == undefined || p1 == "") {
			tp1 = 0;
		} else {
			tp1 = p1;
		}

		if(p2 == undefined || p2 == "") {
			tp2 = 0;
		} else {
			tp2 = p2;
		}
		if(p3 == undefined || p3 == "") {
			tp3 = 0;
		} else {
			tp3 = p3;
		}
		if(p4 == undefined || p4 == "") {
			tp4 = 0;
		} else {
			tp4 = p4;
		}
		if(p5 == undefined || p5 == "") {
			tp5 = 0;
		} else {
			tp5 = p5;
		}

		if(tp1 > 0) {
			tp1 = (tp1 * 256 + tp2).toString();
		} else {
			tp1 = tp2.toString();
		}

		if(tp1 >= 0) {
			tday = tp1.toString() + '天';
		}
		if(tp3 >= 0) {
			thour = tp3.toString() + '小时';
		}
		if(tp4 >= 0) {
			tmin = tp4.toString() + '分钟';
		} else {
			tmin = "";
		}
		result = tday + thour + tmin;
		return result;
	}

	/**
	 *
	 * @param {Object} p1
	 * @param {Object} p2
	 * @param {Object} p3
	 * @param {Object} p4
	 * @param {Object} p5
	 */
	function makeformatPower(p1, p2, p3, p4, p5) {
		var tp1 = 0;
		var tp2 = 0;
		var tp3 = 0;
		var tp4 = 0;
		var tp5 = 0;

		var tper1 = 0;
		var tper2 = 0;
		var tper3 = 0;
		var result = 0;
		if(p1 == undefined) {
			tp1 = 0;
		} else {
			tp1 = parseInt(p1 / 16) * 10 + (p1 % 16);
		}
		if(p2 == undefined) {
			tp2 = 0;
		} else {
			tp2 = parseInt(p2 / 16) * 10 + (p2 % 16);
		}
		if(p3 == undefined) {
			tp3 = 0;
		} else {
			tp3 = parseInt(p3 / 16) * 10 + (p3 % 16);
		}
		if(p4 == undefined) {
			tp4 = 0;
		} else {
			tp4 = parseInt(p4 / 16) * 10 + (p4 % 16);
		}
		//电量换算
		if(p5 > 0) {
			tp5 = tp1 * 1000000 + tp2 * 10000 + tp3 * 100 + tp4;
			tp5 = tp5 / 100;
			tp5 = tp5.toFixed(2);
			tmpCountPower = tp5;
			result = tp5.toString() + '度';
		} else {
			tp5 = tp1 * 10000 + tp2 * 100 + tp3;
			tp5 = tp5 / 10;
			tp5 = tp5.toFixed(2);
			tmpCountPower = tp5;
			result = tp5.toString();
		}
		return result;
	}

	/**
	 * 强力防霉新协议数据处理
	 */
	function ifGetDataResult(p1) {
		var ifGet = true;
		if((p1[10] == 0xB1) || (p1[10] == 0xB0)) {
			var si = 0;
			var sj = 0;
			var sk = p1[11];
			var tmpCmdType = [];
			var tmpCmdResult = 1;
			var tmpCmdValue = [];

			var shift = 0;
			for(si = 0; si < sk; si++) {
				tmpCmdResult = p1[14 + si * 5 + shift];
				if(tmpCmdResult == 0) {
					var tmpCmdValueLength = p1[15 + si * 5 + shift];
					if(tmpCmdValueLength > 1) {
						shift = shift + (tmpCmdValueLength - 1);
					}
				} else {
					ifGet = false;
					break;
				}
			}
		}
		return ifGet;
	}

	/********** Control / Query Helper *************/

	/**
	 * 控制单个属性
	 * @param {Number} lowPosition 低位
	 * @param {Number} highPosition 高位
	 * @param {Array<Number>} valueArray 值组
	 * @param {function(Object)} success 成功回调(返回data)
	 * @param {function(Object)} failed 失败回调(返回失败message)
	 */
	function controlNewProtocalSingleProperty(lowPosition, highPosition, valueArray, success, failed) {
		that.showLoading();
		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = lowPosition;
		itemsBytes[1] = highPosition;
		itemsBytes[2] = valueArray.length; //属性长度
		for(var i = 0; i < valueArray.length; i++) {
			itemsBytes[2 + (i + 1)] = valueArray[i];
		}

		var cmdBytes = _dataParse.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			if(success) {
				success(messageBack);
             that.requestDeviceStatus();				
			}
			processNewProtocolDataAndNotifyRefreshView(messageBack);
		}, function(message) {
			processOperateFailCallBack(message);
			if(failed) {
				failed(failed);
			}
		});
	}

	/**
	 * 查询属性
	 * @param {Array<Number>} positionArray 高低位组
	 * @param {function(Object)} success 成功回调(返回data)
	 * @param {function(Object)} failed 失败回调(返回失败message)
	 */
	function requestNewProtocalProperties(positionArray, success, failed) {
		var tmpCheckTypeCount = positionArray.length / 2; //查询属性个数
		var cmdBytes = _dataParse.cmdNewVerForCheck(tmpCheckTypeCount, positionArray);
		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
			if(success) {
				success(messageBack);
			}
		}, function(message) {
			processOperateFailCallBack(message);
			if(failed) {
				failed(failed);
			}
		});
	}
}