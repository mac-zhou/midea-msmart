function ACDriver() {
	var _messageBodyControl = undefined,_messageBodyRequestStatus = undefined;_messageBodyCheckStatus = undefined;
	var _equipmentReturnCommandBack = undefined,_x05Xa0Back = undefined,_x04Xa1Back,frameCumulative=1;
	(function init(){
		
		//20150320 wjl
		_messageBodyControl = mdSmart.message.createMessageBody(25);
		_messageBodyRequestStatus = mdSmart.message.createMessageBody(25);
		
		_messageBodyCheckStatus = mdSmart.message.createMessageBody(7);  //查询设备状态组包数组
	}());
	
	
	//设置属性定义
	this.deviceStatus = {
		locationOrder:{
			name:"分区地址",value:0x00
		},
		locationCount:{
			name:"分机数量",value:0x00
		},		
		faultFlag:{
			name:"故障标志",value:0x00,view:{0:"无故障",1:"有故障"}
		},
		fastCheckStatus:{
			name:"快检状态",value:0x00,view:{0:"关闭",1:"开启"}
		},
		timeingMode:{
			name:"定时方式",value:0x00,view:{0:"相对定时",1:"绝对定时"}
		},
		iModeRecovery:{
			name:"I模式恢复",value:0x00,view:{0:"关闭",1:"开启"}
		},
		runningState:{
			name:"运行状态",value:0x00,view:{0:"关机",1:"开机"}
		},
		settingMode:{
			name:"设定模式",value:0x00,view:{0:"无效",1:"自动",2:"制冷",3:"抽湿",4:"制热",5:"送风"}
		},
		settingTemperature:{
			name:"设定温度",value:0x00,view:{0:"无效",1:"17℃",2:"18℃",3:"19℃",4:"20℃",5:"21℃",6:"22℃",7:"23℃",8:"24℃",9:"25℃",10:"26℃",11:"27℃",12:"28℃",13:"29℃",14:"30℃"}
		},
		settingTemperatureDot5:{
			name:"+0.5",value:0x00,view:{0:"+0.0",1:"+0.5"}
		},
		noPolarWindSpeedValue:{
			name:"无极风速值",value:0x00,view:{0:"无效",101:"固定风",102:"自动风",80:"高风",60:"中风",40:"低风",20:"静音风",60:"中风"}
		},
		timingOpen:{
			name:"定时开",value:0x00,view:{0:"关",1:"开"}
		},
		timingOpenAbsoluteHours:{
			name:"定时开－小时",value:0x00
		},
		timingOpenAbsoluteMinutes:{
			name:"定时开－分",value:0x00
		},
		timingClose:{
			name:"定时关",value:0x00,view:{0:"关",1:"开"}
		},
		timingCloseAbsoluteHours:{
			name:"定时关－小时",value:0x00
		},
		timingCloseAbsoluteMinutes:{
			name:"定时关－分",value:0x00
		},
		shushiFeng:{
			name:"舒适风",value:0x00,view:{0x11:"广角",0x12:"左广角",0x13:"右广角",0x14:"左定点",0x15:"右定点",0x16:"正面定点",0x17:"环绕立体风",0x18:"跟随-迎风",0x19:"避开-避风",0x20:"正出风上下摆",0x21:"正出风左右摆",0x22:"侧出风左右摆"}
		},
		downWind:{
			name:"下摆风",value:0x00,view:{0:"关闭",1:"开启"}
		},
		downWindControl:{
			name:"下摆风单独控制",value:0x00,view:{0:"非单独控制",1:"单独控制"}
		},
		personalFeeling:{
			name:"随身感",value:0x00,view:{0:"关闭",1:"开启"}
		},
		zhihuiyan:{
			name:"智慧眼",value:0x00,view:{0:"关闭",1:"开启"}
		},
		energySaving:{
			name:"节能",value:0x00,view:{0:"关",1:"开"}
		},
		strong:{
			name:"强劲",value:0x00,view:{0:"关闭",1:"开启"}
		},
		ruiFeng:{
			name:"睿风",value:0x00,view:{0:"关闭",1:"开启"}
		},
		shengDian:{
			name:"省电",value:0x00,view:{0:"关闭",1:"开启"}
		},
		sleepMode:{
			name:"舒睡模式",value:0x00,view:{0:"无舒睡",1:"舒睡1",10:"舒睡2",11:"舒睡3"}
		},
		selfPersonalFeeling:{
			name:"本机随身感",value:0x00,view:{0:"关",1:"开"}
		},
		selfSleep:{
			name:"本机舒睡",value:0x00,view:{0:"关",1:"开"}
		},
		purifyingFunction:{
			name:"净化功能",value:0x00,view:{0:"关",1:"开"}
		},
		ecoFunction:{
			name:"ECO功能",value:0x00,view:{0:"关",1:"开"}
		},
		electricHeat:{
			name:"电辅热",value:0x00,view:{0:"关",1:"开"}
		},
		dry:{
			name:"干燥",value:0x00,view:{0:"关",1:"开"}
		},
		naturalWindFunction:{
			name:"自然风功能",value:0x00,view:{0:"关",1:"开"}
		},
		childrenSleepMode:{
			name:"儿童舒睡模式",value:0x00,view:{0:"关",1:"开"}
		},
		coolWindMode:{
			name:"凉风模式",value:0x00,view:{0:"关",1:"开"}
		},
		peakValleyElectricity:{
			name:"峰谷节电",value:0x00,view:{0:"关",1:"开"}
		},
		catchCold:{
			name:"防着凉",value:0x00,view:{0:"关",1:"开"}
		},
		nightLight:{
			name:"小夜灯",value:0x00,view:{0:"关",1:"开"}
		},
		ventilation:{
			name:"换气",value:0x00,view:{0:"关",1:"开"}
		},
		celsiusFahrenheit:{
			name:"摄氏/华氏",value:0x00,view:{0:"关",1:"华氏"}
		},
		tubro:{
			name:"TUBRO",value:0x00,view:{0:"关",1:"开"}
		},
		sleepFunctionStatus:{
			name:"Sleep功能状态",value:0x00,view:{0:"关",1:"开"}
		},
		indoorTemperature:{
			name:"室内温度(整数),表示方法：温度值 x 2 + 50",value:0x00
		},
		outdoorTemperature:{
			name:"室外温度(整数),表示方法：温度值 x 2 + 50",value:0x00
		},
		dustFullMark:{
			name:"尘满标识",value:0x00,view:{0:"尘满未到",1:"尘满时间到"}
		},
		settingTemperature2:{
			name:"设定温度2",value:0x00,view:{0:"无效",1:"13℃",2:"14℃",3:"15℃",17:"30℃",18:"31℃",19:"32℃",20:"33℃",21:"34℃",22:"35℃"}
		},
		pmvMode:{
			name:"PMV模式",value:0x00,view:{0:"PMV关闭",1:"PMV=-3",2:"PMV=-2.5",3:"PMV=-2",4:"PMV功能-1.5",5:"PMV功能-1",6:"PMV功能-0.5",7:"PMV功能0",8:"PMV功能0.5",9:"PMV功能1",10:"PMV功能1.5",11:"PMV功能2",12:"PMV功能2.5"}
		},
		faultNo:{
			name:"故障代号",value:0x00,view:{0:"",1:"室内板与显示板通信故障 fg_ERROR_EB",2:"室内主控板E方故障",3:"室内板与室外板通信故障",4:"过零检测故障",5:"室内板风机失速故障",6:"室外冷凝器传感器故障",7:"室外环境温度传感器故障",8:"室外压缩机排气温度传感器故障",9:"室外E方故障",10:"室内温度传感器故障",11:"室内蒸发器温度传感器故障",12:"室外风速失速故障",13:"IPM模块保护",14:"电压保护",15:"室外压缩机顶部温度保护",16:"室外温度过低保护",17:"压缩机位置保护",18:"显示板E方故障",21:"外管温保护",23:"排气高温保护",25:"制热防冷风",26:"电流保护",29:"蒸发器高低温保护",30:"冷凝器高低温保护限频",31:"排气高低温保护",32:"室内外通信配错协议",33:"冷媒泄漏保护"}
		},
		ecoSleepRunningMinus:{
			name:"ECO/舒睡已运行时间 － 秒（范围：0～59）",value:0x00
		},
		ecoSleepRunningSecond:{
			name:"ECO/舒睡已运行时间－ 分（低二位）（范围：0～59）",value:0x00
		},
		ecoSleepRunningHour:{
			name:"ECO/舒睡已运行时间－ 小时（范围：0～10）",value:0x00
		},
		//20150320 wjl
		readyColdOrHot:{
			name:"预冷预热",value:0x00,view:{0:"关闭",1:"开启"}
		},
		braceLetSleep:{
			name:"手环与舒睡联动",value:0x00,view:{0:"关闭",1:"开启"}
		},
		braceLetContral:{
			name:"手环离家回家模式",value:0x00,view:{0:"关闭",1:"开启"}
		},
		smartWind:{
			name:"无风感功能",value:0x00,view:{0:"关闭",1:"开启"}
		},	
		downleftandrightMove:{
			name:"下左右摇摆",value:0x00,view:{0:"关闭",1:"开启"}
		},	
		childKick:{
			name:"踢被子",value:0x00,view:{0:"关闭",1:"开启"}
		},		
		lightClass:{
			name:"屏显",value:0x00,view:{0:"最亮",1:"二档",2:"三档",3:"四档",4:"五档",5:"六档",6:"七档",7:"关闭"}
		},			
		eightHot:{
			name:"8度制热",value:0x00,view:{0:"关闭",1:"开启"}
		},
		doubleContral:{
			name:"双温控制",value:0x00,view:{0:"关闭",1:"开启"}
		},	
		doubleContralTemp:{
			name:"双温控制设定温度 000表示无效 1-13度",value:0x05
		},	
		doubleContralDot:{
			name:"双温控制小数位",value:0x00,view:{0:"0",1:"0.5度"}
		},
		indoorTemperatureDot:{
			name:"室内温度(小数)",value:0x00
		},
		outdoorTemperatureDot:{
			name:"室外温度(小数)",value:0x00
		},
		setHumidity:{
			name:"设定湿度",value:0x00
		},
		//2017-04-17
		smartSleepSW:{
			name:"舒睡开关",value:0x00,view:{0:"关闭",1:"开启"}
		},
		smartSleepTime:{
			name:"舒睡时间",value:0x00,view:{0:"0小时",1:"1小时",2:"2小时",3:"3小时",4:"4小时",5:"5小时"
			,6:"6小时",7:"7小时",8:"8小时",9:"9小时",10:"10小时"}
		},
		updownLocation:{
			name:"上下风角度",value:0x00
		},
		leftrightLocation:{
			name:"左右风角度",value:0x00
		},	
		sleepTimeFirst:{
			name:"舒睡第1时温度",value:0x00
		},
		sleepTimeSecond:{
			name:"舒睡第2时温度",value:0x00
		},
		sleepTimeThird:{
			name:"舒睡第3时温度",value:0x00
		},
		sleepTimeFourth:{
			name:"舒睡第4时温度",value:0x00
		},
		sleepTimeFifth:{
			name:"舒睡第5时温度",value:0x00
		},
		sleepTimeSixth:{
			name:"舒睡第6时温度",value:0x00
		},
		sleepTimeSeventh:{
			name:"舒睡第7时温度",value:0x00
		},
		sleepTimeEighth:{
			name:"舒睡第8时温度",value:0x00
		},
		sleepTimeNinth:{
			name:"舒睡第9时温度",value:0x00
		},	
		sleepTimeTenth:{
			name:"舒睡第10时温度",value:0x00
		},
		unit_1_status:{
			name:"1号机状态",value:0x00,view:{0:"未知",1:"在线",2:"不在线",3:"故障"}
		},
		unit_2_status:{
			name:"2号机状态",value:0x00,view:{0:"未知",1:"在线",2:"不在线",3:"故障",4:"逻辑冲突"}
		},
		unit_3_status:{
			name:"3号机状态",value:0x00,view:{0:"未知",1:"在线",2:"不在线",3:"故障",4:"逻辑冲突"}
		},
		unit_4_status:{
			name:"4号机状态",value:0x00,view:{0:"未知",1:"在线",2:"不在线",3:"故障",4:"逻辑冲突"}
		},
		unit_5_status:{
			name:"5号机状态",value:0x00,view:{0:"未知",1:"在线",2:"不在线",3:"故障",4:"逻辑冲突"}
		},
		unit_6_status:{
			name:"6号机状态",value:0x00,view:{0:"未知",1:"在线",2:"不在线",3:"故障",4:"逻辑冲突"}
		},
		unit_7_status:{
			name:"7号机状态",value:0x00,view:{0:"未知",1:"在线",2:"不在线",3:"故障",4:"逻辑冲突"}
		},
		unit_8_status:{
			name:"8号机状态",value:0x00,view:{0:"未知",1:"在线",2:"不在线",3:"故障",4:"逻辑冲突"}
		},	
		unit_1_code:{
			name:"1号机条码",value:"00000000000000000000000000000000"
		},
		unit_2_code:{
			name:"2号机条码",value:"00000000000000000000000000000000"
		},
		unit_3_code:{
			name:"3号机条码",value:"00000000000000000000000000000000"
		},
		unit_4_code:{
			name:"4号机条码",value:"00000000000000000000000000000000"
		},
		unit_5_code:{
			name:"5号机条码",value:"00000000000000000000000000000000"
		},
		unit_6_code:{
			name:"6号机条码",value:"00000000000000000000000000000000"
		},
		unit_7_code:{
			name:"7号机条码",value:"00000000000000000000000000000000"
		},
		unit_8_code:{
			name:"8号机条码",value:"00000000000000000000000000000000"
		},
	};
};

//新旧协议区分解释
ACDriver.prototype.parseMessageProtocol = function(pReceiveMessage){
		
//		pReceiveMessage =[0xAA,0x25,0xAC,0x00,0x00,0x00,0x00,0x00,0x02,0x03,
//                        0xBC,0x00,0x01,0x04,0x0A,0x00,0x12,0x04,0x04,0x01,
//                        0x01,0x02,0x01,0x01,0x02,0x02,0x02,0x00,0x00,0x00,
//                        0x00,0x00,0x00,0x00,0x00,0x00,0x73,0xC6];
            
		var receiveMessageBody = pReceiveMessage.slice(10,pReceiveMessage.length - 1);
		
//		alert('receiveMessageBody:' + receiveMessageBody);
		
		var messageType = mdSmart.message.getByte(pReceiveMessage,9);
		var isEquipmentReturnCommandBack = false,isX05Xa0Back=false,isX04Xa1Back=false;
		bridge.logToIOS("_parseMessage="+pReceiveMessage);
		_equipmentReturnCommandBack = pReceiveMessage;
	
		var isNEWVerBack = false;
		
		//2017-04-17 一拖多机型新协议命令回复处理
		if((receiveMessageBody[0] == 0xBC) || (receiveMessageBody[0] == 0xBA))
		{
			isNEWVerBack =  true;
		}		
		//2017-04-17 一拖多机型新协议命令全部状态查询回复处理
		if(receiveMessageBody[0] == 0xBF){
			//设备返回命令(设备当前状态返回)
			isEquipmentReturnCommandBack = true;
		}
		//设备返回命令(设备当前状态返回)
		if(isEquipmentReturnCommandBack == true){
			parseEquipmentReturnCommandBackToStatus(receiveMessageBody);
		}
		
		//设备返回命令(设备当前状态返回)
		if(isNEWVerBack == true){
			parseEquipmentReturnCommandBackForNewVer(receiveMessageBody);
		}		

//		var result = {
//			messageType:messageType,
//			status:_status
//		};
//  $.event.trigger("updateViewMessage", {});
		return 0;	
};

// 设备返回命令==>_status
function parseEquipmentReturnCommandBackToStatus(pReceiveMessageBody){
	console.log("sssssssssssss",pReceiveMessageBody);
	//2017-04-同步分区地址
   
	_ACDriver.deviceStatus.locationOrder = mdSmart.message.getByte(pReceiveMessageBody,1);
	
	_ACDriver.deviceStatus.faultFlag.value = mdSmart.message.getBit(pReceiveMessageBody,2,7);
	_ACDriver.deviceStatus.fastCheckStatus.value = mdSmart.message.getBit(pReceiveMessageBody,2,5);
	_ACDriver.deviceStatus.timeingMode.value = mdSmart.message.getBit(pReceiveMessageBody,2,4);
	_ACDriver.deviceStatus.iModeRecovery.value = mdSmart.message.getBit(pReceiveMessageBody,2,2);
	_ACDriver.deviceStatus.runningState.value = mdSmart.message.getBit(pReceiveMessageBody,2,0);
	
	
	_ACDriver.deviceStatus.settingMode.value = mdSmart.message.getBits(pReceiveMessageBody,3,5,7);
	
	_ACDriver.deviceStatus.settingTemperature.value = mdSmart.message.getBits(pReceiveMessageBody,3,0,3);
	_ACDriver.deviceStatus.settingTemperature.value = _ACDriver.deviceStatus.settingTemperature.value + 16;
	if(_ACDriver.deviceStatus.settingTemperature.value > 30){
		_ACDriver.deviceStatus.settingTemperature.value = 26;
	}
		if(_ACDriver.deviceStatus.settingTemperature.value < 17){
		_ACDriver.deviceStatus.settingTemperature.value = 26;
	}
	
	_ACDriver.deviceStatus.settingTemperatureDot5.value = mdSmart.message.getBit(pReceiveMessageBody,3,4);
	
	_ACDriver.deviceStatus.noPolarWindSpeedValue.value = mdSmart.message.getBits(pReceiveMessageBody,4,0,6);
	
	console.log('旧协议_ACDriver.deviceStatus.locationOrder:' + 	_ACDriver.deviceStatus.locationOrder); 
	console.log('旧协议_ACDriver.deviceStatus.runningState.value:' + _ACDriver.deviceStatus.runningState.value);
	console.log('旧协议_ACDriver.deviceStatus.settingMode.value:' + _ACDriver.deviceStatus.settingMode.value);
	console.log('旧协议_ACDriver.deviceStatus.settingTemperature.value:' + _ACDriver.deviceStatus.settingTemperature.value);
	console.log('旧协议_ACDriver.deviceStatus.noPolarWindSpeedValue.value:' + _ACDriver.deviceStatus.noPolarWindSpeedValue.value);
		  
	
	_ACDriver.deviceStatus.timingOpen.value = mdSmart.message.getBit(pReceiveMessageBody,5,7);
	console.log('旧协议_ACDriver.deviceStatus.timingOpen.value:' + _ACDriver.deviceStatus.timingOpen.value);
	_ACDriver.deviceStatus.timingOpenAbsoluteHours.value = mdSmart.message.getBits(pReceiveMessageBody,5,0,6);
	_ACDriver.deviceStatus.timingOpenAbsoluteMinutes.value = mdSmart.message.getBits(pReceiveMessageBody,7,4,7);
	if(_ACDriver.deviceStatus.timingOpenAbsoluteHours.value==0x7F){
		_ACDriver.deviceStatus.timingOpen.value = 0;
	}else{
		if(_ACDriver.deviceStatus.runningState.value==0){
		_ACDriver.deviceStatus.timingOpen.value = 1;
		var timeValue = parseInt(_ACDriver.deviceStatus.timingOpenAbsoluteHours.value) * 15 + parseInt(_ACDriver.deviceStatus.timingOpenAbsoluteMinutes.value);
	   _ACDriver.deviceStatus.timingOpenAbsoluteHours.value = parseInt(timeValue / 60);
	   _ACDriver.deviceStatus.timingOpenAbsoluteMinutes.value = parseInt(timeValue) % 60;
	  }else{
	  	_ACDriver.deviceStatus.timingOpen.value = 0;
	  }
	}
	console.log("timeValue:",timeValue);
	console.log("_ACDriver.deviceStatus.timingOpenAbsoluteHours.value:",_ACDriver.deviceStatus.timingOpenAbsoluteHours.value);
	console.log("_ACDriver.deviceStatus.timingOpenAbsoluteMinutes.value:",_ACDriver.deviceStatus.timingOpenAbsoluteMinutes.value);
	
	_ACDriver.deviceStatus.timingClose.value = mdSmart.message.getBit(pReceiveMessageBody,6,7);
	_ACDriver.deviceStatus.timingCloseAbsoluteHours.value = mdSmart.message.getBits(pReceiveMessageBody,6,0,6);
	_ACDriver.deviceStatus.timingCloseAbsoluteMinutes.value = mdSmart.message.getBits(pReceiveMessageBody,7,0,3);
	if(_ACDriver.deviceStatus.timingCloseAbsoluteHours.value==0x7F){
	_ACDriver.deviceStatus.timingClose.value = 0;
	}else{
		if(_ACDriver.deviceStatus.runningState.value==1){
	_ACDriver.deviceStatus.timingClose.value = 1;
	var timeValue = parseInt(_ACDriver.deviceStatus.timingCloseAbsoluteHours.value) * 15 + parseInt(_ACDriver.deviceStatus.timingCloseAbsoluteMinutes.value);
	_ACDriver.deviceStatus.timingCloseAbsoluteHours.value = parseInt(timeValue / 60);
    _ACDriver.deviceStatus.timingCloseAbsoluteMinutes.value = parseInt(timeValue) % 60;
	  }else{
	_ACDriver.deviceStatus.timingClose.value = 0;
	  }
	}
	
	console.log("timeValue:",timeValue);
	console.log("_ACDriver.deviceStatus.timingCloseAbsoluteHours.value:",_ACDriver.deviceStatus.timingCloseAbsoluteHours.value);
	console.log("_ACDriver.deviceStatus.timingCloseAbsoluteMinutes.value:",_ACDriver.deviceStatus.timingCloseAbsoluteMinutes.value);
	console.log('旧协议_ACDriver.deviceStatus.timingClose.value00:' + _ACDriver.deviceStatus.timingClose.value);
	
//	if((_ACDriver.deviceStatus.runningState.value==1)&&(_ACDriver.deviceStatus.timingCloseAbsoluteHours.value>0||_ACDriver.deviceStatus.timingCloseAbsoluteMinutes.value>0)&&
//	(_ACDriver.deviceStatus.timingCloseAbsoluteHours.value!=127)){
//	_ACDriver.deviceStatus.timingClose.value=1;
//  var	timeValue = parseInt(_ACDriver.deviceStatus.timingCloseAbsoluteHours.value) * 15 + parseInt(_ACDriver.deviceStatus.timingCloseAbsoluteMinutes.value);
//	_ACDriver.deviceStatus.timingCloseAbsoluteHours.value = parseInt(timeValue / 60);
//	_ACDriver.deviceStatus.timingCloseAbsoluteMinutes.value = parseInt(timeValue) % 60;
//	}else if((_ACDriver.deviceStatus.runningState.value==0)&&(_ACDriver.deviceStatus.timingOpenAbsoluteHours.value>0||_ACDriver.deviceStatus.timingOpenAbsoluteMinutes.value>0)
//	&&(_ACDriver.deviceStatus.timingOpenAbsoluteHours.value!=127)){
//	_ACDriver.deviceStatus.timingOpen.value=1;
//	var timeValue = parseInt(_ACDriver.deviceStatus.timingOpenAbsoluteHours.value) * 15 + parseInt(_ACDriver.deviceStatus.timingOpenAbsoluteMinutes.value);
//	_ACDriver.deviceStatus.timingOpenAbsoluteHours.value = parseInt(timeValue / 60);
//	_ACDriver.deviceStatus.timingOpenAbsoluteMinutes.value = parseInt(timeValue) % 60;
//	}
	console.log('旧协议_ACDriver.deviceStatus.timingClose.value:' + _ACDriver.deviceStatus.timingClose.value);
	console.log('旧协议_ACDriver.deviceStatus.timingCloseAbsoluteHours.value:' + _ACDriver.deviceStatus.timingCloseAbsoluteHours.value);
	console.log('旧协议_ACDriver.deviceStatus.timingCloseAbsoluteMinutes.value:' + _ACDriver.deviceStatus.timingCloseAbsoluteMinutes.value);
	
	_ACDriver.deviceStatus.shushiFeng.value = mdSmart.message.getByte(pReceiveMessageBody,8);
	_ACDriver.deviceStatus.downWind.value = mdSmart.message.getBit(pReceiveMessageBody,21,7);
	_ACDriver.deviceStatus.personalFeeling.value = mdSmart.message.getBit(pReceiveMessageBody,9,7);
	_ACDriver.deviceStatus.zhihuiyan.value = mdSmart.message.getBit(pReceiveMessageBody,9,6);
	_ACDriver.deviceStatus.strong.value = mdSmart.message.getBit(pReceiveMessageBody,9,5);
	_ACDriver.deviceStatus.ruiFeng.value = mdSmart.message.getBit(pReceiveMessageBody,9,4);
	_ACDriver.deviceStatus.shengDian.value = mdSmart.message.getBit(pReceiveMessageBody,9,3);
	_ACDriver.deviceStatus.sleepMode.value = mdSmart.message.getBits(pReceiveMessageBody,9,0,1);
	console.log("旧协议_ACDriver.deviceStatus.sleepMode.value:",_ACDriver.deviceStatus.sleepMode.value);
	_ACDriver.deviceStatus.selfPersonalFeeling.value = mdSmart.message.getBit(pReceiveMessageBody,10,7);
	_ACDriver.deviceStatus.selfSleep.value = mdSmart.message.getBit(pReceiveMessageBody,10,6);
	_ACDriver.deviceStatus.purifyingFunction.value = mdSmart.message.getBit(pReceiveMessageBody,10,5);
	_ACDriver.deviceStatus.ecoFunction.value = mdSmart.message.getBit(pReceiveMessageBody,10,4);
	_ACDriver.deviceStatus.electricHeat.value = mdSmart.message.getBit(pReceiveMessageBody,10,3);
	console.log('旧协议_ACDriver.deviceStatus.electricHeat.value:' + _ACDriver.deviceStatus.electricHeat.value);
	_ACDriver.deviceStatus.dry.value = mdSmart.message.getBit(pReceiveMessageBody,10,2);
	console.log('旧协议_ACDriver.deviceStatus.dry.value:' + _ACDriver.deviceStatus.dry.value);
	_ACDriver.deviceStatus.naturalWindFunction.value = mdSmart.message.getBit(pReceiveMessageBody,10,1);
	_ACDriver.deviceStatus.childrenSleepMode.value = mdSmart.message.getBit(pReceiveMessageBody,10,0);
	_ACDriver.deviceStatus.coolWindMode.value = mdSmart.message.getBit(pReceiveMessageBody,11,7);
	_ACDriver.deviceStatus.peakValleyElectricity.value = mdSmart.message.getBit(pReceiveMessageBody,11,6);
	_ACDriver.deviceStatus.catchCold.value = mdSmart.message.getBit(pReceiveMessageBody,11,5);
	_ACDriver.deviceStatus.nightLight.value = mdSmart.message.getBit(pReceiveMessageBody,11,4);
	_ACDriver.deviceStatus.ventilation.value = mdSmart.message.getBit(pReceiveMessageBody,11,3);
	_ACDriver.deviceStatus.celsiusFahrenheit.value = mdSmart.message.getBit(pReceiveMessageBody,11,2);
	_ACDriver.deviceStatus.tubro.value = mdSmart.message.getBit(pReceiveMessageBody,11,1);
	_ACDriver.deviceStatus.sleepFunctionStatus.value = mdSmart.message.getBit(pReceiveMessageBody,11,0);
	
	//一拖多
	if(_ACDriver.deviceStatus.sleepMode.value == 3){
		_ACDriver.deviceStatus.sleepFunctionStatus.value = 1;
	}
	else{
		_ACDriver.deviceStatus.sleepFunctionStatus.value = 0;
	}
	
	console.log('旧协议_ACDriver.deviceStatus.sleepFunctionStatus.value:',_ACDriver.deviceStatus.sleepFunctionStatus.value);
	
	
	_ACDriver.deviceStatus.indoorTemperature.value = mdSmart.message.getByte(pReceiveMessageBody,12);
	_ACDriver.deviceStatus.outdoorTemperature.value = mdSmart.message.getByte(pReceiveMessageBody,13);

	_ACDriver.deviceStatus.indoorTemperature.value = parseInt((_ACDriver.deviceStatus.indoorTemperature.value - 50) / 2);
	_ACDriver.deviceStatus.outdoorTemperature.value = parseInt((_ACDriver.deviceStatus.outdoorTemperature.value-50) / 2);
	
	_ACDriver.deviceStatus.dustFullMark.value = mdSmart.message.getBit(pReceiveMessageBody,14,5);
	_ACDriver.deviceStatus.settingTemperature2.value = mdSmart.message.getBits(pReceiveMessageBody,14,0,4);
	_ACDriver.deviceStatus.pmvMode.value = mdSmart.message.getBits(pReceiveMessageBody,15,0,3);
	_ACDriver.deviceStatus.faultNo.value = mdSmart.message.getByte(pReceiveMessageBody,17);
	_ACDriver.deviceStatus.ecoSleepRunningMinus.value = mdSmart.message.getBits(pReceiveMessageBody,18,2,7);
	_ACDriver.deviceStatus.ecoSleepRunningSecond.value = mdSmart.message.getBits(pReceiveMessageBody,19,4,7) << 2 | mdSmart.message.getBits(pReceiveMessageBody,17,0,1);
	_ACDriver.deviceStatus.ecoSleepRunningHour.value = mdSmart.message.getBits(pReceiveMessageBody,19,0,3);
	
	_ACDriver.deviceStatus.indoorTemperatureDot.value = mdSmart.message.getBits(pReceiveMessageBody,16,0,3);
	_ACDriver.deviceStatus.outdoorTemperatureDot.value = mdSmart.message.getBits(pReceiveMessageBody,16,4,7);
	_ACDriver.deviceStatus.indoorTemperatureDot.value = parseInt(_ACDriver.deviceStatus.indoorTemperatureDot.value);
	_ACDriver.deviceStatus.outdoorTemperatureDot.value = parseInt(_ACDriver.deviceStatus.outdoorTemperatureDot.value);
	
	_ACDriver.deviceStatus.lightClass.value = mdSmart.message.getBits(pReceiveMessageBody,15,4,6);
	//2015-04-14 设定湿度值
	_ACDriver.deviceStatus.setHumidity.value = mdSmart.message.getBits(pReceiveMessageBody,20,0,6);
//	    frameCumulative=mdSmart.message.getByte(pReceiveMessageBody,20);
	
	 //升级协议前长度为22，超过22按新协议解释   2015-04-03
	 if(pReceiveMessageBody.length > 25){
        //20150320 wjl
	bridge.logToIOS("AC_P04 smartWind="+mdSmart.message.getBit(pReceiveMessageBody,23,3));
        _ACDriver.deviceStatus.readyColdOrHot.value = mdSmart.message.getBit(pReceiveMessageBody,23,0);
        _ACDriver.deviceStatus.braceLetSleep.value = mdSmart.message.getBit(pReceiveMessageBody,23,1);
        _ACDriver.deviceStatus.braceLetContral.value = mdSmart.message.getBit(pReceiveMessageBody,23,2);
        _ACDriver.deviceStatus.smartWind.value = mdSmart.message.getBit(pReceiveMessageBody,23,3);
    } 
    if(_ACDriver.deviceStatus.noPolarWindSpeedValue.value==0){
	_ACDriver.deviceStatus.noPolarWindSpeedValue.value=1;
}
     $.event.trigger("updateViewMessage", {});
}

ACDriver.prototype.statusExplainProtocol = function(pReceiveMessage){
	
};

ACDriver.prototype.parseNewProtocol = function(code) {
	this.syncStatus();
	
};

ACDriver.prototype.parseStandardProtocol = function(code) {
	this.syncStatus();
};

//2015-04-08 新协议返回解析
function  refreshNewVer(p1,p2) {
//	alert('refreshNewVer:' + 'p1' + p1 +';' + 'p2:' + p2);
	if((p1[0] == 0x01) && (p1[1] == 0x00)){
		_ACDriver.deviceStatus.runningState.value = p2[0];						//2017-04-17 开关状态
	}
	else if((p1[0] == 0x02) && (p1[1] == 0x00)){
		_ACDriver.deviceStatus.settingMode = p2[0];						//2017-04-17 模式状态
	}
	else if((p1[0] == 0x03) && (p1[1] == 0x00)){
		_ACDriver.deviceStatus.settingTemperature = (p2[0] - 50)/2;				//2017-04-17 设定温度
	}
	else if((p1[0] == 0x04) && (p1[1] == 0x00)){
		_ACDriver.deviceStatus.indoorTemperature = (p2[0] - 50)/2;					//2017-04-17 室内温度
	}
	else if((p1[0] == 0x05) && (p1[1] == 0x00)){
		_ACDriver.deviceStatus.outdoorTemperature = (p2[0] - 50)/2;				//2017-04-17 室外温度
	}
	else if((p1[0] == 0x06) && (p1[1] == 0x00)){
		_ACDriver.deviceStatus.noPolarWindSpeedValue = p2[0];				//2017-04-17 设定风速
//		alert('底_ACDriver.deviceStatus.noPolarWindSpeedValue:' + _ACDriver.deviceStatus.noPolarWindSpeedValue);
	}
	else if((p1[0] == 0x07) && (p1[1] == 0x00)){
		_ACDriver.deviceStatus.noPolarWindSpeedValue = p2[0];				//2017-04-17 实际风速
	}	
	else if((p1[0] == 0x08) && (p1[1] == 0x00)){
		_ACDriver.deviceStatus.shushiFeng = p2[0];						//2017-04-17 设定风向
	}
	else if((p1[0] == 0x09) && (p1[1] == 0x00)){
		_ACDriver.deviceStatus.updownLocation = p2[0];					//2017-04-17 上下风角度
	}	
	else if((p1[0] == 0x0a) && (p1[1] == 0x00)){
		_ACDriver.deviceStatus.leftrightLocation = p2[0];					//2017-04-17 左右风角度
	}		
	else if((p1[0] == 0x0B) && (p1[1] == 0x00)){
		_ACDriver.deviceStatus.timingOpen = p2[0];	
		//2017-04-17 定时开
		_ACDriver.deviceStatus.timingOpenAbsoluteHours = p2[1];			//2017-04-17 小时
		_ACDriver.deviceStatus.timingOpenAbsoluteMinutes = p2[2];			//2017-04-17 分
	}
	else if((p1[0] == 0x0C) && (p1[1] == 0x00)){
		_ACDriver.deviceStatus.timingClose = p2[0];						//2017-04-17 定时开
		_ACDriver.deviceStatus.timingCloseAbsoluteHours = p2[1];			//2017-04-17 小时
		_ACDriver.deviceStatus.timingCloseAbsoluteMinutes = p2[2];		//2017-04-17 分
	}
	else if((p1[0] == 0x0D) && (p1[1] == 0x00)){
		_ACDriver.deviceStatus.ecoFunction = p2[0];						//2017-04-17 ECO
	}
	else if((p1[0] == 0x0E) && (p1[1] == 0x00)){
		_ACDriver.deviceStatus.purifyingFunction = p2[0];					//2017-04-17 净化
	}
	else if((p1[0] == 0x0F) && (p1[1] == 0x00)){
		_ACDriver.deviceStatus.electricHeat = p2[0];						//2017-04-17 电辅热
	}
	else if((p1[0] == 0x10) && (p1[1] == 0x00)){
		_ACDriver.deviceStatus.dry = p2[0];								//2017-04-17 干燥
	}		
	else if((p1[0] == 0x11) && (p1[1] == 0x00)){
		_ACDriver.deviceStatus.sleepFunctionStatus = p2[0];				//2017-04-18 舒睡状态
	console.log("rrrrrrrrrrr",_ACDriver.deviceStatus.sleepFunctionStatus);
		
		_ACDriver.deviceStatus.sleepTimeFirst 		= (p2[2] - 50) / 2;//第1小时舒睡温度
		_ACDriver.deviceStatus.sleepTimeSecond 		= (p2[3] - 50) / 2;//第2小时舒睡温度
		_ACDriver.deviceStatus.sleepTimeThird 		= (p2[4] - 50) / 2;//第3小时舒睡温度
		_ACDriver.deviceStatus.sleepTimeFourth 		= (p2[5] - 50) / 2;//第4小时舒睡温度
		_ACDriver.deviceStatus.sleepTimeFifth 		= (p2[6] - 50) / 2;//第5小时舒睡温度
		_ACDriver.deviceStatus.sleepTimeSixth 		= (p2[7] - 50) / 2;//第6小时舒睡温度
		_ACDriver.deviceStatus.sleepTimeSeventh		= (p2[8] - 50) / 2;//第7小时舒睡温度
		_ACDriver.deviceStatus.sleepTimeEighth 		= (p2[9] - 50) / 2;//第8小时舒睡温度
		_ACDriver.deviceStatus.sleepTimeNinth 		= (p2[10] - 50) / 2;//第9小时舒睡温度
	}	
	else if((p1[0] == 0x01) && (p1[1] == 0x0a)){
		_ACDriver.deviceStatus.unit_1_code = p2.slice(1,33);		//1号机条码
		_ACDriver.deviceStatus.unit_2_code = p2.slice(33,65);		//2号机条码
		_ACDriver.deviceStatus.unit_3_code = p2.slice(65,97);		//3号机条码
		_ACDriver.deviceStatus.unit_4_code = p2.slice(97,129);	//4号机条码
		_ACDriver.deviceStatus.unit_5_code = p2.slice(129,161);;	//5号机条码
		_ACDriver.deviceStatus.unit_6_code = p2.slice(161,193);;	//6号机条码
	}
	else if((p1[0] == 0x02) && (p1[1] == 0x0a)){
		_ACDriver.deviceStatus.unit_7_code = p2.slice(1,33);		//7号机条码
		_ACDriver.deviceStatus.unit_8_code = p2.slice(33,65);		//8号机条码
	}
	else if((p1[0] == 0x04) && (p1[1] == 0x0a)){
		if(p2[0] == p2[1]){
			_ACDriver.deviceStatus.locationCount = p2[0];
			_ACDriver.deviceStatus.unit_1_status = p2[2];
			_ACDriver.deviceStatus.unit_2_status = p2[3];
			_ACDriver.deviceStatus.unit_3_status = p2[4];
			_ACDriver.deviceStatus.unit_4_status = p2[5];
			_ACDriver.deviceStatus.unit_5_status = p2[6];
			_ACDriver.deviceStatus.unit_6_status = p2[7];
			_ACDriver.deviceStatus.unit_7_status = p2[8];
			_ACDriver.deviceStatus.unit_8_status = p2[9];
			
//			alert('_ACDriver.deviceStatus.locationCount:' + _ACDriver.deviceStatus.locationCount + ';' + 
//				  '_ACDriver.deviceStatus.unit_1_status:' + _ACDriver.deviceStatus.unit_1_status + ';' +
//				  '_ACDriver.deviceStatus.unit_2_status:' + _ACDriver.deviceStatus.unit_2_status + ';' +
//				  '_ACDriver.deviceStatus.unit_3_status:' + _ACDriver.deviceStatus.unit_3_status + ';' +
//				  '_ACDriver.deviceStatus.unit_4_status:' + _ACDriver.deviceStatus.unit_4_status + ';' +
//				  '_ACDriver.deviceStatus.unit_5_status:' + _ACDriver.deviceStatus.unit_5_status + ';' +
//				  '_ACDriver.deviceStatus.unit_6_status:' + _ACDriver.deviceStatus.unit_6_status + ';' +
//				  '_ACDriver.deviceStatus.unit_7_status:' + _ACDriver.deviceStatus.unit_7_status + ';' +
//				  '_ACDriver.deviceStatus.unit_8_status:' + _ACDriver.deviceStatus.unit_8_status
//				 );
		}
		else{
			alert('系统设置错误.');
		}
	}
	else{
		return;
	}		
}

//2015-04-08 新协议返回解析
function parseEquipmentReturnCommandBackForNewVer(pReceiveMessageBody) {
	_ACDriver.deviceStatus.locationOrder = pReceiveMessageBody[1];//同步分区地址
	
	var dealCount = pReceiveMessageBody[2];//属性个数
	
	var si = 0;
	var sj = 0;
	var NewCmdType =[];               //属性命令
	var NewCmdLength = 0;			  //属性长度
	var NewValue =[];				  //属性值
	var sk = 3;

	for(si = 0; si < dealCount; si++){
		NewCmdType[0] = pReceiveMessageBody[sk];
		NewCmdType[1] = pReceiveMessageBody[sk + 1];  //高位
		
		NewCmdLength = pReceiveMessageBody[sk + 3];
		if(pReceiveMessageBody[sk + 2] == 0x00){
			for(sj = 0; sj < NewCmdLength; sj++){
				NewValue[sj] = pReceiveMessageBody[sk + 4 + sj];	
			}
			
			refreshNewVer(NewCmdType,NewValue);	
		}		
		else{
//			alert('设置失败！');
		}
       sk =  sk + 3 + NewCmdLength + 1 ;
	}
}

		
		
	
/**
 * 一拖多版新协议命令打包,专门用于控制
 * 根据家电控制内容转换为控制指令
 * @param {Number} itemNum 家电要控制的属性个数
 * @param {Array} items 家电要控制的属性内容， {[家电属性代码（2字节）+ 属性值长度（1字节）+ 属性值（变长）],[...]}
 * @return {Array} 用于发码的家电字节数组
 */
ACDriver.prototype.cmdNewProtocol4MutableItemControl_JZ = function(itemNum,items) {
	   var itemNumWithTone = itemNum + 1;//增加声音控制 
	   var messageBody =[];
	   mdSmart.message.setByte(messageBody,0,0xBA);
	   
//	   alert('_ACDriver.deviceStatus.locationOrder_1:' + _ACDriver.deviceStatus.locationOrder);
	   
	   mdSmart.message.setByte(messageBody,1,_ACDriver.deviceStatus.locationOrder); //分区地址
	   
	   mdSmart.message.setByte(messageBody,2,itemNumWithTone); //属性个数
	   
	   var itemsContentLength = items.length;
	   for (i = 0 ; i < itemsContentLength ; i++) {
	   	 mdSmart.message.setByte(messageBody,3 + i,items[i]);
	   }
	   
	  var toneFirstBit = 3 + itemsContentLength;
	  
	  mdSmart.message.setByte(messageBody,toneFirstBit,0x1A);
	  mdSmart.message.setByte(messageBody,toneFirstBit + 1,0x00);
	  mdSmart.message.setByte(messageBody,toneFirstBit + 2,0x01);
	  var SNStr = bridge.getCurrentDevSN();
	  var promptStr = localStorage.getItem("ACTone"+SNStr);
	  if ("0" == promptStr) {
			mdSmart.message.setByte(messageBody,toneFirstBit + 3,0x00);
	  } else {
			mdSmart.message.setByte(messageBody,toneFirstBit + 3,0x01);
	  }
	   
	   mdSmart.message.setByte(messageBody,toneFirstBit + 4,0x00);
	   mdSmart.message.setByte(messageBody,toneFirstBit + 4,mdSmart.message.CRC8(messageBody));
	   var message = mdSmart.message.createMessage(0xAC,0x02,messageBody);
	   
	   return message;
}


/**
	 * 一拖多版新协议命令打包,专门用于查询
	 * 根据家电控制内容转换为控制指令
	 * @param {Number} itemNum 家电要控制的属性个数
	 * @param {Array} items 家电要控制的属性内容， {[家电属性代码（2字节)]}
	 * @return {Array} 用于发码的家电字节数组
	 */
ACDriver.prototype.cmdNewProtocol4MutableItemQueue_JZ = function(itemNum,items,locationOrder) {
	   var itemNumWithTone = itemNum + 1;//增加声音控制
	   var messageBody =[];
	   mdSmart.message.setByte(messageBody,0,0xBC);
	   			
	   mdSmart.message.setByte(messageBody,1,_ACDriver.deviceStatus.locationOrder); //分区地址
	   
       mdSmart.message.setByte(messageBody,2,itemNumWithTone); //属性个数
       
       var itemsContentLength = items.length;
       for (i = 0 ; i < itemsContentLength ; i++) {
       	 mdSmart.message.setByte(messageBody,3 + i,items[i]);
       }
       
      var toneFirstBit = 3 + itemsContentLength;
      
      mdSmart.message.setByte(messageBody,toneFirstBit,0x1A);
      mdSmart.message.setByte(messageBody,toneFirstBit + 1,0x00);
      mdSmart.message.setByte(messageBody,toneFirstBit + 2,0x01);
        
      var SNStr = bridge.getCurrentDevSN();
      
              
      var promptStr = localStorage.getItem("ACTone"+SNStr);
	  if ("0" == promptStr) {
			mdSmart.message.setByte(messageBody,toneFirstBit + 3,0x00);
	  } else {
			mdSmart.message.setByte(messageBody,toneFirstBit + 3,0x01);
	  }
       
       mdSmart.message.setByte(messageBody,toneFirstBit + 4,0x00);
       
//     mdSmart.message.setByte(messageBody,toneFirstBit + 4,_CRC8(messageBody));
	   mdSmart.message.setByte(messageBody,toneFirstBit + 4,mdSmart.message.CRC8(messageBody));
       
	   var message = mdSmart.message.createMessage(0xAC,0x03,messageBody);
//	   console.log("111111111111111111111",locationOrder);
//	   console.log("111111111111111111111",message);
		return message;
	}
/**
 * 全控操作
 * @param msg[0]:开关状态，msg[1]:运行模式，msg[2]:设定温度，msg[3]:设定风速
 */
ACDriver.prototype.loopControlDevice = function(msg) {
  var itemsNum = 6;
  var itemsBytes = [];

  //新协议开关机
  itemsBytes[0] = 0x01;
  itemsBytes[1] = 0x00;
  itemsBytes[2] = 1; //属性长度
  itemsBytes[3] = msg[0];
  
  //新协议模式
  itemsBytes[4] = 0x02;
  itemsBytes[5] = 0x00;
  itemsBytes[6] = 1; //属性长度
  itemsBytes[7] = msg[1];
  
  //新协议设定温度
  itemsBytes[8] = 0x03;
  itemsBytes[9] = 0x00;
  itemsBytes[10] = 1; //属性长度
  itemsBytes[11] = (msg[2] * 2) + 50;
  
  //新协议设定风速
  itemsBytes[12] = 0x06;
  itemsBytes[13] = 0x00;
  itemsBytes[14] = 1; //属性长度
  itemsBytes[15] = msg[3]; 
  
  //清定时开关	
	itemsBytes[16] = 0x0B;
	itemsBytes[17] = 0x00;			
	itemsBytes[18] = 3; //属性长度
	itemsBytes[19] = 0;
	itemsBytes[20] = 0;
	itemsBytes[21] = 0;
	
	itemsBytes[22] = 0x0C;
	itemsBytes[23] = 0x00;			
	itemsBytes[24] = 3; //属性长度
	itemsBytes[25] = 0;
	itemsBytes[26] = 0;
	itemsBytes[27] = 0;		
  
   
  //生成控制指令，回调后更新界面
  var cmdBytes = this.cmdNewProtocol4MutableItemControl_JZ(itemsNum, itemsBytes);

  return cmdBytes;
  
 }


/*** 一拖多版新协议命令打包,专门用于查询分机详细状态*/
ACDriver.prototype.cmdNewProtocol4MutableItemDeviceQueue_JZ = function(deviceOrder) {
	
//	   alert('niana');
	   var messageBody =[];
	   mdSmart.message.setByte(messageBody,0,0xBF);
	   mdSmart.message.setByte(messageBody,1,deviceOrder);	//分区地址	
	   mdSmart.message.setByte(messageBody,2,0x21);	
	   mdSmart.message.setByte(messageBody,3,0x00);	
	   mdSmart.message.setByte(messageBody,4,0xFF);	
	   mdSmart.message.setByte(messageBody,5,0x03);	
	   mdSmart.message.setByte(messageBody,6,0xFF);	
	   mdSmart.message.setByte(messageBody,7,0x00);	
	   mdSmart.message.setByte(messageBody,8,0x02);	
	   mdSmart.message.setByte(messageBody,9,0x00);
	   mdSmart.message.setByte(messageBody,10,0x00);
	   mdSmart.message.setByte(messageBody,11,0x00);
	   mdSmart.message.setByte(messageBody,12,0x08);
	   mdSmart.message.setByte(messageBody,13,0x00);
	   mdSmart.message.setByte(messageBody,13,mdSmart.message.CRC8(messageBody));
       
	   var message = mdSmart.message.createMessage(0xAC,0x03,messageBody);
		return message;
	}


/**
 * 开关机操作
 * @param isOpen：true开机，false关机
 */
ACDriver.prototype.controlDeviceOnAndOff = function(isOpen) {
		var itemsNum = 3;
		var itemsBytes = [];

		//新协议开关机
		itemsBytes[0] = 0x01;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(isOpen){
			itemsBytes[3] = 1;
		}
		else{
			itemsBytes[3] = 0;
	 	}
			
		//清定时开关	
		itemsBytes[4] = 0x0B;
		itemsBytes[5] = 0x00;			
		itemsBytes[6] = 3; //属性长度
		itemsBytes[7] = 0;
		itemsBytes[8] = 0;
		itemsBytes[9] = 0;
		itemsBytes[10] = 0x0C;
		itemsBytes[11] = 0x00;			
		itemsBytes[12] = 3; //属性长度
		itemsBytes[13] = 0;
		itemsBytes[14] = 0;
		itemsBytes[15] = 0;		
				
		//发送指令设置开关机，回调后更新界面
		var cmdBytes = this.cmdNewProtocol4MutableItemControl_JZ(itemsNum, itemsBytes);

		return cmdBytes;
		
//		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
//			_dataManager.resetCachePreventCold();
//			processNewProtocolDataAndNotifyRefreshView(messageBack);
//		}, function(message) {
//			processOperateFailCallBack(message);
//		});
	}

//设置模式
ACDriver.prototype.controlComfortMode = function(modeType) {

		var itemsNum = 2;
		var itemsBytes = [];

		//新协议模式
		itemsBytes[0] = 0x02;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if((modeType == 0) || (modeType > 7)){
			itemsBytes[3] = 1;
		}
		else{
			itemsBytes[3] = modeType;
	 	}
		
		//2017-08-18 设置模式同时强制关闭舒睡
		itemsBytes[4] = 0x11;
		itemsBytes[5] = 0x00;
		itemsBytes[6] = 11; //属性长度
		itemsBytes[7] = 0x00;
		itemsBytes[8] = 10;
		itemsBytes[9] = 50;
		itemsBytes[10] = 50;
		itemsBytes[11] = 50;
		itemsBytes[12] = 50;
		itemsBytes[13] = 50;
		itemsBytes[14] = 50;
		itemsBytes[15] = 50;
		itemsBytes[16] = 50;
		itemsBytes[17] = 50;
				
		//发送指令设置模式，回调后更新界面
		var cmdBytes = this.cmdNewProtocol4MutableItemControl_JZ(itemsNum, itemsBytes);
		
		return cmdBytes;
		
//		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
//			_dataManager.resetCachePreventCold();
//			processNewProtocolDataAndNotifyRefreshView(messageBack);
//		}, function(message) {
//			processOperateFailCallBack(message);
//		});
	}

//设置风速
ACDriver.prototype.controlComfortWindSpeed = function(windSpeedValue) {

		var itemsNum = 1;
		var itemsBytes = [];

		//新协议模式
		itemsBytes[0] = 0x06;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		
		if((windSpeedValue ==0 )||(windSpeedValue > 102)){
			itemsBytes[3] = 102;
		}
		else{
			itemsBytes[3] = windSpeedValue;
		}
		//发送指令设置风速，回调后更新界面
		var cmdBytes = this.cmdNewProtocol4MutableItemControl_JZ(itemsNum, itemsBytes);
		
		return cmdBytes;
		
//		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
//			_dataManager.resetCachePreventCold();
//			processNewProtocolDataAndNotifyRefreshView(messageBack);
//		}, function(message) {
//			processOperateFailCallBack(message);
//		});
	}

/**
 * 设置温度,参数：整数，小数
 * @param integerNum:整数，范围17到30值，
 * 
 */
ACDriver.prototype.controlSetTemperature = function(integerNum) {

		var itemsNum = 2;
		var itemsBytes = [];

		//新协议模式
		itemsBytes[0] = 0x03;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		itemsBytes[3] = (integerNum * 2) + 50;
		
		
		//2017-08-18 设置模式同时强制关闭舒睡
		itemsBytes[4] = 0x11;
		itemsBytes[5] = 0x00;
		itemsBytes[6] = 11; //属性长度
		itemsBytes[7] = 0x00;
		itemsBytes[8] = 10;
		itemsBytes[9] = 50;
		itemsBytes[10] = 50;
		itemsBytes[11] = 50;
		itemsBytes[12] = 50;
		itemsBytes[13] = 50;
		itemsBytes[14] = 50;
		itemsBytes[15] = 50;
		itemsBytes[16] = 50;
		itemsBytes[17] = 50;
		
		//发送指令设置温度，回调后更新界面
		var cmdBytes = this.cmdNewProtocol4MutableItemControl_JZ(itemsNum, itemsBytes);
		
		return cmdBytes;
		
//		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
//			_dataManager.resetCachePreventCold();
//			processNewProtocolDataAndNotifyRefreshView(messageBack);
//		}, function(message) {
//			processOperateFailCallBack(message);
//		});
}




/**
 * 定时功能打开，或者关闭
 * @param isOn:true 定时开机，false定时关机,hh小时，mm分钟
 */
ACDriver.prototype.controlSetTimerDeviceOnOff = function(isOn,isSw, hh, mm) {

		var itemsNum = 2;
		var itemsBytes = [];	
		
		if(isOn){
			//定时开
			itemsBytes[0] = 0x0C;
			itemsBytes[1] = 0x00;			
			itemsBytes[2] = 3; //属性长度
			itemsBytes[3] = isSw;
			itemsBytes[4] = hh;
			itemsBytes[5] = mm;
			//定时开
			itemsBytes[6] = 0x0B;
			itemsBytes[7] = 0x00;			
			itemsBytes[8] = 3; //属性长度
			itemsBytes[9] = 0;
			itemsBytes[10] = 0;
			itemsBytes[11] = 0;
		}
		else{
			//定时开
			itemsBytes[0] = 0x0B;
			itemsBytes[1] = 0x00;			
			itemsBytes[2] = 3; //属性长度
			itemsBytes[3] = isSw;
			itemsBytes[4] = hh;
			itemsBytes[5] = mm;
			//定时开
			itemsBytes[6] = 0x0C;
			itemsBytes[7] = 0x00;			
			itemsBytes[8] = 3; //属性长度
			itemsBytes[9] = 0;
			itemsBytes[10] = 0;
			itemsBytes[11] = 0;			
		}
		//发送指令设置定时开关机，回调后更新界面
		var cmdBytes = this.cmdNewProtocol4MutableItemControl_JZ(itemsNum, itemsBytes);
		
		return cmdBytes;
		
//		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
//			_dataManager.resetCachePreventCold();
//			processNewProtocolDataAndNotifyRefreshView(messageBack);
//		}, function(message) {
//			processOperateFailCallBack(message);
//		});		
}

/**
 * 查询定时状态
 * 
 */
ACDriver.prototype.queryTimerDeviceOnOff = function(p1) {
console.log("555555555555555555555555",p1);
		var itemsNum = 8;
		var itemsBytes = [];
		
		if(p1 == true){
			//新协议模式
			itemsBytes[0] = 0x0B;
			itemsBytes[1] = 0x00;
		}
		else{
		//定时关
		//新协议模式
			itemsBytes[0] = 0x0C;
			itemsBytes[1] = 0x00;		
		}
		itemsBytes[2] = 0x01;
		itemsBytes[3] = 0x00;
		
		itemsBytes[4] = 0x02;
		itemsBytes[5] = 0x00;
		
		itemsBytes[6] = 0x03;
		itemsBytes[7] = 0x00;
		
		itemsBytes[8] = 0x06;
		itemsBytes[9] = 0x00;
		
		itemsBytes[10] = 0x0f;
		itemsBytes[11] = 0x00;	
		
		itemsBytes[12] = 0x10;
		itemsBytes[13] = 0x00;
		
		//舒睡
		itemsBytes[14] = 0x11;
		itemsBytes[15] = 0x00;		
		
		//发送指令设置定时开关机，回调后更新界面
		var cmdBytes = this.cmdNewProtocol4MutableItemQueue_JZ(itemsNum, itemsBytes);
		console.log("vvvvvvvvvvvv:",cmdBytes);
		return cmdBytes;		
}

//设置干燥
	/**
 * 干燥功能切换
 * @param isOpen:true 干燥功能开发，false干燥功能关闭
 * 干燥在制热、自动、送风模式下无效
 */
ACDriver.prototype.controlComfortDry = function(isOpen) {

		var itemsNum = 1;
		var itemsBytes = [];

		//新协议模式
		itemsBytes[0] = 0x10;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(isOpen){
			itemsBytes[3] = 1;
		}
		else{
			itemsBytes[3] = 0;
		}
		//发送指令设置干燥，回调后更新界面
		var cmdBytes = this.cmdNewProtocol4MutableItemControl_JZ(itemsNum, itemsBytes);
		
		return cmdBytes;
		
//		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
//			_dataManager.resetCachePreventCold();
//			processNewProtocolDataAndNotifyRefreshView(messageBack);
//		}, function(message) {
//			processOperateFailCallBack(message);
//		});
}

/**
 * 电辅热功能切换
 * @param isOpen:true 电辅热功能打开，false干燥功能关闭
 * 仅在自动、制热模式有效
 */
ACDriver.prototype.controlSwitchElecHeatHelper = function(isOpen) {

		var itemsNum = 1;
		var itemsBytes = [];

		//新协议模式
		itemsBytes[0] = 0x0F;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(isOpen){
			itemsBytes[3] = 1;
		}
		else{
			itemsBytes[3] = 0;
		}
		//发送指令设置电辅热，回调后更新界面
		var cmdBytes = this.cmdNewProtocol4MutableItemControl_JZ(itemsNum, itemsBytes);
		
		return cmdBytes;
		
//		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
//			_dataManager.resetCachePreventCold();
//			processNewProtocolDataAndNotifyRefreshView(messageBack);
//		}, function(message) {
//			processOperateFailCallBack(message);
//		});
}

/**
 * 屏显功能切换
 * @param isOpen:true 屏显功能打开，false屏显功能关闭
 */
ACDriver.prototype.controlSwitchScreenDisplay = function(isOpen) {

		var itemsNum = 1;
		var itemsBytes = [];

		//新协议模式
		itemsBytes[0] = 0x17;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if(isOpen){
			itemsBytes[3] = 1;
		}
		else{
			itemsBytes[3] = 0;
		}
		//发送指令设置屏显，回调后更新界面
		var cmdBytes = this.cmdNewProtocol4MutableItemControl_JZ(itemsNum, itemsBytes);
		
		return cmdBytes;
		
//		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
//			_dataManager.resetCachePreventCold();
//			processNewProtocolDataAndNotifyRefreshView(messageBack);
//		}, function(message) {
//			processOperateFailCallBack(message);
//		});
}
	
/**
 * 查询分机在线状态查询
 * @param isOpen:true 屏显功能打开，false屏显功能关闭
 */
ACDriver.prototype.controlDeviceStatus_JZ = function(isOpen) {
		
//		var itemsNum = 1;
//		var itemsBytes = [];
//
//		//新协议模式
//		itemsBytes[0] = 0x04;
//		itemsBytes[1] = 0x0A;

		//发送指令查询设备，回调后更新界面
//		var cmdBytes = this.cmdNewProtocol4MutableItemQueue_JZ(itemsNum, itemsBytes);
		var cmdBytes = [];
		cmdBytes[0] = 0xAA;
		cmdBytes[1] = 0x12;
		cmdBytes[2] = 0xAC;
		cmdBytes[3] = 0x00;
		cmdBytes[4] = 0x00;
		cmdBytes[5] = 0x00;
		cmdBytes[6] = 0x00;
		cmdBytes[7] = 0x00;
		cmdBytes[8] = 0x00;
		cmdBytes[9] = 0x03;
		cmdBytes[10] = 0xBC;
		cmdBytes[11] = 0x00;
		cmdBytes[12] = 0x01;
		cmdBytes[13] = 0x04;
		cmdBytes[14] = 0x0a;
		cmdBytes[15] = 0x00;
		cmdBytes[16] = 0x03;
		cmdBytes[17] = 0xCD;
		cmdBytes[18] = 0xA4;
		return cmdBytes;
		
//		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
//			_dataManager.resetCachePreventCold();
//			processNewProtocolDataAndNotifyRefreshView(messageBack);
//		}, function(message) {
//			processOperateFailCallBack(message);
//		});
}	
	
/**
 * 查询分机条码查询
 * @param groupOrder:分组号
 */
ACDriver.prototype.controlDeviceCode_JZ = function(groupOrder) {

		var itemsNum = 1;
		var itemsBytes = [];
		
		//新协议模式
		itemsBytes[0] = groupOrder;
		itemsBytes[1] = 0x0A;
		
		//发送指令查询设备，回调后更新界面
		var cmdBytes = this.cmdNewProtocol4MutableItemQueue_JZ(itemsNum, itemsBytes);
		
		return cmdBytes;
		
//		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
//			_dataManager.resetCachePreventCold();
//			processNewProtocolDataAndNotifyRefreshView(messageBack);
//		}, function(message) {
//			processOperateFailCallBack(message);
//		});
}		

/**
 *发送数据到家电，控制舒睡开关
 * @param {Object} sleepModeValue  0：关 ， 3:开
 */
ACDriver.prototype.setLocalSleepStatus = function(sleepBuffer) {

		var itemsNum = 1;
		var itemsBytes = [];
		
		//新协议模式
		itemsBytes[0] = 0x11;
		itemsBytes[1] = 0x00;
		
		itemsBytes[2] = sleepBuffer.length;
		itemsBytes[3] = sleepBuffer[0];
		itemsBytes[4] = sleepBuffer[1];
		itemsBytes[5] = (sleepBuffer[2] * 2) + 50;
		itemsBytes[6] = (sleepBuffer[3] * 2) + 50;
		itemsBytes[7] = (sleepBuffer[4] * 2) + 50;
		itemsBytes[8] = (sleepBuffer[5] * 2) + 50;
		itemsBytes[9] = (sleepBuffer[6] * 2) + 50;
		itemsBytes[10] = (sleepBuffer[7] * 2) + 50;
		itemsBytes[11] = (sleepBuffer[8] * 2) + 50;
		itemsBytes[12] = (sleepBuffer[9] * 2) + 50;
		itemsBytes[13] = (sleepBuffer[10] * 2) + 50;
		
		//发送指令设置舒睡，回调后更新界面
		var cmdBytes = this.cmdNewProtocol4MutableItemControl_JZ(itemsNum, itemsBytes);	
//		alert('cmdBytes:' +cmdBytes);
		return cmdBytes;
}

/**
 * 无风感功能切换
 * @param isOpen:true 无风感功能打开，false 无风感功能关闭
 * 无风感仅在制冷模式下有效
 */
ACDriver.prototype.controlSwitchNoWindFeel = function(isOpen) {

		var itemsNum = 1;
		var itemsBytes = [];

		itemsBytes[0] = 0x18;
		itemsBytes[1] = 0x00;
		itemsBytes[2] = 1; //属性长度
		if (isOpen) {
			itemsBytes[3] = 1;
		} else {
			itemsBytes[3] = 0;
		}
		var cmdBytes = this.cmdNewProtocol4MutableItemControl(itemsNum, itemsBytes);
//		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
//			processNewProtocolDataAndNotifyRefreshView(messageBack);
//		}, function(message) {
//			processOperateFailCallBack(message);
//		});

		return cmdBytes;
		
}
	
	/**
	 * 请求室内湿度值
	 */
ACDriver.prototype.requestHumidityValue = function() {

		var tmpCheckTypeCount = 1; //查询属性个数
		var tmpValue = [];
		//室内湿度
		tmpValue[0] = 0x00; //高位  
		tmpValue[1] = 0x15; //低位

		var cmdBytes = this.cmdNewVerForCheck(tmpCheckTypeCount, tmpValue);
		
		return cmdBytes;
		
//		var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
//			processHumidityValueRefreshView(messageBack);
//		}, function(message) {
//			processOperateFailCallBack(message);
//		});
}

var _ACDriver = new ACDriver();


//maybe useful
// ACDriver.prototype.setDeviceStatus = function() {

// };

// ACDriver.prototype.setTemp = function() {

// };

// ACDriver.prototype.setWindSpeed = function() {

// };

// ACDriver.prototype.setTimer = function(isOpen) {

// };

