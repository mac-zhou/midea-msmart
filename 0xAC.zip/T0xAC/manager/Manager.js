/**
 * @author yuxg
 * @file 定义ACDataManager ，对底层数据进行封装处理
 */
mdSmart.ACDataManager = function() {
	var _deviceInfo = undefined;
	var _deviceStatus = undefined;
	var _dataStorage = undefined;
	var _deviceVideoUrl = undefined;
	var _mideaAfterSaleUrl = "";
	var _mideaStoreUrl = "";
	var _mideaFanUrl = "";
	var _mideaFAQContent = "";
	var _promptTone = true;
	var _devicePreventCold = undefined;
	var _cacheDevicePreventCold = undefined;
	var _preventColdAPNSRemind = true; //儿童防着凉推送提醒功能，false表示关闭推送提醒，true表示打开推送提醒
	var _ladderControlStatus = false;
	var _deviceCheckProgressStatus = undefined;
	var _deviceCheckFinishStatus = undefined;
	var _sleepModeStatus = undefined;
	var _deviceElectricQuantity = undefined;
	var _deviceStrongPreventStatus = undefined;
	var _deviceCalibrationStatus = undefined;
	var _wristbandStatus = undefined;
	var _deviceBluetoothStatus = undefined;
	var _deviceSelfCleaningStatus = undefined;
	var _deviceColdHotStatus = undefined;
	var _deviceVolumeStatus = undefined;
	var _deviceVoiceStatus = undefined;
	var _deviceSelfLearningStatus = undefined;

	mdSmart.ACDataManager.ACDeviceType = {
		DeviceTypeInvalid: -1,
		QA100: 0,
		SA100: 1,
		SA200: 2,
		SA300: 3,
		YA: 4, //YA挂机
		YAB3: 5,
		WJABC: 6,
		//		WJB: 6,
		//		WJC: 7,
		YA100: 8,
		CJ200: 9,
		WYA: 10,
		WPA: 11,
		LBB2: 12,
		LBB3: 13,
		PA400: 14,
		WEA: 15, //儿童空调
		CA: 16,
		TAB3: 17,
		TAB12: 18,
		KHB1: 19,
		CACP: 20,
		ZA300: 21,
		ZA300B3: 22,
		ZB300: 23,
		YA300: 24,
		YA301: 25,
		YA302: 26,
		PC400B23: 27,
		WXA: 28,
		ZB300YJ: 29,
		WJ7: 30,
		WYB: 31,
		YA201: 32,
		PCB50: 33,
		YB200: 34,
		DA100: 35,
		YB200Test: 36,
		WXD: 37,
		YB300: 38,
		WDAA3: 39,
		WDAD3: 40,
		WYAD2D3: 41,
		WPAD3: 42,
		DA400B3: 43,
		PC400B1: 44,
		DA200300: 45,
		DA400D3: 46,
		PA400B3: 47,
		J9: 48,
		YA400D2D3: 49,
		QA301B1: 50,
		WCBA3: 51,
		IQ100: 52,
		DA100Z: 53,
		IQ300: 54,
		J7: 55,
		WPBC: 56,
		WPCD: 57,
		YB400: 58,
		PE400B3: 59,
		DA400BP: 60,
		DA400DP: 61,
		J8: 62,
		YA400B2: 63,
		YB301: 64,
		YA200: 65,
		ONETOONE: 66,
		YB201: 67,
		PF200: 68,
		GM100: 69,
		//		26YA:70,
		WYS: 70,
		WOW: 71,
		S10: 72,
		W10: 73,
		FA100: 74,
		FA200:75,
		MQ200: 76,
		GW10:77,
		OTHER: 111111
	}
	//	yuyin版本说明
	var yuyinVersionContent = {
		yuyinsmContent: ""
	}

	/*
	yuyin版本
 */
	var yuyinVersion = {
		yuyinDeviceStatus: 0, //设备状态, 0：空闲，1：下载中，2：下载成功，3：下载失败，4：升级中，5：升级成功，6：升级失败
		yuyinDeviceCompany: 0, //公司
		yuyinVersionCurrentVersion: 0, //目前设备版本
		yuyinUpdateVersion: 0, //设备已下载版本
		YuyinDownloadRateVersionProgress: 0, //下载进度
		yuyinUpdateRateVersionProgress: 0 //升级进度
	}

	/*
	过滤网校准
 */
	var DeviceScreenCalibration = {
		screenCalibrationStatus: 0
	}
	/**
	 *  设备运行模式
	 */
	mdSmart.ACDataManager.ACRunMode = {
		RunModeInvalid: -1,
		RunModeAuto: 1,
		RunModeBecomeCool: 2,
		RunModeRemoveWet: 3,
		RunModeBecomeHeat: 4,
		RunModeSupplyWind: 5,
		RunModeComfortDry: 6,
		RunModeManualDry: 7
	}

	mdSmart.ACDataManager.ACPMVMode = {
		PMVModeClose: -111,
		PMVModeOne: -3,
		PMVModeTwo: -2.5,
		PMVModeThree: -2,
		PMVModeFour: -1.5,
		PMVModeFive: -1,
		PMVModeSix: -0.5,
		PMVModeSeven: 0,
		PMVModeEight: 0.5,
		PMVModeNine: 1,
		PMVModeTen: 1.5,
		PMVModeEleven: 2,
		PMVModeTwelve: 2.5,
		PMVModeThirteen: 3
	}

	var ACStrongPreventStatus = {
		queryState: 1,
		queryCount: 0,
		finishFlag: 0,
		remainingTime: "20分钟",
		queryInterval: 15000,
		P_rate: 0,
		P_real: 0,
		maxThreshold: 0,
		currentFilterStatus: 0,
		level: 0,
		animateTime: 1200000
	}
	var ACCalibrationStatus = {
		queryState: 1,
		queryCount: 0,
		finishFlag: 0,
		remainingTime: "20分钟",
		queryInterval: 15000,
		P_rate: 0,
		P_real: 0,
		maxThreshold: 0,
		currentFilterStatus: 0,
		level: 0,
		animateTime: 1200000
	}

	/**
	 *  睡眠曲线定义，推荐曲线，自定义曲线由用户设置
	 *  selectSleepType:0代表推荐曲线，1代表自定义曲线
	 */
	var ACSleepCurveMode = {
		selectSleepType: 0, //0代表推荐曲线，1代表自定义曲线，2代表小米运动曲线
		sleepCurveRecommend: {
			firstHour: 26,
			secondHour: 26,
			thirdHour: 26,
			forthHour: 26,
			fifthHour: 26,
			sixthtHour: 26,
			seventhHour: 26,
			eighthHour: 26,
			ninthHour: 26,
			tenthHour: 26
		},
		sleepCurveCustom: {
			firstHour: 26,
			secondHour: 26,
			thirdHour: 26,
			forthHour: 26,
			fifthHour: 26,
			sixthtHour: 26,
			seventhHour: 26,
			eighthHour: 26,
			ninthHour: 26,
			tenthHour: 26
		},
		sleepCurveInteligent: {
			firstHour: 26,
			secondHour: 26,
			thirdHour: 26,
			forthHour: 26,
			fifthHour: 26,
			sixthtHour: 26,
			seventhHour: 26,
			eighthHour: 26,
			ninthHour: 26,
			tenthHour: 26
		}
	}

	// 定义设备固有属性
	var ACDeviceInfo = function() {
		//定义空调属性
		this.deviceType = mdSmart.ACDataManager.ACDeviceType.DeviceTypeInvalid;

		this.hasNewProtocolAutoUpload = true; // 新协议主动上报
		this.hasOldProtocolAutoUpload = true; // 就协议主动上报
		this.hasRefrigerantCheck = true; // 制冷
		this.hasHotMode = true; // 制热
		this.hasWindMode = true; // 送风
		this.hasAutoMode = true; // 自动
		this.hasDryMode = true; // 抽湿
		this.hasSmartRemoveWet = true; // 舒适抽湿
		this.hasManualRemoveWet = true; // 个性抽湿
		this.hasDot5Support = true; // 0.5度控制
		this.hasNoPolar = true; // 无极调速
		this.hasOuterDoorDisplay = true; // 室外温度显示
		this.hasHumidityDisplay = true; // 室内湿度显示
		this.hasUpSwipeWind = true; // 上摆风
		this.hasDownSwipeWind = true; // 下摆风
		this.hasUpDownSwipeWind = true; // 上下摆风
		this.hasLeftRightSwipeWind = true; // 左右摆风
		this.hasSwipeWind = true; // 摆风
		this.hasECO = true; // ECO
		this.hasDry = true; // 干燥
		this.hasElectricHeat = true; // 电辅热
		this.hasPurify = true; // 净化
		this.hasNatureWind = true; // 自然风
		this.hasChildrenPreventCold = true; // 儿童防着凉
		this.hasReadyColdOrHot = true; // 预冷预热
		this.hasNoWindFeel = true; // 无风感
		this.hasPMV = true; // PMV
		this.hasSavingPower = true; // 省电
		this.hasPurifyCheck = true; // PM2.5检测
		this.hasSleepCurve = true; // 舒睡曲线
		this.hasXiaoMiSmartCurve = true; // 小米曲线
		this.hasMyXiaoMiBracelet = true; // 小米手环
		this.hasBlueToothUpgrade = true; // 蓝牙在线升级
		this.hasLadderControl = true; // 健康降温
		this.hasSelfLearn = true; // 自学习
		this.hasDeviceExamination = true; // 体检
		this.hasStrainerClean = true; // 滤网检测
		this.hasPowerManager = true; // 电量统计
		this.hasStrong = true; // 
		this.hasComfortDry = true; // 舒适抽湿
		this.hasManualDry = true; // 手动抽湿
		this.hasSafeInvade = true; //安防监控
		this.hasIntelControl = true; //智能控制
		this.hasGestureRecognize = true; //手势识别
		this.hasSelfCleaning = true; //自清洁控制
		this.hasVoice = true; //语音功能
		this.hasColdHot = true; //冷热感功能
		this.hasVolume = true; //音量功能
		this.hasYuyinVersion = true;
		this.hasPreventStraightLineWind = false; //防直吹
		this.hasChildrenPreventWind = false; //儿童防冷风
		this.hasUpDownNoWindFeel = false; //有单独上下无风感(不要吐槽翻译 照抄上面的)
		this.isCentralAC = false;
		this.hasPreventStraightLineWind = false; //防直吹
		this.hasChildrenPreventWind = false; //儿童防冷风
		this.hasUpDownNoWindFeel = false; //有单独上下无风感(不要吐槽翻译 照抄上面的)
		this.hasShow = true; //屏显
		this.hasKeepWarm = true; //保温功能
		this.hasWindBlowing = false; //旧协议防直吹功能
		this.hasFilterScreen = false; //过滤网脏堵
		this.hasChangesTemperature = false;
		this.hasNoWindFeelModal = false;
		this.hasDisney = false;
		this.hasTime1TO1 = false;
		this.hasVideoDescription = false;
	}

	/**
	 * 定义设备当前运行状态json对象
	 *
	 */
	var ACDeviceStatus = {
		"deviceName": "空调",
		"deviceRunningStatus": false, //false表示关，true表示开
		"runningMode": mdSmart.ACDataManager.ACRunMode.RunModeInvalid,
		"temperatureInteger": -1, //温度整数部分 17~30		
		"temperatureDecimal": 0, //温度小数部分0，0.5
		"indoorTempInteger": -1,
		"indoorTempDecimal": -1,
		"indoorTemp": -1,
		"outerTempInteger": 26,
		"outerTempDecimal": 0,
		"outerTemp": 26,
		"humidityValue": "--",
		"windSpeedValue": 60,
		"timerOpenStatus": false, //定时开功能 false:关，true:开
		"timerOpenTime": -1, //返回分钟数
		"timerCloseStatus": false, //定时关功能 false:关，true:开
		"timerCloseTime": -1, //返回分钟数
		"upDownProduceWindStatus": false,
		"leftRighProducetWindStatus": false,
		"upSwipeWindStatus:": false,
		"downSwipeWindStatus": false,
		"swipeWindStatus": false,
		"sleepStatus": false,
		"ECOStatus": false,
		"keepWarmStatus": false,
//		"ladderCoolStatus":false,
		"windBlowingStatus": false,
		"strongStatu": false,
		"purifyStatus": false,
		"electricHeatStatus": false,
		"DryStatus": false,
		"preventCool": false,
		"tubroStatus": false,
		"readyColdOrHot": false,
		"ladderTempStatus": false,
		"selfLearnStatus": false,
		"PMVMode": mdSmart.ACDataManager.ACPMVMode.PMVModeClose,
		"natureWindStatus": false,
		"screenDisplay": false,
		"noWindFeel": false,
		"upNoWindFeel": false,
		"downNoWindFeel": false,
		"savingElectricStatus": false,
		"comfortDryStatus": false, //舒适抽湿
		"manualDryStatus": false, //手动抽湿
		"setHumidityValue": 30, //设定湿度
		"securityStatus": false,
		"angleEyeStatus": true,
		"intrusionStatus": false,
		"intrusionVideoStatus": false,
		"faceRecognitionStatus": false,
		"infraredLightStatus": false,
		"intelligentControlStatus": false,
		"energySavingStatus": false,
		"windDirectionStatus": 0,
		"windSpeedStatus": false,
		"gestureRecognitionOnOffStatus": false,
		"gestureRecognitionDirectionStatus": false,
		"remoteVideoStatus": false,
		"selfCleaningStatus": false,
		"windAvoidStatus": false,
		"straightBlowStatus": false,
		"softWindFeelSwitchStatus": false,
		"windFeelingFA100tSwitchStatus": false,
		"familyNumber": 0,
		"exclusiveOnOffStatus": false,
		"isWindBlow": false,
		"isWindClose": false,
		"PMNumber": ""
	}

	var ACDeviceVideoUrl = {
		"ProductInstruction": "", //产品介绍
		"DailyUse": "", //日常使用
		"CleanMaintain": "", //清洁维护
		"ContactUs": "", //联系我们
		"WifiControl": "", //WI-FI控制
		"IntactTotal": "", //完整视频
	}

	var ACDevicePreventCold = function() {
		this.beColdSensitivity = 1; //0高，1中，2低
		this.beHeatSensitivity = 1; //0高，1中，2低
		this.beColdTemperateRise = 3; //制冷温度升高
		this.beHeatTemperateRise = 3; //制热温度升高
		this.beColdMin = 17; //制冷温度下限 步进为0.5
		this.beColdMax = 30; //制冷温度上限
		this.beHeatMin = 17; //制热温度下限
		this.beHeatMax = 30; //制热温度上限
	}

	var ACDeviceCheckScore = function() {
		this.lastCheckTime = ""; //上次检测时间
		this.score = ""; //体检分数
		this.scoreLevel = ""; //体检是否合格：0	不合格	1	合格
		this.filterStatus = ""; //滤网是否合格：0	不合格	1	合格	
		this.refrigStatus = ""; //冷媒是否合格：0	不合格	1	合格
		this.compressorStatus = ""; //压缩机是否合格：0		不合格	1	合格
		this.checkNum = ""; //体检项目总数
		this.checkStatus = ""; //体检结果：0	异常		1	正常
		this.faultNum = ""; //故障数量
		this.faultList = ""; //故障数组
		this.errCode = ""; //故障码
		this.errMsg = ""; //故障字符串
	}

	var ACDeviceElecQty = function() {
		this.todayElecQty = "";
		this.realTimePower = {
			"power": "", //实时功率，单位：瓦
			"runTime": "", //本次运行时间 单位：分钟
			"runElecQty": "", //本次运行电量 单位:度
			"totalRunTime": "", //总运行时间 单位：分钟
			"totalRunElecQty": "" //总运行电量 单位:度
		};

		this.ecoRunningStatus = {
			"EcoTime": "", //上次ECO运行时间 单位：分钟
			"EcoElecQty": "" //上次ECO运行电量 单位：度
		};

		this.elecQty = {
			"totalElecQty": "", //累计电量
			"currentWeekElecQty": {
				"totalElecQty": "", //本周累计电量
				"details": {
					"one": "",
					"two": "",
					"three": "",
					"four": "",
					"five": "",
					"six": "",
					"seven": ""
				}

			},
			"currentMonthElecQty": {
				"totalElecQty": "", //本月累计电量
				"details": {
					"one": "",
					"two": "",
					"three": "",
					"four": "",
					"five": "",
					"six": "",
					"seven": "",
					"eight": "",
					"nine": "",
					"ten": "",
					"eleven": "",
					"twelve": "",
					"thirteen": "",
					"fourteen": "",
					"fifteen": "",
					"sixteen": "",
					"seventeen": "",
					"eighteen": "",
					"nineteen": "",
					"twenty": "",
					"twentyOne": "",
					"twentyTwo": "",
					"twentyThree": "",
					"twentyFour": "",
					"twentyFive": "",
					"twentySix": "",
					"twentySeven": "",
					"twentyEight": "",
					"twentyNine": "",
					"thirty": "",
					"thirtyOne": ""
				}

			}
		}

	}
	var DeviceColdWindStatus = {
		coldWind: "",
	}
	var DeviceWeatherReportStatus = {
		weatherReport: "",
	}
	//定时天气播报控制状态数据
	var DeviceTimingWeatherReportStatus = {
		timingWeatherReportSwitch: "", //定时天气播报开关
		oneHatus: "", // 第一组时间小时
		oneMatus: "", //第一组时间分钟
		twoHatus: "", //第二组时间小时
		twoMatus: "", //第二组时间分钟
		threeHatus: "", //第三组时间小时
		threeMatus: "", //第三组时间分钟
	}
	var DeviceSelfCleaningStatus = {
		selfCleaning: "",
	}
	var DeviceWindAvoidStatus = {
		windAvoid: "",
	}
	var DeviceWindBlowingStatus = {
		windBlowing: "",
	}
	var DeviceSoftWindFeelingStatus = {
		straightBlow: "",
		softWindFeel: "",
		windFeelingFA100: ""
	}

	var DeviceCheckProgressStatus = {
		name: "",
		progress: 0
	}
	var DeviceCheckFinishStatus = {
		score: "",
		scoreLevel: 1,
		scanProcess: "", //扫描进度
		strainer: "", //滤网状态信息
		electricalMachine: {
			faultNum: 0,
			faultDetail: []
		}, //电机故障
		coolants: "", //冷媒状态信息
		compressor: {
			faultNum: 0,
			faultDetail: []
		}, //压缩机故障	
		checkParameters: "", //体检参数：正常、异常
		checkFaultNum: "", //体检故障数量
		checkNum: '',
		checkFaultDetail: []
	}
	//语音控制状态数据
	var DeviceVoiceStatus = {
		voiceBroadcastStatus: "", //语音功能
		awakenStatus: "", //唤醒词状态
		toneStatus: 1, //播报声调
		voiceTimeLength: -1, //语音识别超时时间长度
		initialPowerBroadcastSwitch: "", //上电播报开关
		friendshipBroadcastSwitch: "", //友情播报开关
		safetyBroadcastSwitch: "", //安全播报开关
		weatherBroadcastSwitch: "", //天气预报播报开关
		informationBroadcast: "", //维护信息播报
	}
	//音量控制状态数据
	var DeviceVolumeStatus = {
		volumeControlType: "", //音量调节的类型 
		manualAdjustment: 1, //手动调节
		minVolume: 1, // 自动调节的最小音量
		maximumVolume: 1, //自动调节的最大音量    	
	}

	//冷热感控制状态数据
	var DeviceColdHotStatus = {
		coldHotSwitch: "", //冷热感开关
		coldHotStall: 1, //冷热感的档位 
		coldHotNumber: -1, //冷热感的人数
		PeopleClothes: -1, //人的穿衣情况
		SeasonalState: "", //季节状态
		WeatherCondition: "", //天气状态
		NightTimeHour: -1, //夜晚判断绝对时间的时间点小时
		NightTimeMinute: -1, //夜晚判断绝对时间的时间点分钟
	}
	//过滤网脏堵检测传感器
	var DeviceFilterDirtyPluggingStatus = {
		testStatus: "", //检测状态
		meshFailure1: "", //滤网故障1
		meshFailure2: "", //滤网故障2
		currenLevel: 0, //当前滤网脏堵检测等级
		ADvalueLow: "", //表示检测到的AD值
		ADvalueHigh: "", //预留
		controlADrangeLow: "", //表示控制板AD检测量程
		controlADrangeHigh: "", //表示控制板AD首次检测量程
		thresholdValue: "", //滤网脏堵检测阈值百分比
		dutyRatio: "", //滤网脏堵检测占空比
		environmentValueLow: "", //环境光检测值低位
		environmentValueHigh: "", //预留
		percentageReadings: "", //检测值百分比
		fanRunTimeLow: "", //风机累计运行时间低位
		fanRunTimeHigh: "", //风机累计运行时间高位
	}
	//小米手环
	var WristbandStatus = {
		wristbandList: [],
		wristbandDate: "--",
		wristbandConsumption: "--",
		wristbandSteps: "--",
		wristbandWalkTime: "--",
		wristbandRunDistance: "--",
		wristbandDayDistance: "--",
		wristbandNameList: []
	}
	//蓝牙模块升级
	var DeviceBluetoothStatus = {
		bluetoothMacList: [],
		bluetoothMac: "",
		currentBluetoothSoftVersion: [],
		newestBluetoothSoftVersion: "0.0.2.0",
		bluetoothNewestVersionProgress: 0,
		bluetoothUpgradeProgressValue: 0,
		currentBluetoothMode: "2"
	}

	//自学习状态
	var ACSelfLearningStatus = function() {
		this.selfLearningPermission = "false";
		this.selfLearningSlotStart = 0;
		this.selfLearningSlotStop = 24;
		this.selfLearningStatus = "false";
		this.selfLearningCurve = "";
		this.selfLearningValueList = "";
		this.selfLearningTempAvgToday = "";
		this.selfLearningTempMinToday = "";
		this.selfLearningTempMaxToday = "";
		this.selfLearningWindspeedAvgToday = "";
		this.selfLearningWindspeedMinToday = "";
		this.selfLearningWindspeedMaxToday = "";
		this.selfLearningTempAvgYes = "";
		this.selfLearningTempMinYes = "";
		this.selfLearningTempMaxYes = "";
		this.selfLearningWindspeedAvgYes = "";
		this.selfLearningWindspeedMinYes = "";
		this.selfLearningWindspeedMaxYes = "";
		this.selfLearningTempAvgBeforeYes = "";
		this.selfLearningTempMinBeforeYes = "";
		this.selfLearningTempMaxBeforeYes = "";
		this.selfLearningWindspeedAvgBeforeYes = "";
		this.selfLearningWindspeedMinBeforeYes = "";
		this.selfLearningWindspeedMaxBeforeYes = "";
	}

	//属性初始化
	_deviceInfo = new ACDeviceInfo();
	_deviceStatus = ACDeviceStatus;
	setDeviceName(); //设置空调名字
	_deviceVideoUrl = ACDeviceVideoUrl;
	_devicePreventCold = new ACDevicePreventCold();
	_cacheDevicePreventCold = new ACDevicePreventCold();
	_deviceCheckProgressStatus = DeviceCheckProgressStatus;
	_deviceCheckFinishStatus = DeviceCheckFinishStatus;
	_sleepModeStatus = ACSleepCurveMode;
	_deviceElectricQuantity = new ACDeviceElecQty();
	_deviceStrongPreventStatus = ACStrongPreventStatus;
	_deviceCalibrationStatus = ACCalibrationStatus;
	_wristbandStatus = WristbandStatus; //小米手环
	_deviceBluetoothStatus = DeviceBluetoothStatus; //蓝牙模块升级
	_deviceSelfCleaningStatus = DeviceSelfCleaningStatus; //自清洁
	_deviceWindAvoidStatus = DeviceWindAvoidStatus; //风避人
	_deviceVoiceStatus = DeviceVoiceStatus; //语音
	_deviceColdHotStatus = DeviceColdHotStatus; //冷热感
	_deviceVolumeStatus = DeviceVolumeStatus; //音量
	_yuyinVersion = yuyinVersion; //yuyin升级
	_yuyinVersionContent = yuyinVersionContent; //yuyin版本说明
	_deviceSelfLearningStatus = new ACSelfLearningStatus();
	_deviceColdWindStatus = DeviceColdWindStatus; //防冷风
	_deviceWeatherReportStatus = DeviceWeatherReportStatus; //天气播报
	_deviceTimingWeatherReportStatus = DeviceTimingWeatherReportStatus; //定时天气播报
	_deviceFilterDirtyPluggingStatus = DeviceFilterDirtyPluggingStatus; //过滤网脏堵检测传感器
	_deviceScreenCalibration = DeviceScreenCalibration; //过滤网校准
	_deviceWindBlowingStatus = DeviceWindBlowingStatus; //新防直吹
	_deviceSoftWindFeelingStatus = DeviceSoftWindFeelingStatus; //柔风感

	//根据家电SN获取机型，返回机型名称
	_deviceInfo.extraDeviceTypeForSelfClean = [];
	_deviceInfo.extraDeviceTypeForKeepWarm = [];
	_deviceInfo.extraDeviceTypeForYADot5 = [];
	_deviceInfo.extraDeviceTypeForYADot5jr26YA = [];

	function getDeviceType() {
		var subQA100List = "11005/10977/11007/10979/10563/10567/10711/11415/11417/11423/11425/11467/11469/11471/11473/11475/11477";
		var subSA100List = "11175/11177/11419/11421/11437/11439/11441/Z1140";
		var subSA200List = "11285/11287/11351/11353/11355/11357"; //SA200  SA201
		var subSA300List = "11179/11181/11183/11313/11315/11317/11537/11539/11541/Z1139/Z1149/Z2155/Z1166/Z2185";
		var subYAList = "11381/11387/11383/11385/11389/11393/11391/11395/11463/11465/11571/11573/11575/Z2165/Z2168/Z1151/Z1152/Z1153/Z1154/Z1158/Z2165/Z2166/Z2167/Z1167/Z2169/Z2170/Z2172/Z2186/11839/11919/11917/11915/11913";
		var sub26YAList = "11835"; //26YA100机型
		var subYAB3List = "11397/11399/11401/11403/11405/11407/Z2170/Z1155/Z1156";
		var subWJABCList = "11295/11301/11297/11303/11299/11305"; //WJA、WJB、WJC
		//		var subWJAList = "11295/11301";
		//		var subWJBList = "11297/11303";
		//		var subWJCList = "11299/11305";
		var subYA100List = "50491/50493/50271/50273/50603/50607/50663/50665";
		var subCJ200List = "50601/50509/50507/50605/Z1138";
		var subWYAList = "50585/50583";
		var subWPAList = "50559/50557";
		var subLBB2List = "50095/50163/50077/50167"; // LB(B2)
		var subLBB3List = "50119/50213/50397/50081/50285/50403/50661/50695"; // LB(B3)
		var subPA400List = "50387/50401";
		var subWEAList = "11373/11375/11377/11379/11309/11311/10983/10985/F0283/F0285/F0287/F0289/F0291/F0293 /F0295/F0297/F0299 /F0301/F0303/F0305/Z1172/Z1211/Z1212/Z1173";
		var subCAList = "11447/11451/11453/11455/11457/11459/11525/11527";
		var subTAB3List = "11489/11491/11493/11505/11507/11509/Z1161/Z1162/Z2182/Z2183/11551/11553/11557/11561/11565";
		var subTAB12List = "11495/11497/11499/11501/11503/11511/11513/11515/Z1165/Z1164/Z1163/Z2180/Z2181/Z2184/11543/11545/11547/11549/11555/11559/11563/11585/11587/11833/11837/11931/11929/Z2240/Z1217/Z1219/Z2242/11945/11947";
		var subKHB1List = "50637/50639/50655/50653/50723";
		var subCACPList = "11533/11535"; //CA定速机
		var subZA300List = "50199/50201/50265/50269/50307/50373/50317/50375/50431/50433"; //ZA300(B2)
		var subZA300B3List = "50251/50253/50281/50289/50309/50315/50383/50385/50427/50429/50669/50701"; //ZA300(B3)
		var subZB300List = "50657/50659"; //ZB300
		var subZB300YJList = "Z1170/Z2191"; //ZB300YJ
		var subYA300List = "50205/50207/50393/50451";
		var subYA301List = "50531/50533/50677/50687/G0041/G0043/G0047/G0049/G0045/G0051/50777/50779/Z2231/Z1207"; //YA301、WYCA1
		var subYA302List = "50577/50579/50679/50693";
		var subYA201List = "50609/50681/50689/50611/50675/50685/50775/50773"; //YA201 20170527将773 775从YA200转到YA201 By lyf
		var subYA200List = "50771/50769"; //YA200
		var subPC400B23List = "11367/11369/11371/11323/11327/11445/11449/11461/11757/11759/11761/11323/11325/11327/11445/11449/11461/F0473/Z2217"; //PC400(B2)、PC400(B3)
		var subWXAList = "11695/11697/Z1209/Z2234/12023/12025";
		var subWJ7List = "10167/10169/10171";
		var subWYBList = "50725/50727";
		var subPCB50List = "11719";
		var subYB200List = "50731/50733/Z1184/Z2208";
		var subYB200TestList = "55555";
		var subDA100List = "11717/11711";
		var subWXDList = "11713/11715/Z1208/Z2233";
		var subYB300List = "50753/50755/Z1187/Z2212/50841/50839/50835/50837/Z1204/Z2229/50903/Z2254/Z1231/50905/Z1231/Z2254"; //TOP
		var subWDAA3List = "11763/11765/Z2214/11879/11885/Z1210/Z2235/11991/11989/11993/11995/12019/12021"; //WDBA3
		var subWDAD3List = "11735/11737/11883/11881/11799/11803/11801/11805"; //WDBD3
		var subWYAD2D3List = "50763/50599/50761/50589/50597/Z1216/Z2239";
		var subWPAD3List = "50749/50751/50737/50739/50741/50743";
		var subDA400B3List = "11605/11613/11641/11729/11731/11733/Z3063/Z3065/Z2187/Z2215/11843/11231";
		var subPC400B1List = "11775/11777/11829/11831/11937/11933"; //PE200、PC200
		var subDA200300List = "11589/11591/11593/11597/11599/11649/Z1168/Z2188/Z2164/11739/11741/11743/11745/11747/11749/11661/11663/11667/Z1169/Z2189/11751/11753/11755/11821/11823/11825/11827/Z1191/Z2218/Z1192/Z2219/11891/11889/11925/11927/Z1206/11941/11943/12005/12007/12009/12013/12011/12013/12011"; //WCC，WDB
		var subDA400D3List = "11779/11781/11783/11785/11787/11789/11791/11793";
		var subDA400BP = "50853/50847/Z2241/Z1218"; //DA400带不吹人功能，变频
		var subDA400DP = "50843/50845/50849/50851"; //DA400带不吹人功能，定频
		var subPA400B3List = "50745/50747";
		var subJ9List = "19003/19001/Z2900/Z1900/Z1902/19013/19014/19011/19012/Z2902/19017/19015"; //J9,J10
		var subYA400D2D3List = "50569/50571/50587/50593/50757/50759/50647/50648/50649";
		var subQA301B1List = "11795/11797/11796/11798/Z2213/Z1188";
		var subWCBA3List = "F0275/F0277/F0279/F0281/F0307/F0309/F0311/F0313/F0315/F0317/11701/11699/11987/11985";
		var subIQ100List = "Z1194/11819/11813/Z2221/Z1198";
		var subDA100ZList = "11809/11811/Z1193/Z2220/11907/11905/11911/11909/11895/11893/11923/11921/Z1201/Z2232"; //WCCA2,WCBA2,WCEN8A2
		var subIQ300List = "Z1195/Z2222/11815/11817";
		var subJ7List = "Z2901/Z1008/Z1901/50103/50101/50079/50081/50781/50783/50109/50107/Z1205/Z2230"; //WYD
		var subYA400B2List = "50565/50567/50613/50621/50683/50691";
		var subWPBCList = "50789/50791/50785/50787/Z2237/Z1214"; //WPB、WPC
		var subWPCDList = "50797/50799";
		var subYB400List = "50823/50825/Z2227/Z1199/50891/50893/50907/50909/50947/50945/50949/50951"; //WYE、WYG
		var subPE400B3List = "11723/11727";
		var subJ8List = "Z2903/Z1903/50113/50111"; //J10
		var subYB301List = "50861/50863/Z1215/Z2238/Z1223/Z2246/50875/50873/50877/50879/Z1224/Z2247/50917/50919/Z1241/50921/50923/Z1242/50933/50935/50941/50943/Z1264"; //YB303、YB305、YB306、YB308、YB302、YB333
		var subWYSList = "50895/50897/Z1244";
		var sub1TO1List = "96901/96902/96903/96904/96135"; //一拖一
		var subYB201List = "50869/50871/Z1226/Z2249/Z1227/Z2250/50889/50887/50925/50927/Z1243"; //YB202、YB203
		var subPF200List = "11963/11961/Z2245/Z1222/11981/11983/Z1234/Z2258 "; //TOP
		var subGM100List = "11967/11965/Z1229/Z2252";
		var subWOWList = "11979/11977/Z1235/Z2259/Z2266";
		var sub1TOnList = "PD004"; //一拖多
		var subS10List = "20003/20001/Z1904/Z2904";
		var subFA100List = "12037/12035/Z1261/Z1262";
		var subFA200List = "12039/12041/Z1263";
		var subW10List = "60001/60003";
		var subWXDFList = "12070/12072";
		var subYB100List = "50939/Z1259";
		var subMQ200List = "Z2270/Z2269/Z1249/Z1248/12065/12067";
		var subGW10List = "Z1908/20017";
		
		_deviceInfo.extraDeviceTypeForSelfClean = [subJ7List, subDA100ZList, subYB200List, subYAB3List, subYAList,
			subLBB3List, subWEAList, subTAB3List, subTAB12List, subKHB1List, subZA300B3List, subZB300List,
			subYA301List, subYA201List, subYA302List, subPC400B23List, subWXAList, subWXDList, subYB300List,
			subWDAA3List, subPC400B1List, subDA200300List, subJ9List, subQA301B1List, subJ7List, subWPBCList,
			subWJ7List, subYB400List, subWYBList, subWCBA3List, subPE400B3List, subDA400B3List, subJ8List,
			subYA400B2List, subDA400BP, subDA400DP, subYB301List, subYA200List, subYB201List, subPF200List, subGM100List,
			sub26YAList, subWYSList, subWOWList, subPCB50List, subS10List, subFA100List, subW10List, subWXDFList,
			subYB100List, subMQ200List ,subFA200List,subGW10List
		];

		_deviceInfo.extraDeviceTypeForKeepWarm = [subGM100List, subWOWList, subS10List, subFA100List, subWXDFList,subFA200List,subGW10List];

		_deviceInfo.extraDeviceTypeForYADot5 = [subYAList];
		_deviceInfo.extraDeviceTypeForYADot5YAB3 = [subYAB3List];
		_deviceInfo.extraDeviceTypeForYADot5jr26YA = [sub26YAList];

		var deviceSN = bridge.getCurrentDevSN();
		if(deviceSN == 0) {
			return "";
		}

		var deviceBarCode = undefined;
		var deviceType = undefined;
		if(deviceSN != "") {
			if(deviceSN.length == '32') {
				//				dataDeviceID = deviceSN.substring(6, 28);
				deviceBarCode = deviceSN.substring(12, 17);
			} else if(deviceSN.length == '22') {
				//				dataDeviceID = deviceSN.substring(0, 22);
				deviceBarCode = deviceSN.substring(6, 11);
			} else {
				deviceBarCode = "";
				//				dataDeviceID = "";
			}
			//alert(deviceBarCode);
		} else {
			deviceBarCode = "";
			//			dataDeviceID = "";
		}

		if(subQA100List.indexOf(deviceBarCode) != '-1') {
			deviceType = "QA100";
		} else if(subSA100List.indexOf(deviceBarCode) != '-1') {
			deviceType = "SA100";
		} else if(subSA200List.indexOf(deviceBarCode) != '-1') {
			deviceType = "SA200";
		} else if(subSA300List.indexOf(deviceBarCode) != '-1') {
			deviceType = "SA300";
		} else if(subYAList.indexOf(deviceBarCode) != '-1') {
			deviceType = "YA";
		} else if(sub26YAList.indexOf(deviceBarCode) != '-1') {
			deviceType = "26YA";
		} else if(subYAB3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YAB3";
		} else if(subWJABCList.indexOf(deviceBarCode) != '-1') {
			deviceType = "WJABC";
		} else if(subYA100List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YA100";
		} else if(subCJ200List.indexOf(deviceBarCode) != '-1') {
			deviceType = "CJ200";
		} else if(subWYAList.indexOf(deviceBarCode) != '-1') {
			deviceType = "WYA";
		} else if(subWPAList.indexOf(deviceBarCode) != '-1') {
			deviceType = "WPA";
		} else if(subLBB2List.indexOf(deviceBarCode) != '-1') {
			deviceType = "LBB2";
		} else if(subLBB3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "LBB3";
		} else if(subPA400List.indexOf(deviceBarCode) != '-1') {
			deviceType = "PC400";
		} else if(subWEAList.indexOf(deviceBarCode) != '-1') {
			deviceType = "WEA";
		} else if(subCAList.indexOf(deviceBarCode) != '-1') {
			deviceType = "CA";
		} else if(subTAB3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "TAB3";
		} else if(subTAB12List.indexOf(deviceBarCode) != '-1') {
			deviceType = "TAB12";
		} else if(subKHB1List.indexOf(deviceBarCode) != '-1') {
			deviceType = "KHB1";
		} else if(subCACPList.indexOf(deviceBarCode) != '-1') {
			deviceType = "CACP";
		} else if(subZA300List.indexOf(deviceBarCode) != '-1') {
			deviceType = "ZA300";
		} else if(subZA300B3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "ZA300B3";
		} else if(subZB300List.indexOf(deviceBarCode) != '-1') {
			deviceType = "ZB300";
		} else if(subZB300YJList.indexOf(deviceBarCode) != '-1') {
			deviceType = "ZB300YJ";
		} else if(subYA300List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YA300";
		} else if(subYA201List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YA201";
		} else if(subYA200List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YA200";
		} else if(subYA301List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YA301";
		} else if(subYA302List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YA302";
		} else if(subPC400B23List.indexOf(deviceBarCode) != '-1') {
			deviceType = "PC400B23";
		} else if(subWXAList.indexOf(deviceBarCode) != '-1') {
			deviceType = "WXA";
		} else if(subWJ7List.indexOf(deviceBarCode) != '-1') {
			deviceType = "WJ7";
		} else if(subWYBList.indexOf(deviceBarCode) != '-1') {
			deviceType = "WYB";
		} else if(subPCB50List.indexOf(deviceBarCode) != '-1') {
			deviceType = "PCB50";
		} else if(subYB200List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YB200";
		} else if(subDA100List.indexOf(deviceBarCode) != '-1') {
			deviceType = "DA100";
		} else if(subYB200TestList.indexOf(deviceBarCode) != '-1') {
			deviceType = "YB200Test";
		} else if(subWXDList.indexOf(deviceBarCode) != '-1') {
			deviceType = "WXD";
		} else if(subYB300List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YB300";
		} else if(subWDAA3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "WDAA3";
		} else if(subWDAD3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "WDAD3";
		} else if(subWYAD2D3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "WYAD2D3";
		} else if(subWPAD3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "WPAD3";
		} else if(subDA400B3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "DA400B3";
		} else if(subPC400B1List.indexOf(deviceBarCode) != '-1') {
			deviceType = "PC400B1";
		} else if(subDA200300List.indexOf(deviceBarCode) != '-1') {
			deviceType = "DA200300";
		} else if(subDA400D3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "DA400D3";
		} else if(subDA400BP.indexOf(deviceBarCode) != '-1') {
			deviceType = "DA400BP";
		} else if(subDA400DP.indexOf(deviceBarCode) != '-1') {
			deviceType = "DA400DP";
		} else if(subPA400B3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "PA400B3";
		} else if(subJ9List.indexOf(deviceBarCode) != '-1') {
			deviceType = "J9";
		} else if(subYA400D2D3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YA400D2D3";
		} else if(subQA301B1List.indexOf(deviceBarCode) != '-1') {
			deviceType = "QA301B1";
		} else if(subWCBA3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "WCBA3";
		} else if(subIQ100List.indexOf(deviceBarCode) != '-1') {
			deviceType = "IQ100";
		} else if(subDA100ZList.indexOf(deviceBarCode) != '-1') {
			deviceType = "DA100Z";
		} else if(subIQ300List.indexOf(deviceBarCode) != '-1') {
			deviceType = "IQ300";
		} else if(subJ7List.indexOf(deviceBarCode) != '-1') {
			deviceType = "J7";
		} else if(subWPBCList.indexOf(deviceBarCode) != '-1') {
			deviceType = "WPBC";
		} else if(subWPCDList.indexOf(deviceBarCode) != '-1') {
			deviceType = "WPCD";
		} else if(subYB400List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YB400";
		} else if(subPE400B3List.indexOf(deviceBarCode) != '-1') {
			deviceType = "PE400B3";
		} else if(subJ8List.indexOf(deviceBarCode) != '-1') {
			deviceType = "J8";
		} else if(subYA400B2List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YA400B2";
		} else if(subYB301List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YB301";
		} else if(subWYSList.indexOf(deviceBarCode) != '-1') {
			deviceType = "WYS";
		} else if(sub1TO1List.indexOf(deviceBarCode) != '-1') {
			deviceType = "1TO1";
		} else if(sub1TOnList.indexOf(deviceBarCode) != '-1') {
			deviceType = "1TOn";
		} else if(subYB201List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YB201";
		} else if(subPF200List.indexOf(deviceBarCode) != '-1') {
			deviceType = "PF200";
		} else if(subGM100List.indexOf(deviceBarCode) != '-1') {
			deviceType = "GM100";
		} else if(subWOWList.indexOf(deviceBarCode) != '-1') {
			deviceType = "WOW";
		} else if(subS10List.indexOf(deviceBarCode) != '-1') {
			deviceType = "S10";
		} else if(subFA100List.indexOf(deviceBarCode) != '-1') {
			deviceType = "FA100";
		}else if(subFA200List.indexOf(deviceBarCode) != '-1') {
			deviceType = "FA200";
		} else if(subW10List.indexOf(deviceBarCode) != '-1') {
			deviceType = "W10";
		} else if(subWXDFList.indexOf(deviceBarCode) != '-1') {
			deviceType = "WXDF";
		} else if(subYB100List.indexOf(deviceBarCode) != '-1') {
			deviceType = "YB100";
		} else if(subMQ200List.indexOf(deviceBarCode) != '-1') {
			deviceType = "MQ200";
		}else if(subGW10List.indexOf(deviceBarCode) != '-1') {
			deviceType = "GW10";
		} else {
			deviceType = "OTHER";
		}
		//alert(deviceSN);
		// deviceType = "YB301";
		return deviceType;

	}
	this.getDeviceType = getDeviceType;

	function deviceMatchProcess() {
		_deviceInfo.hasNewProtocolAutoUpload = false;
		_deviceInfo.hasOldProtocolAutoUpload = true; //旧协议上报
		_deviceInfo.hasRefrigerantCheck = true; //制冷模式		公共功能
		_deviceInfo.hasHotMode = true; //制热模式		公共功能
		_deviceInfo.hasWindMode = true; //送风模式		公共功能
		_deviceInfo.hasAutoMode = true; //自动模式		公共功能
		_deviceInfo.hasDryMode = true; //抽湿模式		公共功能
		_deviceInfo.hasSmartRemoveWet = false;
		_deviceInfo.hasManualRemoveWet = false;
		_deviceInfo.hasDot5Support = false;
		_deviceInfo.hasNoPolar = true; //默认无极调速
		_deviceInfo.hasOuterDoorDisplay = true; //室外温度显示	CA定频无
		_deviceInfo.hasHumidityDisplay = false;
		_deviceInfo.hasUpSwipeWind = false;
		_deviceInfo.hasDownSwipeWind = false;
		_deviceInfo.hasUpDownSwipeWind = false;
		_deviceInfo.hasLeftRightSwipeWind = false;
		_deviceInfo.hasSwipeWind = false;
		_deviceInfo.hasECO = false;
		_deviceInfo.hasDry = true; //干燥		公共功能
		_deviceInfo.hasElectricHeat = true; //电辅热		公共功能
		_deviceInfo.hasPurify = false;
		_deviceInfo.hasNatureWind = false;
		_deviceInfo.hasChildrenPreventCold = false;
		_deviceInfo.hasReadyColdOrHot = false;
		_deviceInfo.hasNoWindFeel = false;
		_deviceInfo.hasPMV = false;
		_deviceInfo.hasSavingPower = false;
		_deviceInfo.hasPurifyCheck = false;
		_deviceInfo.hasSleepCurve = false;
		_deviceInfo.hasXiaoMiSmartCurve = false;
		_deviceInfo.hasMyXiaoMiBracelet = false;
		_deviceInfo.hasBlueToothUpgrade = false;
		_deviceInfo.hasLadderControl = false;
		_deviceInfo.hasSelfLearn = false;
		_deviceInfo.hasDeviceExamination = true; //体检		公共功能
		_deviceInfo.hasStrainerClean = false;
		_deviceInfo.hasPowerManager = false;
		_deviceInfo.hasStrong = false;
		_deviceInfo.hasComfortDry = false;
		_deviceInfo.hasManualDry = false;
		_deviceInfo.hasSafeInvade = false;
		_deviceInfo.hasIntelControl = false;
		_deviceInfo.hasGestureRecognize = false;
		_deviceInfo.hasSelfCleaning = false;
		_deviceInfo.hasColdHot = false;
		_deviceInfo.hasVoice = false;
		_deviceInfo.hasYuyinVersion = false;
		_deviceInfo.hasPreventStraightLineWind = false;
		_deviceInfo.hasChildrenPreventWind = false;
		_deviceInfo.hasUpDownNoWindFeel = false;
		_deviceInfo.hasShow = true;
		_deviceInfo.hasKeepWarm = false;
		_deviceInfo.hasChangesTemperature = false;
		_deviceInfo.hasNoWindFeelModal = false;
		_deviceInfo.hasVideoDescription = false;

		var deviceType = getDeviceType();
		if(barcodeAnalysisYADot5(_deviceInfo.extraDeviceTypeForYADot5YAB3)) {
			_deviceInfo.hasDot5Support = true;
			_deviceInfo.hasReadyColdOrHot = true;
		}

		if(barcodeAnalysisYADot5(_deviceInfo.extraDeviceTypeForYADot5)) {
			_deviceInfo.hasDot5Support = true;
			_deviceInfo.hasReadyColdOrHot = true;
			_deviceInfo.hasKeepWarm = true;
		} else if(barcodeAnalysisYADot5jr26YA(_deviceInfo.extraDeviceTypeForYADot5jr26YA)) {
			_deviceInfo.hasDot5Support = true;
			_deviceInfo.hasReadyColdOrHot = true;
			_deviceInfo.hasKeepWarm = true;
		} else {
			//保温功能的例外处理
			if(barcodeAnalysisbaowen(_deviceInfo.extraDeviceTypeForKeepWarm)) {
				_deviceInfo.hasKeepWarm = true;
			} else {
				_deviceInfo.hasKeepWarm = false;
			}
		}
		//自清洁的例外处理
		if(barcodeAnalysiszqj(_deviceInfo.extraDeviceTypeForSelfClean)) {
			_deviceInfo.hasSelfCleaning = true;
		} else {
			_deviceInfo.hasSelfCleaning = false;
		}
		switch(deviceType) {
			case "1TOn": //QA100
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.oneTOn;
					_deviceInfo.isCentralAC = true;
					break;
				}
			case "QA100": //QA100
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.QA100;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasPurify = true;
					_deviceInfo.hasPowerManager = true;
					_deviceInfo.hasSleepCurve = true;
					break;
				}
			case "SA100": //SA100
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.SA100;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasPMV = true;
					_deviceInfo.hasHumidityDisplay = true;
					_deviceInfo.hasSleepCurve = true;
					break;
				}
			case "SA200": //SA200,SA201
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.SA200;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasPMV = true;
					_deviceInfo.hasSleepCurve = true;
					break;
				}
			case "SA300":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.SA300;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasSleepCurve = true;
					break;
				}
			case "YA":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.YA;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasSleepCurve = true;
					break;
				}
			case "WOW":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.WOW;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasFilterScreen = true;
					_deviceInfo.hasReadyColdOrHot = true;
					break;
				}
			case "26YA":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.YA;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasSleepCurve = true;
					break;
				}
			case "GM100":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.GM100;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasReadyColdOrHot = true;
					break;
				}
			case "S10":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.GM100;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasReadyColdOrHot = true;
					break;
				}
			case "YAB3":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.YAB3;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasReadyColdOrHot = true;
					//					_deviceInfo.hasSelfCleaning = true;
					break;
				}

			case "WJABC":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.WJABC;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasSleepCurve = true;
					break;
				}
			case "YA100":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.YA100;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasPurify = true;
					_deviceInfo.hasPowerManager = true;
					break;
				}
			case "CJ200":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.CJ200;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasPurify = true;
					break;
				}
			case "WYA":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.WYA;
					//					_deviceInfo.hasUpSwipeWind = true;
					//					_deviceInfo.hasDownSwipeWind = true;
					_deviceInfo.hasSwipeWind = true;
					_deviceInfo.hasPurify = true;
					break;
				}
			case "WPA":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.WPA;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					break;
				}
			case "LBB2":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.LBB2;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasPurify = true;
					break;
				}
			case "LBB3":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.LBB3;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasNoPolar = false;
					break;
				}
			case "PA400":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.PA400;
					_deviceInfo.hasUpDownSwipeWind = true;
					break;
				}
			case "WEA":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.WEA;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasChildrenPreventCold = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasSleepCurve = true;
					break;
				}
			case "MQ200":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.MQ200;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasChildrenPreventCold = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasDisney = true;
					break;
				}
			case "CA":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.CA;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasMyXiaoMiBracelet = true;
					_deviceInfo.hasBlueToothUpgrade = true;
					break;
				}
			case "TAB3":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.TAB3;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasNoWindFeel = true;
					_deviceInfo.hasNatureWind = true;
					_deviceInfo.hasPMV = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasHumidityDisplay = true;
					_deviceInfo.hasLadderControl = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasComfortDry = true;
					_deviceInfo.hasManualDry = true;
					break;
				}
			case "TAB12":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.TAB12;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasNoWindFeel = true;
					_deviceInfo.hasNatureWind = true;
					_deviceInfo.hasPMV = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasHumidityDisplay = true;
					_deviceInfo.hasLadderControl = true;
					_deviceInfo.hasPowerManager = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasComfortDry = true;
					_deviceInfo.hasManualDry = true;
					break;
				}
			case "FA100":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.FA100;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasHumidityDisplay = true;
					_deviceInfo.hasLadderControl = true;
					_deviceInfo.hasPowerManager = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasComfortDry = true;
					_deviceInfo.hasManualDry = true;
					_deviceInfo.hasChangesTemperature = true;
					_deviceInfo.hasNoWindFeelModal = true;
					_deviceInfo.hasChildrenPreventCold = true;
					//					_deviceInfo.hasPMV = true;
					break;
				}
			case "FA200":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.FA200;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasHumidityDisplay = true;
					_deviceInfo.hasLadderControl = true;
					_deviceInfo.hasPowerManager = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasComfortDry = true;
					_deviceInfo.hasManualDry = true;
					_deviceInfo.hasNoWindFeelModal = true;
					//					_deviceInfo.hasPMV = true;
					break;
				}
			case "KHB1":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.KHB1;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasPurify = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasPMV = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasHumidityDisplay = true;
					_deviceInfo.hasComfortDry = true;
					_deviceInfo.hasManualDry = true;
					break;
				}
			case "J8":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.KHB1;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasDot5Support = true;
					break;
				}
			case "CACP":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.CACP;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasOuterDoorDisplay = false;
					_deviceInfo.hasNoPolar = false;
					_deviceInfo.hasDeviceExamination = false;
					_deviceInfo.hasSleepCurve = true;
					break;
				}
			case "ZA300":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.ZA300;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasPurify = true;
					break;
				}
			case "ZA300B3":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.ZA300B3;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					// _deviceInfo.hasPurify = true;
					_deviceInfo.hasNoPolar = false;
					break;
				}
			case "ZB300":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.ZB300;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasSavingPower = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasNoPolar = false;
					//					_deviceInfo.hasSelfCleaning = true;
					break;
				}
			case "ZB300YJ":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.ZB300YJ;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasSavingPower = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasNoPolar = false;
					break;
				}
			case "YA300":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.YA300;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasPurify = true;
					break;
				}
			case "YA301":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.YA301;
					_deviceInfo.hasUpSwipeWind = true;
					_deviceInfo.hasDownSwipeWind = true;
					_deviceInfo.hasPurify = true;
					break;
				}
			case "W10":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.W10;
					_deviceInfo.hasUpSwipeWind = true;
					_deviceInfo.hasDownSwipeWind = true;
					break;
				}
			case "YA201":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.YA201;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasPurify = true;
					break;
				}
			case "YA200":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.YA200;
					_deviceInfo.hasLeftRightSwipeWind = true;
					break;
				}
			case "YA302":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.YA302;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasPurify = true;
					break;
				}
			case "PC400B23":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.PC400B23;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasDot5Support = true;
					break;
				}
			case "WXA":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.WXA;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasPowerManager = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasStrainerClean = true;
					_deviceInfo.hasLadderControl = true;
					//					_deviceInfo.hasMyXiaoMiBracelet = true;
					//					_deviceInfo.hasBlueToothUpgrade = true;
					//					_deviceInfo.hasSelfCleaning = true;
					break;
				}
			case "WJ7":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.WJ7;
					_deviceInfo.hasNatureWind = true;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasSleepCurve = true;
					break;
				}
			case "WYB":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.WYB;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					//					_deviceInfo.hasSelfCleaning = true;
					break;
				}
			case "PCB50":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.PCB50;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasSleepCurve = true;
                     _deviceInfo.hasReadyColdOrHot = true;
					//				
					break;
				}
			case "YB200":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.YB200;
					_deviceInfo.hasComfortDry = true;
					_deviceInfo.hasManualDry = true;
					_deviceInfo.hasPMV = true;
					_deviceInfo.hasNatureWind = true;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasPurify = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasLadderControl = true;
					_deviceInfo.hasHumidityDisplay = true;
					_deviceInfo.hasSafeInvade = true;
					_deviceInfo.hasIntelControl = true;
					_deviceInfo.hasGestureRecognize = true;
					_deviceInfo.hasReadyColdOrHot = true;
					break;
				}
			case "YB100":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.YB100;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasUpSwipeWind = true;
					_deviceInfo.hasDownSwipeWind = true;
					_deviceInfo.hasPurify = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasLadderControl = true;
					_deviceInfo.hasSafeInvade = true;
					_deviceInfo.hasIntelControl = true;
					_deviceInfo.hasGestureRecognize = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasUpDownNoWindFeel = true;
					_deviceInfo.hasLadderControl = true;
					break;
				}
			case "DA100":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.DA100;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasSleepCurve = true;
					break;
				}
			case "DA100Z":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.DA100Z;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasSleepCurve = true;
					break;
				}
			case "YB200Test":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.YB200Test;
					_deviceInfo.hasComfortDry = true;
					_deviceInfo.hasManualDry = true;
					_deviceInfo.hasPMV = true;
					_deviceInfo.hasNatureWind = true;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasPurify = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasLadderControl = true;
					_deviceInfo.hasHumidityDisplay = true;
					_deviceInfo.hasSafeInvade = true;
					_deviceInfo.hasIntelControl = true;
					_deviceInfo.hasGestureRecognize = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasStrainerClean = true;
					_deviceInfo.hasPowerManager = true;
					break;
				}
			case "WXD":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.WXD;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasSleepCurve = true;
					break;
				}
			case "WXDF":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.WXDF;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasSleepCurve = true;
					break;
				}
			case "YB300":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.YB300;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasLadderControl = true;
					break;
				}
			case "WDAA3":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.WDAA3;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasECO = true;
					break;
				}
			case "WDAD3":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.WDAD3;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasOuterDoorDisplay = false;
					_deviceInfo.hasNoPolar = false;
					_deviceInfo.hasDeviceExamination = false;
					_deviceInfo.hasSleepCurve = true;
					break;
				}
			case "WYAD2D3":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.WYAD2D3;
					_deviceInfo.hasUpSwipeWind = true;
					_deviceInfo.hasDownSwipeWind = true;
					_deviceInfo.hasOuterDoorDisplay = false;
					_deviceInfo.hasDeviceExamination = false;
					break;
				}
			case "WPAD3":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.WPAD3;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasOuterDoorDisplay = false;
					_deviceInfo.hasDeviceExamination = false;
					_deviceInfo.hasNoPolar = false;
					break;
				}
			case "DA400B3":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.DA400B3;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasOuterDoorDisplay = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasReadyColdOrHot = true;
					break;
				}
			case "PC400B1":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.PC400B1;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasDot5Support = true;
					break;
				}
			case "GW10":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.GW10;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasSleepCurve = true;
					break;
				}
				
			case "PE400B3":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.PE400B3;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasDot5Support = true;
					break;
				}
			case "DA200300":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.DA200300;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasOuterDoorDisplay = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasECO = true;
					break;
				}
			case "DA400D3":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.DA400D3;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasOuterDoorDisplay = false;
					_deviceInfo.hasNoPolar = false;
					_deviceInfo.hasDeviceExamination = false;
					_deviceInfo.hasSleepCurve = true;
					break;
				}
			case "DA400BP":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.DA400BP;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasNoPolar = false;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasPreventStraightLineWind = true;
					break;
				}
			case "DA400DP":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.DA400DP;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasNoPolar = false;
					_deviceInfo.hasDeviceExamination = false;
					_deviceInfo.hasOuterDoorDisplay = false;
					_deviceInfo.hasPreventStraightLineWind = true;

					break;
				}
			case "PA400B3":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.PA400B3;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasNoPolar = false;
					_deviceInfo.hasReadyColdOrHot = true;
					break;
				}
			case "J9":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.WJ9;
					_deviceInfo.hasNatureWind = true;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasReadyColdOrHot = true;
					break;
				}
			case "YA400D2D3":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.YA400D2D3;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasOuterDoorDisplay = false;
					_deviceInfo.hasDeviceExamination = false;
					break;
				}
			case "QA301B1":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.QA301B1;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasDot5Support = true;
					break;
				}
			case "WCBA3":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.WCBA3;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasDot5Support = true;
					break;
				}
			case "IQ100":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.IQ100;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasHumidityDisplay = true;
					_deviceInfo.hasLadderControl = true;
					_deviceInfo.hasPowerManager = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasComfortDry = true;
					_deviceInfo.hasManualDry = true;
					_deviceInfo.hasVoice = true;
					_deviceInfo.hasColdHot = true;
					_deviceInfo.hasYuyinVersion = true;
					break;
				}
			case "IQ300":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.IQ300;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasHumidityDisplay = true;
					_deviceInfo.hasLadderControl = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasComfortDry = true;
					_deviceInfo.hasManualDry = true;
					_deviceInfo.hasVoice = true;
					_deviceInfo.hasYuyinVersion = true;
					break;
				}
			case "J7":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.J7;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					break;
				}
			case "YA400B2":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.YA400B2;
					_deviceInfo.hasLeftRightSwipeWind = true;
					break;
				}
			case "WPBC":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.WPBC;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasNoPolar = false;
					break;
				}
			case "WPCD":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.WPCD;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasNoPolar = false;
					_deviceInfo.hasOuterDoorDisplay = false;
					_deviceInfo.hasDeviceExamination = false;
					break;
				}
			case "YB400":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.YB400;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasDot5Support = true;
					break;
				}
			case "YB301":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.YB301;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasChildrenPreventWind = true;
					_deviceInfo.hasUpDownNoWindFeel = true;
					break;
				}
			case "WYS":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.WYS;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasUpDownNoWindFeel = true;
					break;
				}
			case "YB201":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.YB301;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasDot5Support = true;
					_deviceInfo.hasChildrenPreventWind = true;
					_deviceInfo.hasUpDownNoWindFeel = true;
					_deviceInfo.hasLadderControl = true;
					break;
				}
			case "1TO1":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.ONETOONE;
					_deviceInfo.hasElectricHeat = true;
					_deviceInfo.hasDry = true;
					_deviceInfo.hasShow = false;
					_deviceInfo.hasNoPolar = false;
					_deviceInfo.hasDeviceExamination = false;
					_deviceInfo.hasTime1TO1 = true;
					break;
				}
			case "PF200":
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.PF200;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasECO = true;
					_deviceInfo.hasSleepCurve = true;
					_deviceInfo.hasReadyColdOrHot = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					_deviceInfo.hasDot5Support = true;
					break;
				}
			default:
				{
					_deviceInfo.deviceType = mdSmart.ACDataManager.ACDeviceType.OTHER;
					_deviceInfo.hasUpDownSwipeWind = true;
					_deviceInfo.hasLeftRightSwipeWind = true;
					break;
				}
		}

		if(deviceType == "") {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * 根据SN码，进行设备信息初始化
	 */
	this.initDeviceInfo = function() {
		var result = deviceMatchProcess();
		if(!result) {
			setTimeout(function() {
				deviceMatchProcess();
				$.event.trigger("delay::operation::get::device::info", {});
			}, 500);
		} else {
			$.event.trigger("delay::operation::get::device::info", {});
		}
	}

	function barcodeAnalysiszqj(typeList) {
		var hasSelfClean = false;
		var deviceCodeCollection = "";

		for(var i = 0; i < typeList.length; i++) {
			deviceCodeCollection += typeList[i];
			deviceCodeCollection += "/";
		}

		var deviceSN = bridge.getCurrentDevSN();
		var dataDeviceID = undefined;
		var deviceType = undefined;
		var deviceBarCode = undefined;
		if(deviceSN != "") {
			if(deviceSN.length == 32) {
				dataDeviceID = deviceSN.substring(6, 28);
				deviceBarCode = deviceSN.substring(12, 17);
			} else if(deviceSN.length == 22) {
				dataDeviceID = deviceSN.substring(0, 22);
				deviceBarCode = deviceSN.substring(6, 11);
			} else {
				dataDeviceID = "";
			}
		} else {
			dataDeviceID = "";
		}

		var codeVersion = undefined;
		codeVersion = parseInt(dataDeviceID.substring(0, 1), 16);
		if(codeVersion == 13) return false;
		if(codeVersion >= 2) {
			var barCodeChar = "78901234ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			var codeVersionrqYear = dataDeviceID.substring(11, 12);
			var pos = barCodeChar.indexOf(codeVersionrqYear);
			//2017年之后
			if(pos >= 0) {
				if(deviceCodeCollection.indexOf(deviceBarCode) != -1) {
					hasSelfClean = true;
				} else {
					hasSelfClean = false;
				}
			} else if(codeVersionrqYear == "6") {
				codeVersionrq = parseInt(dataDeviceID.substring(12, 13),16);
				if((codeVersionrq >= 9) && (deviceCodeCollection.indexOf(deviceBarCode) != -1)) {
					hasSelfClean = true;
				}
			} else {
				hasSelfClean = false;
			}

			if(deviceBarCode && deviceBarCode == "Z1214") {
				hasSelfClean = false;
			}

			return hasSelfClean;
		}
	}

	function barcodeAnalysisbaowen(typeList) {
		var hasKeepWarm = false;
		var deviceCodeCollection = "";

		for(var i = 0; i < typeList.length; i++) {
			deviceCodeCollection += typeList[i];
			deviceCodeCollection += "/";
		}

		var deviceSN = bridge.getCurrentDevSN();
		var dataDeviceID = undefined;
		var deviceType = undefined;
		var deviceBarCode = undefined;
		if(deviceSN != "") {
			if(deviceSN.length == 32) {
				dataDeviceID = deviceSN.substring(6, 28);
				deviceBarCode = deviceSN.substring(12, 17);
			} else if(deviceSN.length == 22) {
				dataDeviceID = deviceSN.substring(0, 22);
				deviceBarCode = deviceSN.substring(6, 11);
			} else {
				dataDeviceID = "";
			}
		} else {
			dataDeviceID = "";
		}

		var codeVersion = undefined;
		codeVersion = parseInt(dataDeviceID.substring(0, 1),16);
		if(codeVersion == 13) return false;
		if(codeVersion >= 2) {
			var barCodeChar = "8901234ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			var codeVersionrqYear = dataDeviceID.substring(11, 12);
			var pos = barCodeChar.indexOf(codeVersionrqYear);
			if(pos >= 0) {
				if(deviceCodeCollection.indexOf(deviceBarCode) != -1) {
					hasKeepWarm = true;
				} else {
					hasKeepWarm = false;
				}
			} else if(codeVersionrqYear == "7") {
				codeVersionrq = dataDeviceID.substring(12, 13);
				var barCodeCharmonth = "789ABC"
				var poy = barCodeCharmonth.indexOf(codeVersionrq);
				if((poy >= 0) && (deviceCodeCollection.indexOf(deviceBarCode) != -1)) {
					hasKeepWarm = true;
				} else {
					hasKeepWarm = false;
				}
			}
		}

		return hasKeepWarm;
	}

	function barcodeAnalysisYADot5(typeList) {
		var YADot5 = false;
		var deviceCodeCollection = "";
		for(var i = 0; i < typeList.length; i++) {
			deviceCodeCollection += typeList[i];
			deviceCodeCollection += "/";
		}

		var deviceSN = bridge.getCurrentDevSN();
		var dataDeviceID = undefined;
		var deviceType = undefined;
		var deviceBarCode = undefined;
		if(deviceSN != "") {
			if(deviceSN.length == 32) {
				dataDeviceID = deviceSN.substring(6, 28);
				deviceBarCode = deviceSN.substring(12, 17);
			} else if(deviceSN.length == 22) {
				dataDeviceID = deviceSN.substring(0, 22);
				deviceBarCode = deviceSN.substring(6, 11);
			} else {
				dataDeviceID = "";
			}
		} else {
			dataDeviceID = "";
		}

		var codeVersion = undefined;
		codeVersion = parseInt(dataDeviceID.substring(0, 1), 16);
		if(codeVersion == 13) return false;
		if(codeVersion >= 2) {
			var barCodeChar = "8901234ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			var codeVersionrqYear = dataDeviceID.substring(11, 12);
			var pos = barCodeChar.indexOf(codeVersionrqYear);
			if(pos >= 0) {
				if(deviceCodeCollection.indexOf(deviceBarCode) != -1) {
					YADot5 = true;
				} else {
					YADot5 = false;
				}
			} else if(codeVersionrqYear == "7") {
				codeVersionr = parseInt(dataDeviceID.substring(13, 15));
				var barCodeCharmonth = "ABC";
				var codeVersionrq = dataDeviceID.substring(12, 13);
				var poy = barCodeCharmonth.indexOf(codeVersionrq);
				if((codeVersionrq == "9") && (codeVersionr >= 6) && (deviceCodeCollection.indexOf(deviceBarCode) != -1)) {
					YADot5 = true;
				} else if((poy >= 0) && (deviceCodeCollection.indexOf(deviceBarCode) != -1)) {
					YADot5 = true;
				} else {
					YADot5 = false;
				}
			}
		}
		return YADot5;
	}
	//兼容26YA旧机型17年30号切换新机型
	function barcodeAnalysisYADot5jr26YA(typeList) {
		var YADot5jianrongjiu = false;
		var deviceCodeCollection = "";

		for(var i = 0; i < typeList.length; i++) {
			deviceCodeCollection += typeList[i];
			deviceCodeCollection += "/";
		}

		var deviceSN = bridge.getCurrentDevSN();
		var dataDeviceID = undefined;
		var deviceType = undefined;
		var deviceBarCode = undefined;
		if(deviceSN != "") {
			if(deviceSN.length == 32) {
				dataDeviceID = deviceSN.substring(6, 28);
				deviceBarCode = deviceSN.substring(12, 17);
			} else if(deviceSN.length == 22) {
				dataDeviceID = deviceSN.substring(0, 22);
				deviceBarCode = deviceSN.substring(6, 11);
			} else {
				dataDeviceID = "";
			}
		} else {
			dataDeviceID = "";
		}

		var codeVersion = undefined;
		codeVersion = parseInt(dataDeviceID.substring(0, 1));
		if(codeVersion == 13) return false;
		if(codeVersion >= 2) {
			var barCodeChar = "8901234ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			var codeVersionrqYear = dataDeviceID.substring(11, 12);
			var pos = barCodeChar.indexOf(codeVersionrqYear);
			if(pos >= 0) {
				if(deviceCodeCollection.indexOf(deviceBarCode) != -1) {
					YADot5jianrongjiu = true;
				} else {
					YADot5jianrongjiu = false;
				}
			} else if(codeVersionrqYear == "7") {
				codeVersionr = parseInt(dataDeviceID.substring(13, 15));
				var barCodeCharmonth = "ABC";
				var codeVersionrq = dataDeviceID.substring(12, 13);
				var poy = barCodeCharmonth.indexOf(codeVersionrq);
				if((codeVersionrq == "9") && (codeVersionr >= 30) && (deviceCodeCollection.indexOf(deviceBarCode) != -1)) {
					YADot5jianrongjiu = true;
				} else if((poy >= 0) && (deviceCodeCollection.indexOf(deviceBarCode) != -1)) {
					YADot5jianrongjiu = true;
				} else {
					YADot5jianrongjiu = false;
				}
			}
		}
		return YADot5jianrongjiu;
	}

	this.setDataStorage = function(dataStorage) {
		_dataStorage = dataStorage;
	}
	this.getDataStorage = function() {
		return _dataStorage;
	}

	//更新设备状态,设备状态需要根据具体的机型和功能表来填写
	this.updateDeviceStatus = function(status) {
		console.log("updateDeviceStatus");
		_deviceStatus.deviceRunningStatus = status.runningState.value == 1 ? true : false;
		if(status.runningState.value == 1) {
			_deviceSelfCleaningStatus.selfCleaning = false;
			_deviceStatus.selfCleaningStatus = false;
		}
		if(status.shushiFeng.value == 1 || status.downWind.value == 1) {
			_deviceColdHotStatus.coldHotSwitch = false;
			_deviceStatus.coldHotSwitch = false;
		}
		if(status.setHumidity.value < 30) {
			_deviceStatus.setHumidityValue = 30;
		} else if(status.setHumidity.value > 90) {
			_deviceStatus.setHumidityValue = 90;
		} else {
			_deviceStatus.setHumidityValue = status.setHumidity.value;
		}

		switch(status.settingMode.value) {
			case 0:
				{
					_deviceStatus.runningMode = mdSmart.ACDataManager.ACRunMode.RunModeInvalid;
					_deviceStatus.readyColdOrHot = false;
					_deviceStatus.comfortDryStatus = false;
					_deviceStatus.manualDryStatus = false;
					break;
				}
			case 1:
				{
					_deviceStatus.runningMode = mdSmart.ACDataManager.ACRunMode.RunModeAuto;
					_deviceStatus.readyColdOrHot = false;
					_deviceStatus.comfortDryStatus = false;
					_deviceStatus.manualDryStatus = false;
					break;
				}
			case 2:
				{
					_deviceStatus.runningMode = mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool;
					_deviceStatus.comfortDryStatus = false;
					_deviceStatus.manualDryStatus = false;
					break;
				}
			case 3:
				{
					_deviceStatus.runningMode = mdSmart.ACDataManager.ACRunMode.RunModeRemoveWet;
					_deviceStatus.readyColdOrHot = false;
					_deviceStatus.comfortDryStatus = false;
					_deviceStatus.manualDryStatus = false;
					break;
				}
			case 4:
				{
					_deviceStatus.runningMode = mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat;
					_deviceStatus.comfortDryStatus = false;
					_deviceStatus.manualDryStatus = false;
					break;
				}
			case 5:
				{
					_deviceStatus.runningMode = mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind;
					_deviceStatus.readyColdOrHot = false;
					_deviceStatus.comfortDryStatus = false;
					_deviceStatus.manualDryStatus = false;
					break;
				}
			case 6:
				{
					_deviceStatus.readyColdOrHot = false;
					if(status.setHumidity.value == 101) {
						_deviceStatus.runningMode = mdSmart.ACDataManager.ACRunMode.RunModeComfortDry;
						_deviceStatus.comfortDryStatus = true;
						_deviceStatus.manualDryStatus = false;
					} else {
						_deviceStatus.runningMode = mdSmart.ACDataManager.ACRunMode.RunModeManualDry;
						_deviceStatus.manualDryStatus = true;
						_deviceStatus.comfortDryStatus = false;
					}
					break;
				}

		}
		if(!_deviceStatus.deviceRunningStatus) {
			_deviceStatus.manualDryStatus = false;
			_deviceStatus.comfortDryStatus = false;
		}
		_deviceStatus.temperatureInteger = status.settingTemperature.value == 0 ? -1 : (status.settingTemperature.value + 16);
		_deviceStatus.temperatureDecimal = status.settingTemperatureDot5.value == 1 ? 0.5 : 0;

		if(parseInt((parseInt(status.indoorTemperature.value) - 50) / 2) < -19 || parseInt((parseInt(status.indoorTemperature.value) - 50) / 2) > 50) {
			_deviceStatus.indoorTempInteger = "--";
		} else {
			_deviceStatus.indoorTempInteger = parseInt((parseInt(status.indoorTemperature.value) - 50) / 2);
		}
		_deviceStatus.indoorTempDecimal = (status.indoorTemperatureDot.value * 0.1).toFixed(1);

		if(status.indoorTemperature.value > 49) {
			_deviceStatus.indoorTemp = Number(_deviceStatus.indoorTempInteger) + Number(_deviceStatus.indoorTempDecimal);
		} else {
			_deviceStatus.indoorTemp = Number(_deviceStatus.indoorTempInteger) - Number(_deviceStatus.indoorTempDecimal);
		}

		_deviceStatus.outerTempDecimal = status.outdoorTemperatureDot.value;
		if(status.outdoorTemperature.value < 181 && status.settingMode.value != 5) {
			_deviceStatus.outerTempInteger = parseInt((parseInt(status.outdoorTemperature.value) - 50) / 2);
			if(status.outdoorTemperature.value == 49) {
				_deviceStatus.outerTemp = "-" + _deviceStatus.outerTempInteger + "." + _deviceStatus.outerTempDecimal;
			} else {
				_deviceStatus.outerTemp = _deviceStatus.outerTempInteger + "." + _deviceStatus.outerTempDecimal;
			}
		} else {
			_deviceStatus.outerTempInteger = "--";
			_deviceStatus.outerTemp = "--";
		}

		_deviceStatus.windSpeedValue = status.noPolarWindSpeedValue.value;
		if(_deviceStatus.windSpeedValue100) {

		}
		_deviceStatus.timerOpenStatus = status.timingOpen.value == 1 ? true : false;
		_deviceStatus.timerOpenTime = timeParse(status.timingOpenAbsoluteHours.value, status.timingOpenAbsoluteMinutes.value);
		_deviceStatus.timerCloseStatus = status.timingClose.value == 1 ? true : false;
		_deviceStatus.timerCloseTime = timeParse(status.timingCloseAbsoluteHours.value, status.timingCloseAbsoluteMinutes.value);
		if(_deviceInfo.hasUpDownSwipeWind) {
			_deviceStatus.upDownProduceWindStatus = ((status.shushiFeng.value & 0xfc) == 0x3c);
		}

		if(_deviceInfo.hasLeftRightSwipeWind) {
			_deviceStatus.leftRighProducetWindStatus = ((status.shushiFeng.value & 0xf3) == 0x33);
			//			console.log("_deviceInfo.hasLeftRightSwipeWind");
			//			 console.log("TYPE1:"+getDeviceType()+","+_deviceStatus.leftRighProducetWindStatus+",7位："+(status.shushiFeng.value.toString(16)) +'kkk' +_deviceInfo.hasUpDownNoWindFeel);
			if(_deviceInfo.hasUpDownNoWindFeel && !(_deviceStatus.leftRighProducetWindStatus)) {
				//				console.log("TYPE2:"+getDeviceType()+","+_deviceStatus.leftRighProducetWindStatus+",7位："+(status.shushiFeng.value.toString(16)) +'kkk' +_deviceInfo.hasUpDownNoWindFeel);
				//YB301特殊处理，无论左左右还是右左右开启都算开启
				//				_deviceStatus.leftRighProducetWindStatus = (((status.shushiFeng.value & 0xf3) == 0x31) || 
				//															((status.shushiFeng.value & 0xf3) == 0x32)) &&
				//															((status.downWindControl == 0x00)  && (status.downWindControlLR == 0x01));
				_deviceStatus.leftRighProducetWindStatus = ((status.downWindControl == 0x00) & (status.downWindControlLR == 0x01));

				//				console.log("_deviceStatus.leftRighProducetWindStatus");
				//				console.log('status.shushiFeng.value');
				//				console.log(status.shushiFeng.value);
				//				console.log('status.downWindControl.value');
				//				console.log(status);
				//				console.log('status.downWindControlLR.value');
				//console.log(status.downWindControlLR.value);
			}
			if(_deviceStatus.upDownProduceWindStatus || _deviceStatus.leftRighProducetWindStatus) {
				_deviceWindAvoidStatus.windAvoid = false;
				_deviceStatus.windAvoidStatus = false;
			}
			//重写左右风判断逻辑
			if(_deviceInfo.hasUpDownNoWindFeel) {
				var pk = ((status.downWindControl == 0x00) & (status.downWindControlLR == 0x01));
				//第9位
				if(status.downWind.value == 1) {
					_deviceStatus.leftRighProducetWindStatus = status.downWind.value;
				}
				if((status.shushiFeng.value == 0x3f) || (status.shushiFeng.value == 0x33)) {
					_deviceStatus.leftRighProducetWindStatus = 1;
				}
				_deviceStatus.leftRighProducetWindStatus = _deviceStatus.leftRighProducetWindStatus | pk;

				if((_deviceStatus.leftRighProducetWindStatus) && (_deviceStatus.noWindFeel) || (_deviceStatus.deviceRunningStatus == false)) {
					_deviceStatus.noWindFeel = false;
					_deviceStatus.upNoWindFeel = false;
					_deviceStatus.downNoWindFeel = false;
				}
				if(_deviceStatus.deviceRunningStatus == false) {
					_deviceStatus.leftRighProducetWindStatus = 0;
				}
				setTimeout(function() {
					if(_deviceStatus.upNoWindFeel && _deviceStatus.downNoWindFeel) {
						_deviceStatus.leftRighProducetWindStatus = 0;
					}
				}, 3000);
				//				alert('status.downWind.value:' +status.downWind.value +'status.shushiFeng.value:' + status.shushiFeng.value);
			}
		}

		if(_deviceInfo.hasUpSwipeWind) {
			_deviceStatus.upSwipeWindStatus = ((status.shushiFeng.value & 0xf3) == 0x33);
		}
		if(_deviceInfo.hasUpSwipeWind && _deviceStatus.upSwipeWindStatus) {
			_deviceStatus.upNoWindFeel = false;
		}
		if(_deviceInfo.hasUpSwipeWind && _deviceStatus.upSwipeWindStatus && _deviceStatus.isWindClose) {
			_deviceStatus.windDirectionStatus = 0;
		}
		if(_deviceInfo.hasUpSwipeWind && _deviceStatus.upSwipeWindStatus == false && _deviceStatus.isWindBlow) {
			_deviceStatus.windDirectionStatus = 0;
		}

		if(_deviceInfo.hasDownSwipeWind) {
			_deviceStatus.downSwipeWindStatus = status.downWind.value == 1 ? true : false;
		}
		if(_deviceInfo.hasDownSwipeWind && _deviceStatus.downSwipeWindStatus) {
			_deviceStatus.downNoWindFeel = false;
		}
		if(_deviceInfo.hasDownSwipeWind && _deviceStatus.downSwipeWindStatus == false && _deviceStatus.isWindBlow) {
			_deviceStatus.windDirectionStatus = 0;
		}
		if(_deviceInfo.hasDownSwipeWind && _deviceStatus.downSwipeWindStatus && _deviceStatus.isWindClose) {
			_deviceStatus.windDirectionStatus = 0;
		}

		if(_deviceInfo.hasSwipeWind) {
			_deviceStatus.swipeWindStatus = ((status.shushiFeng.value & 0xf3) == 0x33);
		}

		if(_deviceInfo.hasSleepCurve) {
			_deviceStatus.sleepStatus = status.sleepMode.value == 3 ? true : false;
		}

		if(_deviceInfo.hasECO) {
			_deviceStatus.ECOStatus = status.ecoFunction.value == 1 ? true : false;
		}
		if(_deviceInfo.hasChangesTemperature&&_deviceStatus.ECOStatus){
		    _deviceColdHotStatus.coldHotSwitch = false;
			_deviceStatus.coldHotSwitch = false;	
			_deviceSoftWindFeelingStatus.windFeelingFA100 = false;
			_deviceStatus.windFeelingFA100tSwitchStatus = false;
		}

		_deviceStatus.keepWarmStatus = status.keepWarm.value == 1 ? true : false;
		if(_deviceStatus.keepWarmStatus) {
			_deviceStatus.isWindBlow = false;
			_deviceStatus.windAvoidStatus = false;
			_deviceWindAvoidStatus.windAvoid = false;
			_deviceStatus.windDirectionStatus = 0;
		}
//		_deviceStatus.ladderCoolStatus=_status.ladderCool.value == 1 ? true : false;
		if(_deviceInfo.hasChangesTemperature&&_deviceStatus.keepWarmStatus){
		    _deviceColdHotStatus.coldHotSwitch = false;
			_deviceStatus.coldHotSwitch = false;	
			_deviceSoftWindFeelingStatus.windFeelingFA100 = false;
			_deviceStatus.windFeelingFA100tSwitchStatus = false;
		}
		_deviceStatus.shabbatStatus = status.shabbat.value == 1 ? true : false;
		_deviceStatus.dustFullMarkStatus = status.dustFullMark.value == 1 ? true : false;
		_deviceStatus.filterReplaceStatus = status.filterReplace.value == 1 ? true : false;

		//	_deviceStatus.windBlowingStatus = status.windBlowing.value == 1 ? true : false;

		_deviceStatus.strongStatu = status.strong.value == 1 ? true : false;
		if(_deviceInfo.hasPurify) {
			_deviceStatus.purifyStatus = status.purifyingFunction.value == 1 ? true : false;
		}
		if(_deviceInfo.hasElectricHeat) {
			_deviceStatus.electricHeatStatus = status.electricHeat.value == 1 ? true : false;
		}
		if(_deviceInfo.hasDry) {
			if(mdSmart.ACDataManager.ACRunMode.RunModeAuto == _deviceStatus.runningMode ||
				mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat == _deviceStatus.runningMode ||
				mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind == _deviceStatus.runningMode) {
				_deviceStatus.DryStatus = false;
			} else {
				_deviceStatus.DryStatus = status.dry.value == 1 ? true : false;
			}
		}
		if(_deviceInfo.hasChildrenPreventCold) {
			_deviceStatus.preventCool = status.catchCold.value == 1 ? true : false;
			if(_deviceStatus.preventCool) {
				_deviceStatus.isWindBlow = false;
				_deviceStatus.windAvoidStatus = false;
				_deviceWindAvoidStatus.windAvoid = false;
				_deviceStatus.windDirectionStatus = 0;
			}
		}
		_deviceStatus.tubroStatus = status.tubro.value == 1 ? true : false;

		if(_deviceInfo.hasLadderControl) {
			//TODO需要从服务器获取
		}
		if(_deviceInfo.hasSelfLearn) {
			//TODO需要从服务器获取
		}
		if(_deviceInfo.hasPMV) {
			switch(status.pmvMode.value) {
				case 0:
					{
						_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeClose;
						break;
					}
				case 1:
					{
						_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeOne;
						break;
					}
				case 2:
					{
						_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeTwo;
						break;
					}
				case 3:
					{
						_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeThree;
						break;
					}
				case 4:
					{
						_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeFour;
						break;
					}
				case 5:
					{
						_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeFive;
						break;
					}
				case 6:
					{
						_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeSix;
						break;
					}
				case 7:
					{
						_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeSeven;
						break;
					}
				case 8:
					{
						_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeEight;
						break;
					}
				case 9:
					{
						_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeNine;
						break;
					}
				case 10:
					{
						_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeTen;
						break;
					}
				case 11:
					{
						_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeEleven;
						break;
					}
				case 12:
					{
						_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeTwelve;
						break;
					}
				case 13:
					{
						_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeThirteen;
						break;
					}
			}
		}
		if(_deviceInfo.hasNatureWind) {
			_deviceStatus.natureWindStatus = status.naturalWindFunction.value == 1 ? true : false;
		}
		_deviceStatus.screenDisplay = status.lightClass.value == 7 ? false : true;
		if(_deviceInfo.hasNoWindFeel) {
			_deviceStatus.noWindFeel = status.smartWind.value == 1 ? true : false;
		}
		if(_deviceInfo.hasSavingPower) {

			if(_deviceInfo.deviceType == mdSmart.ACDataManager.ACDeviceType.ZB300YJ) {
				_deviceStatus.savingElectricStatus = status.ecoFunction.value == 1 ? true : false;
			} else {
				_deviceStatus.savingElectricStatus = status.shengDian.value == 1 ? true : false;
			}
		}

		if((!_deviceStatus.upDownProduceWindStatus) ||
			(!_deviceStatus.upSwipeWindStatus) || (!_deviceStatus.downSwipeWindStatus)) {
			_deviceStatus.windSpeedStatus = false;
		}
	}

	/*
	 * 处理特殊数据
	 * CA定速与CA变频机家电上报数据中设定温度整数位及小数位与其他家电不一致
	 * A1命令上报室内温度、室外温度、湿度值需解析
	 */
	this.updateDeviceStatusOfSpecial = function(dataSource) {
		var tmpDeviceType = _deviceInfo.deviceType;
		var receiveMessageBody = dataSource.slice(10, dataSource.length - 1);
		if(mdSmart.ACDataManager.ACDeviceType.CA == tmpDeviceType ||
			mdSmart.ACDataManager.ACDeviceType.CACP == tmpDeviceType) {
			if(receiveMessageBody[0] == 0xA0) {
				_deviceStatus.temperatureInteger = ((receiveMessageBody[1] >> 2) - 4 == 0) ? -1 : ((receiveMessageBody[1] >> 2) + 12);
				_deviceStatus.temperatureDecimal = ((receiveMessageBody[1] >> 1) & 0x01 == 1) ? 0.5 : 0;
			}
		}

		if(receiveMessageBody[0] == 0xA1) {
			if(parseInt((receiveMessageBody[13] - 50) / 2) < -19 || parseInt((receiveMessageBody[13] - 50) / 2) > 50) {
				_deviceStatus.indoorTempInteger = "--";
			} else {
				_deviceStatus.indoorTempInteger = parseInt((receiveMessageBody[13] - 50) / 2);
			}

			_deviceStatus.indoorTempDecimal = (receiveMessageBody[18] & 0x0f) * 0.1;

			if(receiveMessageBody[13] > 49) {
				_deviceStatus.indoorTemp = Number(_deviceStatus.indoorTempInteger) + Number(_deviceStatus.indoorTempDecimal);
			} else {
				_deviceStatus.indoorTemp = Number(_deviceStatus.indoorTempInteger) - Number(_deviceStatus.indoorTempDecimal);
			}

			//			_deviceStatus.outerTempDecimal = (receiveMessageBody[18] >> 4) * 0.1;
			_deviceStatus.outerTempDecimal = receiveMessageBody[18] >> 4;
			if(receiveMessageBody[14] > 11 && receiveMessageBody[14] < 181 && _deviceStatus.runningMode != 5) {
				_deviceStatus.outerTempInteger = parseInt((receiveMessageBody[14] - 50) / 2);
				_deviceStatus.outerTemp = _deviceStatus.outerTempInteger + "." + _deviceStatus.outerTempDecimal;
			} else {
				_deviceStatus.outerTempInteger = "--";
				_deviceStatus.outerTemp = "--";
			}

			if(receiveMessageBody[17] < 1 || receiveMessageBody[17] > 99) {
				_deviceStatus.humidityValue = "--";
			} else {
				_deviceStatus.humidityValue = receiveMessageBody[17];
			}

		}
	}

	/**
	 * 返回当前设备的相关信息，包括设备有哪些功能，当前运行的状态
	 * 数据结构currentDevice = {deviceInfo;_deviceInfo,deviceStatus:_deviceStatus}
	 */
	this.getCurrentDevice = function() {

		var currentDevice = {
			deviceInfo: _deviceInfo,
			deviceStatus: _deviceStatus
		};
		return currentDevice;
	}

	this.closeCurrentDevicePMV = function() {
		_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeClose;
	}

	this.closeNoWindFeelECONaturalWind = function() {
		_deviceStatus.noWindFeel = false;
		_deviceStatus.natureWindStatus = false;
		_deviceStatus.ECOStatus = false;
		_deviceStatus.sleepStatus = false;
		_deviceStatus.keepWarmStatus = false;
		_deviceStatus.windBlowingStatus = false;
	}

	/**
	 * 返回FAQ的内容
	 */
	this.getFAQContent = function() {
		return _mideaFAQContent;
	}

	this.setFAQContent = function(FAQContent) {
		_mideaFAQContent = FAQContent;
	}

	/**
	 * 返回使用说明的url地址对象，ACDeviceVideoUrl = {}
	 */
	this.getInstructionsUrls = function() {
		return _deviceVideoUrl;
	}

	/**
	 * 更新使用说明的URl地址对象，ACDeviceVideoUrl
	 */
	this.updateInstructionURL = function(videoURL) {
		if(videoURL.ProductInstruction!=""&&videoURL.DailyUse!==""&&videoURL.CleanMaintain!==""
		&&videoURL.ContactUs!==""&&videoURL.WifiControl!==""&&videoURL.IntactTotal!==""){
			_deviceInfo.hasVideoDescription=true;
		}
		_deviceVideoUrl.ProductInstruction = videoURL.ProductInstruction;
		_deviceVideoUrl.DailyUse = videoURL.DailyUse;
		_deviceVideoUrl.CleanMaintain = videoURL.CleanMaintain;
		_deviceVideoUrl.ContactUs = videoURL.ContactUs;
		_deviceVideoUrl.WifiControl = videoURL.WifiControl;
		_deviceVideoUrl.IntactTotal = videoURL.IntactTotal;
	}

	/**
	 * 获得美粉圈url
	 */
	this.getMideaFanUrl = function() {
		return _mideaFanUrl;

	}

	this.setMideaFanUrl = function(funUrl) {
		_mideaFanUrl = funUrl;
	}

	/**
	 * 获得美的商城url
	 */
	this.getMideaStoreUrl = function() {
		return _mideaStoreUrl;
	}

	this.setMideaStoreUrl = function(storeUrl) {
		_mideaStoreUrl = storeUrl;
	}

	/**
	 * 获得美的售后url
	 */
	this.getMideaAfterSaleUrl = function() {
		return _mideaAfterSaleUrl;
	}

	this.setMideaAfterSaleUrl = function(afterSaleUrl) {
		_mideaAfterSaleUrl = afterSaleUrl;
	}

	/**
	 *  设备时间转换为自然时间
	 *
	 *  @param deviceHour   设备时间小时
	 *  @param deviceMinute 设备时间分钟
	 *
	 *  @return 返回自然时间的分钟数
	 */
	function timeParse(deviceHour, deviceMinute) {
		var sumMin = parseInt(deviceHour) * 15 + parseInt(15 - deviceMinute);
		return sumMin;
	}

	/**
	 * 获得设备的名字
	 * @return 设备的名字
	 */
	function setDeviceName() {
		bridge.getCardTitle(function(message) {
			var name = "空调";
			if((undefined != message) && ("" != message) && (null != message)) {
				name = message;
			}
			_deviceStatus.deviceName = name;
		});
	}

	/**
	 * 设置提示音状态 isOpen:true 表示控制时有提示音,false表示控制时没有提示音
	 */
	this.setPromptTone = function(isOpen) {
		var SNStr = bridge.getCurrentDevSN();
		_promptTone = isOpen;
		var promptNum = isOpen == true ? 1 : 0;
		_dataStorage.setKeystrokeStatus(promptNum);
		localStorage.setItem("ACTone" + SNStr, promptNum);
	}

	/**
	 * 根据本地存储初始化提示音控制
	 */
	this.initPromptToneFromLocal = function() {
		var SNStr = bridge.getCurrentDevSN();
		if(SNStr !== "" && SNStr != undefined) {
			runInitPromptToneFromLocal(SNStr);
		} else {
			var t = setInterval(function() {
				SNStr = bridge.getCurrentDevSN();
				if(SNStr !== "" && SNStr != undefined) {
					clearInterval(t);
					runInitPromptToneFromLocal(SNStr);
				}
			}, 100);
		}

	}

	function runInitPromptToneFromLocal(SNStr) {

		var promptStr = localStorage.getItem("ACTone" + SNStr);
		if("0" == promptStr) {
			_promptTone = false;
			_dataStorage.setKeystrokeStatus(0);
		} else {
			_promptTone = true;
			_dataStorage.setKeystrokeStatus(1);
		}
	}

	/**
	 * 获得提示音状态 true,表示提示音开，false表示提示音关闭
	 */
	this.getPromptTone = function() {
		return _promptTone;
	}

	/**
	 * 更新防着凉推送提醒开关状态 isOpen:true表示开启，false表示关闭
	 */
	this.setPreventColdAPNSRemind = function(isOpen) {
		_preventColdAPNSRemind = isOpen;
	}

	this.getPreventColdAPNSRemind = function() {
		return _preventColdAPNSRemind;
	}

	/**
	 * 更新阶梯降温开关状态 isOpen:true表示开启，false表示关闭
	 */
	this.setLadderControlStatus = function(isOpen) {
		_ladderControlStatus = isOpen;
	}

	this.getLadderControlStatus = function() {
		return _ladderControlStatus;
	}
	/**
	 * 更新入侵推送提醒开关状态 isOpen:true表示开启，false表示关闭
	 */
	this.setIntrusionRemind = function(isOpen) {
		_intrusionStatus = isOpen;
	}

	this.getIntrusionRemind = function() {
		return _intrusionStatus;
	}

	/**
	 *获取运行模式的名字
	 */
	this.getDeviceRunModeName = function() {
		var name = "";
		switch(_deviceStatus.runningMode) {
			case mdSmart.ACDataManager.ACRunMode.RunModeAuto:
				{
					name = "自动运行";
					break;
				}
			case mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool:
				{
					name = "制冷运行";
					break;
				}
			case mdSmart.ACDataManager.ACRunMode.RunModeRemoveWet:
				{
					name = "抽湿运行";
					break;
				}
			case mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat:
				{
					name = "制热运行";
					break;
				}
			case mdSmart.ACDataManager.ACRunMode.RunModeSupplyWind:
				{
					name = "送风运行";
					break;
				}
			case mdSmart.ACDataManager.ACRunMode.RunModeComfortDry:
				{
					name = "舒适抽湿";
					break;
				}
			case mdSmart.ACDataManager.ACRunMode.RunModeManualDry:
				{
					name = "个性抽湿";
					break;
				}
		}
		return name;
	}

	/**
	 * 获得儿童踢被子界面更新后的状态信息
	 */
	this.getPreventColdParameterModify = function() {
		var tmpPreventCold = new ACDevicePreventCold();
		if(-1 == _cacheDevicePreventCold.beColdSensitivity) {
			tmpPreventCold.beColdSensitivity = _devicePreventCold.beColdSensitivity;
		} else {
			tmpPreventCold.beColdSensitivity = _cacheDevicePreventCold.beColdSensitivity;
		}
		if(-1 == _cacheDevicePreventCold.beHeatSensitivity) {
			tmpPreventCold.beHeatSensitivity = _devicePreventCold.beHeatSensitivity;
		} else {
			tmpPreventCold.beHeatSensitivity = _cacheDevicePreventCold.beHeatSensitivity;
		}
		if(-1 == _cacheDevicePreventCold.beColdTemperateRise) {
			tmpPreventCold.beColdTemperateRise = _devicePreventCold.beColdTemperateRise;
		} else {
			tmpPreventCold.beColdTemperateRise = _cacheDevicePreventCold.beColdTemperateRise;
		}
		if(-1 == _cacheDevicePreventCold.beHeatTemperateRise) {
			tmpPreventCold.beHeatTemperateRise = _devicePreventCold.beHeatTemperateRise;
		} else {
			tmpPreventCold.beHeatTemperateRise = _cacheDevicePreventCold.beHeatTemperateRise;
		}
		if(-1 == _cacheDevicePreventCold.beColdMin) {
			tmpPreventCold.beColdMin = _devicePreventCold.beColdMin;
		} else {
			tmpPreventCold.beColdMin = _cacheDevicePreventCold.beColdMin;
		}
		if(-1 == _cacheDevicePreventCold.beColdMax) {
			tmpPreventCold.beColdMax = _devicePreventCold.beColdMax;
		} else {
			tmpPreventCold.beColdMax = _cacheDevicePreventCold.beColdMax;
		}
		if(-1 == _cacheDevicePreventCold.beHeatMin) {
			tmpPreventCold.beHeatMin = _devicePreventCold.beHeatMin;
		} else {
			tmpPreventCold.beHeatMin = _cacheDevicePreventCold.beHeatMin;
		}
		if(-1 == _cacheDevicePreventCold.beHeatMax) {
			tmpPreventCold.beHeatMax = _devicePreventCold.beHeatMax;
		} else {
			tmpPreventCold.beHeatMax = _cacheDevicePreventCold.beHeatMax;
		}
		return tmpPreventCold;
	}

	/**
	 * 重置踢被子缓存状态
	 */
	this.resetCachePreventCold = function() {
		_cacheDevicePreventCold.beColdSensitivity = -1;
		_cacheDevicePreventCold.beHeatSensitivity = -1;
		_cacheDevicePreventCold.beColdTemperateRise = -1;
		_cacheDevicePreventCold.beHeatTemperateRise = -1;
		_cacheDevicePreventCold.beColdMin = -1;
		_cacheDevicePreventCold.beColdMax = -1;
		_cacheDevicePreventCold.beHeatMin = -1;
		_cacheDevicePreventCold.beHeatMax = -1;
	}

	/**
	 * 获得防着凉状态信息 ACDevicePreventCold
	 */
	this.getPreventColdStatus = function() {
		return _devicePreventCold;
	}

	/**
	 * 下面的一些列update***方法更新防着凉设置的相关状态，客户端调用者，直接设置更新
	 */
	this.updateBeColdSensitivity = function(beColdSensitivity) {
		_cacheDevicePreventCold.beColdSensitivity = beColdSensitivity;
		window.setTimeout(function() {
			$.event.trigger("updatePreventColdViewMsg", {});
		}, 1000);
	}

	this.updateBeHeatSensitivity = function(beHeatSensitivity) {
		_cacheDevicePreventCold.beHeatSensitivity = beHeatSensitivity;
		window.setTimeout(function() {
			$.event.trigger("updatePreventColdViewMsg", {});
		}, 1000);
	}

	this.updateBeColdTemperateRise = function(beColdTemperateRise) {
		_cacheDevicePreventCold.beColdTemperateRise = beColdTemperateRise;
		window.setTimeout(function() {
			$.event.trigger("updatePreventColdViewMsg", {});
		}, 1000);
	}

	this.updateBeHeatTemperateRise = function(beHeatTemperateRise) {
		_cacheDevicePreventCold.beHeatTemperateRise = beHeatTemperateRise;
		window.setTimeout(function() {
			$.event.trigger("updatePreventColdViewMsg", {});
		}, 1000);
	}

	this.updateBeColdMin = function(beColdMin) {
		_cacheDevicePreventCold.beColdMin = beColdMin;
		window.setTimeout(function() {
			$.event.trigger("updatePreventColdViewMsg", {});
		}, 1000);
	}

	this.updateBeColdMax = function(beColdMax) {
		_cacheDevicePreventCold.beColdMax = beColdMax;
		window.setTimeout(function() {
			$.event.trigger("updatePreventColdViewMsg", {});
		}, 1000);
	}

	this.updateBeHeatMin = function(beHeatMin) {
		_cacheDevicePreventCold.beHeatMin = beHeatMin;
		window.setTimeout(function() {
			$.event.trigger("updatePreventColdViewMsg", {});
		}, 1000);
	}

	this.updatebeHeatMax = function(beHeatMax) {
		_cacheDevicePreventCold.beHeatMax = beHeatMax;
		window.setTimeout(function() {
			$.event.trigger("updatePreventColdViewMsg", {});
		}, 1000);
	}

	/**
	 * 新协议数据处理
	 */
	this.newProtocolDataProcess = function(p1) {
		if((p1[10] == 0xB1) || (p1[10] == 0xB0)) {
			var si = 0;
			var sj = 0;
			var sk = p1[11];

			var tmpCmdType = [];
			var tmpCmdResult = 1;
			var tmpCmdValue = [];

			var shift = 0;
			//			if (sk > 5) sk = 5;
			for(si = 0; si < sk; si++) {
				tmpCmdResult = p1[14 + si * 5 + shift];
				if(tmpCmdResult == 0) {
					tmpCmdType[0] = p1[12 + si * 5 + shift];
					tmpCmdType[1] = p1[13 + si * 5 + shift];
					var tmpCmdValueLength = p1[15 + si * 5 + shift];
					for(sj = 0; sj < tmpCmdValueLength; sj++) {
						tmpCmdValue[sj] = p1[16 + si * 5 + sj + shift];
					}
					if(tmpCmdValueLength > 1) {
						shift = shift + (tmpCmdValueLength - 1);
					}
					if(tmpCmdValueLength > 0 || tmpCmdValueLength == 0) {
						newProtocolFunctionParse(tmpCmdType, tmpCmdValueLength, tmpCmdValue);
					}
				}
			}
		}
	}

	/**
	 * 新协议上报数据处理
	 */
	this.newProtocolUploadDataProcess = function(p1) {
		if((p1[10] == 0xB5) || (p1[10] == 0xB4)) { //	家电上报数据的处理
			var si = 0;
			var sj = 0;
			var sk = p1[11];

			var tmpCmdType = [];
			var tmpCmdResult = 1;
			var tmpCmdValue = [];

			var shift = 0;

			for(si = 0; si < sk; si++) {
				tmpCmdType[0] = p1[12 + si * 4 + shift];
				tmpCmdType[1] = p1[13 + si * 4 + shift];
				tmpCmdValue = [];
				var tmpCmdValueLength = p1[14 + si * 4 + shift];
				for(sj = 0; sj < tmpCmdValueLength; sj++) {
					tmpCmdValue[sj] = p1[15 + si * 4 + sj + shift];
				}
				if(tmpCmdValueLength > 1) {
					shift = shift + (tmpCmdValueLength - 1);
				}
				newProtocolFunctionParse(tmpCmdType, tmpCmdValueLength, tmpCmdValue);
			}
		}

		//	if(p1[10] == 0xC0) { //	05\C0家电上报数据的处理
		//		var si = 0;
		//		var sj = 0;
		//		var source = p1[11];
		//		var sk = p1[12];
		//
		//		var tmpCmdType = [];
		//		var tmpCmdResult = 1;
		//		var tmpCmdValue = [];
		//
		//		var shift = 0;
		//
		//		for(si = 0; si < sk; si++) {
		//			tmpCmdType[0] = p1[13 + si * 4 + shift];
		//			tmpCmdType[1] = p1[14 + si * 4 + shift];
		//			tmpCmdValue = [];
		//			var tmpCmdValueLength = p1[15 + si * 4 + shift];
		//			for(sj = 0; sj < tmpCmdValueLength; sj++) {
		//				tmpCmdValue[sj] = p1[16 + si * 4 + sj + shift];
		//			}
		//			if(tmpCmdValueLength > 1) {
		//				shift = shift + (tmpCmdValueLength - 1);
		//			}
		//			newProtocolFunctionParse(tmpCmdType, tmpCmdValueLength, tmpCmdValue);
		//		}
		//	}
	}
	
	/**
	 * 新协议上报数据处理
	 */
//this.newProtocolUploadDataProcess = function(p1) {
//if((p1[10] == 0xB5) || (p1[10] == 0xB4)) { // 家电上报数据的处理
// var si = 0;
// var sj = 0;
// var sk = p1[11];
//
// var tmpCmdType = [];
// var tmpCmdResult = 1;
// var tmpCmdValue = [];
//
// var shift = 0;
// var tk = 12;   
//
// for(si = 0; si < sk; si++) {
//
//  tmpCmdType[0] = p1[tk];
//  tk =  tk + 1;
//  tmpCmdType[1] = p1[tk];
//  tk =  tk + 1;
//  var tmpCmdValueLength = p1[tk];
//  tk = tk + 1;
//
//  tmpCmdValue = [];
//
//  for(sj = 0; sj < tmpCmdValueLength; sj++) {
//      tmpCmdValue[sj] = p1[tk];
//      tk =  tk  + 1;
//  }
//
//  newProtocolFunctionParse(tmpCmdType, tmpCmdValueLength, tmpCmdValue);
//
// }
//}
// }

	/**
	 *  根据新协议数据解析得到所需功能数据，更新_devicePreventCold防着凉状态
	 *  预冷预热，无风感
	 */
	function newProtocolFunctionParse(p1, p2, p3) {
		var deviceType = getDeviceType();
		//预冷预热
		if((p1[1] == 0x02) && (p1[0] == 0x01)) {
			if(p3[0] == 1) {
				localStorage.setItem("ACDeviceReadyColdOrHot", 1);
			} else {
				localStorage.setItem("ACDeviceReadyColdOrHot", 0);
			}

			if(mdSmart.ACDataManager.ACRunMode.RunModeBecomeCool == _deviceStatus.runningMode ||
				mdSmart.ACDataManager.ACRunMode.RunModeBecomeHeat == _deviceStatus.runningMode) {
				_deviceStatus.readyColdOrHot = localStorage.getItem("ACDeviceReadyColdOrHot") == 1 ? true : false;
			} else {
				_deviceStatus.readyColdOrHot = false;
			}
		}
		//无风感
		if((p1[1] == 0x00) && (p1[0] == 0x18)) {
			//兼容0018旧版本协议
			if(p3[0] == 1) {
				//无风感状态 
				_deviceStatus.noWindFeel =
					_deviceStatus.upNoWindFeel =
					_deviceStatus.downNoWindFeel = true;
				_deviceStatus.windDirectionStatus = 0;
				_deviceStatus.windSpeedStatus = false;
				if((_deviceInfo.hasNoWindFeel) && (_deviceStatus.noWindFeel)) {
					_deviceStatus.leftRighProducetWindStatus = 0;
				}
				resolveNewProtocolConflict4NoWindFeel();
			} else if(p3[0] == 2) {
				_deviceStatus.upNoWindFeel = true;
				_deviceStatus.noWindFeel =
					_deviceStatus.downNoWindFeel = false;
				_deviceStatus.upSwipeWindStatus = false;
				_deviceStatus.windDirectionStatus = 0;
				_deviceStatus.windSpeedStatus = false;
			} else if(p3[0] == 3) {
				_deviceStatus.downNoWindFeel = true;
				_deviceStatus.noWindFeel =
					_deviceStatus.upNoWindFeel = false;
				_deviceStatus.downSwipeWindStatus = false;
				_deviceStatus.windDirectionStatus = 0;
				_deviceStatus.windSpeedStatus = false;
			} else {
				//无风感状态 
				_deviceStatus.noWindFeel =
					_deviceStatus.upNoWindFeel =
					_deviceStatus.downNoWindFeel = false;
			}
		}
		//上下无风感
		if((p1[1] == 0x00) && (p1[0] == 0x3d)) {
			_deviceStatus.upNoWindFeel = p3[0] == 1;
		}
		if((p1[1] == 0x00) && (p1[0] == 0x3e)) {
			_deviceStatus.downNoWindFeel = p3[0] == 1;
		}

		//新防直吹
		if((p1[1] == 0x00) && (p1[0] == 0x42)) {
			if(_deviceInfo.deviceType != mdSmart.ACDataManager.ACDeviceType.FA100) {
				if(p3[0] == undefined) {
					_deviceInfo.hasWindBlowing = false
				} else {
					_deviceInfo.hasWindBlowing = true;
				}
			}
			if(p3[0] == 2) {
				_deviceStatus.windDirectionStatus = 0;
				_deviceWindBlowingStatus.windBlowing = true;
				_deviceStatus.windBlowingStatus = true;
				_deviceStatus.upDownProduceWindStatus = false;
				_deviceStatus.upSwipeWindStatus = false;
				_deviceStatus.downSwipeWindStatus = false;
				_deviceStatus.upNoWindFeel = false;
				_deviceStatus.downNoWindFeel = false;
				_deviceStatus.natureWindStatus = false;
				_deviceSoftWindFeelingStatus.straightBlow = true;
				_deviceStatus.straightBlowStatus = true;
				_deviceSoftWindFeelingStatus.windFeelingFA100 = false;
				_deviceStatus.windFeelingFA100tSwitchStatus = false;
				_deviceSoftWindFeelingStatus.softWindFeel = false;
				_deviceStatus.softWindFeelSwitchStatus = false;
				_deviceStatus.preventCool = false;
				_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeClose;
				_deviceStatus.sleepStatus = false;
				_deviceColdHotStatus.coldHotSwitch = false;
				_deviceStatus.coldHotSwitch = false;
				_dataStorage.setComfortWind0x3LV(0x00);
				_dataStorage.setComfortWind0x3RV(0x00);
				_dataStorage.setNaturalWindFunctionSwitch(0x00);
			} else {
				_deviceWindBlowingStatus.windBlowing = false;
				_deviceStatus.windBlowingStatus = false;
				_deviceSoftWindFeelingStatus.straightBlow = false;
				_deviceStatus.straightBlowStatus = false;
				_deviceSoftWindFeelingStatus.softWindFeel = false;
				_deviceStatus.softWindFeelSwitchStatus = false;
				_deviceSoftWindFeelingStatus.windFeelingFA100 = false;
				_deviceStatus.windFeelingFA100tSwitchStatus = false;
			}
		}

		if((p1[1] == 0x00) && (p1[0] == 0x43)) {
			if(p3[0] == 2) {
				_deviceStatus.windDirectionStatus = 0;
				_deviceStatus.upDownProduceWindStatus = false;
				_deviceStatus.upSwipeWindStatus = false;
				_deviceStatus.downSwipeWindStatus = false;
				_deviceStatus.upNoWindFeel = false;
				_deviceStatus.downNoWindFeel = false;
				_deviceStatus.natureWindStatus = false;
				_deviceSoftWindFeelingStatus.straightBlow = true;
				_deviceStatus.straightBlowStatus = true;
				_deviceSoftWindFeelingStatus.windFeelingFA100 = false;
				_deviceStatus.windFeelingFA100tSwitchStatus = false;
				_deviceSoftWindFeelingStatus.softWindFeel = false;
				_deviceStatus.softWindFeelSwitchStatus = false;
				_deviceStatus.preventCool = false;
				_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeClose;
				_deviceStatus.sleepStatus = false;
				_deviceColdHotStatus.coldHotSwitch = false;
				_deviceStatus.coldHotSwitch = false;
				_dataStorage.setComfortWind0x3LV(0x00);
				_dataStorage.setComfortWind0x3RV(0x00);
				_dataStorage.setNaturalWindFunctionSwitch(0x00);
			} else if(p3[0] == 3) {
				_deviceStatus.windDirectionStatus = 0;
				_deviceStatus.upDownProduceWindStatus = false;
				_deviceStatus.upSwipeWindStatus = false;
				_deviceStatus.downSwipeWindStatus = false;
				_deviceStatus.upNoWindFeel = false;
				_deviceStatus.downNoWindFeel = false;
				_deviceStatus.natureWindStatus = false;
				_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeClose;
				_deviceStatus.sleepStatus = false;
				_deviceSoftWindFeelingStatus.softWindFeel = true;
				_deviceStatus.softWindFeelSwitchStatus = true;
				_deviceSoftWindFeelingStatus.straightBlow = false;
				_deviceStatus.straightBlowStatus = false;
				_deviceSoftWindFeelingStatus.windFeelingFA100 = false;
				_deviceStatus.windFeelingFA100tSwitchStatus = false;
				_deviceColdHotStatus.coldHotSwitch = false;
				_deviceStatus.coldHotSwitch = false;
				_deviceStatus.preventCool = false;
				_deviceStatus.windBlowingStatus = false;
				_deviceStatus.sleepStatus = false;
				_deviceStatus.natureWindStatus = false;
				_deviceStatus.tubroStatus = false;
				//关闭强劲
				_dataStorage.setStrongSwitch(0x00);
				//关闭自然风
				_dataStorage.setNaturalWindFunctionSwitch(0x00);
				//关闭睿风
				_dataStorage.setRuiFengSwitch(0x00);
				//关闭儿童睡眠
				_dataStorage.setChildrenSleepMode(0x00);
				//关闭舒睡
				_dataStorage.setSleepModeSwitch(0x00);
				//关闭PMV		
				_dataStorage.setPMVFunction(0);
			} else if(p3[0] == 4) {
				_deviceStatus.ECOStatus = false;
				_deviceStatus.keepWarmStatus = false;
				_deviceStatus.windDirectionStatus = 0;
				_deviceStatus.upDownProduceWindStatus = false;
				_deviceStatus.upSwipeWindStatus = false;
				_deviceStatus.downSwipeWindStatus = false;
				_deviceStatus.upNoWindFeel = false;
				_deviceStatus.downNoWindFeel = false;
				_deviceStatus.natureWindStatus = false;
				_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeClose;
				_deviceStatus.sleepStatus = false;
				_deviceSoftWindFeelingStatus.windFeelingFA100 = true;
				_deviceStatus.windFeelingFA100tSwitchStatus = true;
				_deviceSoftWindFeelingStatus.softWindFeel = false;
				_deviceStatus.softWindFeelSwitchStatus = false;
				_deviceSoftWindFeelingStatus.straightBlow = false;
				_deviceStatus.straightBlowStatus = false;
				_deviceColdHotStatus.coldHotSwitch = false;
				_deviceStatus.coldHotSwitch = false;
				_deviceStatus.preventCool = false;
				if(!_deviceInfo.hasUpDownNoWindFeel) {
					_dataStorage.setComfortWind0x3LV(0x00);
					_dataStorage.setComfortWind0x3RV(0x00);
				}
				_deviceStatus.windBlowingStatus = false;
				_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeClose;
				_deviceStatus.sleepStatus = false;
				_deviceStatus.natureWindStatus = false;
				_deviceStatus.tubroStatus = false;
				//关闭强劲
				_dataStorage.setStrongSwitch(0x00);
				//关闭自然风
				_dataStorage.setNaturalWindFunctionSwitch(0x00);
				//关闭睿风
				_dataStorage.setRuiFengSwitch(0x00);
				//关闭儿童睡眠
				_dataStorage.setChildrenSleepMode(0x00);
				//关闭舒睡
				_dataStorage.setSleepModeSwitch(0x00);
				//关闭PMV		
				_dataStorage.setPMVFunction(0);
			} else {
				_deviceWindBlowingStatus.windBlowing = false;
				_deviceStatus.windBlowingStatus = false;
				_deviceSoftWindFeelingStatus.straightBlow = false;
				_deviceStatus.straightBlowStatus = false;
				_deviceSoftWindFeelingStatus.softWindFeel = false;
				_deviceStatus.softWindFeelSwitchStatus = false;
				_deviceSoftWindFeelingStatus.windFeelingFA100 = false;
				_deviceStatus.windFeelingFA100tSwitchStatus = false;
			}
		}
		//智能风速功能
		if((p1[1] == 0x00) && (p1[0] == 0x33)) {
			if(p3[0] == 1) {
				_deviceStatus.windSpeedStatus = true;
				_deviceWindAvoidStatus.windAvoid = true;
				_deviceStatus.windAvoidStatus = true;
				_deviceStatus.natureWindStatus = false;
				_deviceStatus.preventCool = false;
				_deviceStatus.keepWarmStatus = false;
				_dataStorage.setNoPolarWindSpeedValue(102);
				_deviceStatus.noWindFeel =
					_deviceStatus.upNoWindFeel =
					_deviceStatus.downNoWindFeel = false;
				_deviceStatus.upSwipeWindStatus = true;
				_deviceStatus.downSwipeWindStatus = true;
				_deviceStatus.upDownProduceWindStatus = true;
				if(_deviceInfo.hasChangesTemperature) {
					_deviceStatus.upSwipeWindStatus = false;
					_deviceStatus.downSwipeWindStatus = false;
					_deviceStatus.upDownProduceWindStatus = false;
					_deviceStatus.leftRighProducetWindStatus = false;
				}
			} else {
				_deviceWindAvoidStatus.windAvoid = false;
				_deviceStatus.windAvoidStatus = false;
				_deviceStatus.windSpeedStatus = false;
			}
		}
		//自清洁
		if((p1[1] == 0x00) && (p1[0] == 0x39)) {
			if(p3[0] == 1) {
				//自清洁状态
				_deviceSelfCleaningStatus.selfCleaning = true;
				_deviceStatus.selfCleaningStatus = true;
				_deviceStatus.deviceRunningStatus = false;
				_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeClose;
				_deviceStatus.sleepStatus = false;
				_deviceStatus.natureWindStatus = false;
				_deviceStatus.tubroStatus = false;
				_deviceStatus.upDownProduceWindStatus = false;
				_deviceStatus.leftRighProducetWindStatus = false;
				_deviceStatus.upSwipeWindStatus = false;
				_deviceStatus.downSwipeWindStatus = false;
				_deviceStatus.ECOStatus = false;
				_deviceStatus.timerOpenStatus = false;
				_deviceStatus.timerCloseStatus = false;
				_deviceStatus.electricHeatStatus = false;
				_deviceStatus.purifyStatus = false;
				_deviceStatus.windSpeedValue = 102;
				_deviceStatus.noWindFeel = false;
				_deviceStatus.windSpeedStatus = false;
				_deviceStatus.upNoWindFeel = false;
				_deviceStatus.downNoWindFeel = false;
				_deviceStatus.keepWarmStatus = false;
				_deviceStatus.preventCool = false;
				_deviceWindBlowingStatus.windBlowing = false;
				_deviceStatus.windBlowingStatus = false;
				_deviceStatus.windDirectionStatus = 0;
				_deviceStatus.isWindBlow = false;
				_deviceStatus.isWindClose = false;
				_deviceSoftWindFeelingStatus.softWindFeel = false;
				_deviceStatus.softWindFeelSwitchStatus = false;
				_deviceStatus.windFeelingFA100tSwitchStatus = false;
				_deviceWindAvoidStatus.windAvoid = false;
				_deviceColdHotStatus.coldHotSwitch = false;
				_deviceStatus.coldHotSwitch = false;
				_deviceWindAvoidStatus.windAvoid = false;
				_deviceStatus.windAvoidStatus = false;
				_deviceSoftWindFeelingStatus.straightBlow = false;
				_deviceStatus.straightBlowStatus = false;
			} else {
				//自清洁状态
				_deviceSelfCleaningStatus.selfCleaning = false;
				_deviceStatus.selfCleaningStatus = false;
			}
		}
		//100 高，50中,1低
		//制冷踢被子灵敏度
		if((p1[1] == 0x04) && (p1[0] == 0x10)) {
			if(p3[0] <= 100 && p3[0] > 50) {
				_devicePreventCold.beColdSensitivity = 0;
			} else if(p3[0] >= 50 && p3[0] < 100) {
				_devicePreventCold.beColdSensitivity = 1;
			} else {
				_devicePreventCold.beColdSensitivity = 2;
			}
		}
		//制热踢被子灵敏度
		if((p1[1] == 0x04) && (p1[0] == 0x11)) {
			if(p3[0] <= 100 && p3[0] > 50) {
				_devicePreventCold.beHeatSensitivity = 0;
			} else if(p3[0] >= 50 && p3[0] < 100) {
				_devicePreventCold.beHeatSensitivity = 1;
			} else {
				_devicePreventCold.beHeatSensitivity = 2;
			}
		}
		//制冷踢被子后温度补偿值
		if((p1[1] == 0x04) && (p1[0] == 0x12)) {
			var coldTempValue = p3[0];
			var temperateValue = coldTempValue * 0.5;
			_devicePreventCold.beColdTemperateRise = temperateValue;
		}
		//制热踢被子后温度补偿值
		if((p1[1] == 0x04) && (p1[0] == 0x13)) {
			var heatTempValue = p3[0];
			var temperateValue = heatTempValue * 0.5;
			_devicePreventCold.beHeatTemperateRise = temperateValue;
		}

		//制冷踢被子后温度上下限
		if((p1[1] == 0x04) && (p1[0] == 0x1b)) {
			if(p3[0] > 60) {
				_devicePreventCold.beColdMin = 27;
			} else {
				_devicePreventCold.beColdMin = p3[0] / 2;
			}
			if(p3[1] > 60) {
				_devicePreventCold.beColdMax = 28;
			} else {
				_devicePreventCold.beColdMax = p3[1] / 2;
			}
		}

		//制热踢被子后温度上下限
		if((p1[1] == 0x04) && (p1[0] == 0x1c)) {
			if(p3[0] > 60) {
				_devicePreventCold.beHeatMin = 17;
			} else {
				_devicePreventCold.beHeatMin = p3[0] / 2;
			}

			if(p3[1] > 60) {
				_devicePreventCold.beHeatMax = 30;
			} else {
				_devicePreventCold.beHeatMax = p3[1] / 2;
			}
		}

		//ECO运行时间
		if((p1[1] == 0x00) && (p1[0] == 0x1E)) {
			var ecoTime;
			if(undefined != p3) {
				if(p3[0] == 0) {
					ecoTime = p3[3] + '小时' + p3[2] + '分钟' + p3[1] + '秒';
					_deviceElectricQuantity.ecoRunningStatus.EcoTime = ecoTime;
				} else {
					ecoTime = p3[3] + '小时' + p3[2] + '分钟' + p3[1] + '秒';
					_deviceElectricQuantity.ecoRunningStatus.EcoTime = ecoTime;
				}
			}
		}

		//ECO运行耗电量
		if((p1[1] == 0x00) && (p1[0] == 0x1F)) {
			var ecoEng;
			if(undefined != p3) {
				var integerNum = parseInt(p3[0]) * 100 + parseInt(p3[1]) * 10 + parseInt(p3[2]);
				ecoEng = integerNum.toString() + '.' + p3[3].toString() + '度';
				_deviceElectricQuantity.ecoRunningStatus.EcoElecQty = ecoEng;
			}
		}

		//查询室内湿度
		if((p1[1] == 0x00) && (p1[0] == 0x15)) {
			if(p3[0] > 0 && p3[0] < 100) {
				_deviceStatus.humidityValue = p3[0];
			}
		}

		//安防功能
		if((p1[1] == 0x00) && (p1[0] == 0x29)) {
			if(p3[0] == 3) {
				_deviceStatus.securityStatus = true;
			} else if(p3[0] == 0) {
				_deviceStatus.angleEyeStatus = false;
				_deviceStatus.securityStatus = false;
			} else {
				_deviceStatus.securityStatus = false;
			}
		}
		//入侵功能
		if((p1[1] == 0x00) && (p1[0] == 0x2c)) {
			if(p3[0] == 1) {
				_deviceStatus.intrusionStatus = true;
			} else {
				_deviceStatus.intrusionStatus = false;
			}
		}
		//入侵录像功能
		if((p1[1] == 0x00) && (p1[0] == 0x2d)) {
			if(p3[0] == 1) {
				_deviceStatus.intrusionVideoStatus = true;
			} else {
				_deviceStatus.intrusionVideoStatus = false;
			}
		}
		//人脸识别功能
		if((p1[1] == 0x00) && (p1[0] == 0x2e)) {
			if(p3[0] == 1) {
				_deviceStatus.faceRecognitionStatus = true;
			} else {
				_deviceStatus.faceRecognitionStatus = false;
			}
		}
		//红外补光功能
		if((p1[1] == 0x00) && (p1[0] == 0x2f)) {
			if(p3[0] == 1) {
				_deviceStatus.infraredLightStatus = true;
			} else {
				_deviceStatus.infraredLightStatus = false;
			}
		}
		//智能控制功能
		if((p1[1] == 0x00) && (p1[0] == 0x31)) {
			if(p3[0] == 1) {
				_deviceStatus.intelligentControlStatus = true;
				_deviceStatus.upDownProduceWindStatus = false;
				_deviceStatus.leftRighProducetWindStatus = false;
				_deviceStatus.natureWindStatus = false;
			} else {
				_deviceStatus.intelligentControlStatus = false;
			}
		}
		//防冷风
		if((p1[1] == 0x00) && (p1[0] == 0x3a)) {
			if(p3[0] == 1) {
				//防冷风状态 
				_deviceColdWindStatus.coldWind = true;
			} else {
				//防冷风状态 
				_deviceColdWindStatus.coldWind = false;
			}
		}
		//天气播报
		if((p1[1] == 0x00) && (p1[0] == 0x3b)) {
			if(p3[0] == 1) {
				//天气播报状态 
				_deviceWeatherReportStatus.weatherReport = true;
			} else {
				//天气播报状态 
				_deviceWeatherReportStatus.weatherReport = false;
			}
		}
		//无人节能功能
		if((p1[1] == 0x00) && (p1[0] == 0x30)) {
			if(p3[0] == 1) {
				_deviceStatus.energySavingStatus = true;
			} else {
				_deviceStatus.energySavingStatus = false;
			}
		}
		//风向控制功能
		if((p1[1] == 0x00) && (p1[0] == 0x32)) {
			_deviceStatus.windDirectionStatus = p3[0];
			if(p3[0] == 1) {
				_deviceStatus.isWindBlow = true;
				_deviceStatus.isWindClose = false;
				_deviceStatus.natureWindStatus = false;
				_deviceStatus.windSpeedStatus = false;
				_deviceStatus.preventCool = false;
				_deviceStatus.keepWarmStatus = false;
				_deviceStatus.upSwipeWindStatus = true;
				_deviceStatus.downSwipeWindStatus = true;
				_deviceStatus.upDownProduceWindStatus = true;
				_deviceStatus.noWindFeel =
					_deviceStatus.upNoWindFeel =
					_deviceStatus.downNoWindFeel = false;
			} else if(p3[0] == 2) {
				_deviceStatus.isWindClose = true;
				_deviceStatus.isWindBlow = false;
				_deviceStatus.natureWindStatus = false;
				_deviceStatus.windSpeedStatus = false;
				_deviceStatus.upSwipeWindStatus = false;
				_deviceStatus.downSwipeWindStatus = false;
				_deviceStatus.upDownProduceWindStatus = false;
				_deviceStatus.noWindFeel =
					_deviceStatus.upNoWindFeel =
					_deviceStatus.downNoWindFeel = false;
			} else {
				_deviceStatus.isWindBlow = false;
				_deviceStatus.isWindClose = false;
			}
		}

		//专属功能
		if((p1[1] == 0x00) && (p1[0] == 0x45)) {
			if(p3[0] == 1) {
				_deviceStatus.exclusiveOnOffStatus = true;
			} else {
				_deviceStatus.exclusiveOnOffStatus = false;
			}
		}
		//家人个数
		if((p1[1] == 0x00) && (p1[0] == 0x44)) {
			_deviceStatus.familyNumber = p3[0];
		}
		//PM2.5
		if((p1[1] == 0x02) && (p1[0] == 0x0B)) {
			_deviceStatus.PMNumber = (p3[2]) << 8 | p3[1];
//          _deviceStatus.PMNumber = p3[1];
		}
		//手势识别功能
		if((p1[1] == 0x00) && (p1[0] == 0x34)) {
			if(p3[0] == 1) {
				_deviceStatus.gestureRecognitionOnOffStatus = true;
			} else {
				_deviceStatus.gestureRecognitionOnOffStatus = false;
			}
			if(p3[1] == 1) {
				_deviceStatus.gestureRecognitionDirectionStatus = true;
			} else {
				_deviceStatus.gestureRecognitionDirectionStatus = false;
			}
		}
		//远程视频功能
		if((p1[1] == 0x00) && (p1[0] == 0x35)) {
			if(p3[0] == 1) {
				_deviceStatus.remoteVideoStatus = true;
			} else {
				_deviceStatus.remoteVideoStatus = false;
			}
		}
		//语音功能
		if((p1[1] == 0x00) && (p1[0] == 0x20)) {

			_deviceVoiceStatus.voiceBroadcastStatus = p3[0];
			_deviceVoiceStatus.awakenStatus = p3[1];
			if(p3[2] <= 1) {
				_deviceVoiceStatus.toneStatus = 1;
			} else {
				_deviceVoiceStatus.toneStatus = 2;
			}

			_deviceVoiceStatus.voiceTimeLength = p3[3];

			if(p3[4] == 1) {
				_deviceVoiceStatus.initialPowerBroadcastSwitch = true;
			} else {
				_deviceVoiceStatus.initialPowerBroadcastSwitch = false;
			}
			if(p3[5] == 1) {
				_deviceVoiceStatus.friendshipBroadcastSwitch = true;
			} else {
				_deviceVoiceStatus.friendshipBroadcastSwitch = false;
			}
			if(p3[6] == 1) {
				_deviceVoiceStatus.safetyBroadcastSwitch = true;
			} else {
				_deviceVoiceStatus.safetyBroadcastSwitch = false;
			}
			if(p3[7] == 1) {
				_deviceVoiceStatus.weatherBroadcastSwitch = true;
			} else {
				_deviceVoiceStatus.weatherBroadcastSwitch = false;
			}
			if(p3[8] == 1) {
				_deviceVoiceStatus.informationBroadcast = true;
			} else {
				_deviceVoiceStatus.informationBroadcast = false;
			}
		}
		//音量功能
		if((p1[1] == 0x00) && (p1[0] == 0x24)) {

			_deviceVolumeStatus.volumeControlType = p3[0];
			_deviceVolumeStatus.manualAdjustment = parseInt(p3[1] / 20);
			_deviceVolumeStatus.minVolume = p3[2];
			_deviceVolumeStatus.maximumVolume = p3[3];
		}

		//冷热感功能
		if((p1[1] == 0x00) && (p1[0] == 0x21)) {
			if(p3[0] == 1) {
				_deviceColdHotStatus.coldHotSwitch = true;
				_deviceStatus.coldHotSwitch = true;
				_deviceStatus.preventCool = false;
				_deviceSelfCleaningStatus.selfCleaning = false;
				_deviceStatus.selfCleaningStatus = false;
				resolveNewProtocolConflict4NoWindFeel();
				if(_deviceInfo.hasChangesTemperature) {
					_deviceStatus.ECOStatus = false;
					_deviceStatus.keepWarmStatus = false;
				}
			} else {
				_deviceColdHotStatus.coldHotSwitch = false;
				_deviceStatus.coldHotSwitch = false;
			}
			_deviceColdHotStatus.coldHotStall = p3[1];
			_deviceColdHotStatus.coldHotNumber = p3[2];
			_deviceColdHotStatus.PeopleClothes = p3[3];
			_deviceColdHotStatus.SeasonalState = p3[4];
			_deviceColdHotStatus.WeatherCondition = p3[5];
			_deviceColdHotStatus.NightTimeHour = p3[6];
			_deviceColdHotStatus.NightTimeMinute = p3[7];
		}
		//过滤网脏堵
		if((p1[1] == 0x04) && (p1[0] == 0x09)) {
			_deviceFilterDirtyPluggingStatus.testStatus = p3[0] & 0x40;
			_deviceFilterDirtyPluggingStatus.meshFailure1 = p3[0] & 0x02;
			_deviceFilterDirtyPluggingStatus.meshFailure2 = p3[0] & 0x04;
			_deviceFilterDirtyPluggingStatus.currenLevel = p3[1];
			_deviceFilterDirtyPluggingStatus.ADvalueLow = p3[2];
			_deviceFilterDirtyPluggingStatus.ADvalueHigh = p3[3];
			_deviceFilterDirtyPluggingStatus.controlADrangeLow = p3[4];
			_deviceFilterDirtyPluggingStatus.controlADrangeHigh = p3[5];
			_deviceFilterDirtyPluggingStatus.thresholdValue = p3[6];
			_deviceFilterDirtyPluggingStatus.dutyRatio = p3[7];
			_deviceFilterDirtyPluggingStatus.environmentValueLow = p3[8];
			_deviceFilterDirtyPluggingStatus.environmentValueHigh = p3[9];
			_deviceFilterDirtyPluggingStatus.percentageReadings = p3[10];
			_deviceFilterDirtyPluggingStatus.fanRunTimeLow = p3[11];
			_deviceFilterDirtyPluggingStatus.fanRunTimeHigh = p3[12];
		}

		//过滤网校准
		if((p1[1] == 0x04) && (p1[0] == 0x0A)) {
			_deviceScreenCalibration.screenCalibrationStatus = p3[0];
		}

		//回家自动开机功能
		if((p1[1] == 0x05) && (p1[0] == 0x07)) {
			if(p3[0] == 1) {
				_deviceStatus.autoOnStatus = true;
			} else {
				_deviceStatus.autoOnStatus = false;
			}
		}
		//离家自动关机功能
		if((p1[1] == 0x05) && (p1[0] == 0x08)) {
			if(p3[0] == 1) {
				_deviceStatus.autoOffStatus = true;
			} else {
				_deviceStatus.autoOffStatus = false;
			}
		}
		//蓝牙版本信息
		if((p1[1] == 0x05) && (p1[0] == 0x04)) {
			for(var i = 0; i < p2; i++) {
				_deviceBluetoothStatus.currentBluetoothSoftVersion[i] = p3[i];
			}
		}
		//蓝牙MAC信息
		if((p1[1] == 0x05) && (p1[0] == 0x14)) {
			var bluetoothMac = "";
			for(var j = p3.length - 1; j > 1; j--) {
				bluetoothMac += (toHex(p3[j]) + ":");
			}
			bluetoothMac += toHex(p3[1]);
			_deviceBluetoothStatus.bluetoothMac = bluetoothMac;
		}
		//蓝牙MAC信息
		if((p1[1] == 0x05) && (p1[0] == 0x03)) {
			_deviceBluetoothStatus.currentBluetoothMode = p3[0];
		}
	}

	/**
	 * 停止基准校准，改变本地状态
	 */
	this.stopCalibration = function() {
		_deviceCalibrationStatus.P_rate = '2';
		_deviceCalibrationStatus.P_real = '2';
		_deviceCalibrationStatus.maxThreshold = '2';
		_deviceCalibrationStatus.finishFlag = 0;
		_deviceCalibrationStatus.level = 0;
		_deviceCalibrationStatus.queryState = 0;
	}

	/**
	 * 停止强力防霉，改变本地状态
	 */
	this.stopStrongPrevent = function() {
		_deviceStrongPreventStatus.P_rate = '2';
		_deviceStrongPreventStatus.P_real = '2';
		_deviceStrongPreventStatus.maxThreshold = '2';
		_deviceStrongPreventStatus.finishFlag = 0;
		_deviceStrongPreventStatus.level = 0;
		_deviceStrongPreventStatus.queryState = 0;
	}

	/**
	 * 基准校准新协议数据处理
	 */
	this.newProtocolCalibrationDataProcess = function(p1) {
		if((p1[10] == 0xB1) || (p1[10] == 0xB0)) {
			var si = 0;
			var sj = 0;
			var sk = p1[11];

			var tmpCmdType = [];
			var tmpCmdResult = 1;
			var tmpCmdValue = [];

			var shift = 0;
			for(si = 0; si < sk; si++) {
				tmpCmdResult = p1[14 + si * 5 + shift];
				tmpCmdType[0] = p1[12 + si * 5 + shift];
				tmpCmdType[1] = p1[13 + si * 5 + shift];
				var tmpCmdValueLength = p1[15 + si * 5 + shift];
				for(sj = 0; sj < tmpCmdValueLength; sj++) {
					tmpCmdValue[sj] = p1[16 + si * 5 + sj + shift];
				}
				if(tmpCmdValueLength > 1) {
					shift = shift + (tmpCmdValueLength - 1);
				}
				newProtocolFunctionCalibrationParse(tmpCmdType, tmpCmdValueLength, tmpCmdValue);
			}

			explainCalibrationResult();
		}
	}

	//解析基准校准的结果
	function explainCalibrationResult() {
		if(_deviceCalibrationStatus.P_rate == 0 || _deviceCalibrationStatus.P_real == 0 || _deviceCalibrationStatus.maxThreshold == 0) {

		} else if(_deviceCalibrationStatus.P_rate == '-1' || _deviceCalibrationStatus.P_real == '-1' || _deviceCalibrationStatus.maxThreshold == '-1') {

		} else {
			_deviceCalibrationStatus.remainingTime = "20分钟";
			_deviceCalibrationStatus.animateTime = 1200000;
			_deviceCalibrationStatus.queryInterval = 15000;
			_deviceCalibrationStatus.queryState = 0;
			if(_deviceCalibrationStatus.finishFlag == 2) {
				computeCalibrationResult();
			} else {

			}
		}
	}

	function computeCalibrationResult() {
		var rate = _deviceCalibrationStatus.P_rate;
		var real = _deviceCalibrationStatus.P_real;
		var threshold = _deviceCalibrationStatus.maxThreshold;
		var present = 0;
		if(real <= rate * (1 - 0.01 * threshold)) {
			present = 100;
		} else if(real > rate * (1 - 0.01 * threshold) && real < rate) {
			present = parseInt((rate - real) * 100 / (rate - parseInt(rate * (100 - threshold) * 0.01)));
		} else if(real >= rate) {
			present = 0;
		}

		if(present < 30) {
			_deviceCalibrationStatus.level = 1;
		} else if(present >= 30 && present < 70) {
			_deviceCalibrationStatus.level = 2;
		} else {
			_deviceCalibrationStatus.level = 3;
		}
	}

	//2015-04-10  解释基准校准新协议
	function newProtocolFunctionCalibrationParse(p1, p2, p3) {
		//基准功率 FFFF 正在检测   FFFC 检测失败    
		if((p1[1] == 0x04) && (p1[0] == 0x02)) {
			if(p3[0] == 0xFA && p3[1] == 0xFF) {
				_deviceCalibrationStatus.P_rate = 0;
			} else if(p3[0] == 0xFC && p3[1] == 0xFF) {
				_deviceCalibrationStatus.P_rate = '-1';
			} else {
				_deviceCalibrationStatus.P_rate = parseInt(p3[1] * 256) + parseInt(p3[0]);
			}
		}
		//实际功率
		if((p1[1] == 0x04) && (p1[0] == 0x03)) {
			if(p3[0] == 0xFA && p3[1] == 0xFF) {
				_deviceCalibrationStatus.P_real = 0;
			} else if(p3[0] == 0xFC && p3[1] == 0xFF) {
				_deviceCalibrationStatus.P_real = '-1';
			} else {
				_deviceCalibrationStatus.P_real = parseInt(p3[1] * 256) + parseInt(p3[0]);
			}
		}
		//脏堵最大阈值
		if((p1[1] == 0x04) && (p1[0] == 0x04)) {
			_deviceCalibrationStatus.maxThreshold = p3[0];
		}
		//强力防霉完成标志
		if((p1[1] == 0x04) && (p1[0] == 0x05)) {
			_deviceCalibrationStatus.finishFlag = p3[0];
		}
		//强力防霉剩余时间
		if((p1[1] == 0x04) && (p1[0] == 0x07)) {
			_deviceCalibrationStatus.animateTime = p3[1] * 60000 + p3[0] * 1000;
			if(p3[1] > 0) {
				if(p3[0] < 60 && p3[0] > 0) {
					_deviceCalibrationStatus.remainingTime = p3[1] + "分钟" + p3[0] + "秒";
				} else if(p3[0] == 0) {
					_deviceCalibrationStatus.remainingTime = p3[1] + "分钟";
				} else {
					_deviceCalibrationStatus.remainingTime = p3[1] + "分钟59秒";
				}
			} else if(p3[1] == 0) {
				if(p3[0] < 60 && p3[0] > 0) {
					_deviceCalibrationStatus.remainingTime = p3[0] + "秒";
				} else {
					_deviceCalibrationStatus.remainingTime = "59秒";
				}
			} else {
				_deviceCalibrationStatus.remainingTime = "20分钟";
			}
			if(p3[1] == 0 && p3[0] < 15) {
				_deviceCalibrationStatus.queryInterval = parseInt(p3[1] + 1) * 1000;
			}
		}

		//强力防霉完成标志
		if((p1[1] == 0x04) && (p1[0] == 0x08)) {
			_deviceCalibrationStatus.P_rate = 0;
			_deviceCalibrationStatus.P_real = 0;
			_deviceCalibrationStatus.maxThreshold = 0;
			_deviceCalibrationStatus.finishFlag = 0;
			_deviceCalibrationStatus.queryState = 1;
			var timer1 = parseInt(p3[0]);
			var timer2 = parseInt(p3[1]);
			var timer3 = parseInt(p3[2]);
			var minCount = parseInt((timer1 + timer2 + timer3) / 6);
			var secCount = parseInt(timer1 + timer2 + timer3) * 10 % 60;
			if(minCount == 0) {
				_deviceCalibrationStatus.remainingTime = secCount + "秒";
			} else {
				if(secCount == 0) {
					_deviceCalibrationStatus.remainingTime = minCount + "分钟";
				} else {
					_deviceCalibrationStatus.remainingTime = minCount + "分钟" + secCount + "秒";
				}
			}
			_deviceCalibrationStatus.animateTime = minCount * 60000 + secCount * 1000;
		}
	}

	/**
	 * 强力防霉新协议数据处理
	 */
	this.newProtocolStrongPreventDataProcess = function(p1) {
		if((p1[10] == 0xB1) || (p1[10] == 0xB0)) {
			var si = 0;
			var sj = 0;
			var sk = p1[11];

			var tmpCmdType = [];
			var tmpCmdResult = 1;
			var tmpCmdValue = [];

			var shift = 0;
			for(si = 0; si < sk; si++) {
				tmpCmdResult = p1[14 + si * 5 + shift];
				tmpCmdType[0] = p1[12 + si * 5 + shift];
				tmpCmdType[1] = p1[13 + si * 5 + shift];
				var tmpCmdValueLength = p1[15 + si * 5 + shift];
				for(sj = 0; sj < tmpCmdValueLength; sj++) {
					tmpCmdValue[sj] = p1[16 + si * 5 + sj + shift];
				}
				if(tmpCmdValueLength > 1) {
					shift = shift + (tmpCmdValueLength - 1);
				}
				newProtocolFunctionStrongPreventParse(tmpCmdType, tmpCmdValueLength, tmpCmdValue);
			}

			explainFilterResult();
		}
	}

	//解析强力防霉的结果
	function explainFilterResult() {
		if(_deviceStrongPreventStatus.P_rate == 0 || _deviceStrongPreventStatus.P_real == 0 || _deviceStrongPreventStatus.maxThreshold == 0) {

		} else if(_deviceStrongPreventStatus.P_rate == '-1' || _deviceStrongPreventStatus.P_real == '-1' || _deviceStrongPreventStatus.maxThreshold == '-1') {

		} else {
			_deviceStrongPreventStatus.remainingTime = "20分钟";
			_deviceStrongPreventStatus.animateTime = 1200000;
			_deviceStrongPreventStatus.queryInterval = 15000;
			_deviceStrongPreventStatus.queryState = 0;
			if(_deviceStrongPreventStatus.finishFlag == 1) {
				computeFilterResult();
			} else {

			}
		}
	}

	function computeFilterResult() {
		var rate = _deviceStrongPreventStatus.P_rate;
		var real = _deviceStrongPreventStatus.P_real;
		var threshold = _deviceStrongPreventStatus.maxThreshold;
		var present = 0;
		if(real <= rate * (1 - 0.01 * threshold)) {
			present = 100;
		} else if(real > rate * (1 - 0.01 * threshold) && real < rate) {
			present = parseInt((rate - real) * 100 / (rate - parseInt(rate * (100 - threshold) * 0.01)));
		} else if(real >= rate) {
			present = 0;
		}

		if(present < 30) {
			_deviceStrongPreventStatus.level = 1;
		} else if(present >= 30 && present < 70) {
			_deviceStrongPreventStatus.level = 2;
		} else {
			_deviceStrongPreventStatus.level = 3;
		}
	}

	//2015-04-10  解释新协议
	function newProtocolFunctionStrongPreventParse(p1, p2, p3) {
		//基准功率 FFFF 正在检测   FFFC 检测失败    
		if((p1[1] == 0x04) && (p1[0] == 0x02)) {
			if(p3[0] == 0xFF && p3[1] == 0xFF) {
				_deviceStrongPreventStatus.P_rate = 0;
			} else if(p3[0] == 0xFC && p3[1] == 0xFF) {
				_deviceStrongPreventStatus.P_rate = '-1';
			} else {
				_deviceStrongPreventStatus.P_rate = parseInt(p3[1] * 256) + parseInt(p3[0]);
			}
		}
		//实际功率
		if((p1[1] == 0x04) && (p1[0] == 0x03)) {
			if(p3[0] == 0xFF && p3[1] == 0xFF) {
				_deviceStrongPreventStatus.P_real = 0;
			} else if(p3[0] == 0xFC && p3[1] == 0xFF) {
				_deviceStrongPreventStatus.P_real = '-1';
			} else {
				_deviceStrongPreventStatus.P_real = parseInt(p3[1] * 256) + parseInt(p3[0]);
			}
		}
		//脏堵最大阈值
		if((p1[1] == 0x04) && (p1[0] == 0x04)) {
			_deviceStrongPreventStatus.maxThreshold = p3[0];
		}
		//强力防霉完成标志
		if((p1[1] == 0x04) && (p1[0] == 0x05)) {
			_deviceStrongPreventStatus.finishFlag = p3[0];
		}
		//强力防霉剩余时间
		if((p1[1] == 0x04) && (p1[0] == 0x07)) {
			_deviceStrongPreventStatus.animateTime = p3[1] * 60000 + p3[0] * 1000;
			if(p3[1] > 0) {
				if(p3[0] < 60 && p3[0] > 0) {
					_deviceStrongPreventStatus.remainingTime = p3[1] + "分钟" + p3[0] + "秒";
				} else if(p3[0] == 0) {
					_deviceStrongPreventStatus.remainingTime = p3[1] + "分钟";
				} else {
					_deviceStrongPreventStatus.remainingTime = p3[1] + "分钟59秒";
				}
			} else if(p3[1] == 0) {
				if(p3[0] < 60 && p3[0] > 0) {
					_deviceStrongPreventStatus.remainingTime = p3[0] + "秒";
				} else {
					_deviceStrongPreventStatus.remainingTime = "59秒";
				}
			} else {
				_deviceStrongPreventStatus.remainingTime = "20分钟";
			}
			if(p3[1] == 0 && p3[0] < 15) {
				_deviceStrongPreventStatus.queryInterval = parseInt(p3[1] + 1) * 1000;
			}
		}

		//强力防霉完成标志
		if((p1[1] == 0x04) && (p1[0] == 0x08)) {
			_deviceStrongPreventStatus.P_rate = 0;
			_deviceStrongPreventStatus.P_real = 0;
			_deviceStrongPreventStatus.maxThreshold = 0;
			_deviceStrongPreventStatus.finishFlag = 0;
			_deviceStrongPreventStatus.queryState = 1;
			var timer1 = parseInt(p3[0]);
			var timer2 = parseInt(p3[1]);
			var timer3 = parseInt(p3[2]);
			var minCount = parseInt((timer1 + timer2 + timer3) / 6);
			var secCount = parseInt(timer1 + timer2 + timer3) * 10 % 60;
			if(minCount == 0) {
				_deviceStrongPreventStatus.remainingTime = secCount + "秒";
			} else {
				if(secCount == 0) {
					_deviceStrongPreventStatus.remainingTime = minCount + "分钟";
				} else {
					_deviceStrongPreventStatus.remainingTime = minCount + "分钟" + secCount + "秒";
				}
			}
			_deviceStrongPreventStatus.animateTime = minCount * 60000 + secCount * 1000;
		}
	}

	function resolveNewProtocolConflict4NoWindFeel() {
		if(!_deviceInfo.hasUpDownNoWindFeel) {
			_dataStorage.setComfortWind0x3LV(0x00);
			_dataStorage.setComfortWind0x3RV(0x00);
		}
		//关闭旧协议防直吹
		//	_dataStorage.setWindBlowingSwitch(0x00);
		//关闭左右风
		_dataStorage.setComfortWind0x3LH(0x00);
		_dataStorage.setComfortWind0x3RH(0x00);
		//关闭强劲
		_dataStorage.setStrongSwitch(0x00);
		//关闭自然风
		_dataStorage.setNaturalWindFunctionSwitch(0x00);
		//关闭睿风
		_dataStorage.setRuiFengSwitch(0x00);
		//关闭儿童睡眠
		_dataStorage.setChildrenSleepMode(0x00);
		//关闭舒睡
		_dataStorage.setSleepModeSwitch(0x00);
		//关闭PMV		
		_dataStorage.setPMVFunction(0);
		//风速默认为自动风
		_dataStorage.setNoPolarWindSpeedValue(102);
		//同步状态
		syncStatusByNewProtocol4NoWindFeel();
	}

	/**
	 * 无风感，新协议控制时设备状态信息同步
	 */

	function syncStatusByNewProtocol4NoWindFeel() {
		_deviceStatus.windBlowingStatus = false;
		_deviceStatus.windSpeedValue = 102;
		_deviceStatus.PMVMode = mdSmart.ACDataManager.ACPMVMode.PMVModeClose;
		_deviceStatus.sleepStatus = false;
		_deviceStatus.natureWindStatus = false;
		_deviceStatus.tubroStatus = false;
		if(!_deviceInfo.hasUpDownNoWindFeel) {
			_deviceStatus.upDownProduceWindStatus = false;
		}

		//		_deviceStatus.leftRighProducetWindStatus = false;
		//YB301 无风感与左右风逻辑处理 2017-05-08 wjl
		if(_deviceInfo.hasUpDownNoWindFeel && !(_deviceStatus.leftRighProducetWindStatus)) {
			//YB301特殊处理，无论左左右还是右左右开启都算开启
			_deviceStatus.leftRighProducetWindStatus = (status.downWindControl == 0x00) & (status.downWindControlLR == 0x01);
		}
		if(_deviceInfo.hasUpDownNoWindFeel) {
			_deviceStatus.upSwipeWindStatus = false;
			_deviceStatus.downSwipeWindStatus = false;
			_deviceStatus.noWindFeel = false;
		}
	}

	/**
	 * 获得检测过程中的状态信息
	 * @return {DeviceCheckProgressStatus} _deviceCheckProgressStatus:{name:"滤网清洗",progress:65}
	 */
	this.getDeviceCheckProgressStatus = function() {
		return _deviceCheckProgressStatus;
	}

	/**
	 * 设置检测过程中的状态信息
	 * @param {DeviceCheckProgressStatus} status ：{name:"滤网清洗",progress:65}
	 */
	this.setDeviceCheckProgressStatus = function(status) {
		_deviceCheckProgressStatus.name = status.name;
		_deviceCheckProgressStatus.progress = status.progress;
	}

	/**
	 * 获得设备检测结果信息
	 * @return {DeviceCheckFinishStatus}
	 */
	this.getDeviceCheckFinishStatus = function() {
		return _deviceCheckFinishStatus;
	}
	//获取小米手环状态
	this.getWristbandStatus = function() {
		return _wristbandStatus;
	}

	/**
	 * 设置设备检测的结果{
		score:"",
		strainer:"",//滤网状态信息
		electricalMachine:{
			faultNum:0,
			faultDetail:[]
		},//电机故障
		coolants:"",//冷媒状态信息
		compressor:{
			faultNum:0,
			faultDetail:[]
		}//压缩机故障	
	}
	 */
	this.setDeviceCheckFinishStatus = function(status) {
		_deviceCheckProgressStatus.score = status.score;
		_deviceCheckProgressStatus.strainer = status.strainer;
		_deviceCheckProgressStatus.electricalMachine.faultNum = status.electricalMachine.faultNum;
		_deviceCheckProgressStatus.electricalMachine.faultDetail = status.electricalMachine.faultDetail;
		_deviceCheckProgressStatus.coolants = status.coolants;
		_deviceCheckProgressStatus.compressor.faultNum = status.compressor.faultNum;
		_deviceCheckProgressStatus.compressor.faultDetail = status.compressor.faultNum;
	}

	/**
	 * 获取睡眠曲线的状态对象
	 */
	this.getSleepMode = function() {
		return _sleepModeStatus;
	}

	/**
	 *更新睡眠状态
	 * @param {number} sleepType:0 代表推荐曲线 ，1 代表自定义曲线,其他值暂无效
	 * @param {Array} sleepArr:0~9各个时间的睡眠曲线值：例如：sleepArr[0] = 28，sleepArr[1] = 27~sleepArr[9] = 18
	 * @param {Boolean} isSelected表示当前曲线是否被选择
	 * */
	this.updateSleepMode = function(sleepType, sleepObj, isSelected) {
		if(0 == sleepType) {
			_sleepModeStatus.sleepCurveRecommend.firstHour = sleepObj.value0;
			_sleepModeStatus.sleepCurveRecommend.secondHour = sleepObj.value1;
			_sleepModeStatus.sleepCurveRecommend.thirdHour = sleepObj.value2;
			_sleepModeStatus.sleepCurveRecommend.forthHour = sleepObj.value3;
			_sleepModeStatus.sleepCurveRecommend.fifthHour = sleepObj.value4;
			_sleepModeStatus.sleepCurveRecommend.sixthtHour = sleepObj.value5;
			_sleepModeStatus.sleepCurveRecommend.seventhHour = sleepObj.value6;
			_sleepModeStatus.sleepCurveRecommend.eighthHour = sleepObj.value7;
			_sleepModeStatus.sleepCurveRecommend.ninthHour = sleepObj.value8;
			_sleepModeStatus.sleepCurveRecommend.tenthHour = sleepObj.value9;
			if(isSelected) {
				_sleepModeStatus.selectSleepType = 0;
			}
		} else if(1 == sleepType) {
			_sleepModeStatus.sleepCurveCustom.firstHour = sleepObj.value0;
			_sleepModeStatus.sleepCurveCustom.secondHour = sleepObj.value1;
			_sleepModeStatus.sleepCurveCustom.thirdHour = sleepObj.value2;
			_sleepModeStatus.sleepCurveCustom.forthHour = sleepObj.value3;
			_sleepModeStatus.sleepCurveCustom.fifthHour = sleepObj.value4;
			_sleepModeStatus.sleepCurveCustom.sixthtHour = sleepObj.value5;
			_sleepModeStatus.sleepCurveCustom.seventhHour = sleepObj.value6;
			_sleepModeStatus.sleepCurveCustom.eighthHour = sleepObj.value7;
			_sleepModeStatus.sleepCurveCustom.ninthHour = sleepObj.value8;
			_sleepModeStatus.sleepCurveCustom.tenthHour = sleepObj.value9;
			if(isSelected) {
				_sleepModeStatus.selectSleepType = 1;
			}
		} else if(2 == sleepType) {
			_sleepModeStatus.sleepCurveInteligent.firstHour = sleepObj.value0;
			_sleepModeStatus.sleepCurveInteligent.secondHour = sleepObj.value1;
			_sleepModeStatus.sleepCurveInteligent.thirdHour = sleepObj.value2;
			_sleepModeStatus.sleepCurveInteligent.forthHour = sleepObj.value3;
			_sleepModeStatus.sleepCurveInteligent.fifthHour = sleepObj.value4;
			_sleepModeStatus.sleepCurveInteligent.sixthtHour = sleepObj.value5;
			_sleepModeStatus.sleepCurveInteligent.seventhHour = sleepObj.value6;
			_sleepModeStatus.sleepCurveInteligent.eighthHour = sleepObj.value7;
			_sleepModeStatus.sleepCurveInteligent.ninthHour = sleepObj.value8;
			_sleepModeStatus.sleepCurveInteligent.tenthHour = sleepObj.value9;
			if(isSelected) {
				_sleepModeStatus.selectSleepType = 2;
			}
		}
	}

	this.selectRecommendCurve = function() {
		_sleepModeStatus.selectSleepType = 0;
	}

	this.selectCustomCurve = function() {
		_sleepModeStatus.selectSleepType = 1;
	}

	this.selectInteligentCurve = function() {
		_sleepModeStatus.selectSleepType = 2;
	}
	/**
	 *设置睡眠曲线
	 * @param {Array} curveVal 0~9 ，自定义曲线的值
	 */
	this.selectCustomCurveValue = function(curveVal) {
		//		_sleepModeStatus.selectSleepType = 1;
		var curveData = [];
		for(var i = 1; i < 9; i++) {
			if(curveVal[i] < 17) {
				curveData[i - 1] = 17;
			} else if(curveVal[i] > 30) {
				curveData[i - 1] = 30;
			} else {
				curveData[i - 1] = curveVal[i];
			}
		}

		_sleepModeStatus.sleepCurveCustom.firstHour = curveData[0];
		_sleepModeStatus.sleepCurveCustom.secondHour = curveData[1];
		_sleepModeStatus.sleepCurveCustom.thirdHour = curveData[2];
		_sleepModeStatus.sleepCurveCustom.forthHour = curveData[3];
		_sleepModeStatus.sleepCurveCustom.fifthHour = curveData[4];
		_sleepModeStatus.sleepCurveCustom.sixthtHour = curveData[5];
		_sleepModeStatus.sleepCurveCustom.seventhHour = curveData[6];
		_sleepModeStatus.sleepCurveCustom.eighthHour = curveData[7];
		_sleepModeStatus.sleepCurveCustom.ninthHour = curveData[7];
		_sleepModeStatus.sleepCurveCustom.tenthHour = curveData[7];
	}

	/**
	 * 获得电量对象，包含电量相关所有数据结构
	 */
	this.getElectricQuantity = function() {
		return _deviceElectricQuantity;
	}

	/**
	 * 获得自学习相关所有数据结构
	 */
	this.getSelfLearning = function() {
		return _deviceSelfLearningStatus;
	}

	/*
	 yuyin版本说明
	 */
	this.deviceYuyinVersionContent = function(p1) {
		//		alert("deviceYuyinVersionContent"+p1);
		_yuyinVersionContent.yuyinsmContent = p1;
	}
	this.getYuyinVersionContent = function() {
		return _yuyinVersionContent;
	}
	/*
	 yuyin版本
	 */
	this.getYuyinVersion = function() {
		return _yuyinVersion;
	}

	this.deviceYuyinStatus = function(p1) {
		_yuyinVersion.yuyinDeviceStatus = p1;
	}

	this.deviceYuyinCompany = function(p1) {
		_yuyinVersion.yuyinDeviceCompany = p1;
	}

	this.updateYuyinVersionCurrentVersion = function(p1) {
		_yuyinVersion.yuyinVersionCurrentVersion = p1;
	}

	this.updateYuyinVersion = function(p1) {
		_yuyinVersion.yuyinUpdateVersion = p1;
	}
	this.downloadRateYuyinVersionProgress = function(p1) {
		_yuyinVersion.YuyinDownloadRateVersionProgress = p1;
	}

	this.updateRateYuyinVersionProgress = function(p1) {
		_yuyinVersion.yuyinUpdateRateVersionProgress = p1;
	}

	/**
	 * 获取强力防霉的状态对象
	 */
	this.getStrongPrevent = function() {
		return _deviceStrongPreventStatus;
	}

	this.updateStrongPreventQueryState = function(p1) {
		_deviceStrongPreventStatus.queryState = p1;
	}

	/**
	 * 获取基准校准的状态对象
	 */
	this.getCalibration = function() {
		return _deviceCalibrationStatus;
	}

	this.updateCalibrationQueryState = function(p1) {
		_deviceCalibrationStatus.queryState = p1;
	}
	/**
	 * 获取语音控制的状态对象
	 */
	this.getVoiceState = function() {
		return _deviceVoiceStatus;
	}
	/**
	 * 获取音量状态对象
	 */
	this.getVolumeState = function() {
		return _deviceVolumeStatus;
	}

	/**
	 * 获取冷热感控制对象
	 */
	this.getColdHotState = function() {
		return _deviceColdHotStatus;
	}
	/**
	 * 获取过滤网脏堵检测传感器
	 */
	this.getFilterDirtyPlugging = function() {
		return _deviceFilterDirtyPluggingStatus;
	}
	/**
	 * 获取过滤网校准
	 */
	this.getScreenCalibration = function() {
		return _deviceScreenCalibration;
	}
	/*
	 * 获取蓝牙对象
	 */
	this.getDeviceBluetoothStatus = function() {
		return _deviceBluetoothStatus;
	}
	//获取自清洁对象
	this.getDeviceCleaningStatus = function() {
		return _deviceSelfCleaningStatus;
	}
	//获取风避人
	this.getDeviceWindAvoidStatus = function() {
		return _deviceWindAvoidStatus;
	}
	//获取新防直吹
	this.getDeviceWindBlowingStatus = function() {
		return _deviceWindBlowingStatus;
	}
	//获取柔风感
	this.getDeviceSoftWindFeelingStatus = function() {
		return _deviceSoftWindFeelingStatus;
	}
	//获取防冷风对象
	this.getDeviceColdWindStatus = function() {
		return _deviceColdWindStatus;
	}
	//获取天气播报对象
	this.getDeviceWeatherReportStatus = function() {
		return _deviceWeatherReportStatus;
	}
	//十进制转十六进制
	function toHex(num) {　　
		var rs = "";　　
		var temp;　　
		while(num / 16 > 0) {　　　　
			temp = num % 16;　　　　
			rs = (temp + "").replace("10", "A").replace("11", "B").replace("12", "C").replace("13", "D").replace("14", "E").replace("15", "F") + rs;　　　　
			num = parseInt(num / 16);　　
		}
		if(rs.length == 1) {
			rs = "0" + rs;
		}　　
		return rs;
	}

}